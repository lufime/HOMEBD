# HOMEBD — Beta 1.0.0.0

## Correção de compilação
- Corrigido o conflito entre a variável local `background` (cor `Int`) e a propriedade `View.background` (`Drawable`) no `MainActivity.kt`.
- Cartões, Spinners e elementos gráficos passam a atribuir corretamente `GradientDrawable` à propriedade da View.
- A área LIVE DATA usa `setBackgroundColor()` para a cor de fundo.
- Mantido o layout vertical com LIVE DATA e DIAGNOSTICS em scroll independente.

# HOMEBD — CHANGELOG

## Beta 1.0.0.0

Initial public beta baseline.

### Application
- HOMEBD universal OBD-II / CAN diagnostics application.
- Portrait dashboard with centered, full-width cards.
- LIVE DATA with its own vertical scroll area.
- DIAGNOSTICS with an independent vertical scroll area.
- Bluetooth OBD-II device selection.
- Automatic vehicle profile.
- OBD-II PID scanning.
- HV / UDS scan area.
- Home Assistant connection and configuration.

### Home Assistant
- Native HOMEBD custom integration.
- WebSocket communication.
- HOMEBD entities use the `sensor.homebd_*` namespace.
- REST transport is not part of the project architecture.

### Safety
- READ-ONLY diagnostic operation.
- No coding, programming, reset or parameter-writing functions.

### Project
- Developer: **lufime**
- Copyright © 2026 lufime.
- Beta version: **1.0.0.0**
