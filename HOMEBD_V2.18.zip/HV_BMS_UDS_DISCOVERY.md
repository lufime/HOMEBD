# HOMEBD — HV/BMS UDS Discovery

Objetivo: descobrir ECUs/DIDs do sistema híbrido do Citroën C5 AIRCROSS Hybrid
sem escrever ou alterar nada no veículo.

## Fluxo
1. Usar as ECUs CAN já descobertas.
2. Enviar apenas pedidos UDS `22 DID` de leitura.
3. Aceitar apenas respostas positivas `62 DID DATA`.
4. Guardar ECU, DID e DATA em hexadecimal.
5. Só depois de confirmar os dados no veículo atribuir significado a SOC,
   tensão, corrente, temperatura ou energia.

## Segurança
READ-ONLY. Não executar coding, adaptation, routine, programação ou reset.

## Importante
O helper está isolado para ser ligado ao transporte CAN/ELM327 existente.
Não assume que um DID específico é SOC ou outro valor HV sem validação.
