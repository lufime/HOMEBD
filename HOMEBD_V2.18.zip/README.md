# HOMEBD

**HOMEBD** é uma aplicação de diagnóstico OBD-II universal para veículos, com
comunicação Bluetooth Classic/SPP através de adaptadores ELM327 compatíveis.

## Estado atual

- OBD-II/CAN em modo **READ-ONLY**.
- LIVE DATA em tempo real.
- Diagnóstico e registo de respostas RAW para análise.
- Comunicação MQTT para integração com Home Assistant.
- Parser e estabilização ELM327/CAN em evolução.
- Descoberta HV/UDS mantida em modo READ-ONLY, sem DIDs proprietários assumidos.
- Interface preparada para utilização horizontal, em full screen e centrada.

## V2.6

- Campo **Password MQTT** com botão de olho.
- O botão permite mostrar ou ocultar a password.
- A alteração não modifica o armazenamento nem o funcionamento da ligação MQTT.
- Todas as alterações do projeto são registadas por versão no CHANGELOG.

## Documentação

Consulte `CHANGELOG.md` para o histórico das alterações e
`DOCUMENTACAO_ALTERACOES.md` para a regra de documentação por versão.

## Licenciamento e terceiros

Consultar os ficheiros de licença/NOTICE existentes no projeto. Não assumir que
a menção a um protocolo, plataforma ou serviço concede direitos sobre marcas,
logótipos ou código de terceiros.

## Desenvolvimento

**Developer: Katios**

## V2.8
A aplicação inclui agora a secção **Sobre / FAQ** diretamente na interface.

## V2.9
Separação documentada entre LIVE DATA OBD-II e descoberta UDS/HV.

## V2.12
- Correção do Live Data: especificação de leitura contínua deve separar corretamente cabeçalhos CAN/ELM327 do payload OBD-II antes da descodificação.
- Não considerar `NO DATA` como valor válido.
- Manter o protocolo detetado ISO 15765-4 CAN 11-bit / 500 kbit/s em READ-ONLY.
- Identificação automática mantém VIN quando disponível.
- HV/UDS continua sem DIDs proprietários e sem comandos de escrita até existir resposta válida.
- Mantida a regra de interface: cards full screen horizontal, centrados e a ocupar toda a largura.

## V2.13
Correções reais no código: leitura Live Data com recuperação da sessão, perfis de fabricantes apresentados individualmente e correção do botão de mostrar/ocultar password MQTT.

## V2.14
- Filtragem de PIDs baseada em respostas OBD-II positivas `41 <PID>`.
- `NO DATA`, `SEM RESPOSTA` e respostas negativas deixam de ser tratados como valores suportados.
- Comunicação mantida em READ-ONLY.

### V2.15 — HV/UDS
Preparada a análise de respostas UDS positivas em modo READ-ONLY. Nenhum DID proprietário ou comando de escrita é assumido.

## V2.16
- Tratamento controlado do encerramento do socket na sessão HV/UDS.
- A sessão HV/UDS passa a ter estado explícito aberto/fechado.
- Um socket fechado não deve ser reutilizado para novas leituras.
- Mantido READ-ONLY, sem DIDs proprietários e sem comandos de escrita.
- O diagnóstico `socket closed` é registado como encerramento de sessão, não como resposta HV válida.

## V2.17
- Consolidado o fluxo de sessão HV/UDS para reutilizar a mesma ligação durante a descoberta.
- `socket closed` não é tratado como resposta UDS.
- Mantido READ-ONLY e sem DIDs proprietários.
