package pt.autohome.c5.obd

/**
 * HOMEBD - UDS HV/BMS discovery, READ-ONLY.
 *
 * UDS 0x22 = ReadDataByIdentifier
 * Positive response = 0x62 + DID + DATA
 *
 * This helper never performs ECU writes, coding, adaptation, routines or reset.
 */
object HvUdsDiscovery {

    data class Response(
        val ecu: String,
        val did: Int,
        val dataHex: String
    )

    fun buildReadDataByIdentifier(did: Int): ByteArray {
        require(did in 0x0000..0xFFFF)
        return byteArrayOf(
            0x22,
            ((did shr 8) and 0xFF).toByte(),
            (did and 0xFF).toByte()
        )
    }

    fun parsePositiveResponse(ecu: String, bytes: ByteArray): Response? {
        if (bytes.size < 3 || (bytes[0].toInt() and 0xFF) != 0x62) return null

        val did = ((bytes[1].toInt() and 0xFF) shl 8) or
            (bytes[2].toInt() and 0xFF)

        val data = bytes.drop(3)
            .joinToString("") { "%02X".format(it.toInt() and 0xFF) }

        return Response(ecu, did, data)
    }
}
