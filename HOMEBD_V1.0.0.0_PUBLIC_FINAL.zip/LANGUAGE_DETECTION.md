# Automatic language detection

HOMEBD uses Android locale resources. The interface follows the device/app
language automatically.

Supported UI languages:
- English (fallback)
- Portuguese
- Spanish
- French

Technical identifiers such as CAN, UDS, PID, VIN, BMS and WebSocket remain
unchanged.
