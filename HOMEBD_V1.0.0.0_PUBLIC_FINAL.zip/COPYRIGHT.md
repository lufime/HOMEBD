# HOMEBD Copyright

Copyright © 2026 Lusano — HOMEBD

HOMEBD is developed as an independent project. No Car Scanner application
code, proprietary libraries, or proprietary assets are included.

CAN, OBD-II and UDS are used as technical communication protocols.
