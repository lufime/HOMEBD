# HOMEBD — THIRD PARTY NOTICES

**HOMEBD — Beta 1.0.0.0**

## Copyright do projeto

Copyright © 2026 lufime. All rights reserved.

## Kotlin 2.0.21

Componente utilizado:
- Kotlin 2.0.21

Licença:
- Apache License 2.0

Licença oficial:
https://www.apache.org/licenses/LICENSE-2.0

Informação oficial:
https://kotlinlang.org/docs/faq.html

## Gradle

Componente utilizado:
- Gradle

Licença:
- Apache License 2.0

Licença oficial:
https://www.apache.org/licenses/LICENSE-2.0

Informação oficial:
https://docs.gradle.org/current/userguide/licenses.html

## Android Gradle Plugin 8.7.3

Componente utilizado:
- Android Gradle Plugin 8.7.3

Informação oficial:
https://developer.android.com/build/releases/gradle-plugin

Termos legais Android:
https://developer.android.com/legal

## Android SDK / Android APIs

Componente utilizado:
- Android SDK / Android APIs

Informação oficial:
https://developer.android.com/legal

## Protocolos automóveis

OBD-II, CAN, ISO-TP e UDS são utilizados como referências/protocolos técnicos.

Não são apresentados como bibliotecas de software de terceiros incorporadas no HOMEBD.

## HOMEBD

Código original e materiais próprios:
Copyright © 2026 lufime, salvo componentes de terceiros identificados neste documento.


## OBD/CAN data policy
