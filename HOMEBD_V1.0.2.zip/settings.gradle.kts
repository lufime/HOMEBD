pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortl()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "HOMEBD"
include(":app")
