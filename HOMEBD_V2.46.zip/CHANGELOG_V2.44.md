# HOMEBD V2.44

- Mantida a ligação Home Assistant REST da V2.43.
- Adicionada política dedicada de estabilização CAN para o caso observado:
  protocolo AUTO/0 + 0 PIDs, apesar de respostas UDS em 7E0→7E8 e 7E5→7ED.
- Prioridade de protocolo READ-ONLY: ISO 15765-4 CAN 11-bit / 500 kbit/s (ATSP6),
  seguida de fallback AUTO (ATSP0).
- Não adiciona comandos de escrita, programação, reset ou coding.
- Mantida orientação vertical e integração REST sem MQTT/Mosquitto.
