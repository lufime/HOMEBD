# HOMEBD V2.42

Correção do build da V2.41.

- Adicionado `postAsync()` em `HomeBdRestBridge.kt`.
- Corrigido `Unresolved reference 'postAsync'` reportado pelo GitHub Actions.
- Publicação REST dos sensores continua assíncrona e protegida contra exceções.
- Mantidos HTTPS, Home Assistant REST, sem MQTT/Mosquitto e orientação vertical.
