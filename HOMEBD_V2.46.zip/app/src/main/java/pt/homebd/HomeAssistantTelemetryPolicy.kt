package pt.homebd

/**
 * HOMEBD -> Home Assistant telemetry policy.
 *
 * Target: responsive live data without creating one HTTP request per sensor.
 * READ-ONLY from the vehicle perspective; this only publishes HA states.
 */
object HomeAssistantTelemetryPolicy {
    const val UPDATE_INTERVAL_MS: Long = 1_000L

    /**
     * Only publish a sensor when its value changed, or at least every 5s so
     * the HA state remains visibly alive even when a value is stable.
     */
    const val HEARTBEAT_MS: Long = 5_000L

    /**
     * Maximum number of concurrent REST telemetry requests.
     * The publisher should reuse the HTTP client/connection where supported.
     */
    const val MAX_CONCURRENT_REQUESTS: Int = 1
}
