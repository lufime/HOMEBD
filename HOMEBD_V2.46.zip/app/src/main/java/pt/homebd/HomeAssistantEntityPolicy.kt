package pt.homebd

/**
 * HOMEBD-owned Home Assistant entities.
 *
 * HOMEBD publishes only entities under the `sensor.homebd_*` namespace.
 * UI lists supplied by Home Assistant should use this predicate when the
 * user asks to display HOMEBD entities only.
 */
object HomeAssistantEntityPolicy {
    const val PREFIX = "sensor.homebd_"

    fun isHomeBdEntity(entityId: String?): Boolean =
        entityId?.trim()?.lowercase()?.startsWith(PREFIX) == true
}
