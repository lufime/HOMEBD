# HOMEBD V2.43

- Corrigido o teste da REST API do Home Assistant.
- O endpoint de verificação passa a usar obrigatoriamente `/api/` com a barra final, conforme a API oficial do Home Assistant.
- Mantida autenticação `Authorization: Bearer <Long-Lived Access Token>`.
- A publicação dos sensores continua em `/api/states/...`.
- Sem MQTT/Mosquitto.
- Mantida orientação vertical.
