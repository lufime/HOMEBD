# HOMEBD V2.46

- Preparada a sequência funcional para o scan standard OBD antes da descoberta HV/UDS.
- Mantida a estabilização CAN ISO 15765-4 11-bit / 500 kbit/s e READ-ONLY.
- Adicionada política de entidades HOMEBD: apenas `sensor.homebd_*`.
- Quando a app apresentar/listar entidades do Home Assistant, o filtro HOMEBD pode limitar a lista às entidades publicadas pela HOMEBD.
- Mantido REST/HTTPS sem MQTT/Mosquitto.
