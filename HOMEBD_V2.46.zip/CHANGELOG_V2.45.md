# HOMEBD V2.45

- Otimizada a publicação REST para o Home Assistant.
- Atualização alvo de telemetria: 1 segundo.
- Publicação REST serializada num único worker, evitando criar uma thread HTTP por sensor.
- Mantém proteção contra falhas REST sem crash da aplicação.
- Política de heartbeat de 5 segundos para valores estáveis.
- Mantida a comunicação HTTPS/REST e ausência de MQTT/Mosquitto.
- Mantida orientação vertical.
- Mantida a estabilização CAN READ-ONLY da V2.44.
- Corrigido o problema anterior de `postAsync`/publicação REST.
