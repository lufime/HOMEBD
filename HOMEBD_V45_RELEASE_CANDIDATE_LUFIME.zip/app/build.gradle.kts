plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "pt.homebd"
    compileSdk = 36

    defaultConfig {
        applicationId = "pt.homebd"
        minSdk = 26
        targetSdk = 36
        versionCode = 7
        versionName = "1.8"
    }
}

kotlin {
    jvmToolchain(17)
}
