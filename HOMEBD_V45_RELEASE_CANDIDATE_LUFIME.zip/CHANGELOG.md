# Changelog

# HOMEBD V43 — TEST

- LIVE DATA updates incrementally instead of waiting for a full PID cycle.
- Last valid value is retained when an individual PID read fails.
- Monitor status (PID 0101) is shown as MIL state and stored DTC count instead of raw hexadecimal.
- Version: 1.7 / V43 TEST.
- Developer: lufime.
