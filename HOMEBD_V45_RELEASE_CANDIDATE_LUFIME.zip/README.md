# HOMEBD

**Home Onboard Monitoring Engine Board Data**

Universal Android OBD-II diagnostic application.

## Current version

**V45 — RELEASE CANDIDATE — BETA VERSION 1.0**

**Developed by:** lufime

## What HOMEBD can do

### OBD-II connection
- Bluetooth Classic OBD-II connection using the standard SPP UUID.
- Automatic ELM327 initialization.
- Paired Bluetooth device selection.
- OBD-II connection status display.

### Live diagnostics
- Continuous LIVE DATA polling while the OBD connection is active.
- Incremental display updates without requiring a new scan for every value.
- Keeps the last valid value when an individual PID read fails.
- Scrollable diagnostic message area.
- Human-readable PID values instead of only raw hexadecimal responses.

### Standard OBD-II data
The application can decode supported standard PIDs such as:
- Engine RPM
- Vehicle speed
- Engine coolant temperature
- Intake air temperature
- Engine load
- MAP / manifold pressure
- MAF
- Throttle position
- Fuel level
- ECU/module voltage
- Ambient temperature
- Fuel rate
- Fuel trims and other supported standard PIDs

### Automatic PID discovery
- Detects the PID ranges reported as supported by the ECU.
- Queries supported PIDs instead of repeatedly requesting every possible PID.
- Supports expansion to additional standard OBD-II PIDs.

### Vehicle types
The HOMEBD architecture is designed for:
- Combustion vehicles
- Hybrid vehicles (HEV)
- Plug-in hybrids (PHEV)
- Battery electric vehicles (EV)

Availability of EV/hybrid-specific values depends on what the vehicle ECU exposes. Standard OBD-II does not provide every manufacturer-specific battery or electric-drive value.

### Manufacturer profiles
- Automatic manufacturer detection when a VIN is exposed through OBD-II Mode 09 PID 02.
- Manual manufacturer selection when automatic detection is unavailable.
- Standard OBD-II decoding remains the universal fallback.
- Manufacturer-specific PIDs can be added without changing the standard OBD-II core.

### Hybrid / EV data planned or supported when available
Depending on vehicle and ECU support, the application can be extended to show:
- Electric kilometres
- Combustion kilometres
- Total kilometres
- Electric/combustion percentages
- Current drive mode
- Electrical power (kW)
- Electrical energy (kWh)
- Consumption (kWh/100 km)
- HV battery state of charge (SOC)
- Fuel consumption (L/100 km)

These values are not guaranteed by the standard OBD-II PID set and may require manufacturer-specific ECU data or calculated values.

## User interface
- Automotive HOMEBD header.
- Bluetooth indicator.
- Engine warning indicator.
- HOMEBD application icon/header artwork.
- Automatic system-language selection is planned for the complete application UI.
- Credits identify the developer as **lufime**.

## Project structure

- `app/src/main/java/pt/homebd/MainActivity.kt` — application code.
- `app/src/main/res/drawable/homebd_header.png` — header artwork.
- `app/src/main/res/drawable/homebd_icon.png` — application icon artwork.
- `app/build.gradle.kts` — Android application configuration and version.

## Third-party code and licences

The V45 project was inspected and **no external runtime libraries are declared** in `app/build.gradle.kts` (`implementation`, `api`, etc.). No third-party OBD library is included in the project.

The project uses the following open-source/platform tooling:

| Component | Version in project | Licence / status |
|---|---:|---|
| Kotlin Gradle plugin | 2.0.21 | Apache License 2.0 |
| Android Gradle Plugin | 8.7.3 | Android/Google build tooling; see official licensing information |
| Gradle Build Tool | CI/build environment | Apache License 2.0 |
| Android SDK / Android APIs | compileSdk 35 | Android platform/Open Source Project components; individual components may have their own notices |
| Java/JDK | Java 17 toolchain | JDK distribution licensing applies to the selected distribution |

See `LICENSES.md` for the attribution/licence notes and official references.

## Original project code

The HOMEBD application source code in `app/src/main/java/pt/homebd/` is project code created for HOMEBD. The inspection of V45 did not identify copied third-party OBD source code or an included third-party runtime OBD library.

This statement is a project audit note, not a legal guarantee about every historical source used during development.

## Build / workflow

The ZIP intentionally does **not** contain the GitHub Actions workflow. The workflow is maintained separately under `.github/workflows/build.yml` when used.

## Beta notice

**V45 — RELEASE CANDIDATE — BETA VERSION 1.0** is a test release. Vehicle data availability and update rate depend on the OBD-II adapter, ECU, vehicle manufacturer/model and supported PIDs.
