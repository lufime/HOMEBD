# HOMEBD — Licences and third-party notices

## 1. HOMEBD project code

The HOMEBD application code under `app/src/main/java/pt/homebd/` is project code created for the HOMEBD project.

Developer: **lufime**

No third-party OBD runtime library is declared in `app/build.gradle.kts`.

## 2. Kotlin

The project uses Kotlin Gradle plugin **2.0.21**.

Kotlin is open source and licensed under the **Apache License 2.0**.

Official information:
https://kotlinlang.org/docs/contribute.html

## 3. Gradle

The Gradle Build Tool is licensed under the **Apache License 2.0**.

Official information:
https://docs.gradle.org/current/userguide/licenses.html

## 4. Android Gradle Plugin

The project uses Android Gradle Plugin **8.7.3**. The Android build system is provided by Google/Android tooling. The applicable notices and licensing terms for the tooling and Android components should be retained when redistributing the corresponding binaries.

Official Android Gradle Plugin documentation:
https://developer.android.com/build/releases/about-agp

## 5. Android SDK / Android platform

HOMEBD uses Android SDK APIs. Android is an open-source platform with component-specific licence and notice requirements. HOMEBD does not redistribute the Android operating system itself.

Official Android Open Source Project:
https://source.android.com/

## 6. OBD-II / ELM327

HOMEBD communicates using standard OBD-II requests and ELM327-compatible AT commands. No ELM327 third-party software library is included in the project ZIP.

The use of a protocol/command set does not by itself mean that third-party source code has been copied into HOMEBD.

## 7. Images and branding

`homebd_header.png` and `homebd_icon.png` are HOMEBD project artwork. The project does not intentionally include the official Android robot logo or the official Home Assistant logo as application branding.

## Important

This file records the project dependencies and licence information identified in the V44 source ZIP. It is not legal advice and does not replace the licence/notice files supplied with any external binary or SDK installed by the build environment.
