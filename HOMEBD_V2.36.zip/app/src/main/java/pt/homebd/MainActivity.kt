package pt.homebd

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.content.pm.PackageManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.*
import java.io.InputStream
import java.io.IOException
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.LinkedBlockingQueue
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private fun ui(pt: String, en: String): String =
        if (HomeBdLanguage.detect(this) == HomeBdLanguage.Language.PT) pt else en

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun isActivityUsable(): Boolean =
        !isFinishing && (Build.VERSION.SDK_INT < 17 || !isDestroyed)

    private fun safeUi(action: () -> Unit) {
        if (!isActivityUsable()) return
        runOnUiThread {
            if (isActivityUsable()) {
                try { action() } catch (_: Throwable) { /* UI callback must never crash HOMEBD */ }
            }
        }
    }

    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private var bleGatt: BluetoothGatt? = null
    private var bleWriteCharacteristic: BluetoothGattCharacteristic? = null
    private var bleNotifyCharacteristic: BluetoothGattCharacteristic? = null
    private val bleRx = LinkedBlockingQueue<Byte>(8192)
    @Volatile private var usingBle = false
    private var bleConnectedLatch: CountDownLatch? = null
    private var bleServicesLatch: CountDownLatch? = null
    private var bleNotificationLatch: CountDownLatch? = null
    private var bleWriteLatch: CountDownLatch? = null

    private val bleUartServices = listOf(
        UUID.fromString("6E400001-B5A3-F393-E0A9-E50E24DCCA9E"),
        UUID.fromString("0000FFE0-0000-1000-8000-00805F9B34FB"),
        UUID.fromString("49535343-FE7D-4AE5-8FA9-9FAFD205E455")
    )
    private val bleWriteUuids = setOf(
        UUID.fromString("6E400002-B5A3-F393-E0A9-E50E24DCCA9E"),
        UUID.fromString("0000FFE1-0000-1000-8000-00805F9B34FB"),
        UUID.fromString("49535343-8841-43F4-A8D4-ECBE34729BB3")
    )
    private val bleNotifyUuids = setOf(
        UUID.fromString("6E400003-B5A3-F393-E0A9-E50E24DCCA9E"),
        UUID.fromString("0000FFE1-0000-1000-8000-00805F9B34FB"),
        UUID.fromString("49535343-1E4D-4BD9-BA61-23C647249616")
    )

    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var scanButton: TextView
    private lateinit var connectButton: TextView
    private var adapterInfo = "Adaptador: não identificado"
    private lateinit var adapterInfoView: TextView
    private lateinit var devicesSpinner: Spinner
    private lateinit var manufacturerSpinner: Spinner
    private lateinit var aboutButton: TextView
    private lateinit var faqButton: TextView
    private lateinit var restButton: TextView
    private lateinit var hvUdsButton: TextView
    private lateinit var restStatusView: TextView
    private lateinit var homeAssistantButton: TextView
    private lateinit var restBridge: HomeBdRestBridge
    private lateinit var liveDataScroll: ScrollView
    private lateinit var liveDataLog: TextView
    private lateinit var liveDataContainer: LinearLayout
    private val liveGroupExpanded = mutableMapOf<String, Boolean>()
    private var hasScannedOnce = false
    private var detectedProtocol = ""
    private var canActive = false
    private var pendingExportText = ""
    private var pendingExportLabel = "HOMEBD"
    private var adapterKind = "Desconhecido"
    private var adapterIdentity = ""

    private data class ManufacturerProfile(
        val name: String,
        val parameters: List<Pair<String, String>>
    )

    private data class UdsDid(
        val did: String,
        val label: String
    )

    // Public/documented ECU identification DIDs selected for the READ-ONLY
    // Stellantis profile. Unknown/unavailable DIDs are simply reported as such.
    private val stellantisDids = listOf(
        UdsDid("F18C", "ECU Serial Number"),
        UdsDid("F187", "ECU Part Number"),
        UdsDid("F192", "ECU Hardware Number"),
        UdsDid("F193", "ECU Hardware Version"),
        UdsDid("F194", "ECU Software Number"),
        UdsDid("F195", "ECU Software Version")
    )

    // Renault / Dacia: only standardized UDS identification DIDs are used.
    // No proprietary Renault/Dacia DID is guessed or imported from third-party
    // CAN databases. Unsupported DIDs are simply ignored.
    private val renaultDids = listOf(
        UdsDid("F187", "ECU Part Number"),
        UdsDid("F18A", "System Supplier"),
        UdsDid("F18C", "ECU Serial Number"),
        UdsDid("F190", "VIN"),
        UdsDid("F191", "ECU Hardware Number"),
        UdsDid("F194", "ECU Software Number"),
        UdsDid("F195", "ECU Software Version")
    )

    // Volkswagen / Audi / SEAT / Škoda (VAG): only standardized UDS ECU
    // identification DIDs are used. No proprietary VAG CAN database is copied.
    private val vagDids = listOf(
        UdsDid("F187", "ECU Part Number"),
        UdsDid("F18A", "System Supplier"),
        UdsDid("F18C", "ECU Serial Number"),
        UdsDid("F190", "VIN"),
        UdsDid("F191", "ECU Hardware Number"),
        UdsDid("F192", "Supplier ECU Hardware Number"),
        UdsDid("F193", "Supplier ECU Hardware Version"),
        UdsDid("F194", "ECU Software Number"),
        UdsDid("F195", "ECU Software Version")
    )

    // Ford: only standardized UDS identification DIDs are used.
    // No proprietary Ford CAN database is copied or inferred.
    private val fordDids = listOf(
        UdsDid("F187", "ECU Part Number"),
        UdsDid("F18A", "System Supplier"),
        UdsDid("F18C", "ECU Serial Number"),
        UdsDid("F190", "VIN"),
        UdsDid("F191", "ECU Hardware Number"),
        UdsDid("F194", "ECU Software Number"),
        UdsDid("F195", "ECU Software Version")
    )

    // Nissan / INFINITI: only standardized UDS identification DIDs are used.
    // Nissan TechInfo documents ECU identification and VIN fields, but proprietary
    // request maps are not reproduced here. No third-party CAN database is used.
    private val nissanDids = listOf(
        UdsDid("F18C", "ECU Serial Number"),
        UdsDid("F190", "VIN"),
        UdsDid("F187", "ECU Part Number"),
        UdsDid("F194", "ECU Software Number"),
        UdsDid("F195", "ECU Software Version")
    )

    // Tesla: keep the ELM327 profile conservative. Current HOMEBD transport
    // supports Bluetooth ELM327/CAN; Tesla vehicles may require DoIP/Ethernet
    // depending on model and diagnostic architecture. Only standard UDS VIN
    // identification is attempted over CAN here; no proprietary Tesla map is used.
    private val teslaDids = listOf(
        UdsDid("F190", "VIN")
    )

    // Mazda: public Mazda documentation confirms mandatory OBD readout for
    // operating data and fault diagnosis. No proprietary Mazda DID/CAN map is
    // guessed or copied here; manufacturer-specific data remains unavailable
    // unless a public/documented identifier is verified.
    private val mazdaDids = emptyList<UdsDid>()

    // Subaru: conservative public OBD-II read-only profile. No proprietary
    // Subaru DID/request map is guessed or imported from a third-party CAN database.
    private val subaruDids = listOf(
        UdsDid("F190", "VIN")
    )

    // Mitsubishi: the official Mitsubishi technical-information portal documents
    // OBD-II vehicles and CAN-bus diagnosis through MUT-III. Proprietary Mitsubishi
    // request/DID maps are not reproduced here because the detailed service data
    // are subscriber-restricted. HOMEBD therefore uses standard OBD-II plus a
    // conservative standard UDS VIN read when the ECU exposes it.
    private val mitsubishiDids = listOf(
        UdsDid("F190", "VIN")
    )

    // Lexus: separate profile from Toyota so future documented Lexus-specific
    // read-only diagnostics can be added without mixing manufacturer data.
    // Only the standard VIN DID is attempted here; no proprietary Lexus map
    // is guessed or imported from a third-party CAN database.
    private val lexusDids = listOf(
        UdsDid("F190", "VIN")
    )

    // Isuzu: official Isuzu RMI/TruckService documentation confirms OBD/diagnostic
    // support, while detailed manufacturer diagnostic data are provided through
    // Isuzu diagnostic tooling. HOMEBD therefore keeps this profile conservative:
    // standard OBD-II plus a standard UDS VIN read when the ECU exposes it.
    private val isuzuDids = listOf(
        UdsDid("F190", "VIN")
    )


    // OBD-II Mode 01 PID catalogue. These are protocol identifiers and
    // generic concepts, not copied manufacturer code or proprietary CAN maps.
    // The scanner first asks the vehicle which PID blocks it supports and only
    // then requests the supported PIDs. Every manufacturer profile uses this
    // same standards-based catalogue; manufacturer-specific UDS remains
    // separate and is only used when documented.
    private val pids = linkedMapOf(
        "0101" to "Monitor status / DTCs",
        "0102" to "DTC status since clear",
        "0103" to "Fuel system status",
        "0104" to "Calculated engine load",
        "0105" to "Engine coolant temperature",
        "0106" to "Short-term fuel trim — Bank 1",
        "0107" to "Long-term fuel trim — Bank 1",
        "0108" to "Short-term fuel trim — Bank 2",
        "0109" to "Long-term fuel trim — Bank 2",
        "010A" to "Fuel pressure",
        "010B" to "Intake manifold pressure (MAP)",
        "010C" to "Engine RPM",
        "010D" to "Vehicle speed",
        "010E" to "Ignition timing advance",
        "010F" to "Intake air temperature",
        "0110" to "MAF air flow",
        "0111" to "Throttle position",
        "0112" to "Secondary air status",
        "0113" to "Oxygen sensor presence — Bank 1",
        "0114" to "O2 Sensor 1 voltage / trim",
        "0115" to "O2 Sensor 2 voltage / trim",
        "0116" to "O2 Sensor 3 voltage / trim",
        "0117" to "O2 Sensor 4 voltage / trim",
        "0118" to "O2 Sensor 5 voltage / trim",
        "0119" to "O2 Sensor 6 voltage / trim",
        "011A" to "O2 Sensor 7 voltage / trim",
        "011B" to "O2 Sensor 8 voltage / trim",
        "011C" to "OBD standards supported",
        "011D" to "O2 sensors present — Bank 2",
        "011E" to "Auxiliary input status",
        "011F" to "Engine run time since start",
        "0120" to "Supported PIDs 21–40",
        "0121" to "Distance travelled with MIL on",
        "0122" to "Fuel rail pressure",
        "0123" to "Fuel rail pressure (diesel / alternate)",
        "0124" to "O2 Sensor 1 equivalence / voltage",
        "0125" to "O2 Sensor 2 equivalence / voltage",
        "0126" to "O2 Sensor 3 equivalence / voltage",
        "0127" to "O2 Sensor 4 equivalence / voltage",
        "0128" to "O2 Sensor 5 equivalence / voltage",
        "0129" to "O2 Sensor 6 equivalence / voltage",
        "012A" to "O2 Sensor 7 equivalence / voltage",
        "012B" to "O2 Sensor 8 equivalence / voltage",
        "012C" to "Commanded EGR",
        "012D" to "EGR error",
        "012E" to "Commanded evaporative purge",
        "012F" to "Fuel level input",
        "0130" to "Warm-ups since DTCs cleared",
        "0131" to "Distance since DTCs cleared",
        "0132" to "Evap system vapour pressure",
        "0133" to "Absolute barometric pressure",
        "0134" to "O2 Sensor 1 equivalence ratio / voltage",
        "0135" to "O2 Sensor 2 equivalence ratio / voltage",
        "0136" to "O2 Sensor 3 equivalence ratio / voltage",
        "0137" to "O2 Sensor 4 equivalence ratio / voltage",
        "0138" to "O2 Sensor 5 equivalence ratio / voltage",
        "0139" to "O2 Sensor 6 equivalence ratio / voltage",
        "013A" to "O2 Sensor 7 equivalence ratio / voltage",
        "013B" to "O2 Sensor 8 equivalence ratio / voltage",
        "013C" to "Catalyst temperature — Bank 2 Sensor 1",
        "013D" to "Catalyst temperature — Bank 1 Sensor 2",
        "013E" to "Catalyst temperature — Bank 2 Sensor 2",
        "013F" to "Catalyst temperature — Bank 2 Sensor 2",
        "0140" to "Supported PIDs 41–60",
        "0141" to "Monitor status this drive cycle",
        "0142" to "Control module voltage",
        "0143" to "Absolute load value",
        "0144" to "Commanded equivalence ratio",
        "0145" to "Relative throttle position",
        "0146" to "Ambient / exterior air temperature",
        "0147" to "Absolute throttle position B",
        "0148" to "Absolute throttle position C",
        "0149" to "Accelerator pedal position D",
        "014A" to "Accelerator pedal position E",
        "014B" to "Accelerator pedal position F",
        "014C" to "Commanded throttle actuator",
        "014D" to "Time run with MIL on",
        "014E" to "Time since DTCs cleared",
        "0151" to "Fuel type",
        "0152" to "Ethanol fuel percentage",
        "0153" to "Absolute evaporative system vapour pressure",
        "0154" to "Evap system vapour pressure",
        "0155" to "Short-term secondary O2 trim — Bank 1",
        "0156" to "Long-term secondary O2 trim — Bank 1",
        "0157" to "Short-term secondary O2 trim — Bank 2",
        "0158" to "Long-term secondary O2 trim — Bank 2",
        "0159" to "Fuel rail absolute pressure",
        "015A" to "Relative accelerator pedal position",
        "015B" to "Hybrid battery pack remaining life",
        "015C" to "Engine oil temperature",
        "015D" to "Fuel injection timing",
        "015E" to "Engine fuel rate",
        "015F" to "Engine demand torque",
        "0160" to "Supported PIDs 61–80",
        "0161" to "Engine actual torque",
        "0162" to "Engine reference torque",
        "0163" to "Engine percentage torque",
        "0164" to "Auxiliary input / torque",
        "0165" to "Mass air flow sensor current",
        "0166" to "Engine coolant temperature sensor 1",
        "0167" to "Engine coolant temperature sensor 2",
        "0168" to "Engine coolant temperature sensor 3",
        "0169" to "Engine coolant temperature sensor 4",
        "016A" to "Throttle actuator control",
        "016B" to "Fuel pressure control",
        "016C" to "Commanded diesel intake air flow",
        "016D" to "Exhaust gas recirculation temperature",
        "016E" to "Commanded throttle actuator control",
        "016F" to "Fuel pressure sensor",
        "0170" to "Boost pressure control",
        "0171" to "Variable geometry turbo (VGT) control",
        "0172" to "Wastegate control",
        "0173" to "Exhaust pressure",
        "0174" to "Turbocharger RPM",
        "0175" to "Turbocharger temperature",
        "0176" to "Turbocharger temperature — second set",
        "0177" to "Charge air cooler temperature",
        "0178" to "Exhaust gas temperature — Bank 1",
        "0179" to "Exhaust gas temperature — Bank 2",
        "017A" to "DPF differential pressure",
        "017B" to "DPF status",
        "017C" to "DPF temperature",
        "017D" to "NOx NTE control area status",
        "017E" to "PM NTE control area status",
        "017F" to "Extended engine run time",
        "0180" to "Supported PIDs 81–A0",
        "0183" to "NOx sensor",
        "0184" to "Manifold surface temperature",
        "0185" to "NOx reagent system",
        "0186" to "Particulate matter sensor",
        "0187" to "Intake manifold absolute pressure (later)",
        "0188" to "SCR inducement system",
        "019A" to "Hybrid / EV vehicle system data — battery voltage",
        "019D" to "Engine fuel rate (mass)",
        "01A1" to "NOx sensor corrected data",
        "01A3" to "Evap system vapour pressure (later)",
        "01A7" to "NOx sensor concentration — sensors 3 and 4",
        "01A8" to "NOx sensor corrected concentration — sensors 3 and 4"
    )

    private val manufacturerProfiles = listOf(
        ManufacturerProfile("Automático", pids.toList()),
        ManufacturerProfile("Citroën", pids.toList()),
        ManufacturerProfile("Peugeot", pids.toList()),
        ManufacturerProfile("DS Automobiles", pids.toList()),
        ManufacturerProfile("Opel", pids.toList()),
        ManufacturerProfile("Vauxhall", pids.toList()),
        ManufacturerProfile("Fiat", pids.toList()),
        ManufacturerProfile("Alfa Romeo", pids.toList()),
        ManufacturerProfile("Jeep", pids.toList()),
        ManufacturerProfile("Lancia", pids.toList()),
        ManufacturerProfile("Abarth", pids.toList()),
        ManufacturerProfile("Toyota", pids.toList()),
        ManufacturerProfile("Lexus", pids.toList()),
        ManufacturerProfile("Volkswagen", pids.toList()),
        ManufacturerProfile("Audi", pids.toList()),
        ManufacturerProfile("SEAT", pids.toList()),
        ManufacturerProfile("Škoda", pids.toList()),
        ManufacturerProfile("CUPRA", pids.toList()),
        ManufacturerProfile("Porsche", pids.toList()),
        ManufacturerProfile("BMW", pids.toList()),
        ManufacturerProfile("MINI", pids.toList()),
        ManufacturerProfile("Mercedes-Benz", pids.toList()),
        ManufacturerProfile("Renault", pids.toList()),
        ManufacturerProfile("Nissan", pids.toList()),
        ManufacturerProfile("Hyundai", pids.toList()),
        ManufacturerProfile("Kia", pids.toList()),
        ManufacturerProfile("Ford", pids.toList()),
        ManufacturerProfile("Volvo", pids.toList()),
        ManufacturerProfile("Polestar", pids.toList()),
        ManufacturerProfile("Tesla", pids.toList()),
        ManufacturerProfile("Honda", pids.toList()),
        ManufacturerProfile("Mazda", pids.toList()),
        ManufacturerProfile("Subaru", pids.toList()),
        ManufacturerProfile("Suzuki", pids.toList()),
        ManufacturerProfile("Mitsubishi", pids.toList()),
        ManufacturerProfile("Jaguar", pids.toList()),
        ManufacturerProfile("Land Rover", pids.toList()),
        ManufacturerProfile("BYD", pids.toList()),
        ManufacturerProfile("MG", pids.toList()),
        ManufacturerProfile("Geely", pids.toList()),
        ManufacturerProfile("Chery", pids.toList()),
        ManufacturerProfile("Isuzu", pids.toList()),
        ManufacturerProfile("OBD-II Universal", pids.toList())
    )


    private fun localized(pt: String, en: String): String {
        return if (HomeBdLanguage.name(this).equals("Português", ignoreCase = true)) pt else en
    }

    private fun restText(key: String): String {
        // Keep this table self-contained. Do NOT call restText() from inside
        // the table: that creates infinite recursion and crashes when the
        // REST/Home Assistant dialog is opened.
        val pt = mapOf(
            "title" to "HOMEBD • Home Assistant REST",
            "description" to "Liga diretamente à API REST do Home Assistant. Não é necessário MQTT nem broker.",
            "mode" to "Modo Home Assistant",
            "auto" to "Automático (local → externo)",
            "local" to "URL Home Assistant local (ex.: http://192.168.1.10:8123)",
            "external" to "URL Home Assistant externa (ex.: https://meu-dominio:8123)",
            "token" to "Token de acesso Home Assistant",
            "path" to "Caminho da API",
            "test" to "TESTAR E LIGAR",
            "cancel" to "CANCELAR",
            "disconnect" to "DESLIGAR"
        )
        val en = mapOf(
            "title" to "HOMEBD • Home Assistant REST",
            "description" to "Connects directly to the Home Assistant REST API. MQTT or a broker is not required.",
            "mode" to "Home Assistant mode",
            "auto" to "Automatic (local → external)",
            "local" to "Local Home Assistant URL (e.g. http://192.168.1.10:8123)",
            "external" to "External Home Assistant URL (e.g. https://my-domain:8123)",
            "token" to "Home Assistant access token",
            "path" to "API path",
            "test" to "TEST AND CONNECT",
            "cancel" to "CANCEL",
            "disconnect" to "DISCONNECT"
        )
        val ptMode = HomeBdLanguage.name(this).equals("Português", ignoreCase = true)
        return (if (ptMode) pt else en)[key] ?: key
    }

    private fun diagnosticIntro(): String = localized(
        "HOMEBD pronto.\nDiagnóstico OBD-II universal para veículos.\nSelecione um adaptador OBD-II Bluetooth emparelhado e toque em LIGAR OBDII.\n",
        "HOMEBD ready.\nUniversal OBD-II diagnostics for vehicles.\nSelect a paired Bluetooth OBD-II adapter and tap CONNECT OBD-II.\n"
    )




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val detectedLanguage = HomeBdLanguage.detect(this)
        restBridge = HomeBdRestBridge(this)

        window.statusBarColor = Color.rgb(23, 23, 23)
        window.navigationBarColor = Color.rgb(23, 23, 23)

        // Ecrã normal: o conteúdo nunca fica por baixo das barras do sistema.
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(true)
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = 0
        }

        val background = Color.rgb(28, 28, 28)
        val panel = Color.rgb(55, 55, 55)
        val primary = Color.rgb(235, 235, 235)
        val secondary = Color.rgb(190, 190, 190)
        val blue = Color.rgb(20, 145, 245)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(background)
            setPadding(dp(8), dp(2), dp(8), dp(2))
            clipChildren = true
            clipToPadding = true
        }

        // Compact top bar: app icon on the left frees vertical space while
        // keeping the HOMEBD identity visible at the top of the screen.
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        val appIcon = ImageView(this).apply {
            setImageResource(pt.homebd.R.drawable.homebd_icon)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            contentDescription = "HOMEBD"
        }
        header.addView(appIcon, LinearLayout.LayoutParams(dp(44), dp(44)).apply {
            setMargins(dp(2), 0, dp(10), 0)
        })
        val headerTitle = TextView(this).apply {
            text = "HOMEBD"
            textSize = 21f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }
        header.addView(headerTitle, LinearLayout.LayoutParams(0, -1, 1f))

        status = TextView(this).apply {
            text = ui(localized("Estado: desligado", "Status: disconnected"), "Status: disconnected")
            textSize = 14f
            setTextColor(secondary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        val deviceLabel = TextView(this).apply {
            text = ui(localized("DISPOSITIVO OBD-II", "OBD-II DEVICE"), "OBD-II DEVICE")
            textSize = 12f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        manufacturerSpinner = Spinner(this).apply {
            this.background = GradientDrawable().apply {
                setColor(panel)
                cornerRadius = 2f
            }
            minimumHeight = dp(44)
        }

        devicesSpinner = Spinner(this).apply {
            this.background = GradientDrawable().apply {
                setColor(panel)
                cornerRadius = 2f
            }
            minimumHeight = dp(44)
        }

        connectButton = actionButton(ui(localized("LIGAR OBDII", "CONNECT OBD-II"), "CONNECT OBD-II"), blue, primary)
        val connect = connectButton
        scanButton = actionButton(ui(localized("SCAN PIDs", "SCAN PIDs"), localized("SCAN PIDs", "SCAN PIDs")), Color.rgb(70, 70, 70), primary).apply {
            isEnabled = false
            alpha = 0.55f
        }

        hvUdsButton = actionButton(ui(localized("SCAN HV/UDS", "HV/UDS SCAN"), "HV/UDS SCAN"), Color.rgb(85, 70, 110), primary).apply {
            isEnabled = false
            alpha = 0.55f
        }

        restButton = actionButton(
            if (restBridge.connected) ui("REST DESLIGAR", "REST DISCONNECT") else ui(localized("REST LIGAR", "REST CONNECT"), "REST CONNECT"),
            Color.rgb(45, 110, 75),
            primary
        )

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        buttons.addView(connect, LinearLayout.LayoutParams(0, dp(50), 1f).apply {
            setMargins(dp(0), dp(4), dp(2), dp(4))
        })
        buttons.addView(scanButton, LinearLayout.LayoutParams(0, dp(50), 1f).apply {
            setMargins(dp(2), dp(4), dp(2), dp(4))
        })
        buttons.addView(hvUdsButton, LinearLayout.LayoutParams(0, dp(50), 1f).apply {
            setMargins(dp(2), dp(4), dp(2), dp(4))
        })
        buttons.addView(restButton, LinearLayout.LayoutParams(0, dp(50), 1f).apply {
            setMargins(dp(2), dp(4), dp(0), dp(4))
        })

        log = TextView(this).apply {
            textSize = 14f
            setTextColor(primary)
            setBackgroundColor(panel)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            includeFontPadding = true
            gravity = Gravity.TOP or Gravity.START
            setLineSpacing(0f, 1.0f)
        }

        logScroll = ScrollView(this).apply {
            setBackgroundColor(panel)
            isFillViewport = true
            isVerticalScrollBarEnabled = true
            scrollBarStyle = View.SCROLLBARS_INSIDE_INSET
            isScrollbarFadingEnabled = false
            addView(log, ViewGroup.LayoutParams(-1, -2))
        }

        liveDataLog = TextView(this).apply {
            textSize = 14f
            setTextColor(primary)
            setBackgroundColor(panel)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            gravity = Gravity.TOP or Gravity.START
            includeFontPadding = true
            setLineSpacing(0f, 1.0f)
            isLongClickable = true
        }

        liveDataContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(panel)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        liveDataScroll = ScrollView(this).apply {
            setBackgroundColor(panel)
            isFillViewport = true
            isVerticalScrollBarEnabled = true
            scrollBarStyle = View.SCROLLBARS_INSIDE_INSET
            isScrollbarFadingEnabled = false
            addView(liveDataContainer, ViewGroup.LayoutParams(-1, -2))
        }

        val liveLabel = sectionHeader(ui(localized("LIVE DATA", "LIVE DATA"), localized("LIVE DATA", "LIVE DATA")), ui(localized("EXPORTAR", "EXPORT"), "EXPORT")) {
            exportText(ui(localized("LIVE DATA", "LIVE DATA"), localized("LIVE DATA", "LIVE DATA")), liveDataLog.text.toString(), 101)
        }

        val diagnosticLabel = sectionHeader(ui(localized("DIAGNÓSTICO", "DIAGNOSTICS"), "DIAGNOSTICS"), ui(localized("EXPORTAR", "EXPORT"), "EXPORT")) {
            exportText("DIAGNOSTICO", log.text.toString(), 102)
        }

        aboutButton = TextView(this).apply {
            text = ui("SOBRE • HOMEBD 2.36 • lufime", "ABOUT • HOMEBD 2.36 • lufime")
            textSize = 11f
            setTextColor(secondary)
            gravity = Gravity.CENTER
            includeFontPadding = false
            isClickable = true
            isFocusable = true
            setPadding(dp(4), dp(2), dp(4), dp(2))
        }

        root.addView(header, LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(status, LinearLayout.LayoutParams(-1, dp(28)))

        val selectors = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val deviceColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(0), dp(0), dp(4), dp(0))
        }
        deviceColumn.addView(deviceLabel, LinearLayout.LayoutParams(-1, dp(22)))
        deviceColumn.addView(devicesSpinner, LinearLayout.LayoutParams(-1, dp(46)))

        val manufacturerLabel = TextView(this).apply {
            text = ui(localized("FABRICANTE / PERFIL", "MANUFACTURER / PROFILE"), "MANUFACTURER / PROFILE")
            textSize = 12f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }
        val manufacturerColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(0), dp(0), dp(0))
        }
        manufacturerColumn.addView(manufacturerLabel, LinearLayout.LayoutParams(-1, dp(22)))
        manufacturerColumn.addView(manufacturerSpinner, LinearLayout.LayoutParams(-1, dp(46)))

        selectors.addView(deviceColumn, LinearLayout.LayoutParams(0, dp(70), 1f))
        selectors.addView(manufacturerColumn, LinearLayout.LayoutParams(0, dp(70), 1f))
        root.addView(selectors, LinearLayout.LayoutParams(-1, dp(72)))

        restStatusView = TextView(this).apply {
            text = if (restBridge.baseUrl.isBlank()) localized("REST: Home Assistant não configurado", "REST: Home Assistant not configured")
                   else "REST: ${restBridge.baseUrl}"
            textSize = 11f
            setTextColor(secondary)
            gravity = Gravity.CENTER
            includeFontPadding = false
        }
        root.addView(buttons, LinearLayout.LayoutParams(-1, dp(58)))
        root.addView(restStatusView, LinearLayout.LayoutParams(-1, dp(20)))

        homeAssistantButton = actionButton(
            ui(
                if (homeAssistantLocalUrl().isBlank() && homeAssistantExternalUrl().isBlank())
                    "CONFIGURAR HOME ASSISTANT" else "ABRIR HOME ASSISTANT",
                if (homeAssistantLocalUrl().isBlank() && homeAssistantExternalUrl().isBlank())
                    "CONFIGURE HOME ASSISTANT" else "OPEN HOME ASSISTANT"
            ), blue, primary
        ).apply {
            setOnClickListener {
                try {
                    if (homeAssistantLocalUrl().isBlank() && homeAssistantExternalUrl().isBlank()) {
                        configureHomeAssistantLink()
                    } else {
                        openHomeAssistant()
                    }
                } catch (_: Throwable) {
                    try { Toast.makeText(this@MainActivity, "Não foi possível abrir a configuração do Home Assistant.", Toast.LENGTH_LONG).show() } catch (_: Throwable) {}
                }
            }
            setOnLongClickListener {
                try { configureHomeAssistantLink() } catch (_: Throwable) {}
                true
            }
        }
        root.addView(homeAssistantButton, LinearLayout.LayoutParams(-1, dp(50)).apply {
            setMargins(dp(0), dp(2), dp(0), dp(4))
        })

        root.addView(liveLabel, LinearLayout.LayoutParams(-1, dp(28)))
        root.addView(liveDataScroll, LinearLayout.LayoutParams(-1, dp(135)))
        root.addView(diagnosticLabel, LinearLayout.LayoutParams(-1, dp(28)))
        root.addView(logScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        faqButton = TextView(this).apply {
            text = localized("FAQ", "FAQ")
            textSize = 11f
            setTextColor(blue)
            gravity = Gravity.CENTER
            includeFontPadding = false
            isClickable = true
            isFocusable = true
            setPadding(dp(12), dp(2), dp(12), dp(2))
        }
        footer.addView(faqButton, LinearLayout.LayoutParams(0, dp(30), 1f))
        footer.addView(aboutButton, LinearLayout.LayoutParams(0, dp(30), 1f))
        root.addView(footer, LinearLayout.LayoutParams(-1, dp(30)))

        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener { v, insets ->
                val bars = insets.getInsets(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                v.setPadding(
                    dp(8),
                    bars.top + dp(2),
                    dp(8),
                    bars.bottom + dp(2)
                )
                insets
            }
        }

        setContentView(root)

        append("🌐 " + ui("Idioma automático", "Automatic language") + ": ${HomeBdLanguage.name(this)}")

        // Pressão longa nos dois painéis copia todo o conteúdo.
        installCopyOnLongPress(liveDataLog, ui(localized("LIVE DATA", "LIVE DATA"), localized("LIVE DATA", "LIVE DATA")))
        installCopyOnLongPress(log, ui(localized("DIAGNÓSTICO", "DIAGNOSTICS"), "DIAGNOSTICS"))

        manufacturerSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            manufacturerProfiles.map { it.name }
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        manufacturerSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val profile = manufacturerProfiles[position]
                liveDataLog.text =
                    "Perfil: ${profile.name}\n\n" +
                    "OBD-II standard\n" +
                    "Os PIDs suportados são detetados automaticamente pelo veículo.\n\n" +
                    "Categorias disponíveis:\n" +
                    "• Motor e carga\n" +
                    "• Combustível e mistura\n" +
                    "• Temperaturas e pressões\n" +
                    "• Sensores O2 / emissões\n" +
                    "• Acelerador / pedal\n" +
                    "• Estado OBD / readiness\n" +
                    "• Tensão e dados auxiliares\n" +
                    "• VIN / informação do veículo"
                append("Perfil selecionado: ${profile.name} • catálogo OBD-II standard ativo")
            }
        }

        root.requestApplyInsets()

        connect.setOnClickListener {
            if (isTransportConnected()) {
                // Explicit disconnect: stop polling and close Classic/BLE transport.
                stopLiveData()
                closeTransport()
                status.text = ui(localized("Estado: desligado", "Status: disconnected"), "Status: disconnected")
                scanButton.isEnabled = false
                scanButton.alpha = 0.55f
                connectButton.text = ui(localized("LIGAR OBDII", "CONNECT OBD-II"), "CONNECT OBD-II")
                append("✓ OBD-II desligado.")
                return@setOnClickListener
            }

            val adapter = BluetoothAdapter.getDefaultAdapter()
            val paired = try {
                adapter?.bondedDevices?.toList() ?: emptyList()
            } catch (_: SecurityException) {
                emptyList()
            }

            val position = devicesSpinner.selectedItemPosition
            val device = paired.getOrNull(position)

            if (device != null) {
                connect(device)
            } else {
                append("⚠ Nenhum dispositivo Bluetooth selecionável.")
                append("Emparelhe um adaptador OBD-II Bluetooth nas definições Bluetooth do Android.")
            }
        }

        restButton.setOnClickListener {
            try {
                if (!isActivityUsable()) return@setOnClickListener
                if (restBridge.connected) {
                    restBridge.disconnect()
                    restButton.text = ui(localized("REST LIGAR", "REST CONNECT"), "REST CONNECT")
                    restStatusView.text = "REST: desligado"
                    append("✓ REST desligado.")
                } else if (restBridge.baseUrl.isBlank() || restBridge.token.isBlank()) {
                    showRestDialogSafely()
                } else {
                    restStatusView.text = "REST: a ligar…"
                    restButton.isEnabled = false
                    restBridge.connect { ok, msg ->
                        safeUi {
                            restButton.isEnabled = true
                            restStatusView.text = if (ok) "REST: ligado • ${restBridge.activeMode ?: ""}" else "REST: $msg"
                            restButton.text = if (ok) ui("REST DESLIGAR", "REST DISCONNECT") else ui(localized("REST LIGAR", "REST CONNECT"), "REST CONNECT")
                            append(if (ok) "✓ $msg" else "⚠ $msg\nDica: confirme a URL HTTPS e o token do Home Assistant.")
                        }
                    }
                }
            } catch (t: Throwable) {
                safeUi {
                    restButton.isEnabled = true
                    restStatusView.text = "REST: erro"
                    append("⚠ Erro REST: ${t.message ?: t.javaClass.simpleName}")
                }
            }
        }

        restButton.setOnLongClickListener {
            try { showRestDialog() } catch (_: Throwable) {}
            true
        }

        scanButton.setOnClickListener { runScanner() }
        hvUdsButton.setOnClickListener { runHvUdsDiscovery() }
        aboutButton.setOnClickListener { showAbout() }
        faqButton.setOnClickListener { showFaq() }

        append("HOMEBD pronto.")
        append(localized("Diagnóstico OBD-II universal para veículos.", "Universal OBD-II diagnostics for vehicles."))
        append(localized("Selecione um adaptador OBD-II Bluetooth emparelhado e toque em LIGAR OBDII.", "Select a paired Bluetooth OBD-II adapter and tap CONNECT OBD-II."))
        liveDataLog.text = "Sem dados — ligue o OBD-II e execute SCAN PIDs."

        requestBtPermissions()
        refreshBluetoothList()
    }

    private fun sectionHeader(title: String, action: String, onAction: () -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val label = TextView(this).apply {
            text = title
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        val button = TextView(this).apply {
            text = action
            textSize = 10f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(8), 0, dp(8), 0)
            isClickable = true
            isFocusable = true
            background = GradientDrawable().apply {
                setColor(Color.rgb(55, 55, 55))
                cornerRadius = dp(3).toFloat()
            }
            setOnClickListener { onAction() }
        }

        row.addView(label, LinearLayout.LayoutParams(0, -1, 1f))
        row.addView(button, LinearLayout.LayoutParams(dp(88), dp(26)))
        return row
    }

    private fun installCopyOnLongPress(view: TextView, label: String) {
        view.setOnLongClickListener {
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText(label, view.text.toString()))
            Toast.makeText(this, "$label copiado", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun exportText(label: String, text: String, requestCode: Int) {
        if (text.isBlank()) {
            Toast.makeText(this, "Não existem dados para exportar.", Toast.LENGTH_SHORT).show()
            return
        }

        pendingExportText = text
        pendingExportLabel = label

        val safeName = label.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, "HOMEBD_${safeName}.txt")
        }
        try {
            startActivityForResult(intent, requestCode)
        } catch (_: Exception) {
            Toast.makeText(this, "Não foi possível abrir o exportador.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if ((requestCode == 101 || requestCode == 102) &&
            resultCode == RESULT_OK &&
            data?.data != null
        ) {
            val uri: Uri = data.data!!
            try {
                contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(pendingExportText.toByteArray(Charsets.UTF_8))
                    out.flush()
                }
                Toast.makeText(this, "$pendingExportLabel exportado.", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Erro ao exportar: ${e.message ?: "desconhecido"}", Toast.LENGTH_LONG).show()
            } finally {
                pendingExportText = ""
                pendingExportLabel = "HOMEBD"
            }
        }
    }

    private fun showAbout() {
        val pt = Locale.getDefault().language.equals("pt", ignoreCase = true)
        val title = if (pt) "Sobre o HOMEBD" else "About HOMEBD"
        val message = if (pt) {
            "HOMEBD\n" +
            "Home Onboard Monitoring Engine Board Data\n\n" +
            "HOMEBD — Funcionalidades desenvolvidas\n\n" +
            "• Aplicação Android para diagnóstico OBD-II\n" +
            "• Ligação a adaptadores OBD-II através de Bluetooth\n" +
            "• Deteção e seleção de dispositivos Bluetooth emparelhados\n" +
            "• Comunicação com interfaces compatíveis com ELM327\n" +
            "• Deteção automática do protocolo OBD-II\n" +
            "• Identificação dos PIDs suportados pelo veículo\n" +
            "• Leitura dinâmica e conversão dos parâmetros\n" +
            "• Live Data em tempo real\n" +
            "• Leitura de DTCs quando suportada\n" +
            "• Leitura de VIN quando disponível\n" +
            "• CAN / ISO-TP / UDS quando suportado\n" +
            "• Perfis específicos de fabricantes\n" +
            "• Operação 100% READ-ONLY\n\n" +
            "Nota de desenvolvimento:\n" +
            "O HOMEBD foi desenvolvido de raiz, com arquitetura, funcionalidades e soluções técnicas concebidas especificamente para este projeto e desenvolvidas para a própria aplicação.\n\n" +
            "Versão: BETA VERSION 1.5\n" +
            "Desenvolvido por: Katios"
        } else {
            "HOMEBD\n" +
            "Home Onboard Monitoring Engine Board Data\n\n" +
            "HOMEBD — Developed Features\n\n" +
            "• Android application for OBD-II diagnostics\n" +
            "• Bluetooth connection to OBD-II adapters\n            • Adapter layer designed for ELM327-compatible, STN and OBDLink interfaces\n" +
            "• Detection and selection of paired Bluetooth devices\n" +
            "• Communication with ELM327-compatible interfaces\n" +
            "• Automatic OBD-II protocol detection\n" +
            "• Identification of vehicle-supported PIDs\n" +
            "• Dynamic reading and conversion of parameters\n" +
            "• Real-time Live Data\n" +
            "• DTC reading when supported\n" +
            "• VIN reading when available\n" +
            "• CAN / ISO-TP / UDS when supported\n" +
            "• Manufacturer-specific profiles\n" +
            "• 100% READ-ONLY operation\n\n" +
            "Development Note:\n" +
            "HOMEBD was developed from the ground up, with its architecture, features, and technical solutions specifically designed and developed for this project and its application.\n\n" +
            "Version: BETA VERSION 2.5\n" +
            "Developed by: Katios"
        }

        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton(if (pt) "FECHAR" else "CLOSE", null)
            .show()
    }

    private fun showFaq() {
        val pt = Locale.getDefault().language.equals("pt", ignoreCase = true)
        val title = if (pt) "HOMEBD • FAQ" else "HOMEBD • FAQ"
        val faqText = if (pt) {
            "PERGUNTAS FREQUENTES\n\n" +
            "1. O que é o HOMEBD?\n" +
            "Aplicação Android para diagnóstico OBD-II, leitura de Live Data e comunicação com serviços REST.\n\n" +
            "2. Que adaptadores são suportados?\n" +
            "A aplicação foi desenhada para adaptadores Bluetooth compatíveis com ELM327 e transportes equivalentes suportados pela aplicação. A compatibilidade real depende do adaptador e do veículo.\n\n" +
            "3. O HOMEBD altera a ECU?\n" +
            "Não. A operação de diagnóstico da aplicação é READ-ONLY. Não são enviados comandos de escrita, programação, codificação ou adaptação.\n\n" +
            "4. O que significa 'Desconhecido' num sensor?\n" +
            "Significa que o valor ainda não foi recebido, não está disponível no ECU ou não foi possível converter a resposta. Não significa zero.\n\n" +
            "5. Como funciona o REST?\n" +
            "O HOMEBD publica os dados OBD no tópico base configurado, por exemplo homebd/live. O Home Assistant pode receber esses valores através do servidor REST.\n\n" +
            "6. Posso usar REST fora de casa?\n" +
            "Sim. Com Tailscale ativo no telemóvel e no Home Assistant, pode ser usada a ligação privada ao broker, por exemplo 100.92.242.12:1883.\n\n" +
            "7. O que faço se REST não ligar?\n" +
            "Confirma o Tailscale, o endereço do broker, a endpoint REST, o utilizador/password do servidor REST e o tópico base. Não uses a endpoint do Home Assistant como porta REST.\n\n" +
            "8. Para que serve SCAN PIDs?\n" +
            "Identifica os PIDs OBD-II que o veículo declara suportar e depois permite apresentar os parâmetros disponíveis.\n\n" +
            "9. O HOMEBD funciona com Android Auto?\n" +
            "A integração Android Auto está em desenvolvimento. A interface dedicada deve usar as APIs e categorias permitidas pelo Android Auto; o dashboard completo do telemóvel não é simplesmente reproduzido no ecrã do carro.\n\n" +
            "10. O FAQ vai ser atualizado?\n" +
            "Sim. O FAQ deve ser atualizado a cada versão relevante, refletindo funcionalidades implementadas, alterações de REST/OBD, compatibilidade e limitações conhecidas.\n\n" +
            "ATUALIZAÇÃO — V1.5\n" +
            "• FAQ integrado na aplicação\n" +
            "• Estado e controlo REST LIGAR/DESLIGAR\n" +
            "• Preparação da documentação para evolução Android Auto\n" +
            "• Documentação REST e desenvolvimento atualizada\n\n" +
            "Desenvolvido por: Katios"
        } else {
            "FREQUENTLY ASKED QUESTIONS\n\n" +
            "1. What is HOMEBD?\n" +
            "An Android application for OBD-II diagnostics, Live Data and REST communication.\n\n" +
            "2. Which adapters are supported?\n" +
            "The application is designed for Bluetooth adapters compatible with ELM327 and supported equivalent transports. Actual compatibility depends on the adapter and vehicle.\n\n" +
            "3. Does HOMEBD modify the ECU?\n" +
            "No. Diagnostic operation is READ-ONLY. No write, programming, coding or adaptation commands are sent.\n\n" +
            "4. What does 'Unknown' mean for a sensor?\n" +
            "The value has not been received, is unavailable from the ECU, or could not be converted. It does not mean zero.\n\n" +
            "5. How does REST work?\n" +
            "HOMEBD publishes OBD data under the configured base topic, for example homebd/live. Home Assistant can receive these values through servidor REST.\n\n" +
            "6. Can I use REST away from home?\n" +
            "Yes. With Tailscale active on the phone and Home Assistant, the private broker connection can be used, for example 100.92.242.12:1883.\n\n" +
            "7. What if REST does not connect?\n" +
            "Check Tailscale, broker address, port 1883, servidor REST credentials and base topic. Do not use Home Assistant port 8123 as the REST port.\n\n" +
            "8. What does SCAN PIDs do?\n" +
            "It identifies OBD-II PIDs declared as supported by the vehicle and then allows available parameters to be displayed.\n\n" +
            "9. Does HOMEBD work with Android Auto?\n" +
            "Android Auto integration is under development. A dedicated interface must use Android Auto permitted APIs and categories; the phone dashboard is not simply mirrored to the car display.\n\n" +
            "10. Will the FAQ be updated?\n" +
            "Yes. The FAQ should be updated with each relevant release to reflect implemented features, REST/OBD changes, compatibility and known limitations.\n\n" +
            "UPDATE — V1.5\n" +
            "• FAQ integrated in the application\n" +
            "• REST CONNECT/DISCONNECT status and control\n" +
            "• Android Auto development documentation prepared\n" +
            "• REST and development documentation updated\n\n" +
            "Developed by: Katios"
        }

        val textView = TextView(this).apply {
            text = faqText
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(dp(18), dp(8), dp(18), dp(8))
            setLineSpacing(0f, 1.08f)
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(textView, ViewGroup.LayoutParams(-1, -2))
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(scroll)
            .setPositiveButton(if (pt) "FECHAR" else "CLOSE", null)
            .show()
    }

    private fun actionButton(label: String, color: Int, textColor: Int): TextView =
        TextView(this).apply {
            text = label
            textSize = 14f
            setTextColor(textColor)
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            this.background = GradientDrawable().apply {
                setColor(color)
                cornerRadius = 8f
            }
        }

    private fun refreshBluetoothList() {
        val adapter = BluetoothAdapter.getDefaultAdapter()

        if (adapter == null) {
            setDevices(listOf("Bluetooth não disponível neste dispositivo"))
            return
        }

        try {
            if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
            ) {
                setDevices(listOf("Permitir Bluetooth para mostrar dispositivos"))
                return
            }

            if (!adapter.isEnabled) {
                setDevices(listOf("Bluetooth desligado — ative o Bluetooth"))
                return
            }

            val paired = adapter.bondedDevices.toList()
            val names = if (paired.isEmpty()) {
                listOf("Nenhum dispositivo emparelhado")
            } else {
                paired.map { device ->
                    val name = try { device.name ?: "Sem nome" } catch (_: SecurityException) { "Sem nome" }
                    "$name  (${device.address})"
                }
            }

            setDevices(names)
            append(localized("✓ Bluetooth: ${paired.size} dispositivo(s) emparelhado(s).", "✓ Bluetooth: ${paired.size} paired device(s)."))
        } catch (_: SecurityException) {
            setDevices(listOf("Permissão Bluetooth necessária"))
        }
    }

    private fun setDevices(names: List<String>) {
        devicesSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            names
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                ),
                10
            )
        }
    }

    private fun connect(device: BluetoothDevice) {
        stopLiveData()
        thread {
            try {
                runOnUiThread { status.text = "Estado: a ligar…" }
                closeTransport()

                var classicError: Exception? = null
                try {
                    if (Build.VERSION.SDK_INT >= 31 &&
                        checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
                    ) throw SecurityException("Permissão Bluetooth necessária")

                    socket = device.createRfcommSocketToServiceRecord(spp)
                    socket!!.connect()
                    input = socket!!.inputStream
                    output = socket!!.outputStream
                    usingBle = false
                    adapterKind = "OBD-II Bluetooth Classic"
                } catch (e: Exception) {
                    classicError = e
                    try { socket?.close() } catch (_: Exception) {}
                    socket = null
                    input = null
                    output = null

                    runOnUiThread { status.text = "Estado: a ligar por BLE…" }
                    connectBle(device)
                    usingBle = true
                    adapterKind = "OBD-II Bluetooth BLE"
                }

                elm("ATZ", 5000)
                Thread.sleep(1200)
                elm("ATE0", 2500)
                adapterIdentity = elm("ATI", 2500)
                adapterKind = identifyAdapter(adapterIdentity) + if (usingBle) " • BLE" else " • Bluetooth Classic"
                elm("ATL0", 2500)
                elm("ATS0", 2500)
                elm("ATSP0", 2500)

                val protocol = elm("ATDP", 2500)
                var protocolNumber = elm("ATDPN", 2500)
                    .trim().uppercase().removePrefix("A")

                if (protocol.isBlank()) throw IOException("Adaptador não respondeu ao ATDP")

                detectedProtocol = protocolNumber
                canActive = protocolNumber in setOf("6", "7", "8", "9", "A", "B", "C") ||
                    protocol.uppercase().contains("CAN") || protocol.uppercase().contains("J1939")

                // Some ELM327-compatible adapters report protocol 0/AUTO even
                // when the vehicle is already on CAN. Before giving up, test the
                // standard CAN variants with a harmless OBD-II capability query.
                // Keep the first protocol that produces a valid 0100 response
                // selected for the rest of the session.
                if (!canActive || protocolNumber == "0") {
                    val stable = stabilizeCanProtocol()
                    if (stable != null) {
                        protocolNumber = stable
                        detectedProtocol = stable
                        canActive = true
                        append("✓ CAN estabilizado: protocolo $stable (0100 respondeu).")
                    }
                }

                if (canActive) {
                    elm("ATCFC1", 1500)
                    append("✓ CAN detectado: ISO 15765-4 CAN 11-bit / 500 kbit/s.")
                    append("✓ CAN em modo READ-ONLY.")
                }

                runOnUiThread {
                    status.text = if (canActive)
                        "Estado: LIGADO • $adapterKind • CAN • READ-ONLY"
                    else
                        "Estado: LIGADO • $adapterKind • READ-ONLY"
                    scanButton.isEnabled = true
                    scanButton.alpha = 1f
                    hvUdsButton.isEnabled = true
                    hvUdsButton.alpha = 1f
                    connectButton.text = "DESLIGAR OBDII"
                }

                append("✓ Interface inicializada: $adapterKind")
                if (adapterIdentity.isNotBlank()) append("Identificação: ${clean(adapterIdentity)}")
                append("Transporte: ${if (usingBle) "Bluetooth Low Energy (BLE)" else "Bluetooth Classic / SPP"}")
                append("Protocolo: ${clean(protocol)}")
                append("Número de protocolo: ${if (protocolNumber.isBlank()) "desconhecido" else protocolNumber}")
                append("Pronto para SCAN PIDs.")
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Estado: erro de ligação"
                    connectButton.text = ui(localized("LIGAR OBDII", "CONNECT OBD-II"), "CONNECT OBD-II")
                    scanButton.isEnabled = false
                    scanButton.alpha = 0.55f
                    hvUdsButton.isEnabled = false
                    hvUdsButton.alpha = 0.55f
                }
                append("✕ ERRO: ${e.message ?: "erro desconhecido"}")
            }
        }
    }

    /**
     * Try the standard 11/29-bit CAN variants without sending any write or
     * diagnostic-control service. PID 0100 is a standard OBD-II capability
     * query and is used only as a transport validation.
     */
    private fun stabilizeCanProtocol(): String? {
        val candidates = listOf("6", "7", "8", "9")
        for (candidate in candidates) {
            try {
                elm("ATSP$candidate", 1800)
                elm("ATCAF1", 1000)
                elm("ATCFC1", 1000)
                val raw = elm("0100", 3000)
                if (isPositiveObdResponse(raw, 0x41, 0x00)) {
                    return candidate
                }
            } catch (_: Exception) {
                // Continue with the next standard CAN variant.
            }
        }
        elm("ATSP0", 1200)
        return null
    }

    private fun isPositiveObdResponse(raw: String, service: Int, pid: Int): Boolean {
        val hex = raw.uppercase(Locale.US).replace(Regex("[^0-9A-F]"), "")
        val marker = String.format(Locale.US, "%02X%02X", service, pid)
        return hex.contains(marker)
    }

    private fun connectBle(device: BluetoothDevice) {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) throw SecurityException("Permissão Bluetooth necessária")

        bleConnectedLatch = CountDownLatch(1)
        bleServicesLatch = CountDownLatch(1)
        bleNotificationLatch = CountDownLatch(1)
        bleGatt = device.connectGatt(this, false, bleCallback, BluetoothDevice.TRANSPORT_LE)

        if (bleConnectedLatch?.await(8, TimeUnit.SECONDS) != true) {
            closeBle()
            throw IOException("BLE: tempo limite ao ligar ao adaptador")
        }
        if (bleServicesLatch?.await(8, TimeUnit.SECONDS) != true || bleWriteCharacteristic == null) {
            closeBle()
            throw IOException("BLE: serviço OBD/UART não encontrado")
        }
        // Notifications must be enabled before any OBD command is sent.
        if (bleNotifyCharacteristic != null &&
            bleNotificationLatch?.await(5, TimeUnit.SECONDS) != true) {
            closeBle()
            throw IOException("BLE: notificações não foram ativadas")
        }
    }

    private val bleCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, statusCode: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                bleConnectedLatch?.countDown()
                if (Build.VERSION.SDK_INT >= 31 &&
                    checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
                ) return
                gatt.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                bleConnectedLatch?.countDown()
                bleServicesLatch?.countDown()
                bleNotificationLatch?.countDown()
                bleWriteLatch?.countDown()
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, statusCode: Int) {
            if (statusCode != BluetoothGatt.GATT_SUCCESS) {
                bleServicesLatch?.countDown()
                return
            }

            var write: BluetoothGattCharacteristic? = null
            var notify: BluetoothGattCharacteristic? = null

            for (service in gatt.services) {
                val serviceMatches = bleUartServices.contains(service.uuid)
                for (characteristic in service.characteristics) {
                    val props = characteristic.properties
                    val canWrite = props and BluetoothGattCharacteristic.PROPERTY_WRITE != 0 ||
                        props and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0
                    val canNotify = props and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0 ||
                        props and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0

                    if (canWrite && (serviceMatches || bleWriteUuids.contains(characteristic.uuid))) write = characteristic
                    if (canNotify && (serviceMatches || bleNotifyUuids.contains(characteristic.uuid))) notify = characteristic
                }
            }

            bleWriteCharacteristic = write
            bleNotifyCharacteristic = notify

            if (notify != null && Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
            ) {
                gatt.setCharacteristicNotification(notify, true)
                val descriptor = notify.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
                if (descriptor != null) {
                    descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    gatt.writeDescriptor(descriptor)
                }
            }
            bleServicesLatch?.countDown()
        }

        override fun onDescriptorWrite(
            gatt: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            statusCode: Int
        ) {
            if (descriptor.uuid == UUID.fromString("00002902-0000-1000-8000-00805F9B34FB")) {
                bleNotificationLatch?.countDown()
            }
        }

        override fun onCharacteristicWrite(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            statusCode: Int
        ) {
            bleWriteLatch?.countDown()
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            characteristic.value?.forEach { bleRx.offer(it) }
        }

        @Deprecated("Deprecated in API 33")
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            value.forEach { bleRx.offer(it) }
        }
    }

    private fun writeBle(data: ByteArray) {
        val gatt = bleGatt ?: throw IOException("BLE não ligado")
        val characteristic = bleWriteCharacteristic ?: throw IOException("BLE: característica de escrita não encontrada")
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) throw SecurityException("Permissão Bluetooth necessária")

        // Android GATT writes are asynchronous. Serialise every command so a
        // new OBD request can never overwrite the previous characteristic write.
        val latch = CountDownLatch(1)
        bleWriteLatch = latch
        characteristic.value = data
        characteristic.writeType =
            if (characteristic.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0)
                BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            else
                BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT

        if (!gatt.writeCharacteristic(characteristic)) {
            bleWriteLatch = null
            throw IOException("BLE: falha ao enviar comando")
        }

        if (characteristic.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE == 0) {
            if (!latch.await(3, TimeUnit.SECONDS)) {
                bleWriteLatch = null
                throw IOException("BLE: tempo limite na escrita")
            }
        } else {
            // Give the controller a short scheduling window before waiting for
            // its notification response.
            Thread.sleep(25)
        }
        bleWriteLatch = null
    }

    private fun closeBle() {
        try {
            if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
            ) return
            bleGatt?.disconnect()
            bleGatt?.close()
        } catch (_: Exception) {}
        bleGatt = null
        bleWriteCharacteristic = null
        bleNotifyCharacteristic = null
        bleRx.clear()
        usingBle = false
    }

    private fun closeTransport() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        input = null
        output = null
        closeBle()
        if (::connectButton.isInitialized) {
            runOnUiThread {
                connectButton.text = ui(localized("LIGAR OBDII", "CONNECT OBD-II"), "CONNECT OBD-II")
                scanButton.text = ui(localized("SCAN PIDs", "SCAN PIDs"), localized("SCAN PIDs", "SCAN PIDs"))
                hvUdsButton.isEnabled = false
                hvUdsButton.alpha = 0.55f
                hasScannedOnce = false
            }
        }
    }

    private fun identifyAdapter(identity: String): String {
        val id = identity.uppercase(Locale.US)
        return when {
            id.contains("STN") -> "STN / OBDLink"
            id.contains("OBDLINK") || id.contains("SCANTOOL") -> "OBDLink / compatível"
            id.contains("ELM327") -> "ELM327 compatível"
            id.isBlank() -> "OBD-II Bluetooth"
            else -> "OBD-II compatível"
        }
    }

    private fun elm(cmd: String, timeout: Long = 2500): String {
        if (usingBle) return elmBle(cmd, timeout)

        val out = output ?: return ""
        val ins = input ?: return ""
        try {
            out.write((cmd + "\r").toByteArray(Charsets.US_ASCII))
            out.flush()
        } catch (e: Exception) {
            throw IOException("Falha ao enviar $cmd: ${e.message}", e)
        }

        val start = System.currentTimeMillis()
        val buf = ByteArray(4096)
        val data = StringBuilder()
        while (System.currentTimeMillis() - start < timeout) {
            if (ins.available() > 0) {
                val n = ins.read(buf)
                if (n > 0) data.append(String(buf, 0, n, Charsets.US_ASCII))
                if (data.contains(">")) break
            } else Thread.sleep(30)
        }
        return data.toString().replace("\r", "\n").replace(">", "").trim()
    }

    private fun elmBle(cmd: String, timeout: Long): String {
        if (bleWriteCharacteristic == null) return ""
        bleRx.clear()
        writeBle((cmd + "\r").toByteArray(Charsets.US_ASCII))
        val deadline = System.currentTimeMillis() + timeout
        val data = StringBuilder()
        while (System.currentTimeMillis() < deadline) {
            val remaining = deadline - System.currentTimeMillis()
            val b = bleRx.poll(minOf(remaining, 100), TimeUnit.MILLISECONDS)
            if (b != null) {
                data.append(b.toInt().and(0xFF).toChar())
                if (data.contains(">")) break
            }
        }
        return data.toString().replace("\r", "\n").replace(">", "").trim()
    }

    @Volatile
    private var liveDataRunning = false

    private fun isTransportConnected(): Boolean = usingBle && bleWriteCharacteristic != null || output != null

    private fun stopLiveData() {
        liveDataRunning = false
    }

    /**
     * Experimental read-only UDS discovery for hybrid/high-voltage ECUs.
     *
     * This deliberately does NOT assume a proprietary battery DID or scaling.
     * It probes a small, conservative DID window on common physical CAN
     * diagnostic request IDs and reports only positive 0x62 responses as RAW
     * hexadecimal payloads. No SecurityAccess, writes, coding or programming
     * services are sent. A positive response is evidence that an identifier is
     * readable; it is not interpreted as a battery value until its definition
     * is verified for the vehicle.
     */
    private fun runHvUdsDiscovery() {
        thread {
            if (!isTransportConnected()) {
                append("⚠ OBDII não está ligado.")
                return@thread
            }
            runOnUiThread {
                hvUdsButton.isEnabled = false
                hvUdsButton.alpha = 0.55f
                status.text = "Estado: SCAN HV/UDS em execução…"
            }

            append("=== HV / UDS DISCOVERY — READ-ONLY ===")
            append("Sem DIDs proprietários assumidos e sem comandos de escrita.")
            append("1. Estabilizar CAN • 2. Descobrir ECUs • 3. Procurar respostas UDS 0x62.")

            try {
                // Force the standard 11-bit 500 kbit/s CAN profile first. If it
                // fails, the normal transport remains available and the scan
                // reports the failure instead of fabricating an ECU.
                elm("ATSP6", 2000)
                elm("ATCAF1", 1200)
                elm("ATCFC1", 1200)
                elm("ATH1", 1000)

                val discovered = discoverCanEcus()
                if (discovered.isEmpty()) {
                    append("· Nenhuma ECU física respondeu ao 0100 nos IDs 7E0–7EF.")
                    append("· O gateway/adaptador pode não permitir esta descoberta por endereço físico.")
                } else {
                    append("✓ ECUs OBD/CAN com resposta: ${discovered.joinToString(", ")}")
                }

                // Identification DIDs are intentionally limited to the public
                // standard/documented range. Do not turn an unknown response
                // into a battery measurement. A positive 0x62 is only recorded
                // as RAW data for later verification.
                val dids = (0xF180..0xF1FF).map { String.format(Locale.US, "%04X", it) }
                val targets = if (discovered.isEmpty()) (0x7E0..0x7E7).toList() else discovered
                var found = 0
                val results = mutableListOf<String>()

                for (requestId in targets) {
                    val req = String.format(Locale.US, "%03X", requestId)
                    val responseId = String.format(Locale.US, "%03X", requestId + 8)
                    elm("ATSH$req", 800)
                    elm("ATCRA$responseId", 800)

                    for (did in dids) {
                        val raw = elm("22$did", 750)
                        val payload = extractUdsDidPayload(raw, did)
                        if (payload.isNotBlank()) {
                            found++
                            val line = "• ECU $req • DID $did → $payload"
                            results.add(line)
                            append("✓ $line")
                        }
                    }
                }

                elm("ATCRA", 800)
                elm("ATH0", 800)
                // Keep the working CAN protocol if one was identified; only
                // fall back to AUTO when the adapter did not answer CAN at all.
                if (detectedProtocol.isBlank() || detectedProtocol == "0") {
                    elm("ATSP0", 1200)
                    detectedProtocol = elm("ATDPN", 1200).trim().uppercase().removePrefix("A")
                }

                runOnUiThread {
                    liveDataLog.append("\n=== HV / UDS DISCOVERY ===\n")
                    liveDataLog.append("• ECUs descobertas: ${if (discovered.isEmpty()) "nenhuma" else discovered.joinToString(", ")}\n")
                    if (results.isEmpty()) {
                        liveDataLog.append("• Nenhuma resposta UDS positiva na janela F180–F1FF.\n")
                        liveDataLog.append("• Isto não prova que o BMS não seja acessível; pode usar outro endereço, gateway ou sessão.\n")
                    } else {
                        liveDataLog.append("• $found resposta(s) UDS encontrada(s).\n")
                        results.forEach { liveDataLog.append(it + "\n") }
                        liveDataLog.append("• Valores apresentados como RAW; ainda não são convertidos para SOC, kW ou kWh.\n")
                    }
                    status.text = "Estado: LIGADO • SCAN HV/UDS concluído"
                    hvUdsButton.isEnabled = true
                    hvUdsButton.alpha = 1f
                }
            } catch (e: Exception) {
                append("✕ HV/UDS: ${e.message ?: "erro desconhecido"}")
                try { elm("ATCRA", 800); elm("ATH0", 800) } catch (_: Exception) {}
                runOnUiThread {
                    status.text = "Estado: LIGADO • SCAN HV/UDS com erro"
                    hvUdsButton.isEnabled = true
                    hvUdsButton.alpha = 1f
                }
            }
            append("=== FIM HV / UDS DISCOVERY ===")
        }
    }

    private fun discoverCanEcus(): List<Int> {
        val found = mutableListOf<Int>()
        for (requestId in 0x7E0..0x7EF) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)
            elm("ATSH$req", 600)
            elm("ATCRA$responseId", 600)
            val raw = elm("0100", 1200)
            if (isPositiveObdResponse(raw, 0x41, 0x00)) {
                found.add(requestId)
                append("✓ ECU descoberta: $req → $responseId")
            }
        }
        elm("ATCRA", 700)
        return found
    }

    private fun extractUdsDidPayload(raw: String, did: String): String {
        val hex = raw.uppercase(Locale.US).replace(Regex("[^0-9A-F]"), "")
        val marker = "62${did.uppercase(Locale.US)}"
        val start = hex.indexOf(marker)
        if (start < 0) return ""
        val dataStart = start + marker.length
        if (dataStart >= hex.length) return ""
        // Limit to the first 64 bytes of payload to keep logs manageable.
        val end = minOf(hex.length, dataStart + 128)
        return hex.substring(dataStart, end)
    }

    private fun runScanner() {
        thread {
            if (!isTransportConnected()) {
                append("⚠ OBDII não está ligado.")
                return@thread
            }

            if (liveDataRunning) {
                liveDataRunning = false
                Thread.sleep(250)
            }

            runOnUiThread {
                status.text = "Estado: SCAN OBD-II em execução…"
                scanButton.isEnabled = false
                scanButton.alpha = 0.55f
            }

            append("=== SCAN OBD-II ===")
            append("A consultar PIDs genéricos...")
            append("")

            val selectedProfile = manufacturerProfiles.getOrNull(manufacturerSpinner.selectedItemPosition)
                ?: manufacturerProfiles.first()

            append("Perfil: ${selectedProfile.name}")
            append("Modo: leitura apenas")
            if (canActive) {
                append("CAN: ativo • protocolo $detectedProtocol")
                append("ISO-TP: leitura através do ELM327")
            } else {
                append("CAN: não identificado pelo adaptador/protocolo atual")
            }
            append("")

            // Discover support once. LIVE DATA then repeatedly reads only these
            // confirmed PIDs, keeping the UI current without rescanning.
            val scanList = discoverSupportedStandardPids()

            runOnUiThread {
                liveDataLog.text = "LIVE DATA — ${selectedProfile.name}\n\n" +
                    if (scanList.isEmpty()) {
                        "Nenhum PID standard confirmado pelo veículo.\n\n" +
                            "O HOMEBD não inventa dados: apenas mostra parâmetros efetivamente suportados.\n"
                    } else {
                        "${scanList.size} PIDs standard suportados detetados.\n\n"
                    }
            }

            if (scanList.isEmpty()) {
                append("· Nenhum PID standard suportado foi confirmado.")
                runOnUiThread {
                    status.text = "Estado: LIGADO • SCAN concluído"
                    scanButton.isEnabled = true
                    scanButton.alpha = 1f
                    scanButton.text = if (hasScannedOnce) "RESCAN PIDs" else ui(localized("SCAN PIDs", "SCAN PIDs"), localized("SCAN PIDs", "SCAN PIDs"))
                }
                return@thread
            }

            if (canActive) {
                runCanReadOnlyChecks()
                prepareStandardObdSession()
            }

            append("=== LIVE DATA EM TEMPO REAL ===")
            append("Leitura automática contínua • intervalo aproximado 1 s")
            runOnUiThread {
                status.text = "Estado: LIGADO • LIVE DATA • tempo real"
                scanButton.isEnabled = true
                scanButton.alpha = 1f
                hvUdsButton.isEnabled = true
                hvUdsButton.alpha = 1f
                hasScannedOnce = true
                scanButton.text = "RESCAN PIDs"
            }

            liveDataRunning = true

            while (liveDataRunning && isTransportConnected()) {
                try {
                    val lines = mutableListOf<String>()
                    var liveFuelRateLph: Double? = null
                    var liveSpeedKmh: Double? = null
                    var liveFuelType: String? = null

                    for ((pid, label) in scanList) {
                        if (!liveDataRunning || !isTransportConnected()) break

                        val raw = readObdPidReliable(pid)
                        val result = if (raw.isBlank()) "· NO DATA — sem resposta válida 41 ${pid.substring(2).uppercase()}" else decodeObdPid(pid, raw)

                        if (pid.equals("015E", ignoreCase = true)) {
                            liveFuelRateLph = result
                                .substringBefore(" ")
                                .replace(",", ".")
                                .toDoubleOrNull()
                        }
                        if (pid.equals("0151", ignoreCase = true)) {
                            liveFuelType = result.trim()
                        }
                        if (pid.equals("010D", ignoreCase = true)) {
                            liveSpeedKmh = result
                                .substringBefore(" ")
                                .replace(",", ".")
                                .toDoubleOrNull()
                        }

                        lines.add("• $label: $result")
                        restBridge.publishPid(pid, label, result)
                    }

                    restBridge.publishAggregate(
                        scanList.map { (pid, _) ->
                            val line = lines.firstOrNull { it.startsWith("• ${pids[pid] ?: pid}:") } ?: ""
                            pid to line
                        }
                    )

                    if (!liveDataRunning) break

                    liveFuelRateLph?.let { fuelRate ->
                        lines.add(
                            "• Consumo de combustível: " +
                                if (liveSpeedKmh != null && liveSpeedKmh!! > 0.0) {
                                    "%.2f L/100 km".format(
                                        Locale.US,
                                        fuelRate * 100.0 / liveSpeedKmh!!
                                    )
                                } else {
                                    "— L/100 km (veículo parado)"
                                }
                        )
                    }

                    val electricalVehicle =
                        liveFuelType?.contains("Electric", ignoreCase = true) == true ||
                        liveFuelType?.contains("Bifuel electric", ignoreCase = true) == true

                    if (electricalVehicle) {
                        lines.add("• Consumo elétrico: Não disponível via OBD-II standard")
                        lines.add("• Potência elétrica: Não disponível via OBD-II standard")
                    }

                    val header = "LIVE DATA — ${selectedProfile.name}\n\n" +
                        "${scanList.size} PIDs standard suportados detetados.\n\n"

                    runOnUiThread {
                        if (liveDataRunning) {
                            val oldScrollY = liveDataScroll.scrollY
                            liveDataLog.text = header + lines.joinToString("\n")
                            renderGroupedLiveData(header, lines)
                            liveDataContainer.post {
                                // Keep the user's viewport fixed while values refresh.
                                liveDataScroll.scrollTo(0, oldScrollY.coerceAtMost(liveDataContainer.height))
                            }
                        }
                    }

                    Thread.sleep(900)
                } catch (e: Exception) {
                    if (liveDataRunning) {
                        append("⚠ LIVE DATA: ${e.message ?: "erro de leitura"}")
                    }
                    Thread.sleep(1200)
                }
            }

            runOnUiThread {
                hvUdsButton.isEnabled = isTransportConnected()
                hvUdsButton.alpha = if (isTransportConnected()) 1f else 0.55f
                status.text = if (isTransportConnected())
                    "Estado: LIGADO • LIVE DATA parado"
                else
                    ui(localized("Estado: desligado", "Status: disconnected"), "Status: disconnected")
                scanButton.isEnabled = isTransportConnected()
                scanButton.alpha = if (isTransportConnected()) 1f else 0.55f
                connectButton.text = if (isTransportConnected()) "DESLIGAR OBDII" else ui(localized("LIGAR OBDII", "CONNECT OBD-II"), "CONNECT OBD-II")
            }
        }
    }

    /**
     * Read-only CAN/ISO-TP checks.
     *
     * The ELM327 handles ISO 15765-4 segmentation/flow-control for normal
     * OBD-II requests. No ECU write service (2E/31/etc.) is sent here.
     */
    /**
     * Reads the standard Mode 01 supported-PID bitmaps first, then requests
     * only PIDs the vehicle reports as supported. This keeps every manufacturer
     * profile standards-based without copying proprietary manufacturer maps.
     */

    private val homeAssistantPrefs by lazy {
        getSharedPreferences("homebd_home_assistant", MODE_PRIVATE)
    }

    private fun homeAssistantLocalUrl(): String =
        homeAssistantPrefs.getString("local_url", "")?.trim().orEmpty()

    private fun homeAssistantExternalUrl(): String =
        homeAssistantPrefs.getString("external_url", "")?.trim().orEmpty()

    private fun validWebUrl(value: String): Boolean =
        value.startsWith("http://") || value.startsWith("https://")

    private fun configureHomeAssistantLink() {
        if (!isActivityUsable()) return
        try {
            configureHomeAssistantLinkInternal()
        } catch (_: Throwable) {
            Toast.makeText(this, "Não foi possível abrir a configuração do Home Assistant.", Toast.LENGTH_LONG).show()
        }
    }

    private fun configureHomeAssistantLinkInternal() {
        val localInput = EditText(this).apply {
            hint = "Endereço local (opcional)"
            setText(homeAssistantLocalUrl())
            textSize = 14f
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        val externalInput = EditText(this).apply {
            hint = "Endereço externo (opcional)"
            setText(homeAssistantExternalUrl())
            textSize = 14f
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_URI
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), 0)
            addView(localInput, LinearLayout.LayoutParams(-1, dp(52)))
            addView(externalInput, LinearLayout.LayoutParams(-1, dp(52)))
        }

        AlertDialog.Builder(this)
            .setTitle("HOMEBD • Home Assistant")
            .setMessage("Configure, sem endereço predefinido, um acesso local e/ou externo. A porta 8123 é a porta web do Home Assistant; REST usa outra porta.")
            .setView(box)
            .setNegativeButton(restText("cancel"), null)
            .setPositiveButton("GUARDAR") { _, _ ->
                val local = localInput.text.toString().trim().trimEnd('/')
                val external = externalInput.text.toString().trim().trimEnd('/')
                val localOk = local.isBlank() || validWebUrl(local)
                val externalOk = external.isBlank() || validWebUrl(external)
                if (localOk && externalOk) {
                    homeAssistantPrefs.edit()
                        .putString("local_url", local)
                        .putString("external_url", external)
                        .remove("url")
                        .apply()
                    try {
                        homeAssistantButton.text = ui(localized("ABRIR HOME ASSISTANT", "OPEN HOME ASSISTANT"), "OPEN HOME ASSISTANT")
                    } catch (_: Throwable) {}
                    append("✓ Ligações Home Assistant guardadas (local/external).")
                } else {
                    Toast.makeText(this, "Use http:// ou https:// nos endereços preenchidos.", Toast.LENGTH_LONG).show()
                }
            }
            .show()
    }

    private fun openHomeAssistant() {
        try {
            if (!isActivityUsable()) return
            val local = homeAssistantLocalUrl()
            val external = homeAssistantExternalUrl()
            when {
                local.isNotBlank() && external.isNotBlank() -> chooseHomeAssistantAccess(local, external)
                local.isNotBlank() -> openWebUrl(local)
                external.isNotBlank() -> openWebUrl(external)
                else -> configureHomeAssistantLink()
            }
        } catch (_: Throwable) {
            Toast.makeText(this, "Não foi possível abrir o Home Assistant.", Toast.LENGTH_LONG).show()
        }
    }

    private fun chooseHomeAssistantAccess(local: String, external: String) {
        AlertDialog.Builder(this)
            .setTitle("HOMEBD • Home Assistant")
            .setItems(arrayOf("ACESSO LOCAL", "ACESSO EXTERNO", "CONFIGURAR")) { _, which ->
                when (which) {
                    0 -> openWebUrl(local)
                    1 -> openWebUrl(external)
                    2 -> configureHomeAssistantLink()
                }
            }
            .show()
    }

    private fun openWebUrl(value: String) {
        if (!validWebUrl(value)) {
            configureHomeAssistantLink()
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(value)))
        } catch (_: Exception) {
            Toast.makeText(this, "Não foi possível abrir o Home Assistant.", Toast.LENGTH_LONG).show()
        }
    }

    private fun showRestDialogSafely() {
        if (!isActivityUsable()) return
        try {
            showRestDialog()
        } catch (t: Throwable) {
            append("⚠ Não foi possível abrir a configuração REST: ${t.message ?: t.javaClass.simpleName}")
            try { Toast.makeText(this, "Não foi possível abrir a configuração REST.", Toast.LENGTH_LONG).show() } catch (_: Throwable) {}
        }
    }

    private fun showRestDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), 0)
        }

        fun field(hint: String, value: String, password: Boolean = false): EditText =
            EditText(this).apply {
                this.hint = hint
                setText(value)
                textSize = 14f
                inputType = if (password) {
                    android.text.InputType.TYPE_CLASS_TEXT or
                        android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
                } else {
                    android.text.InputType.TYPE_CLASS_TEXT or
                        android.text.InputType.TYPE_TEXT_VARIATION_URI
                }
            }

        val modeLabel = TextView(this).apply {
            text = restText("mode")
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(4), 0, dp(2))
        }
        val modeSpinner = Spinner(this)
        val modes = listOf(restText("auto"), "Só local", "Só externo")
        modeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, modes)
        modeSpinner.setSelection(when (restBridge.mode) {
            HomeBdRestBridge.Mode.AUTO -> 0
            HomeBdRestBridge.Mode.LOCAL -> 1
            HomeBdRestBridge.Mode.EXTERNAL -> 2
        })

        val local = field(restText("local"), restBridge.localBaseUrl)
        val external = field(restText("external"), restBridge.externalBaseUrl)
        val token = field("Token de acesso Home Assistant (Long-Lived Access Token)", restBridge.token, true)
        val apiPath = field("API (normalmente /api)", restBridge.basePath)

        val tokenRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        token.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        val tokenEye = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_view)
            contentDescription = "Mostrar token"
            background = null
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setOnClickListener {
                val pos = token.selectionStart.coerceAtLeast(0)
                val visible = token.transformationMethod == null
                token.transformationMethod = if (visible) {
                    android.text.method.PasswordTransformationMethod.getInstance()
                } else {
                    android.text.method.HideReturnsTransformationMethod.getInstance()
                }
                token.setSelection(pos.coerceAtMost(token.text.length))
                contentDescription = if (visible) "Mostrar token" else "Ocultar token"
            }
        }
        tokenRow.addView(token)
        tokenRow.addView(tokenEye, LinearLayout.LayoutParams(dp(48), dp(48)))

        box.addView(modeLabel)
        box.addView(modeSpinner)
        box.addView(local)
        box.addView(external)
        box.addView(tokenRow)
        box.addView(apiPath)

        val dialog = AlertDialog.Builder(this)
            .setTitle(restText("title"))
            .setMessage(restText("description"))
            .setView(box)
            .setNegativeButton(restText("cancel"), null)
            .setNeutralButton(restText("disconnect"), null)
            .setPositiveButton(restText("test"), null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                restBridge.disconnect()
                restButton.text = ui(localized("REST LIGAR", "REST CONNECT"), "REST CONNECT")
                restStatusView.text = "REST: desligado"
                append("✓ REST desligado.")
                dialog.dismiss()
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val selectedMode = when (modeSpinner.selectedItemPosition) {
                    1 -> HomeBdRestBridge.Mode.LOCAL
                    2 -> HomeBdRestBridge.Mode.EXTERNAL
                    else -> HomeBdRestBridge.Mode.AUTO
                }
                restBridge.save(
                    local.text.toString(),
                    external.text.toString(),
                    token.text.toString(),
                    apiPath.text.toString(),
                    selectedMode
                )
                restStatusView.text = "REST: a ligar…"
                restBridge.connect { ok, msg ->
                    runOnUiThread {
                        restStatusView.text =
                            if (ok) "REST: ligado • Home Assistant • ${restBridge.activeMode ?: ""}"
                            else "REST: $msg"
                        restButton.text = if (ok) ui("REST DESLIGAR", "REST DISCONNECT") else ui(localized("REST LIGAR", "REST CONNECT"), "REST CONNECT")
                        append(if (ok) "✓ $msg" else "⚠ $msg\nDica: use http://IP_DO_HOME_ASSISTANT:8123 ou https://... e confirme o token.")
                    }
                }
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun renderGroupedLiveData(header: String, lines: List<String>) {
        liveDataContainer.removeAllViews()

        val intro = TextView(this).apply {
            text = header.trimEnd()
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(dp(6), dp(4), dp(6), dp(8))
        }
        liveDataContainer.addView(intro, LinearLayout.LayoutParams(-1, -2))

        val groups = linkedMapOf(
            "MOTOR" to mutableListOf<String>(),
            "TEMPERATURAS" to mutableListOf<String>(),
            "COMBUSTÍVEL" to mutableListOf<String>(),
            "ADMISSÃO / ACELERADOR" to mutableListOf<String>(),
            "ELÉTRICO / HÍBRIDO" to mutableListOf<String>(),
            "EMISSÕES" to mutableListOf<String>(),
            ui(localized("DIAGNÓSTICO", "DIAGNOSTICS"), "DIAGNOSTICS") to mutableListOf<String>()
        )

        fun addGroup(name: String, line: String) { groups[name]?.add(line) }
        lines.forEach { line ->
            val l = line.lowercase(Locale.getDefault())
            when {
                listOf("temperatura", "temperature", "catalisador", "arrefecimento", "admissão", "intake air", "óleo", "oil", "exterior").any { l.contains(it) } -> addGroup("TEMPERATURAS", line)
                listOf("combustível", "fuel", "fuel trim", "pressão de combustível", "fuel pressure", "injeção").any { l.contains(it) } -> addGroup("COMBUSTÍVEL", line)
                listOf("acelerador", "throttle", "borboleta", "map:", "maf", "pressão de admissão", "intake").any { l.contains(it) } -> addGroup("ADMISSÃO / ACELERADOR", line)
                listOf("o2", "lambda", "nox", "emission", "emissões", "egr", "particulate", "dpf", "catalyst").any { l.contains(it) } -> addGroup("EMISSÕES", line)
                listOf("voltagem", "voltage", "potência elétrica", "consumo elétrico", "energia elétrica", "hybrid", "electric", "bateria").any { l.contains(it) } -> addGroup("ELÉTRICO / HÍBRIDO", line)
                listOf("vin", "pid", "dtc", "diagnóstico", "diagnostic", "ecu", "adaptador").any { l.contains(it) } -> addGroup(ui(localized("DIAGNÓSTICO", "DIAGNOSTICS"), "DIAGNOSTICS"), line)
                else -> addGroup("MOTOR", line)
            }
        }

        groups.forEach { (name, items) ->
            if (items.isEmpty()) return@forEach
            val expanded = liveGroupExpanded.getOrPut(name) { true }
            val headerView = TextView(this).apply {
                text = (if (expanded) "▼ " else "▶ ") + name + "  •  ${items.size}"
                textSize = 12f
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.rgb(45, 45, 45))
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(7), dp(8), dp(7))
                isClickable = true
                setOnClickListener {
                    liveGroupExpanded[name] = !(liveGroupExpanded[name] ?: true)
                    renderGroupedLiveData(header, lines)
                }
            }
            liveDataContainer.addView(headerView, LinearLayout.LayoutParams(-1, dp(34)).apply {
                setMargins(0, dp(3), 0, dp(1))
            })

            if (expanded) {
                val body = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(4), dp(2), dp(4), dp(4))
                }
                items.forEach { item ->
                    val lineView = TextView(this).apply {
                        text = item
                        textSize = 13f
                        setTextColor(Color.LTGRAY)
                        setPadding(dp(10), dp(5), dp(8), dp(5))
                        isClickable = true
                        setOnLongClickListener {
                            val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("HOMEBD LIVE DATA", item))
                            Toast.makeText(this@MainActivity, "Dado copiado", Toast.LENGTH_SHORT).show()
                            true
                        }
                    }
                    body.addView(lineView, LinearLayout.LayoutParams(-1, -2))
                }
                body.setOnLongClickListener {
                    val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("HOMEBD $name", items.joinToString("\n")))
                    Toast.makeText(this, "$name copiado", Toast.LENGTH_SHORT).show()
                    true
                }
                liveDataContainer.addView(body, LinearLayout.LayoutParams(-1, -2))
            }
        }
    }

    private fun prepareStandardObdSession() {
        if (!isTransportConnected()) return
        val protocol = detectedProtocol.trim().uppercase(Locale.US)
        if (protocol.isNotBlank() && protocol != "0") elm("ATSP$protocol", 1500)
        elm("ATCAF1", 1000)
        elm("ATCFC1", 1000)
        elm("ATH0", 1000)
        elm("ATCRA", 1000)
        elm("ATSH7DF", 1000)
        elm("ATAT1", 1000)
    }

    private fun discoverSupportedStandardPids(): List<Pair<String, String>> {
        prepareStandardObdSession()
        val blocks = listOf("0100", "0120", "0140", "0160", "0180", "01A0", "01C0")
        val supported = linkedSetOf<Int>()

        blocks.forEach { supportPid ->
            val raw = elm(supportPid, 3000)
            val bytes = obdPayloadBytes(raw, 0x41, supportPid.substring(2).toInt(16))
            if (bytes.size >= 4) {
                val bitmap = (bytes[0] shl 24) or (bytes[1] shl 16) or
                    (bytes[2] shl 8) or bytes[3]
                val base = supportPid.substring(2).toInt(16) + 1
                for (bit in 0..31) {
                    if ((bitmap and (1 shl (31 - bit))) != 0) {
                        supported.add(base + bit)
                    }
                }
            }
        }

        val result = pids.entries.filter { (pid, _) ->
            val value = pid.substring(2).toInt(16)
            value in supported && value !in setOf(0x20, 0x40, 0x60, 0x80, 0xA0, 0xC0)
        }.map { it.key to it.value }

        append("✓ Capacidade OBD-II: ${result.size} PID(s) suportado(s) detetado(s).")
        return result
    }

    private fun obdPayloadBytes(raw: String, service: Int, pid: Int): List<Int> {
        val hex = raw.uppercase().replace(Regex("[^0-9A-F]"), "")
        if (hex.length < 4) return emptyList()

        val bytes = ArrayList<Int>()
        var i = 0
        while (i + 1 < hex.length) {
            hex.substring(i, i + 2).toIntOrNull(16)?.let { bytes.add(it) }
            i += 2
        }

        // ELM327 pode devolver cabeçalhos CAN/ISO-TP e bytes de comprimento
        // antes de 41 <PID>. Localizar o par de resposta evita interpretar
        // esses bytes como parte do valor do PID.
        for (index in 0 until bytes.size - 1) {
            if (bytes[index] == service && bytes[index + 1] == pid) {
                return bytes.drop(index + 2)
            }
        }
        return emptyList()
    }

    /**
     * Lê um PID OBD-II confirmado, com recuperação da sessão quando o
     * adaptador perde temporariamente o filtro/cabeçalho CAN.
     * Apenas respostas positivas 41 <PID> são aceites como dados.
     */
    private fun readObdPidReliable(pid: String): String {
        val pidNum = pid.substring(2).toIntOrNull(16) ?: return ""
        repeat(2) { attempt ->
            val raw = elm(pid, 1800)
            if (obdPayloadBytes(raw, 0x41, pidNum).isNotEmpty()) return raw

            // Recuperar a sessão standard antes da segunda tentativa.
            if (attempt == 0 && isTransportConnected()) {
                prepareStandardObdSession()
                Thread.sleep(80)
            }
        }
        return ""
    }

    private fun decodeObdPid(pid: String, raw: String): String {
        val pidNum = pid.substring(2).toIntOrNull(16) ?: return classifyResponse(raw)
        val payload = obdPayloadBytes(raw, 0x41, pidNum)
        if (payload.isEmpty()) return classifyResponse(raw)

        fun u16(): Int = ((payload.getOrNull(0) ?: 0) shl 8) or (payload.getOrNull(1) ?: 0)
        fun u32(): Long = ((payload.getOrNull(0)?.toLong() ?: 0L) shl 24) or
            ((payload.getOrNull(1)?.toLong() ?: 0L) shl 16) or
            ((payload.getOrNull(2)?.toLong() ?: 0L) shl 8) or
            (payload.getOrNull(3)?.toLong() ?: 0L)
        fun pct(a: Int): String = "%.1f %%".format(Locale.US, a * 100.0 / 255.0)
        fun signedPct(a: Int): String = "%.1f %%".format(Locale.US, a * 100.0 / 128.0 - 100.0)
        fun temp(a: Int): String = "${a - 40} °C"

        return when (pid.uppercase()) {
            "0101" -> decodeMonitorStatus(payload)
            "0102" -> "DTC status: 0x${u16().toString(16).uppercase().padStart(4, '0')}"
            "0103" -> decodeFuelSystemStatus(payload.first())
            "0104" -> pct(payload.first())
            "0105", "010F", "0146", "015C" -> temp(payload.first())
            "0106", "0107", "0108", "0109", "012D", "0155", "0156", "0157", "0158" -> signedPct(payload.first())
            "010A" -> "${payload.first() * 3} kPa"
            "010B" -> "${payload.first()} kPa"
            "010C" -> "%.0f rpm".format(Locale.US, u16() / 4.0)
            "010D" -> "${payload.first()} km/h"
            "010E" -> "%.1f °".format(Locale.US, payload.first() / 2.0 - 64.0)
            "0110" -> "%.2f g/s".format(Locale.US, u16() / 100.0)
            "0111", "0145", "0147", "0148", "0149", "014A", "014B", "015A" -> pct(payload.first())
            "0112" -> decodeSecondaryAirStatus(payload.first())
            "0113", "011D" -> "Sensor presence bitmap: 0x${payload.first().toString(16).uppercase().padStart(2, '0')}"
            in setOf("0114", "0115", "0116", "0117", "0118", "0119", "011A", "011B") ->
                decodeOxygenVoltageTrim(payload)
            "011C" -> decodeObdStandard(payload.first())
            "011E" -> if (payload.first() and 1 == 1) "Active" else "Inactive"
            "011F" -> "${u16()} s (${u16() / 60} min)"
            "0120", "0140", "0160", "0180", "01A0", "01C0" -> "Supported PID bitmap: 0x${u32().toString(16).uppercase().padStart(8, '0')}"
            "0121", "0131" -> "${u16()} km"
            "0122" -> "%.0f kPa".format(Locale.US, u16() * 0.079)
            "0123" -> "${u16() * 10} kPa"
            in setOf("0124", "0125", "0126", "0127", "0128", "0129", "012A", "012B") -> decodeOxygenWideVoltage(payload)
            "012C" -> pct(payload.first())
            "012E" -> pct(payload.first())
            "012F" -> pct(payload.first())
            "0130" -> "${payload.first()} warm-ups"
            "0132" -> "${signedU16(payload) * 0.25} Pa"
            "0133" -> "${payload.first()} kPa"
            in setOf("0134", "0135", "0136", "0137", "0138", "0139", "013A", "013B") -> decodeOxygenWideVoltage(payload)
            "013C", "013D", "013E", "013F" -> "%.1f °C".format(Locale.US, u16() / 10.0 - 40.0)
            "0141" -> decodeMonitorStatus(payload)
            "0142" -> "%.3f V".format(Locale.US, u16() / 1000.0)
            "0143" -> "%.1f %%".format(Locale.US, u16() * 100.0 / 255.0)
            "0144" -> "%.3f ratio".format(Locale.US, u16() / 32768.0)
            "0145" -> pct(payload.first())
            "0146" -> temp(payload.first())
            "014C" -> pct(payload.first())
            "014D", "014E" -> "${u16()} min"
            "0151" -> decodeFuelType(payload.first())
            "0152" -> pct(payload.first())
            "0153" -> "%.3f kPa".format(Locale.US, u16() / 200.0)
            "0154" -> "${signedU16(payload)} Pa"
            "0159" -> "%.0f kPa".format(Locale.US, u16() * 10.0)
            "015B" -> pct(payload.first())
            "015C" -> temp(payload.first())
            "015D" -> "%.2f °".format(Locale.US, u16() / 128.0 - 210.0)
            "015E" -> "%.2f L/h".format(Locale.US, u16() / 20.0)
            "015F", "0161", "0162", "0163" -> "%.1f %% torque".format(Locale.US, payload.first() - 125.0)
            "0165" -> "%.1f mA".format(Locale.US, u16() * 0.001)
            "0166", "0167", "0168", "0169", "0184" -> temp(payload.first())
            "016A", "016E" -> pct(payload.first())
            "016B", "016F" -> "${u16()} kPa"
            "016C" -> "%.1f %%".format(Locale.US, payload.first() * 100.0 / 255.0)
            "016D" -> temp(payload.first())
            "0170", "0171", "0172" -> "Dados multi-byte — não simplificado"
            "0173" -> "${u16()} kPa"
            "0174" -> "${u16()} rpm"
            "0175", "0176", "0177", "0178", "0179", "017A", "017C" -> "Dados multi-byte — não simplificado"
            "017B", "017D", "017E", "017F" -> "Dados multi-byte — não simplificado"
            "0183", "01A1", "01A7", "01A8" -> "NOx: dados multi-byte — não simplificado"
            "0185", "0186", "0187", "0188", "019A", "019D", "01A3" -> "Dados multi-byte — não simplificado"
            else -> "${payload.joinToString(" ") { "%02X".format(it) }} (raw)"
        }
    }

    private fun decodeMonitorStatus(p: List<Int>): String {
        if (p.size < 4) return "Monitor bitmap: ${p.joinToString(" ") { "%02X".format(it) }}"
        val mil = (p[0] and 0x80) != 0
        val dtcCount = p[0] and 0x7F
        val misfireReady = (p[1] and 0x01) != 0
        val fuelReady = (p[1] and 0x02) != 0
        return "MIL=${if (mil) "ON" else "OFF"} • DTC=$dtcCount • monitors=${if (misfireReady || fuelReady) "available" else "not reported"}"
    }

    private fun decodeFuelSystemStatus(code: Int): String = when (code) {
        0x01 -> "Open loop — insufficient engine temperature"
        0x02 -> "Closed loop — using oxygen sensor feedback"
        0x04 -> "Open loop — engine load / fuel cut"
        0x08 -> "Open loop — system fault"
        0x10 -> "Closed loop — fault with at least one sensor"
        else -> "Code 0x${code.toString(16).uppercase().padStart(2, '0')}"
    }

    private fun decodeSecondaryAirStatus(code: Int): String = when (code) {
        0x01 -> "Upstream of catalytic converter"
        0x02 -> "Downstream of catalytic converter"
        0x04 -> "Atmosphere"
        else -> "Code 0x${code.toString(16).uppercase().padStart(2, '0')}"
    }

    private fun decodeObdStandard(code: Int): String = when (code) {
        0x01 -> "OBD-II as defined by CARB"
        0x02 -> "OBD as defined by EPA"
        0x03 -> "OBD and OBD-II"
        0x04 -> "OBD-I"
        0x05 -> "Not intended for OBD"
        0x06 -> "EOBD"
        0x07 -> "EOBD and OBD-II"
        0x08 -> "EOBD and OBD"
        0x09 -> "EOBD, OBD and OBD-II"
        0x0A -> "JOBD"
        else -> "Standard code 0x${code.toString(16).uppercase().padStart(2, '0')}"
    }

    private fun decodeFuelType(code: Int): String = when (code) {
        0x01 -> "Gasoline"
        0x02 -> "Methanol"
        0x03 -> "Ethanol"
        0x04 -> "Diesel"
        0x05 -> "LPG"
        0x06 -> "CNG"
        0x07 -> "Propane"
        0x08 -> "Electric"
        0x09 -> "Bifuel gasoline"
        0x0A -> "Bifuel methanol"
        0x0B -> "Bifuel ethanol"
        0x0C -> "Bifuel LPG"
        0x0D -> "Bifuel CNG"
        0x0E -> "Bifuel propane"
        0x0F -> "Bifuel electric"
        0x10 -> "Bifuel electric + combustion"
        else -> "Fuel type code 0x${code.toString(16).uppercase().padStart(2, '0')}"
    }

    private fun decodeOxygenVoltageTrim(p: List<Int>): String {
        val voltage = p.getOrNull(0)?.times(0.005) ?: 0.0
        val trim = p.getOrNull(1)?.let { it * 100.0 / 128.0 - 100.0 }
        return if (trim == null) "%.3f V".format(Locale.US, voltage)
        else "%.3f V • trim %.1f %%".format(Locale.US, voltage, trim)
    }

    private fun signedU16(p: List<Int>): Int {
        if (p.size < 2) return 0
        val value = (p[0] shl 8) or p[1]
        return if ((value and 0x8000) != 0) value - 0x10000 else value
    }

    private fun decodeOxygenWideVoltage(p: List<Int>): String {
        if (p.size < 4) return "Dados insuficientes"
        val ratioRaw = (p[0] shl 8) or p[1]
        val voltageRaw = (p[2] shl 8) or p[3]
        val ratio = ratioRaw * 2.0 / 65536.0
        val voltage = voltageRaw * 8.0 / 65536.0
        return "lambda %.3f • %.3f V".format(Locale.US, ratio, voltage)
    }

    private fun runCanReadOnlyChecks() {
        append("=== CAN READ-ONLY ===")
        append("ISO-TP: consultar identificação standard OBD-II")

        val selectedProfile = manufacturerProfiles.getOrNull(manufacturerSpinner.selectedItemPosition)
        when (selectedProfile?.name) {
            "Stellantis • Opel / Vauxhall", "Stellantis" -> runStellantisUdsReadOnly()
            "Renault / Dacia" -> runRenaultUdsReadOnly()
            "Volkswagen / Audi / SEAT / Škoda" -> runVagUdsReadOnly()
            "Ford" -> runFordUdsReadOnly()
            "Nissan / INFINITI" -> runNissanUdsReadOnly()
            "Tesla" -> runTeslaUdsReadOnly()
            "Subaru" -> runSubaruReadOnly()
            "Mitsubishi" -> runMitsubishiReadOnly()
            "Lexus" -> runLexusReadOnly()
            "Mazda" -> runMazdaReadOnly()
            "Isuzu" -> runIsuzuReadOnly()
            "BMW" -> runGenericManufacturerUdsReadOnly("BMW", listOf(UdsDid("F190", "VIN")))
            "Mercedes-Benz" -> runGenericManufacturerUdsReadOnly("Mercedes-Benz", listOf(UdsDid("F190", "VIN")))
            "Volvo" -> runGenericManufacturerUdsReadOnly("Volvo", listOf(UdsDid("F190", "VIN")))
            "Honda" -> runGenericManufacturerUdsReadOnly("Honda / Acura", listOf(UdsDid("F190", "VIN")))
            "Hyundai / Kia" -> runGenericManufacturerUdsReadOnly("Hyundai / Kia", listOf(UdsDid("F190", "VIN")))
            "Jaguar / Land Rover" -> runGenericManufacturerUdsReadOnly("Jaguar / Land Rover", listOf(UdsDid("F190", "VIN")))
            "Porsche" -> runGenericManufacturerUdsReadOnly("Porsche", listOf(UdsDid("F190", "VIN")))
            "Suzuki" -> runGenericManufacturerUdsReadOnly("Suzuki", listOf(UdsDid("F190", "VIN")))
            "Geely / Polestar" -> runGenericManufacturerUdsReadOnly("Geely / Polestar", listOf(UdsDid("F190", "VIN")))
        }

        // Mode 09 PID 02: VIN, when the vehicle exposes it.
        val vinRaw = elm("0902", 5000)
        val vin = extractObdAscii(vinRaw, 0x49, 0x02)
        reportCanValue("VIN", vinRaw, vin)

        // Mode 09 PID 04: calibration ID, when available.
        val calRaw = elm("0904", 5000)
        val cal = extractObdAscii(calRaw, 0x49, 0x04)
        reportCanValue("Calibration ID", calRaw, cal)

        // Mode 01 PID 00 is a standard CAN/OBD capability query.
        val pid00 = elm("0100", 3000)
        append("CAN 0100: ${classifyResponse(pid00)}")

        runOnUiThread {
            liveDataLog.append(
                "• CAN: ${if (canActive) "ATIVO / READ-ONLY" else "não disponível"}\\n"
            )
            if (vin.isNotBlank()) liveDataLog.append("• VIN: $vin\\n")
            if (cal.isNotBlank()) liveDataLog.append("• Calibration ID: $cal\\n")
        }
    }

    /**
     * Stellantis UDS READ-ONLY scanner.
     *
     * This does not unlock or bypass a Secure Gateway. It only sends UDS
     * ReadDataByIdentifier (0x22) requests to common 11-bit diagnostic
     * request IDs and accepts positive responses (0x62).
     */
    private fun runGenericManufacturerUdsReadOnly(name: String, dids: List<UdsDid>) {
        append("=== $name UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("A procurar ECUs nos IDs 7E0–7E7…")
        append("Sem mapa proprietário: apenas DIDs standard configurados.")

        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)
            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)
            for (did in dids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread { liveDataLog.append("• ECU $req — ${did.label}: $value\n") }
                }
            }
        }
        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")
        if (found == 0) append("· Nenhum DID UDS $name respondeu.")
        else append("✓ $found leitura(s) UDS $name obtida(s).")
        append("=== FIM $name UDS ===")
    }

    private fun runStellantisUdsReadOnly() {
        append("=== STELLANTIS UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("A procurar ECUs nos IDs 7E0–7E7…")

        // ELM327: CAN 11-bit, automatic formatting and flow control.
        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)

            // Restrict replies to the matching physical ECU response.
            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in stellantisDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        // Return ELM to automatic protocol/headers for normal OBD-II use.
        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhum DID UDS Stellantis respondeu.")
            append("· Isto pode significar ECU não acessível, DID não suportado ou SGW/rede a bloquear a leitura.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM STELLANTIS UDS ===")
    }

    /**
     * Renault / Dacia UDS READ-ONLY scanner.
     *
     * Uses only standardized identification DIDs from the F18x/F19x range.
     * No security access, session switching, coding or programming is sent.
     */
    private fun runRenaultUdsReadOnly() {
        append("=== RENAULT / DACIA UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("DIDs: identificação ECU standard ISO 14229")
        append("A procurar ECUs nos IDs 7E0–7E7…")

        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)

            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in renaultDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhum DID UDS Renault / Dacia respondeu.")
            append("· Isto pode significar ECU não acessível, DID não suportado ou rede/SGW a bloquear a leitura.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM RENAULT / DACIA UDS ===")
    }

    /**
     * Volkswagen / Audi / SEAT / Škoda UDS READ-ONLY scanner.
     *
     * Only UDS ReadDataByIdentifier (0x22) is transmitted. No security access,
     * coding, adaptation, routine control or ECU programming is attempted.
     */
    private fun runVagUdsReadOnly() {
        append("=== VAG UDS READ-ONLY ===")
        append("Volkswagen / Audi / SEAT / Škoda")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("A procurar ECUs nos IDs 7E0–7E7…")

        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)

            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in vagDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhum DID UDS VAG respondeu.")
            append("· ECU não acessível, DID não suportado ou gateway/rede a bloquear a leitura.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM VAG UDS ===")
    }

    /**
     * Ford UDS READ-ONLY scanner.
     *
     * Only UDS ReadDataByIdentifier (0x22) is transmitted. No security access,
     * coding, adaptation, routine control or ECU programming is attempted.
     */
    private fun runNissanUdsReadOnly() {
        append("=== NISSAN / INFINITI UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("A procurar ECUs nos IDs 7E0–7E7…")
        append("Nota: não são usados mapas proprietários Nissan/INFINITI sem documentação pública verificável.")

        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)
            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in nissanDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhum DID UDS Nissan / INFINITI respondeu.")
            append("· ECU/rede/DID pode não suportar a leitura ou pode exigir ferramenta de diagnóstico específica.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM NISSAN / INFINITI UDS ===")
    }

    /**
     * Tesla conservative READ-ONLY diagnostic profile.
     *
     * The current HOMEBD transport is Bluetooth ELM327/CAN. Some Tesla
     * generations use diagnostic Ethernet/DoIP, so this profile never claims
     * universal Tesla ECU access. It only attempts standard UDS VIN reading
     * over CAN when the connected adapter exposes a compatible CAN path.
     */
    private fun runTeslaUdsReadOnly() {
        append("=== TESLA UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("Perfil conservador: apenas VIN standard F190 sobre CAN")
        append("Nota: alguns Tesla requerem DoIP/Ethernet; ELM327 Bluetooth não fornece essa interface.")

        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)
            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in teslaDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhuma resposta Tesla UDS obtida através do CAN/ELM327.")
            append("· Isto não significa que o veículo não tenha diagnóstico; pode requerer DoIP/Ethernet ou uma interface específica Tesla.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM TESLA UDS ===")
    }

    /**
     * Subaru READ-ONLY profile.
     *
     * Uses standard OBD-II data plus a conservative standard UDS VIN read.
     * No proprietary Subaru CAN/request map is included.
     */
    private fun runSubaruReadOnly() {
        append("=== SUBARU READ-ONLY ===")
        append("OBD-II standard + UDS 0x22 quando suportado")
        append("Sem mapa CAN proprietário Subaru não verificado.")

        val pidList = listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position"
        )

        var found = 0
        for ((pid, label) in pidList) {
            val raw = elm(pid, 3000)
            if (isPositiveObdResponse(raw, pid)) {
                found++
                append("✓ Subaru OBD-II $pid — $label: ${classifyResponse(raw)}")
                runOnUiThread {
                    liveDataLog.append("• Subaru — $label: ${classifyResponse(raw)}\n")
                }
            }
        }

        if (canActive) {
            elm("ATSP6", 2000)
            elm("ATCAF1", 1200)
            elm("ATCFC1", 1200)

            var udsFound = 0
            for (requestId in 0x7E0..0x7E7) {
                val req = String.format(Locale.US, "%03X", requestId)
                val responseId = String.format(Locale.US, "%03X", requestId + 8)
                elm("ATSH$req", 1000)
                elm("ATCRA$responseId", 1000)

                for (did in subaruDids) {
                    val raw = elm("22${did.did}", 3000)
                    val value = parseUdsDid(raw, did.did)
                    if (value.isNotBlank()) {
                        udsFound++
                        append("✓ ECU $req → ${did.label}: $value")
                        runOnUiThread {
                            liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                        }
                    }
                }
            }

            elm("ATCRA", 1000)
            elm("ATSP0", 1500)
            detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

            if (udsFound == 0) {
                append("· Nenhum DID UDS Subaru respondeu.")
            } else {
                append("✓ $udsFound leitura(s) UDS Subaru obtida(s).")
            }
        }

        if (found == 0) {
            append("· Nenhuma resposta OBD-II Subaru obtida para os PIDs selecionados.")
        } else {
            append("✓ $found leitura(s) OBD-II Subaru obtida(s).")
        }
        append("=== FIM SUBARU READ-ONLY ===")
    }

    /**
     * Lexus READ-ONLY profile.
     *
     * Lexus has its own manufacturer diagnostic tooling, so HOMEBD keeps this
     * profile separate from Toyota. Only the standard UDS VIN read is attempted
     * here; no proprietary Lexus request/DID map is assumed.
     */
    private fun runLexusReadOnly() {
        append("=== LEXUS READ-ONLY ===")
        append("OBD-II standard + CAN/ISO-TP quando suportado")
        append("Sem mapa CAN proprietário Lexus não verificado.")

        if (canActive) {
            elm("ATSP6", 2000)
            elm("ATCAF1", 1200)
            elm("ATCFC1", 1200)

            var udsFound = 0
            for (requestId in 0x7E0..0x7E7) {
                val req = String.format(Locale.US, "%03X", requestId)
                val responseId = String.format(Locale.US, "%03X", requestId + 8)
                elm("ATSH$req", 1000)
                elm("ATCRA$responseId", 1000)

                for (did in lexusDids) {
                    val raw = elm("22${did.did}", 3000)
                    val value = parseUdsDid(raw, did.did)
                    if (value.isNotBlank()) {
                        udsFound++
                        append("✓ ECU $req → ${did.label}: $value")
                        runOnUiThread {
                            liveDataLog.append("• Lexus ECU $req — ${did.label}: $value\n")
                        }
                    }
                }
            }

            elm("ATCRA", 1000)
            elm("ATSP0", 1500)
            detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

            if (udsFound == 0) {
                append("· Nenhum DID UDS Lexus respondeu.")
            } else {
                append("✓ $udsFound leitura(s) UDS Lexus obtida(s).")
            }
        } else {
            append("· CAN não disponível no adaptador/protocolo atual.")
        }

        append("=== FIM LEXUS READ-ONLY ===")
    }

    /**
     * Isuzu READ-ONLY profile.
     *
     * Isuzu's official technical portals provide diagnostic tooling and OBD
     * information, while detailed manufacturer-specific diagnostic data are
     * provided through the official Isuzu tools. HOMEBD therefore uses only
     * standard OBD-II data plus a conservative standard UDS VIN read.
     */
    private fun runIsuzuReadOnly() {
        append("=== ISUZU READ-ONLY ===")
        append("OBD-II standard + UDS 0x22 quando suportado")
        append("Sem mapa CAN proprietário Isuzu não verificado.")

        val pidList = listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position",
            "012F" to "Fuel level"
        )

        var found = 0
        for ((pid, label) in pidList) {
            val raw = elm(pid, 3000)
            if (isPositiveObdResponse(raw, pid)) {
                found++
                val value = classifyResponse(raw)
                append("✓ Isuzu OBD-II $pid — $label: $value")
                runOnUiThread {
                    liveDataLog.append("• Isuzu — $label: $value\n")
                }
            }
        }

        if (canActive) {
            elm("ATSP6", 2000)
            elm("ATCAF1", 1200)
            elm("ATCFC1", 1200)

            var udsFound = 0
            for (requestId in 0x7E0..0x7E7) {
                val req = String.format(Locale.US, "%03X", requestId)
                val responseId = String.format(Locale.US, "%03X", requestId + 8)
                elm("ATSH$req", 1000)
                elm("ATCRA$responseId", 1000)

                for (did in isuzuDids) {
                    val raw = elm("22${did.did}", 3000)
                    val value = parseUdsDid(raw, did.did)
                    if (value.isNotBlank()) {
                        udsFound++
                        append("✓ ECU $req → ${did.label}: $value")
                        runOnUiThread {
                            liveDataLog.append("• Isuzu ECU $req — ${did.label}: $value\n")
                        }
                    }
                }
            }

            elm("ATCRA", 1000)
            elm("ATSP0", 1500)
            detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

            if (udsFound == 0) {
                append("· Nenhum DID UDS Isuzu respondeu.")
            } else {
                append("✓ $udsFound leitura(s) UDS Isuzu obtida(s).")
            }
        } else {
            append("· CAN não disponível no adaptador/protocolo atual.")
        }

        if (found == 0) {
            append("· Nenhuma resposta OBD-II Isuzu obtida para os PIDs selecionados.")
        } else {
            append("✓ $found leitura(s) OBD-II Isuzu obtida(s).")
        }
        append("=== FIM ISUZU READ-ONLY ===")
    }

    /**
     * Mazda READ-ONLY profile.
     *
     * Mazda public documentation confirms that operating data are normally
     * read through the mandatory OBD connection for fault diagnosis. No
     * proprietary Mazda UDS DID is assumed without a public, verifiable source.
     */
    /**
     * Mitsubishi READ-ONLY profile.
     *
     * Mitsubishi's official technical-information portal documents OBD-II
     * coverage and CAN-bus diagnosis through MUT-III. Detailed proprietary
     * request maps are subscriber-restricted, so HOMEBD does not copy them.
     * Only standard OBD-II data and a conservative UDS VIN read are attempted.
     */
    private fun runMitsubishiReadOnly() {
        append("=== MITSUBISHI READ-ONLY ===")
        append("OBD-II standard + CAN/ISO-TP quando suportado")
        append("Sem mapa CAN proprietário Mitsubishi não verificado.")

        val pidList = listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position",
            "012F" to "Fuel level"
        )

        var found = 0
        for ((pid, label) in pidList) {
            val raw = elm(pid, 3000)
            if (isPositiveObdResponse(raw, pid)) {
                found++
                append("✓ Mitsubishi OBD-II $pid — $label: ${classifyResponse(raw)}")
                runOnUiThread {
                    liveDataLog.append("• Mitsubishi — $label: ${classifyResponse(raw)}\n")
                }
            }
        }

        if (canActive) {
            elm("ATSP6", 2000)
            elm("ATCAF1", 1200)
            elm("ATCFC1", 1200)

            var udsFound = 0
            for (requestId in 0x7E0..0x7E7) {
                val req = String.format(Locale.US, "%03X", requestId)
                val responseId = String.format(Locale.US, "%03X", requestId + 8)
                elm("ATSH$req", 1000)
                elm("ATCRA$responseId", 1000)

                for (did in mitsubishiDids) {
                    val raw = elm("22${did.did}", 3000)
                    val value = parseUdsDid(raw, did.did)
                    if (value.isNotBlank()) {
                        udsFound++
                        append("✓ ECU $req → ${did.label}: $value")
                        runOnUiThread {
                            liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                        }
                    }
                }
            }

            elm("ATCRA", 1000)
            elm("ATSP0", 1500)
            detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

            if (udsFound == 0) {
                append("· Nenhum DID UDS Mitsubishi respondeu.")
            } else {
                append("✓ $udsFound leitura(s) UDS Mitsubishi obtida(s).")
            }
        }

        if (found == 0) {
            append("· Nenhuma resposta OBD-II Mitsubishi obtida para os PIDs selecionados.")
        } else {
            append("✓ $found leitura(s) OBD-II Mitsubishi obtida(s).")
        }
        append("=== FIM MITSUBISHI READ-ONLY ===")
    }

    private fun runMazdaReadOnly() {
        append("=== MAZDA READ-ONLY ===")
        append("OBD-II standard: leitura de dados e diagnóstico")
        append("Sem DIDs proprietários Mazda não verificados.")

        // The generic OBD-II scan performed by HOMEBD remains the supported
        // manufacturer profile. Mode 09 VIN is also queried by the common CAN
        // read-only layer. No write/coding/programming service is sent.
        val pidList = listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position",
            "012F" to "Fuel level"
        )

        var found = 0
        for ((pid, label) in pidList) {
            val raw = elm(pid, 3000)
            if (isPositiveObdResponse(raw, pid)) {
                found++
                append("✓ Mazda OBD-II $pid — $label: ${classifyResponse(raw)}")
                runOnUiThread {
                    liveDataLog.append("• Mazda — $label: ${classifyResponse(raw)}\n")
                }
            }
        }

        if (found == 0) {
            append("· Nenhuma resposta OBD-II Mazda obtida para os PIDs selecionados.")
        } else {
            append("✓ $found leitura(s) OBD-II Mazda obtida(s).")
        }
        append("=== FIM MAZDA READ-ONLY ===")
    }

    private fun runFordUdsReadOnly() {
        append("=== FORD UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("A procurar ECUs nos IDs 7E0–7E7…")

        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)

            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in fordDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhum DID UDS Ford respondeu.")
            append("· ECU não acessível, DID não suportado ou gateway/rede a bloquear a leitura.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM FORD UDS ===")
    }

    private fun isPositiveObdResponse(raw: String, pid: String): Boolean {
        val hex = raw.uppercase().replace(Regex("[^0-9A-F]"), "")
        val marker = "41${pid.takeLast(2).uppercase()}"
        return hex.contains(marker)
    }

    private fun parseUdsDid(raw: String, did: String): String {
        val hex = raw.uppercase().replace(Regex("[^0-9A-F]"), "")
        if (hex.length < 6) return ""

        val didUpper = did.uppercase()
        val marker = "62$didUpper"
        val start = hex.indexOf(marker)
        if (start < 0) return ""

        val dataStart = start + marker.length
        if (dataStart >= hex.length) return ""

        val dataHex = hex.substring(dataStart)
        val bytes = ArrayList<Int>()
        var i = 0
        while (i + 1 < dataHex.length) {
            bytes.add(dataHex.substring(i, i + 2).toIntOrNull(16) ?: break)
            i += 2
        }

        // Human-readable ECU identification is normally ASCII. Preserve
        // printable characters and ignore padding/non-printable bytes.
        val text = bytes
            .filter { it in 0x20..0x7E }
            .map { it.toChar() }
            .joinToString("")
            .trim()

        return if (text.isNotBlank()) text else dataHex.take(64)
    }

    private fun reportCanValue(label: String, raw: String, value: String) {
        if (value.isNotBlank()) {
            append("CAN $label: $value")
        } else {
            append("CAN $label: não disponível (${clean(raw)})")
        }
    }

    private fun extractObdAscii(raw: String, service: Int, pid: Int): String {
        // Convert hex byte pairs from ELM output into bytes. This works with
        // single- and multi-frame ISO-TP payloads after ELM reassembly.
        val hex = raw.uppercase()
            .replace(Regex("[^0-9A-F]"), "")
        if (hex.length < 4) return ""

        val bytes = ArrayList<Int>()
        var i = 0
        while (i + 1 < hex.length) {
            bytes.add(hex.substring(i, i + 2).toIntOrNull(16) ?: -1)
            i += 2
        }

        val start = bytes.indexOfFirst { it == service }
        if (start < 0) return ""

        // Find the PID immediately after the positive response service.
        var pos = start + 1
        while (pos < bytes.size && bytes[pos] < 0) pos++
        if (pos >= bytes.size || bytes[pos] != pid) return ""

        val sb = StringBuilder()
        for (j in pos + 1 until bytes.size) {
            val b = bytes[j]
            if (b in 0x20..0x7E) sb.append(b.toChar())
        }
        return sb.toString().trim()
    }

    private fun classifyResponse(raw: String): String {
        val readable = raw.replace("\r", " ").replace("\n", " ")
            .replace(Regex("\\s+"), " ").trim()
        val compact = readable.uppercase().replace(Regex("[^0-9A-F]"), "")

        return when {
            readable.uppercase().contains("NO DATA") ->
                "· NO DATA — sem resposta desse PID"
            readable.uppercase().contains("ERROR") ->
                "· ERROR — ELM327 recusou o comando"
            readable.uppercase().contains("UNABLE TO CONNECT") ->
                "· SEM LIGAÇÃO ECU"
            Regex("7F[0-9A-F]{4}").find(compact) != null ->
                "✕ Negative Response UDS/OBD: $readable"
            compact.contains("4100") || Regex("\b41[0-9A-F]{2}\b").containsMatchIn(compact) ->
                "✓ Resposta OBD-II: $readable"
            readable.isBlank() ->
                "· SEM RESPOSTA"
            else ->
                "· Resposta: $readable"
        }
    }

    private fun clean(value: String): String =
        value.replace("\n", " ").replace(Regex("\\s+"), " ").trim()

    private fun append(value: String) {
        safeUi {
            if (::log.isInitialized) {
                val current = log.text?.toString().orEmpty()
                log.append(if (current.isEmpty()) value else "\n$value")
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) refreshBluetoothList()
    }

    override fun onDestroy() {
        stopLiveData()
        restBridge.disconnect()
        closeTransport()
        super.onDestroy()
    }
    private fun updateAdapterInfo(identification: String, transportName: String = "Bluetooth") {
        val clean = identification
            .replace("\r", " ")
            .replace("\n", " ")
            .trim()
            .ifBlank { "OBD-II compatível — modelo não identificado" }

        val lower = clean.lowercase()
        val maker = when {
            "obdlink" in lower -> "OBDLink"
            "elm327" in lower || "elm electronics" in lower -> "ELM327"
            "stn" in lower -> "STN"
            else -> "OBD-II compatível"
        }

        adapterInfo = "Adaptador: $maker • $clean • $transportName"
        if (::adapterInfoView.isInitialized) {
            runOnUiThread { adapterInfoView.text = adapterInfo }
        }
    }
}
