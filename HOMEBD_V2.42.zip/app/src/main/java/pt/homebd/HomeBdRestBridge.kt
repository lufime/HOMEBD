package pt.homebd

import android.content.Context
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * Home Assistant REST bridge.
 *
 * Uses the official Home Assistant HTTP API directly.
 * Authentication is a Long-Lived Access Token sent as Bearer.
 * No MQTT broker or Paho client is used.
 */
class HomeBdRestBridge(private val context: Context) {

    enum class Mode { AUTO, LOCAL, EXTERNAL }

    private val prefs = context.getSharedPreferences("homebd_rest", Context.MODE_PRIVATE)

    @Volatile var connected: Boolean = false
        private set

    var mode: Mode = runCatching {
        Mode.valueOf(prefs.getString("mode", Mode.AUTO.name) ?: Mode.AUTO.name)
    }.getOrDefault(Mode.AUTO)
        private set

    var localBaseUrl: String = prefs.getString("local", "") ?: ""
        private set

    var externalBaseUrl: String = prefs.getString("external", "") ?: ""
        private set

    /** Home Assistant Long-Lived Access Token. */
    var token: String = prefs.getString("token", "") ?: ""
        private set

    var basePath: String = prefs.getString("path", "/api") ?: "/api"
        private set

    var activeMode: Mode? = null
        private set

    val baseUrl: String
        get() = when (activeMode ?: mode) {
            Mode.LOCAL -> localBaseUrl
            Mode.EXTERNAL -> externalBaseUrl
            Mode.AUTO -> localBaseUrl.ifBlank { externalBaseUrl }
        }

    fun save(
        local: String,
        external: String,
        accessToken: String,
        path: String,
        selectedMode: Mode
    ) {
        localBaseUrl = normalize(local)
        externalBaseUrl = normalize(external)
        token = accessToken.trim()
        basePath = normalizePath(path)
        mode = selectedMode

        prefs.edit()
            .putString("local", localBaseUrl)
            .putString("external", externalBaseUrl)
            .putString("token", token)
            .remove("username")
            .remove("password")
            .putString("path", basePath)
            .putString("mode", mode.name)
            .apply()
    }

    fun connect(callback: (Boolean, String) -> Unit) {
        Thread {
            var success = false
            var message = "Home Assistant não respondeu."

            try {
                if (token.isBlank()) {
                    message = "Configure o token de acesso do Home Assistant."
                } else {
                    val candidates = when (mode) {
                        Mode.LOCAL -> listOf(Mode.LOCAL)
                        Mode.EXTERNAL -> listOf(Mode.EXTERNAL)
                        Mode.AUTO -> listOf(Mode.LOCAL, Mode.EXTERNAL)
                    }

                    for (candidate in candidates) {
                        val base = when (candidate) {
                            Mode.LOCAL -> localBaseUrl
                            Mode.EXTERNAL -> externalBaseUrl
                            Mode.AUTO -> ""
                        }
                        if (base.isBlank()) continue

                        val result = getApi(candidate)
                        if (result.isSuccess && (result.getOrNull() ?: 0) in 200..299) {
                            connected = true
                            activeMode = candidate
                            success = true
                            message = "Home Assistant ligado • ${candidate.name.lowercase()}"
                            break
                        }
                    }

                    if (!success) {
                        connected = false
                        activeMode = null
                        message = "Home Assistant não respondeu. Verifique URL, token e acesso à rede."
                    }
                }
            } catch (t: Throwable) {
                // REST must never be allowed to crash the application.
                connected = false
                activeMode = null
                message = "Erro REST: ${t.message ?: t.javaClass.simpleName}"
            }

            try {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    try { callback(success, message) } catch (_: Throwable) { /* UI callback must never crash HOMEBD */ }
                }
            } catch (_: Throwable) {
                // Never propagate REST callback failures.
            }
        }.start()
    }

    fun disconnect() {
        connected = false
        activeMode = null
    }

    /** Publish one OBD value as a Home Assistant sensor state.
     *  Uses the official REST state endpoint; no MQTT broker is required.
     */
    fun publishPid(pid: String, label: String, value: String) {
        if (!connected || token.isBlank()) return

        val parsed = parseValue(value) ?: return
        val entityId = entityIdFor(pid, label)
        val attrs = JSONObject()
            .put("friendly_name", "HOMEBD ${cleanLabel(label)}")
            .put("homebd_pid", pid.uppercase())
            .put("source", "HOMEBD")
            .put("raw_value", value)
            .put("state_class", "measurement")

        parsed.unit?.let { attrs.put("unit_of_measurement", it) }
        parsed.deviceClass?.let { attrs.put("device_class", it) }

        val body = JSONObject()
            .put("state", parsed.state)
            .put("attributes", attrs)

        postAsync("${basePath.trimEnd('/')}/states/$entityId", body)
    }

    /** Publish all currently read PIDs. Invalid / NO DATA values are skipped. */
    fun publishAggregate(values: List<Triple<String, String, String>>) {
        values.forEach { (pid, label, value) ->
            publishPid(pid, label, value)
        }
    }

    private data class ParsedValue(
        val state: String,
        val unit: String?,
        val deviceClass: String?
    )

    private fun parseValue(raw: String): ParsedValue? {
        val text = raw.trim()
        if (text.isBlank() || text.contains("NO DATA", ignoreCase = true) || text == "—") return null

        val number = Regex("[-+]?\\d+(?:[.,]\\d+)?").find(text)?.value
            ?.replace(',', '.') ?: return null
        val state = number.toDoubleOrNull()?.let {
            if (it % 1.0 == 0.0) it.toLong().toString() else it.toString()
        } ?: return null

        val lower = text.lowercase()
        val unit = when {
            "km/h" in lower -> "km/h"
            "rpm" in lower -> "rpm"
            "°c" in lower || " c" in lower -> "°C"
            "kpa" in lower -> "kPa"
            "v" in lower && "kv" !in lower -> "V"
            "a" in lower && (lower.contains(" a") || lower.endsWith("a")) -> "A"
            "%" in lower -> "%"
            "g/s" in lower -> "g/s"
            "l/100 km" in lower -> "L/100 km"
            "l/h" in lower -> "L/h"
            "ms" in lower -> "ms"
            else -> null
        }
        val deviceClass = when (unit) {
            "°C" -> "temperature"
            "km/h" -> "speed"
            "V" -> "voltage"
            "A" -> "current"
            "%" -> "percentage"
            "kPa" -> "pressure"
            else -> null
        }
        return ParsedValue(state, unit, deviceClass)
    }

    private fun entityIdFor(pid: String, label: String): String {
        val slug = cleanLabel(label)
            .lowercase(java.util.Locale.ROOT)
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
            .ifBlank { "pid_${pid.lowercase()}" }
        return "sensor.homebd_${slug}_${pid.lowercase()}"
    }

    private fun cleanLabel(label: String): String =
        label.trim().replace(Regex("\\s+"), " ")

    private fun getApi(which: Mode): Result<Int> = runCatching {
        val root = when (which) {
            Mode.LOCAL -> localBaseUrl
            Mode.EXTERNAL -> externalBaseUrl
            Mode.AUTO -> baseUrl
        }.trimEnd('/')
        require(root.isNotBlank())

        val url = URL(root + basePath)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Authorization", "Bearer $token")
        }
        val code = conn.responseCode
        conn.disconnect()
        code
    }

    /**
     * Assíncrono e protegido: falhas de REST nunca podem fechar a aplicação.
     */
    private fun postAsync(path: String, body: JSONObject) {
        val selectedMode = activeMode ?: mode
        Thread {
            try {
                post(selectedMode, path, body.toString())
            } catch (_: Throwable) {
                // Telemetria REST não pode provocar crash.
            }
        }.start()
    }

    private fun post(which: Mode, path: String, body: String): Result<Int> = runCatching {
        val root = when (which) {
            Mode.LOCAL -> localBaseUrl
            Mode.EXTERNAL -> externalBaseUrl
            Mode.AUTO -> baseUrl
        }.trimEnd('/')
        require(root.isNotBlank())

        val url = URL(root + "/" + path.trimStart('/'))
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 8000
            readTimeout = 8000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Authorization", "Bearer $token")
        }

        OutputStreamWriter(conn.outputStream, StandardCharsets.UTF_8).use { it.write(body) }
        val code = conn.responseCode
        conn.disconnect()
        code
    }

    private fun normalize(value: String): String {
        val v = value.trim().removeSuffix("/")
        if (v.isBlank()) return ""
        return if (v.startsWith("http://", ignoreCase = true) ||
            v.startsWith("https://", ignoreCase = true)) {
            v
        } else {
            "http://$v"
        }
    }

    private fun normalizePath(value: String): String {
        val p = value.trim()
        if (p.isBlank()) return "/api"
        return "/" + p.trim('/').ifBlank { "api" }
    }
}
