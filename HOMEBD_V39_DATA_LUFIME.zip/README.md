# HOMEBD

Universal Android OBD-II diagnostic application.

### V39
- Converted generic OBD-II PID responses into readable vehicle data values.
- Added/retained the scrollable diagnostic log.

## Previous UI
- Header includes Bluetooth and engine symbols beside the car.
- Existing Bluetooth device list, OBD connection and PID scan UI retained.
- Header includes Bluetooth and engine symbols beside the car.
- Existing Bluetooth device list, OBD connection and PID scan UI retained.
- No GitHub Actions workflow included in this ZIP.

## Credits
- HOMEBD — Home Onboard Monitoring Engine Board Data
- Version: V39 — TEST
- Developed by: lufime
- Platform: Android
- Diagnostic standard: OBD-II

## Legal / third-party components
The project does not declare external runtime libraries in `app/build.gradle.kts`. Android SDK/Kotlin/Gradle tooling are platform/build dependencies.
