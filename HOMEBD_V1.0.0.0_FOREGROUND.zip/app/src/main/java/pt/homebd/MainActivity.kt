package pt.homebd

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.content.pm.PackageManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import java.net.NetworkInterface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.*
import java.io.InputStream
import java.io.IOException
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.LinkedBlockingQueue
import java.util.Locale
import kotlin.concurrent.thread

/**
 * Scroll area used inside the dashboard. A swipe that starts on this panel
 * stays in the panel while there is content to scroll. When the panel reaches
 * its top or bottom, the gesture is handed back to the dashboard ScrollView.
 * This avoids the usual nested-ScrollView fight and makes finger scrolling
 * predictable.
 */
private class PanelScrollView(context: android.content.Context) : ScrollView(context) {
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                // The finger is inside this panel: keep the gesture here.
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return super.onTouchEvent(event)
    }
}


/*
 * HOMEBD connection safety:
 * - A dead Bluetooth socket must stop LIVE DATA immediately.
 * - Only one HA WebSocket reconnect loop may exist.
 * - Reconnect delays: 2s -> 5s -> 10s -> 30s -> 60s.
 */
private class HomebdReconnectBackoff {
    private val delays = longArrayOf(2_000L, 5_000L, 10_000L, 30_000L, 60_000L)
    private var index = 0

    @Synchronized
    fun nextDelayMs(): Long {
        val value = delays[index]
        if (index < delays.lastIndex) index++
        return value
    }

    @Synchronized
    fun reset() {
        index = 0
    }
}

private fun isBrokenPipeOrSocketError(t: Throwable): Boolean {
    val m = (t.message ?: "").lowercase()
    return m.contains("broken pipe") ||
        m.contains("software caused connection abort") ||
        m.contains("socket is closed") ||
        m.contains("socket closed") ||
        m.contains("connection reset") ||
        m.contains("connection aborted")
}

/** Strict OBD VIN validation. A 17-char arbitrary payload is not enough. */
private fun isValidVinCandidate(value: String?): Boolean {
    if (value == null) return false
    val vin = value.trim().uppercase()
    if (vin.length != 17) return false
    if (!vin.all { it in 'A'..'Z' || it in '0'..'9' }) return false
    // VINs do not use I, O or Q.
    if (vin.any { it == 'I' || it == 'O' || it == 'Q' }) return false
    return true
}


class MainActivity : Activity() {
    @Volatile
    private var homebdLiveDataSocketHealthy: Boolean = true

    @Volatile
    private var homebdLiveDataRunning: Boolean = false

    private val homebdHaReconnectBackoff = HomebdReconnectBackoff()
    @Volatile
    private var homebdHaReconnectScheduled: Boolean = false


    private fun ui(pt: String, en: String): String =
        if (HomeBdLanguage.detect(this) == HomeBdLanguage.Language.PT) pt else en

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun isActivityUsable(): Boolean =
        !isFinishing && (Build.VERSION.SDK_INT < 17 || !isDestroyed)

    private fun safeUi(action: () -> Unit) {
        if (!isActivityUsable()) return
        runOnUiThread {
            if (isActivityUsable()) {
                try { action() } catch (_: Throwable) { /* UI callback must never crash HOMEBD */ }
            }
        }
    }

    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private var bleGatt: BluetoothGatt? = null
    private var bleWriteCharacteristic: BluetoothGattCharacteristic? = null
    private var bleNotifyCharacteristic: BluetoothGattCharacteristic? = null
    private val bleRx = LinkedBlockingQueue<Byte>(8192)
    @Volatile private var usingBle = false
    private var bleConnectedLatch: CountDownLatch? = null
    private var bleServicesLatch: CountDownLatch? = null
    private var bleNotificationLatch: CountDownLatch? = null
    private var bleWriteLatch: CountDownLatch? = null

    private val bleUartServices = listOf(
        UUID.fromString("6E400001-B5A3-F393-E0A9-E50E24DCCA9E"),
        UUID.fromString("0000FFE0-0000-1000-8000-00805F9B34FB"),
        UUID.fromString("49535343-FE7D-4AE5-8FA9-9FAFD205E455")
    )
    private val bleWriteUuids = setOf(
        UUID.fromString("6E400002-B5A3-F393-E0A9-E50E24DCCA9E"),
        UUID.fromString("0000FFE1-0000-1000-8000-00805F9B34FB"),
        UUID.fromString("49535343-8841-43F4-A8D4-ECBE34729BB3")
    )
    private val bleNotifyUuids = setOf(
        UUID.fromString("6E400003-B5A3-F393-E0A9-E50E24DCCA9E"),
        UUID.fromString("0000FFE1-0000-1000-8000-00805F9B34FB"),
        UUID.fromString("49535343-1E4D-4BD9-BA61-23C647249616")
    )

    private lateinit var status: TextView
    private lateinit var statusDot: TextView
    private lateinit var log: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var scanButton: TextView
    private lateinit var connectButton: TextView
    private var adapterInfo = "Adaptador: não identificado"
    private lateinit var adapterInfoView: TextView
    private lateinit var devicesSpinner: Spinner
    private lateinit var manufacturerSpinner: Spinner
    private lateinit var aboutButton: TextView
    private lateinit var faqButton: TextView
    private lateinit var homeAssistantConnectButton: TextView
    private lateinit var hvUdsButton: TextView
    private lateinit var homeAssistantStatusView: TextView
    private lateinit var homeAssistantBridge: HomeBdHaBridge
    private lateinit var liveDataScroll: PanelScrollView
    private lateinit var liveDataLog: TextView
    private lateinit var liveDataContainer: LinearLayout
    private val liveGroupExpanded = mutableMapOf<String, Boolean>()
    private var hasScannedOnce = false
    private var detectedProtocol = ""
    private var canActive = false
    private var pendingExportText = ""
    private var pendingExportLabel = "HOMEBD"
    private var adapterKind = "Desconhecido"
    private var adapterIdentity = ""

    private data class ManufacturerProfile(
        val name: String,
        val parameters: List<Pair<String, String>>
    )

    private data class UdsDid(
        val did: String,
        val label: String
    )

    // Public/documented ECU identification DIDs selected for the READ-ONLY
    // Stellantis profile. Unknown/unavailable DIDs are simply reported as such.
    private val stellantisDids = listOf(
        UdsDid("F18C", "ECU Serial Number"),
        UdsDid("F187", "ECU Part Number"),
        UdsDid("F192", "ECU Hardware Number"),
        UdsDid("F193", "ECU Hardware Version"),
        UdsDid("F194", "ECU Software Number"),
        UdsDid("F195", "ECU Software Version")
    )

    // Renault / Dacia: only standardized UDS identification DIDs are used.
    // No proprietary Renault/Dacia DID is guessed or imported from third-party
    // CAN databases. Unsupported DIDs are simply ignored.
    private val renaultDids = listOf(
        UdsDid("F187", "ECU Part Number"),
        UdsDid("F18A", "System Supplier"),
        UdsDid("F18C", "ECU Serial Number"),
        UdsDid("F190", "VIN"),
        UdsDid("F191", "ECU Hardware Number"),
        UdsDid("F194", "ECU Software Number"),
        UdsDid("F195", "ECU Software Version")
    )

    // Volkswagen / Audi / SEAT / Škoda (VAG): only standardized UDS ECU
    // identification DIDs are used. No proprietary VAG CAN database is copied.
    private val vagDids = listOf(
        UdsDid("F187", "ECU Part Number"),
        UdsDid("F18A", "System Supplier"),
        UdsDid("F18C", "ECU Serial Number"),
        UdsDid("F190", "VIN"),
        UdsDid("F191", "ECU Hardware Number"),
        UdsDid("F192", "Supplier ECU Hardware Number"),
        UdsDid("F193", "Supplier ECU Hardware Version"),
        UdsDid("F194", "ECU Software Number"),
        UdsDid("F195", "ECU Software Version")
    )

    // Ford: only standardized UDS identification DIDs are used.
    // No proprietary Ford CAN database is copied or inferred.
    private val fordDids = listOf(
        UdsDid("F187", "ECU Part Number"),
        UdsDid("F18A", "System Supplier"),
        UdsDid("F18C", "ECU Serial Number"),
        UdsDid("F190", "VIN"),
        UdsDid("F191", "ECU Hardware Number"),
        UdsDid("F194", "ECU Software Number"),
        UdsDid("F195", "ECU Software Version")
    )

    // Nissan / INFINITI: only standardized UDS identification DIDs are used.
    // Nissan TechInfo documents ECU identification and VIN fields, but proprietary
    // request maps are not reproduced here. No third-party CAN database is used.
    private val nissanDids = listOf(
        UdsDid("F18C", "ECU Serial Number"),
        UdsDid("F190", "VIN"),
        UdsDid("F187", "ECU Part Number"),
        UdsDid("F194", "ECU Software Number"),
        UdsDid("F195", "ECU Software Version")
    )

    // Tesla: keep the ELM327 profile conservative. Current HOMEBD transport
    // supports Bluetooth ELM327/CAN; Tesla vehicles may require DoIP/Ethernet
    // depending on model and diagnostic architecture. Only standard UDS VIN
    // identification is attempted over CAN here; no proprietary Tesla map is used.
    private val teslaDids = listOf(
        UdsDid("F190", "VIN")
    )

    // Mazda: public Mazda documentation confirms mandatory OBD readout for
    // operating data and fault diagnosis. No proprietary Mazda DID/CAN map is
    // guessed or copied here; manufacturer-specific data remains unavailable
    // unless a public/documented identifier is verified.
    private val mazdaDids = emptyList<UdsDid>()

    // Subaru: conservative public OBD-II read-only profile. No proprietary
    // Subaru DID/request map is guessed or imported from a third-party CAN database.
    private val subaruDids = listOf(
        UdsDid("F190", "VIN")
    )

    // Mitsubishi: the official Mitsubishi technical-information portal documents
    // OBD-II vehicles and CAN-bus diagnosis through MUT-III. Proprietary Mitsubishi
    // request/DID maps are not reproduced here because the detailed service data
    // are subscriber-restricted. HOMEBD therefore uses standard OBD-II plus a
    // conservative standard UDS VIN read when the ECU exposes it.
    private val mitsubishiDids = listOf(
        UdsDid("F190", "VIN")
    )

    // Lexus: separate profile from Toyota so future documented Lexus-specific
    // read-only diagnostics can be added without mixing manufacturer data.
    // Only the standard VIN DID is attempted here; no proprietary Lexus map
    // is guessed or imported from a third-party CAN database.
    private val lexusDids = listOf(
        UdsDid("F190", "VIN")
    )

    // Isuzu: official Isuzu RMI/TruckService documentation confirms OBD/diagnostic
    // support, while detailed manufacturer diagnostic data are provided through
    // Isuzu diagnostic tooling. HOMEBD therefore keeps this profile conservative:
    // standard OBD-II plus a standard UDS VIN read when the ECU exposes it.
    private val isuzuDids = listOf(
        UdsDid("F190", "VIN")
    )


    // OBD-II Mode 01 PID catalogue. These are protocol identifiers and
    // generic concepts, not copied manufacturer code or proprietary CAN maps.
    // The scanner first asks the vehicle which PID blocks it supports and only
    // then requests the supported PIDs. Every manufacturer profile uses this
    // same standards-based catalogue; manufacturer-specific UDS remains
    // separate and is only used when documented.
    private val pids = linkedMapOf(
        "0101" to "Monitor status / DTCs",
        "0102" to "DTC status since clear",
        "0103" to "Fuel system status",
        "0104" to "Calculated engine load",
        "0105" to "Engine coolant temperature",
        "0106" to "Short-term fuel trim — Bank 1",
        "0107" to "Long-term fuel trim — Bank 1",
        "0108" to "Short-term fuel trim — Bank 2",
        "0109" to "Long-term fuel trim — Bank 2",
        "010A" to "Fuel pressure",
        "010B" to "Intake manifold pressure (MAP)",
        "010C" to "Engine RPM",
        "010D" to "Vehicle speed",
        "010E" to "Ignition timing advance",
        "010F" to "Intake air temperature",
        "0110" to "MAF air flow",
        "0111" to "Throttle position",
        "0112" to "Secondary air status",
        "0113" to "Oxygen sensor presence — Bank 1",
        "0114" to "O2 Sensor 1 voltage / trim",
        "0115" to "O2 Sensor 2 voltage / trim",
        "0116" to "O2 Sensor 3 voltage / trim",
        "0117" to "O2 Sensor 4 voltage / trim",
        "0118" to "O2 Sensor 5 voltage / trim",
        "0119" to "O2 Sensor 6 voltage / trim",
        "011A" to "O2 Sensor 7 voltage / trim",
        "011B" to "O2 Sensor 8 voltage / trim",
        "011C" to "OBD standards supported",
        "011D" to "O2 sensors present — Bank 2",
        "011E" to "Auxiliary input status",
        "011F" to "Engine run time since start",
        "0120" to "Supported PIDs 21–40",
        "0121" to "Distance travelled with MIL on",
        "0122" to "Fuel rail pressure",
        "0123" to "Fuel rail pressure (diesel / alternate)",
        "0124" to "O2 Sensor 1 equivalence / voltage",
        "0125" to "O2 Sensor 2 equivalence / voltage",
        "0126" to "O2 Sensor 3 equivalence / voltage",
        "0127" to "O2 Sensor 4 equivalence / voltage",
        "0128" to "O2 Sensor 5 equivalence / voltage",
        "0129" to "O2 Sensor 6 equivalence / voltage",
        "012A" to "O2 Sensor 7 equivalence / voltage",
        "012B" to "O2 Sensor 8 equivalence / voltage",
        "012C" to "Commanded EGR",
        "012D" to "EGR error",
        "012E" to "Commanded evaporative purge",
        "012F" to "Fuel level input",
        "0130" to "Warm-ups since DTCs cleared",
        "0131" to "Distance since DTCs cleared",
        "0132" to "Evap system vapour pressure",
        "0133" to "Absolute barometric pressure",
        "0134" to "O2 Sensor 1 equivalence ratio / voltage",
        "0135" to "O2 Sensor 2 equivalence ratio / voltage",
        "0136" to "O2 Sensor 3 equivalence ratio / voltage",
        "0137" to "O2 Sensor 4 equivalence ratio / voltage",
        "0138" to "O2 Sensor 5 equivalence ratio / voltage",
        "0139" to "O2 Sensor 6 equivalence ratio / voltage",
        "013A" to "O2 Sensor 7 equivalence ratio / voltage",
        "013B" to "O2 Sensor 8 equivalence ratio / voltage",
        "013C" to "Catalyst temperature — Bank 2 Sensor 1",
        "013D" to "Catalyst temperature — Bank 1 Sensor 2",
        "013E" to "Catalyst temperature — Bank 2 Sensor 2",
        "013F" to "Catalyst temperature — Bank 2 Sensor 2",
        "0140" to "Supported PIDs 41–60",
        "0141" to "Monitor status this drive cycle",
        "0142" to "Control module voltage",
        "0143" to "Absolute load value",
        "0144" to "Commanded equivalence ratio",
        "0145" to "Relative throttle position",
        "0146" to "Ambient / exterior air temperature",
        "0147" to "Absolute throttle position B",
        "0148" to "Absolute throttle position C",
        "0149" to "Accelerator pedal position D",
        "014A" to "Accelerator pedal position E",
        "014B" to "Accelerator pedal position F",
        "014C" to "Commanded throttle actuator",
        "014D" to "Time run with MIL on",
        "014E" to "Time since DTCs cleared",
        "0151" to "Fuel type",
        "0152" to "Ethanol fuel percentage",
        "0153" to "Absolute evaporative system vapour pressure",
        "0154" to "Evap system vapour pressure",
        "0155" to "Short-term secondary O2 trim — Bank 1",
        "0156" to "Long-term secondary O2 trim — Bank 1",
        "0157" to "Short-term secondary O2 trim — Bank 2",
        "0158" to "Long-term secondary O2 trim — Bank 2",
        "0159" to "Fuel rail absolute pressure",
        "015A" to "Relative accelerator pedal position",
        "015B" to "Hybrid battery pack remaining life",
        "015C" to "Engine oil temperature",
        "015D" to "Fuel injection timing",
        "015E" to "Engine fuel rate",
        "015F" to "Engine demand torque",
        "0160" to "Supported PIDs 61–80",
        "0161" to "Engine actual torque",
        "0162" to "Engine reference torque",
        "0163" to "Engine percentage torque",
        "0164" to "Auxiliary input / torque",
        "0165" to "Mass air flow sensor current",
        "0166" to "Engine coolant temperature sensor 1",
        "0167" to "Engine coolant temperature sensor 2",
        "0168" to "Engine coolant temperature sensor 3",
        "0169" to "Engine coolant temperature sensor 4",
        "016A" to "Throttle actuator control",
        "016B" to "Fuel pressure control",
        "016C" to "Commanded diesel intake air flow",
        "016D" to "Exhaust gas recirculation temperature",
        "016E" to "Commanded throttle actuator control",
        "016F" to "Fuel pressure sensor",
        "0170" to "Boost pressure control",
        "0171" to "Variable geometry turbo (VGT) control",
        "0172" to "Wastegate control",
        "0173" to "Exhaust pressure",
        "0174" to "Turbocharger RPM",
        "0175" to "Turbocharger temperature",
        "0176" to "Turbocharger temperature — second set",
        "0177" to "Charge air cooler temperature",
        "0178" to "Exhaust gas temperature — Bank 1",
        "0179" to "Exhaust gas temperature — Bank 2",
        "017A" to "DPF differential pressure",
        "017B" to "DPF status",
        "017C" to "DPF temperature",
        "017D" to "NOx NTE control area status",
        "017E" to "PM NTE control area status",
        "017F" to "Extended engine run time",
        "0180" to "Supported PIDs 81–A0",
        "0183" to "NOx sensor",
        "0184" to "Manifold surface temperature",
        "0185" to "NOx reagent system",
        "0186" to "Particulate matter sensor",
        "0187" to "Intake manifold absolute pressure (later)",
        "0188" to "SCR inducement system",
        "019A" to "Hybrid / EV vehicle system data — battery voltage",
        "019D" to "Engine fuel rate (mass)",
        "01A1" to "NOx sensor corrected data",
        "01A3" to "Evap system vapour pressure (later)",
        "01A7" to "NOx sensor concentration — sensors 3 and 4",
        "01A8" to "NOx sensor corrected concentration — sensors 3 and 4"
    )

    private val manufacturerProfiles = listOf(
        ManufacturerProfile("Automático", pids.toList()),
        ManufacturerProfile("Citroën", pids.toList()),
        ManufacturerProfile("Peugeot", pids.toList()),
        ManufacturerProfile("DS Automobiles", pids.toList()),
        ManufacturerProfile("Opel", pids.toList()),
        ManufacturerProfile("Vauxhall", pids.toList()),
        ManufacturerProfile("Fiat", pids.toList()),
        ManufacturerProfile("Alfa Romeo", pids.toList()),
        ManufacturerProfile("Jeep", pids.toList()),
        ManufacturerProfile("Lancia", pids.toList()),
        ManufacturerProfile("Abarth", pids.toList()),
        ManufacturerProfile("Toyota", pids.toList()),
        ManufacturerProfile("Lexus", pids.toList()),
        ManufacturerProfile("Volkswagen", pids.toList()),
        ManufacturerProfile("Audi", pids.toList()),
        ManufacturerProfile("SEAT", pids.toList()),
        ManufacturerProfile("Škoda", pids.toList()),
        ManufacturerProfile("CUPRA", pids.toList()),
        ManufacturerProfile("Porsche", pids.toList()),
        ManufacturerProfile("BMW", pids.toList()),
        ManufacturerProfile("MINI", pids.toList()),
        ManufacturerProfile("Mercedes-Benz", pids.toList()),
        ManufacturerProfile("Renault", pids.toList()),
        ManufacturerProfile("Nissan", pids.toList()),
        ManufacturerProfile("Hyundai", pids.toList()),
        ManufacturerProfile("Kia", pids.toList()),
        ManufacturerProfile("Ford", pids.toList()),
        ManufacturerProfile("Volvo", pids.toList()),
        ManufacturerProfile("Polestar", pids.toList()),
        ManufacturerProfile("Tesla", pids.toList()),
        ManufacturerProfile("Honda", pids.toList()),
        ManufacturerProfile("Mazda", pids.toList()),
        ManufacturerProfile("Subaru", pids.toList()),
        ManufacturerProfile("Suzuki", pids.toList()),
        ManufacturerProfile("Mitsubishi", pids.toList()),
        ManufacturerProfile("Jaguar", pids.toList()),
        ManufacturerProfile("Land Rover", pids.toList()),
        ManufacturerProfile("BYD", pids.toList()),
        ManufacturerProfile("MG", pids.toList()),
        ManufacturerProfile("Geely", pids.toList()),
        ManufacturerProfile("Chery", pids.toList()),
        ManufacturerProfile("Isuzu", pids.toList()),
        ManufacturerProfile("OBD-II Universal", pids.toList())
    )


    private fun localized(pt: String, en: String): String {
        return if (HomeBdLanguage.name(this).equals("Português", ignoreCase = true)) pt else en
    }

    private fun diagnosticIntro(): String = localized(
        "HOMEBD pronto.\nDiagnóstico OBD-II universal para veículos.\nSelecione um adaptador OBD-II Bluetooth emparelhado e toque em LIGAR OBDII.\n",
        "HOMEBD ready.\nUniversal OBD-II diagnostics for vehicles.\nSelect a paired Bluetooth OBD-II adapter and tap CONNECT OBD-II.\n"
    )




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val detectedLanguage = HomeBdLanguage.detect(this)
        homeAssistantBridge = HomeBdHaBridge(this)

        window.statusBarColor = Color.rgb(23, 23, 23)
        window.navigationBarColor = Color.rgb(23, 23, 23)

        // Ecrã normal: o conteúdo nunca fica por baixo das barras do sistema.
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(true)
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = 0
        }

        // HOMEBD premium portrait layout. The main page is a centered, full-width
        // vertical dashboard. LIVE DATA and DIAGNOSTICS each keep their own scroll.
        val background = Color.rgb(6, 15, 24)
        val panel = Color.rgb(18, 31, 44)
        val panel2 = Color.rgb(25, 41, 56)
        val primary = Color.rgb(245, 248, 252)
        val secondary = Color.rgb(165, 184, 201)
        val blue = Color.rgb(20, 150, 245)
        val green = Color.rgb(10, 125, 75)
        val purple = Color.rgb(65, 42, 125)
        val border = Color.rgb(38, 73, 98)

        fun rounded(color: Int, radius: Int = 12, stroke: Int = border): GradientDrawable =
            GradientDrawable().apply {
                setColor(color)
                cornerRadius = dp(radius).toFloat()
                setStroke(dp(1), stroke)
            }

        fun addCardHeader(parent: LinearLayout, icon: String, title: String, action: String? = null, onAction: (() -> Unit)? = null) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(8), dp(8), dp(8))
            }
            val iconView = TextView(this).apply {
                text = icon
                textSize = 18f
                setTextColor(blue)
                gravity = Gravity.CENTER
                includeFontPadding = false
            }
            row.addView(iconView, LinearLayout.LayoutParams(dp(30), dp(30)))
            val label = TextView(this).apply {
                text = title
                textSize = 17f
                setTextColor(primary)
                gravity = Gravity.CENTER_VERTICAL
                includeFontPadding = false
            }
            row.addView(label, LinearLayout.LayoutParams(0, dp(42), 1f))
            if (action != null && onAction != null) {
                val actionView = TextView(this).apply {
                    text = action
                    textSize = 11f
                    setTextColor(primary)
                    gravity = Gravity.CENTER
                    setPadding(dp(12), 0, dp(12), 0)
                    this.background = rounded(Color.rgb(28, 47, 63), 9, Color.TRANSPARENT)
                    isClickable = true
                    isFocusable = true
                    setOnClickListener { onAction() }
                }
                row.addView(actionView, LinearLayout.LayoutParams(dp(96), dp(38)))
            }
            parent.addView(row, LinearLayout.LayoutParams(-1, dp(50)))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(background)
            setPadding(0, 0, 0, 0)
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(4))
        }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            this.background = rounded(Color.rgb(3, 10, 17), 12, Color.TRANSPARENT)
        }
        val appIcon = ImageView(this).apply {
            setImageResource(pt.homebd.R.drawable.homebd_header)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            contentDescription = "HOMEBD"
        }
        header.addView(appIcon, LinearLayout.LayoutParams(dp(154), dp(72)).apply {
            setMargins(dp(0), 0, dp(6), 0)
        })
        val headerText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        headerText.addView(TextView(this).apply {
            text = ui("Diagnóstico OBD-II universal para veículos", "Universal OBD-II diagnostics for vehicles")
            textSize = 11f
            setTextColor(secondary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }, LinearLayout.LayoutParams(-1, dp(48)))
        header.addView(headerText, LinearLayout.LayoutParams(0, -1, 1f))
        content.addView(header, LinearLayout.LayoutParams(-1, dp(72)).apply {
            setMargins(0, 0, 0, dp(6))
        })

        // Status card
        val statusCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            this.background = rounded(panel, 12)
            setPadding(dp(10), dp(3), dp(10), dp(3))
        }
        statusDot = TextView(this).apply {
            text = "●"
            textSize = 20f
            setTextColor(Color.rgb(255, 175, 195))
            gravity = Gravity.CENTER
            includeFontPadding = false
        }
        statusCard.addView(statusDot, LinearLayout.LayoutParams(dp(28), dp(54)))
        status = TextView(this).apply {
            text = "OBD-II DESLIGADO"
            textSize = 14.5f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
            maxLines = 2
        }
        statusCard.addView(status, LinearLayout.LayoutParams(0, dp(54), 1f))
        val btSummary = TextView(this).apply {
            text = "Bluetooth"
            textSize = 11.5f
            setTextColor(secondary)
            gravity = Gravity.CENTER
            includeFontPadding = false
        }
        statusCard.addView(btSummary, LinearLayout.LayoutParams(dp(76), dp(54)))
        content.addView(statusCard, LinearLayout.LayoutParams(-1, dp(60)).apply {
            setMargins(0, 0, 0, dp(5))
        })

        // Selectors
        val selectors = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val deviceCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            this.background = rounded(panel, 12)
            setPadding(dp(10), dp(4), dp(10), dp(6))
        }
        val deviceLabel = TextView(this).apply {
            text = ui(localized("DISPOSITIVO OBD-II", "OBD-II DEVICE"), "OBD-II DEVICE")
            textSize = 11f
            setTextColor(secondary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }
        deviceCard.addView(deviceLabel, LinearLayout.LayoutParams(-1, dp(24)))
        devicesSpinner = Spinner(this).apply {
            this.background = rounded(panel2, 8, Color.TRANSPARENT)
            minimumHeight = dp(44)
        }
        deviceCard.addView(devicesSpinner, LinearLayout.LayoutParams(-1, dp(48)))
        selectors.addView(deviceCard, LinearLayout.LayoutParams(0, dp(80), 1f).apply { setMargins(0, 0, dp(4), 0) })

        val manufacturerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            this.background = rounded(panel, 12)
            setPadding(dp(10), dp(4), dp(10), dp(6))
        }
        val manufacturerLabel = TextView(this).apply {
            text = ui(localized("FABRICANTE / PERFIL", "MANUFACTURER / PROFILE"), "MANUFACTURER / PROFILE")
            textSize = 11f
            setTextColor(secondary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }
        manufacturerCard.addView(manufacturerLabel, LinearLayout.LayoutParams(-1, dp(24)))
        manufacturerSpinner = Spinner(this).apply {
            this.background = rounded(panel2, 8, Color.TRANSPARENT)
            minimumHeight = dp(44)
        }
        manufacturerCard.addView(manufacturerSpinner, LinearLayout.LayoutParams(-1, dp(48)))
        selectors.addView(manufacturerCard, LinearLayout.LayoutParams(0, dp(80), 1f).apply { setMargins(dp(4), 0, 0, 0) })
        content.addView(selectors, LinearLayout.LayoutParams(-1, dp(84)).apply { setMargins(0, 0, 0, dp(6)) })

        // Four primary actions
        connectButton = actionButton(ui(localized("LIGAR\nOBD-II", "CONNECT\nOBD-II"), "CONNECT\nOBD-II"), blue, primary)
        val connect = connectButton
        scanButton = actionButton(ui(localized("RESCAN\nPIDs", "RESCAN\nPIDs"), "RESCAN\nPIDs"), Color.rgb(24, 42, 58), primary).apply {
            isEnabled = false
            alpha = 0.55f
        }
        hvUdsButton = actionButton(ui(localized("HV / UDS\nSCAN", "HV / UDS\nSCAN"), "HV / UDS\nSCAN"), purple, primary).apply {
            isEnabled = false
            alpha = 0.55f
        }
        homeAssistantConnectButton = actionButton(ui(localized("HOME\nASSISTANT", "HOME\nASSISTANT"), "HOME\nASSISTANT"), green, primary)

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        fun addAction(view: View, left: Int, right: Int) = buttons.addView(view, LinearLayout.LayoutParams(0, dp(68), 1f).apply {
            setMargins(dp(left), 0, dp(right), 0)
        })
        addAction(connect, 0, 3)
        addAction(scanButton, 3, 3)
        addAction(hvUdsButton, 3, 3)
        addAction(homeAssistantConnectButton, 3, 0)
        content.addView(buttons, LinearLayout.LayoutParams(-1, dp(68)).apply { setMargins(0, 0, 0, dp(5)) })

        // Home Assistant card
        val homeCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            this.background = rounded(panel, 12)
            setPadding(dp(10), dp(2), dp(10), dp(2))
        }
        homeAssistantStatusView = TextView(this).apply {
            text = if (homeAssistantBridge.baseUrl.isBlank()) "Home Assistant · não configurado"
                   else "Home Assistant · WebSocket · ligado"
            textSize = 11.5f
            setTextColor(secondary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        homeCard.addView(homeAssistantStatusView, LinearLayout.LayoutParams(0, dp(38), 1f))
        // Compact status only. Configuration is handled by the HOME ASSISTANT action.
        content.addView(homeCard, LinearLayout.LayoutParams(-1, dp(44)).apply { setMargins(0, 0, 0, dp(5)) })

        // LIVE DATA: fixed card height + dedicated vertical scroll.
        val liveCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            this.background = rounded(panel, 12)
        }
        addCardHeader(liveCard, "▥", ui(localized("LIVE DATA", "LIVE DATA"), "LIVE DATA"), "EXPORT") {
            exportText(ui(localized("LIVE DATA", "LIVE DATA"), "LIVE DATA"), liveDataLog.text.toString(), 101)
        }
        liveDataLog = TextView(this).apply {
            textSize = 13f
            setTextColor(primary)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            gravity = Gravity.TOP or Gravity.START
            includeFontPadding = true
            setLineSpacing(0f, 1.0f)
            isLongClickable = true
        }
        liveDataContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(4))
            setBackgroundColor(panel)
        }
        liveDataScroll = PanelScrollView(this).apply {
            setBackgroundColor(panel)
            isFillViewport = true
            isVerticalScrollBarEnabled = true
            scrollBarStyle = View.SCROLLBARS_INSIDE_INSET
            isScrollbarFadingEnabled = false
            scrollBarSize = dp(5)
            addView(liveDataContainer, ViewGroup.LayoutParams(-1, -2))
        }
        liveCard.addView(liveDataScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(liveCard, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0, 0, 0, dp(5)) })

        // DIAGNOSTICS: also scrolls independently.
        val diagnosticCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            this.background = rounded(panel, 12)
        }
        addCardHeader(diagnosticCard, "▣", ui(localized("DIAGNÓSTICO", "DIAGNOSTICS"), "DIAGNOSTICS"), "EXPORT") {
            exportText("DIAGNOSTICO", log.text.toString(), 102)
        }
        log = TextView(this).apply {
            textSize = 13f
            setTextColor(primary)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            includeFontPadding = true
            gravity = Gravity.TOP or Gravity.START
            setLineSpacing(0f, 1.0f)
        }
        logScroll = PanelScrollView(this).apply {
            setBackgroundColor(panel)
            isFillViewport = true
            isVerticalScrollBarEnabled = true
            scrollBarStyle = View.SCROLLBARS_INSIDE_INSET
            isScrollbarFadingEnabled = false
            scrollBarSize = dp(5)
            addView(log, ViewGroup.LayoutParams(-1, -2))
        }
        diagnosticCard.addView(logScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        content.addView(diagnosticCard, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0, 0, 0, dp(5)) })

        // Footer
        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        faqButton = TextView(this).apply {
            text = "FAQ"
            textSize = 12f
            setTextColor(blue)
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
        }
        aboutButton = TextView(this).apply {
            text = "ABOUT"
            textSize = 12f
            setTextColor(blue)
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
        }
        footer.addView(faqButton, LinearLayout.LayoutParams(0, dp(40), 1f))
        footer.addView(TextView(this).apply {
            text = "HOMEBD Beta 1.0.0.0\nlufime"
            textSize = 11f
            setTextColor(secondary)
            gravity = Gravity.CENTER
            includeFontPadding = false
        }, LinearLayout.LayoutParams(0, dp(40), 1f))
        footer.addView(aboutButton, LinearLayout.LayoutParams(0, dp(40), 1f))
        content.addView(footer, LinearLayout.LayoutParams(-1, dp(44)))

        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener { v, insets ->
                val bars = insets.getInsets(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                content.setPadding(dp(10), bars.top + dp(8), dp(10), bars.bottom + dp(4))
                insets
            }
        }

        setContentView(root)

        append("🌐 " + ui("Idioma automático", "Automatic language") + ": ${HomeBdLanguage.name(this)}")

        // Pressão longa nos dois painéis copia todo o conteúdo.
        installCopyOnLongPress(liveDataLog, ui(localized("LIVE DATA", "LIVE DATA"), localized("LIVE DATA", "LIVE DATA")))
        installCopyOnLongPress(log, ui(localized("DIAGNÓSTICO", "DIAGNOSTICS"), "DIAGNOSTICS"))

        manufacturerSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            manufacturerProfiles.map { it.name }
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        manufacturerSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val profile = manufacturerProfiles[position]
                liveDataLog.text =
                    "Perfil: ${profile.name}\n\n" +
                    "OBD-II standard\n" +
                    "Os PIDs suportados são detetados automaticamente pelo veículo.\n\n" +
                    "Categorias disponíveis:\n" +
                    "• Motor e carga\n" +
                    "• Combustível e mistura\n" +
                    "• Temperaturas e pressões\n" +
                    "• Sensores O2 / emissões\n" +
                    "• Acelerador / pedal\n" +
                    "• Estado OBD / readiness\n" +
                    "• Tensão e dados auxiliares\n" +
                    "• VIN / informação do veículo"
                append("Perfil selecionado: ${profile.name} • catálogo OBD-II standard ativo")
            }
        }

        root.requestApplyInsets()

        connect.setOnClickListener {
            if (isTransportConnected()) {
                // Explicit disconnect: stop polling and close Classic/BLE transport.
                stopLiveData()
                closeTransport()
                setStatusText(ui(localized("Estado: desligado", "Status: disconnected"), "Status: disconnected"))
                scanButton.isEnabled = false
                scanButton.alpha = 0.55f
                connectButton.text = ui(localized("LIGAR\nOBD-II", "CONNECT\nOBD-II"), "CONNECT\nOBD-II")
                append("✓ OBD-II desligado.")
                return@setOnClickListener
            }

            val adapter = BluetoothAdapter.getDefaultAdapter()
            val paired = try {
                adapter?.bondedDevices?.toList() ?: emptyList()
            } catch (_: SecurityException) {
                emptyList()
            }

            val position = devicesSpinner.selectedItemPosition
            val device = paired.getOrNull(position)

            if (device != null) {
                connect(device)
            } else {
                append("⚠ Nenhum dispositivo Bluetooth selecionável.")
                append("Emparelhe um adaptador OBD-II Bluetooth nas definições Bluetooth do Android.")
            }
        }

        homeAssistantConnectButton.setOnClickListener {
            try {
                if (!isActivityUsable()) return@setOnClickListener
                if (homeAssistantBridge.connected) {
                    homeAssistantBridge.disconnect()
                    homeAssistantStatusView.text = "Home Assistant · desligado"
                    homeAssistantConnectButton.text = ui(localized("HOME\nASSISTANT", "HOME\nASSISTANT"), "HOME\nASSISTANT")
                    append("✓ Home Assistant desligado.")
                } else if (homeAssistantBridge.baseUrl.isBlank() || homeAssistantBridge.token.isBlank()) {
                    configureHomeAssistantLink()
                } else {
                    homeAssistantConnectButton.isEnabled = false
                    homeAssistantStatusView.text = "Home Assistant · a ligar…"
                    homeAssistantBridge.connect { ok, msg ->
                        safeUi {
                            homeAssistantConnectButton.isEnabled = true
                            homeAssistantStatusView.text = if (ok) "Home Assistant · WebSocket · ligado" else "Home Assistant · $msg"
                            homeAssistantConnectButton.text = if (ok) ui("HOME\nASSISTANT", "HOME\nASSISTANT") else ui(localized("HOME\nASSISTANT", "HOME\nASSISTANT"), "HOME\nASSISTANT")
                            append(if (ok) "✓ $msg" else "⚠ $msg")
                        }
                    }
                }
            } catch (t: Throwable) {
                safeUi {
                    homeAssistantConnectButton.isEnabled = true
                    homeAssistantStatusView.text = "Home Assistant · erro"
                    append("⚠ Erro Home Assistant: ${t.message ?: t.javaClass.simpleName}")
                }
            }
        }

        scanButton.setOnClickListener { runScanner() }
        hvUdsButton.setOnClickListener { runHvUdsDiscovery() }
        aboutButton.setOnClickListener { showAbout() }
        faqButton.setOnClickListener { showFaq() }

        append("HOMEBD pronto.")
        append(localized("Diagnóstico OBD-II universal para veículos.", "Universal OBD-II diagnostics for vehicles."))
        append(localized("Selecione um adaptador OBD-II Bluetooth emparelhado e toque em LIGAR OBDII.", "Select a paired Bluetooth OBD-II adapter and tap CONNECT OBD-II."))
        liveDataLog.text = "Sem dados — ligue o OBD-II e execute SCAN PIDs."

        requestBtPermissions()
        refreshBluetoothList()
    }

    private fun sectionHeader(title: String, action: String, onAction: () -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val label = TextView(this).apply {
            text = title
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        val button = TextView(this).apply {
            text = action
            textSize = 10f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(8), 0, dp(8), 0)
            isClickable = true
            isFocusable = true
            this.background = GradientDrawable().apply {
                setColor(Color.rgb(55, 55, 55))
                cornerRadius = dp(3).toFloat()
            }
            setOnClickListener { onAction() }
        }

        row.addView(label, LinearLayout.LayoutParams(0, -1, 1f))
        row.addView(button, LinearLayout.LayoutParams(dp(88), dp(26)))
        return row
    }

    private fun installCopyOnLongPress(view: TextView, label: String) {
        view.setOnLongClickListener {
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText(label, view.text.toString()))
            Toast.makeText(this, "$label copiado", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun exportText(label: String, text: String, requestCode: Int) {
        if (text.isBlank()) {
            Toast.makeText(this, "Não existem dados para exportar.", Toast.LENGTH_SHORT).show()
            return
        }

        pendingExportText = text
        pendingExportLabel = label

        val safeName = label.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, "HOMEBD_${safeName}.txt")
        }
        try {
            startActivityForResult(intent, requestCode)
        } catch (_: Exception) {
            Toast.makeText(this, "Não foi possível abrir o exportador.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if ((requestCode == 101 || requestCode == 102) &&
            resultCode == RESULT_OK &&
            data?.data != null
        ) {
            val uri: Uri = data.data!!
            try {
                contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(pendingExportText.toByteArray(Charsets.UTF_8))
                    out.flush()
                }
                Toast.makeText(this, "$pendingExportLabel exportado.", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Erro ao exportar: ${e.message ?: "desconhecido"}", Toast.LENGTH_LONG).show()
            } finally {
                pendingExportText = ""
                pendingExportLabel = "HOMEBD"
            }
        }
    }

    private fun showAbout() {
        val pt = Locale.getDefault().language.equals("pt", ignoreCase = true)
        val title = if (pt) "Sobre o HOMEBD" else "About HOMEBD"
        val message = if (pt) {
            "HOMEBD\n" +
            "Home Onboard Monitoring Engine Board Data\n\n" +
            "HOMEBD — Funcionalidades desenvolvidas\n\n" +
            "• Aplicação Android para diagnóstico OBD-II\n" +
            "• Ligação a adaptadores OBD-II através de Bluetooth\n" +
            "• Deteção e seleção de dispositivos Bluetooth emparelhados\n" +
            "• Comunicação com interfaces compatíveis com ELM327\n" +
            "• Deteção automática do protocolo OBD-II\n" +
            "• Identificação dos PIDs suportados pelo veículo\n" +
            "• Leitura dinâmica e conversão dos parâmetros\n" +
            "• Live Data em tempo real\n" +
            "• Leitura de DTCs quando suportada\n" +
            "• Leitura de VIN quando disponível\n" +
            "• CAN / ISO-TP / UDS quando suportado\n" +
            "• Perfis específicos de fabricantes\n" +
            "• Operação 100% READ-ONLY\n\n" +
            "Nota de desenvolvimento:\n" +
            "O HOMEBD foi desenvolvido de raiz, com arquitetura, funcionalidades e soluções técnicas concebidas especificamente para este projeto e desenvolvidas para a própria aplicação.\n\n" +
            "Versão: BETA 1.0.0.0\n" +
            "Desenvolvido por: lufime"
        } else {
            "HOMEBD\n" +
            "Home Onboard Monitoring Engine Board Data\n\n" +
            "HOMEBD — Developed Features\n\n" +
            "• Android application for OBD-II diagnostics\n" +
            "• Bluetooth connection to OBD-II adapters\n            • Adapter layer designed for ELM327-compatible, STN and OBDLink interfaces\n" +
            "• Detection and selection of paired Bluetooth devices\n" +
            "• Communication with ELM327-compatible interfaces\n" +
            "• Automatic OBD-II protocol detection\n" +
            "• Identification of vehicle-supported PIDs\n" +
            "• Dynamic reading and conversion of parameters\n" +
            "• Real-time Live Data\n" +
            "• DTC reading when supported\n" +
            "• VIN reading when available\n" +
            "• CAN / ISO-TP / UDS when supported\n" +
            "• Manufacturer-specific profiles\n" +
            "• 100% READ-ONLY operation\n\n" +
            "Development Note:\n" +
            "HOMEBD was developed from the ground up, with its architecture, features, and technical solutions specifically designed and developed for this project and its application.\n\n" +
            "Version: BETA 1.0.0.0\n" +
            "Developed by: lufime"
        }

        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton(if (pt) "FECHAR" else "CLOSE", null)
            .show()
    }

    private fun showFaq() {
        val pt = Locale.getDefault().language.equals("pt", ignoreCase = true)
        val title = if (pt) "HOMEBD • FAQ" else "HOMEBD • FAQ"
        val faqText = if (pt) {
            "PERGUNTAS FREQUENTES\n\n" +
            "1. O que é o HOMEBD?\n" +
            "Aplicação Android para diagnóstico OBD-II, leitura de Live Data e integração WebSocket com Home Assistant.\n\n" +
            "2. Que adaptadores são suportados?\n" +
            "A aplicação foi desenhada para adaptadores Bluetooth compatíveis com ELM327 e transportes equivalentes suportados pela aplicação. A compatibilidade real depende do adaptador e do veículo.\n\n" +
            "3. O HOMEBD altera a ECU?\n" +
            "Não. A operação de diagnóstico da aplicação é READ-ONLY. Não são enviados comandos de escrita, programação, codificação ou adaptação.\n\n" +
            "4. O que significa 'Desconhecido' num sensor?\n" +
            "Significa que o valor ainda não foi recebido, não está disponível no ECU ou não foi possível converter a resposta. Não significa zero.\n\n" +
            "5. Como funciona a integração Home Assistant?\n" +
            "A HOMEBD usa uma integração própria no Home Assistant e uma ligação WebSocket persistente para enviar as entidades sensor.homebd_*.\n\n" +
            "7. O que faço se o Home Assistant não atualizar?\n" +
            "Confirma a integração HOMEBD em Definições > Dispositivos e serviços, o endereço do Home Assistant e o Long-Lived Access Token.\n\n" +
            "8. Para que serve SCAN PIDs?\n" +
            "Identifica os PIDs OBD-II que o veículo declara suportar e depois permite apresentar os parâmetros disponíveis.\n\n" +
            "10. O FAQ vai ser atualizado?\n" +
            "Sim. O FAQ deve ser atualizado a cada versão relevante, refletindo funcionalidades implementadas, alterações de OBD, compatibilidade e limitações conhecidas.\n\n" +
            "VERSÃO — BETA 1.0.0.0\n" +
            "• FAQ integrado na aplicação\n" +
            "• Ligação Home Assistant por WebSocket persistente\n" +
            "" +
            "• Integração HOMEBD dedicada no Home Assistant\n\n" +
            "Desenvolvido por: lufime"
        } else {
            "FREQUENTLY ASKED QUESTIONS\n\n" +
            "1. What is HOMEBD?\n" +
            "An Android application for OBD-II diagnostics, Live Data and Home Assistant WebSocket integration.\n\n" +
            "2. Which adapters are supported?\n" +
            "The application is designed for Bluetooth adapters compatible with ELM327 and supported equivalent transports. Actual compatibility depends on the adapter and vehicle.\n\n" +
            "3. Does HOMEBD modify the ECU?\n" +
            "No. Diagnostic operation is READ-ONLY. No write, programming, coding or adaptation commands are sent.\n\n" +
            "4. What does 'Unknown' mean for a sensor?\n" +
            "The value has not been received, is unavailable from the ECU, or could not be converted. It does not mean zero.\n\n" +
            "5. How does the Home Assistant integration work?\n" +
            "HOMEBD uses its own Home Assistant integration and a persistent WebSocket connection to publish sensor.homebd_* entities.\n\n" +
            "7. What if Home Assistant does not update?\n" +
            "Check the HOMEBD integration under Settings > Devices & services, the Home Assistant address and the Long-Lived Access Token.\n\n" +
            "8. What does SCAN PIDs do?\n" +
            "It identifies OBD-II PIDs declared as supported by the vehicle and then allows available parameters to be displayed.\n\n" +
            "10. Will the FAQ be updated?\n" +
            "Yes. The FAQ should be updated with each relevant release to reflect implemented features, OBD changes, compatibility and known limitations.\n\n" +
            "VERSION — BETA 1.0.0.0\n" +
            "• FAQ integrated in the application\n" +
            "• Persistent Home Assistant WebSocket connection\n" +
            "" +
            "• Dedicated HOMEBD Home Assistant integration\n\n" +
            "Developed by: lufime"
        }

        val textView = TextView(this).apply {
            text = faqText
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(dp(18), dp(8), dp(18), dp(8))
            setLineSpacing(0f, 1.08f)
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(textView, ViewGroup.LayoutParams(-1, -2))
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(scroll)
            .setPositiveButton(if (pt) "FECHAR" else "CLOSE", null)
            .show()
    }

    private fun setStatusText(value: String) {
        val lower = value.lowercase(Locale.ROOT)
        val isError = lower.contains("erro") || lower.contains("error")
        val connected = isTransportConnected() || lower.contains("ligado")
        status.text = when {
            isError -> "OBD-II · ERRO"
            lower.contains("live data") -> "OBD-II LIGADO\nLIVE DATA · 1 s"
            connected -> "OBD-II LIGADO"
            lower.contains("a ligar") || lower.contains("connecting") -> "OBD-II A LIGAR…"
            else -> "OBD-II DESLIGADO"
        }
        val dotColor = when {
            isError -> Color.rgb(235, 65, 80)
            connected -> Color.rgb(120, 225, 160)
            else -> Color.rgb(255, 175, 195)
        }
        statusDot.setTextColor(dotColor)
    }

    private fun actionButton(label: String, color: Int, textColor: Int): TextView =
        TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(textColor)
            gravity = Gravity.CENTER
            includeFontPadding = false
            setPadding(dp(6), dp(4), dp(6), dp(4))
            isClickable = true
            isFocusable = true
            this.background = GradientDrawable().apply {
                setColor(color)
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), Color.rgb(38, 73, 98))
            }
        }

    private fun refreshBluetoothList() {
        val adapter = BluetoothAdapter.getDefaultAdapter()

        if (adapter == null) {
            setDevices(listOf("Bluetooth não disponível neste dispositivo"))
            return
        }

        try {
            if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
            ) {
                setDevices(listOf("Permitir Bluetooth para mostrar dispositivos"))
                return
            }

            if (!adapter.isEnabled) {
                setDevices(listOf("Bluetooth desligado — ative o Bluetooth"))
                return
            }

            val paired = adapter.bondedDevices.toList()
            val names = if (paired.isEmpty()) {
                listOf("Nenhum dispositivo emparelhado")
            } else {
                paired.map { device ->
                    val name = try { device.name ?: "Sem nome" } catch (_: SecurityException) { "Sem nome" }
                    "$name  (${device.address})"
                }
            }

            setDevices(names)
            append(localized("✓ Bluetooth: ${paired.size} dispositivo(s) emparelhado(s).", "✓ Bluetooth: ${paired.size} paired device(s)."))
        } catch (_: SecurityException) {
            setDevices(listOf("Permissão Bluetooth necessária"))
        }
    }

    private fun setDevices(names: List<String>) {
        devicesSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            names
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun requestBtPermissions() {
        val permissions = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                permissions += Manifest.permission.BLUETOOTH_SCAN
            }
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                permissions += Manifest.permission.BLUETOOTH_CONNECT
            }
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            permissions += Manifest.permission.POST_NOTIFICATIONS
        }

        if (permissions.isNotEmpty()) {
            requestPermissions(permissions.toTypedArray(), 10)
        }
    }

    private fun connect(device: BluetoothDevice) {
        stopLiveData()
        thread {
            try {
                runOnUiThread { setStatusText("Estado: a ligar…") }
                closeTransport()

                var classicError: Exception? = null
                try {
                    if (Build.VERSION.SDK_INT >= 31 &&
                        checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
                    ) throw SecurityException("Permissão Bluetooth necessária")

                    socket = device.createRfcommSocketToServiceRecord(spp)
                    socket!!.connect()
                    input = socket!!.inputStream
                    output = socket!!.outputStream
                    usingBle = false
                    adapterKind = "OBD-II Bluetooth Classic"
                } catch (e: Exception) {
                    classicError = e
                    try { socket?.close() } catch (_: Exception) {}
                    socket = null
                    input = null
                    output = null

                    runOnUiThread { setStatusText("Estado: a ligar por BLE…") }
                    connectBle(device)
                    usingBle = true
                    adapterKind = "OBD-II Bluetooth BLE"
                }

                elm("ATZ", 5000)
                Thread.sleep(1200)
                elm("ATE0", 2500)
                adapterIdentity = elm("ATI", 2500)
                adapterKind = identifyAdapter(adapterIdentity) + if (usingBle) " • BLE" else " • Bluetooth Classic"
                elm("ATL0", 2500)
                elm("ATS0", 2500)
                elm("ATSP0", 2500)

                val protocol = elm("ATDP", 2500)
                var protocolNumber = elm("ATDPN", 2500)
                    .trim().uppercase().removePrefix("A")

                if (protocol.isBlank()) throw IOException("Adaptador não respondeu ao ATDP")

                detectedProtocol = protocolNumber
                canActive = protocolNumber in setOf("6", "7", "8", "9", "A", "B", "C") ||
                    protocol.uppercase().contains("CAN") || protocol.uppercase().contains("J1939")

                // Some ELM327-compatible adapters report protocol 0/AUTO even
                // when the vehicle is already on CAN. Before giving up, test the
                // standard CAN variants with a harmless OBD-II capability query.
                // Keep the first protocol that produces a valid 0100 response
                // selected for the rest of the session.
                if (!canActive || protocolNumber == "0") {
                    val stable = stabilizeCanProtocol()
                    if (stable != null) {
                        protocolNumber = stable
                        detectedProtocol = stable
                        canActive = true
                        append("✓ CAN estabilizado: protocolo $stable (0100 respondeu).")
                    }
                }

                if (canActive) {
                    elm("ATCFC1", 1500)
                    append("✓ CAN detectado: ISO 15765-4 CAN 11-bit / 500 kbit/s.")
                    append("✓ CAN em modo READ-ONLY.")
                }

                // Keep the HOMEBD process alive while the OBD session is active.
                // The foreground service is intentionally started only after the transport
                // and CAN/OBD initialization succeeded.
                HomeBdForegroundService.start(this@MainActivity)

                runOnUiThread {
                    setStatusText(if (canActive)
                        "Estado: LIGADO • $adapterKind • CAN • READ-ONLY"
                    else
                        "Estado: LIGADO • $adapterKind • READ-ONLY")
                    scanButton.isEnabled = true
                    scanButton.alpha = 1f
                    hvUdsButton.isEnabled = true
                    hvUdsButton.alpha = 1f
                    connectButton.text = "DESLIGAR\nOBD-II"
                }

                append("✓ Interface inicializada: $adapterKind")
                if (adapterIdentity.isNotBlank()) append("Identificação: ${clean(adapterIdentity)}")
                append("Transporte: ${if (usingBle) "Bluetooth Low Energy (BLE)" else "Bluetooth Classic / SPP"}")
                append("Protocolo: ${clean(protocol)}")
                append("Número de protocolo: ${if (protocolNumber.isBlank()) "desconhecido" else protocolNumber}")
                append("Pronto para SCAN PIDs.")
            } catch (e: Exception) {
                runOnUiThread {
                    setStatusText("Estado: erro de ligação")
                    connectButton.text = ui(localized("LIGAR\nOBD-II", "CONNECT\nOBD-II"), "CONNECT\nOBD-II")
                    scanButton.isEnabled = false
                    scanButton.alpha = 0.55f
                    hvUdsButton.isEnabled = false
                    hvUdsButton.alpha = 0.55f
                }
                append("✕ ERRO: ${e.message ?: "erro desconhecido"}")
            }
        }
    }

    /**
     * Try the standard 11/29-bit CAN variants without sending any write or
     * diagnostic-control service. PID 0100 is a standard OBD-II capability
     * query and is used only as a transport validation.
     */
    private fun stabilizeCanProtocol(): String? {
        val candidates = listOf("6", "7", "8", "9")
        for (candidate in candidates) {
            try {
                elm("ATSP$candidate", 1800)
                elm("ATCAF1", 1000)
                elm("ATCFC1", 1000)
                val raw = elm("0100", 3000)
                if (isPositiveObdResponse(raw, 0x41, 0x00)) {
                    return candidate
                }
            } catch (_: Exception) {
                // Continue with the next standard CAN variant.
            }
        }
        elm("ATSP0", 1200)
        return null
    }

    private fun isPositiveObdResponse(raw: String, service: Int, pid: Int): Boolean {
        val hex = raw.uppercase(Locale.US).replace(Regex("[^0-9A-F]"), "")
        val marker = String.format(Locale.US, "%02X%02X", service, pid)
        return hex.contains(marker)
    }

    private fun connectBle(device: BluetoothDevice) {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) throw SecurityException("Permissão Bluetooth necessária")

        bleConnectedLatch = CountDownLatch(1)
        bleServicesLatch = CountDownLatch(1)
        bleNotificationLatch = CountDownLatch(1)
        bleGatt = device.connectGatt(this, false, bleCallback, BluetoothDevice.TRANSPORT_LE)

        if (bleConnectedLatch?.await(8, TimeUnit.SECONDS) != true) {
            closeBle()
            throw IOException("BLE: tempo limite ao ligar ao adaptador")
        }
        if (bleServicesLatch?.await(8, TimeUnit.SECONDS) != true || bleWriteCharacteristic == null) {
            closeBle()
            throw IOException("BLE: serviço OBD/UART não encontrado")
        }
        // Notifications must be enabled before any OBD command is sent.
        if (bleNotifyCharacteristic != null &&
            bleNotificationLatch?.await(5, TimeUnit.SECONDS) != true) {
            closeBle()
            throw IOException("BLE: notificações não foram ativadas")
        }
    }

    private val bleCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, statusCode: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                bleConnectedLatch?.countDown()
                if (Build.VERSION.SDK_INT >= 31 &&
                    checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
                ) return
                gatt.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                bleConnectedLatch?.countDown()
                bleServicesLatch?.countDown()
                bleNotificationLatch?.countDown()
                bleWriteLatch?.countDown()
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, statusCode: Int) {
            if (statusCode != BluetoothGatt.GATT_SUCCESS) {
                bleServicesLatch?.countDown()
                return
            }

            var write: BluetoothGattCharacteristic? = null
            var notify: BluetoothGattCharacteristic? = null

            for (service in gatt.services) {
                val serviceMatches = bleUartServices.contains(service.uuid)
                for (characteristic in service.characteristics) {
                    val props = characteristic.properties
                    val canWrite = props and BluetoothGattCharacteristic.PROPERTY_WRITE != 0 ||
                        props and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0
                    val canNotify = props and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0 ||
                        props and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0

                    if (canWrite && (serviceMatches || bleWriteUuids.contains(characteristic.uuid))) write = characteristic
                    if (canNotify && (serviceMatches || bleNotifyUuids.contains(characteristic.uuid))) notify = characteristic
                }
            }

            bleWriteCharacteristic = write
            bleNotifyCharacteristic = notify

            if (notify != null && Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
            ) {
                gatt.setCharacteristicNotification(notify, true)
                val descriptor = notify.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
                if (descriptor != null) {
                    descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    gatt.writeDescriptor(descriptor)
                }
            }
            bleServicesLatch?.countDown()
        }

        override fun onDescriptorWrite(
            gatt: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            statusCode: Int
        ) {
            if (descriptor.uuid == UUID.fromString("00002902-0000-1000-8000-00805F9B34FB")) {
                bleNotificationLatch?.countDown()
            }
        }

        override fun onCharacteristicWrite(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            statusCode: Int
        ) {
            bleWriteLatch?.countDown()
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            characteristic.value?.forEach { bleRx.offer(it) }
        }

        @Deprecated("Deprecated in API 33")
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            value.forEach { bleRx.offer(it) }
        }
    }

    private fun writeBle(data: ByteArray) {
        val gatt = bleGatt ?: throw IOException("BLE não ligado")
        val characteristic = bleWriteCharacteristic ?: throw IOException("BLE: característica de escrita não encontrada")
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) throw SecurityException("Permissão Bluetooth necessária")

        // Android GATT writes are asynchronous. Serialise every command so a
        // new OBD request can never overwrite the previous characteristic write.
        val latch = CountDownLatch(1)
        bleWriteLatch = latch
        characteristic.value = data
        characteristic.writeType =
            if (characteristic.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0)
                BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            else
                BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT

        if (!gatt.writeCharacteristic(characteristic)) {
            bleWriteLatch = null
            throw IOException("BLE: falha ao enviar comando")
        }

        if (characteristic.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE == 0) {
            if (!latch.await(3, TimeUnit.SECONDS)) {
                bleWriteLatch = null
                throw IOException("BLE: tempo limite na escrita")
            }
        } else {
            // Give the controller a short scheduling window before waiting for
            // its notification response.
            Thread.sleep(25)
        }
        bleWriteLatch = null
    }

    private fun closeBle() {
        try {
            if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
            ) return
            bleGatt?.disconnect()
            bleGatt?.close()
        } catch (_: Exception) {}
        bleGatt = null
        bleWriteCharacteristic = null
        bleNotifyCharacteristic = null
        bleRx.clear()
        usingBle = false
    }

    private fun closeTransport() {
        HomeBdForegroundService.stop(this)
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        input = null
        output = null
        closeBle()
        if (::connectButton.isInitialized) {
            runOnUiThread {
                connectButton.text = ui(localized("LIGAR\nOBD-II", "CONNECT\nOBD-II"), "CONNECT\nOBD-II")
                scanButton.text = ui(localized("SCAN PIDs", "SCAN PIDs"), localized("SCAN PIDs", "SCAN PIDs"))
                hvUdsButton.isEnabled = false
                hvUdsButton.alpha = 0.55f
                hasScannedOnce = false
            }
        }
    }

    private fun identifyAdapter(identity: String): String {
        val id = identity.uppercase(Locale.US)
        return when {
            id.contains("STN") -> "STN / OBDLink"
            id.contains("OBDLINK") || id.contains("SCANTOOL") -> "OBDLink / compatível"
            id.contains("ELM327") -> "ELM327 compatível"
            id.isBlank() -> "OBD-II Bluetooth"
            else -> "OBD-II compatível"
        }
    }

    private fun elm(cmd: String, timeout: Long = 2500): String {
        if (usingBle) return elmBle(cmd, timeout)

        val out = output ?: return ""
        val ins = input ?: return ""
        try {
            out.write((cmd + "\r").toByteArray(Charsets.US_ASCII))
            out.flush()
        } catch (e: Exception) {
            throw IOException("Falha ao enviar $cmd: ${e.message}", e)
        }

        val start = System.currentTimeMillis()
        val buf = ByteArray(4096)
        val data = StringBuilder()
        while (System.currentTimeMillis() - start < timeout) {
            if (ins.available() > 0) {
                val n = ins.read(buf)
                if (n > 0) data.append(String(buf, 0, n, Charsets.US_ASCII))
                if (data.contains(">")) break
            } else Thread.sleep(30)
        }
        return data.toString().replace("\r", "\n").replace(">", "").trim()
    }

    private fun elmBle(cmd: String, timeout: Long): String {
        if (bleWriteCharacteristic == null) return ""
        bleRx.clear()
        writeBle((cmd + "\r").toByteArray(Charsets.US_ASCII))
        val deadline = System.currentTimeMillis() + timeout
        val data = StringBuilder()
        while (System.currentTimeMillis() < deadline) {
            val remaining = deadline - System.currentTimeMillis()
            val b = bleRx.poll(minOf(remaining, 100), TimeUnit.MILLISECONDS)
            if (b != null) {
                data.append(b.toInt().and(0xFF).toChar())
                if (data.contains(">")) break
            }
        }
        return data.toString().replace("\r", "\n").replace(">", "").trim()
    }

    @Volatile
    private var liveDataRunning = false

    private fun isTransportConnected(): Boolean = usingBle && bleWriteCharacteristic != null || output != null

    private fun stopLiveData() {
        liveDataRunning = false
    }

    /**
     * Experimental read-only UDS discovery for hybrid/high-voltage ECUs.
     *
     * This deliberately does NOT assume a proprietary battery DID or scaling.
     * It probes a small, conservative DID window on common physical CAN
     * diagnostic request IDs and reports only positive 0x62 responses as RAW
     * hexadecimal payloads. No SecurityAccess, writes, coding or programming
     * services are sent. A positive response is evidence that an identifier is
     * readable; it is not interpreted as a battery value until its definition
     * is verified for the vehicle.
     */
    private fun runHvUdsDiscovery() {
        thread {
            if (!isTransportConnected()) {
                append("⚠ OBDII não está ligado.")
                return@thread
            }
            runOnUiThread {
                hvUdsButton.isEnabled = false
                hvUdsButton.alpha = 0.55f
                setStatusText("Estado: SCAN HV/UDS em execução…")
            }

            append("=== HV / UDS DISCOVERY — READ-ONLY ===")
            append("Sem DIDs proprietários assumidos e sem comandos de escrita.")
            append("1. Estabilizar CAN • 2. Descobrir ECUs • 3. Procurar respostas UDS 0x62.")

            try {
                // Force the standard 11-bit 500 kbit/s CAN profile first. If it
                // fails, the normal transport remains available and the scan
                // reports the failure instead of fabricating an ECU.
                elm("ATSP6", 2000)
                elm("ATCAF1", 1200)
                elm("ATCFC1", 1200)
                elm("ATH1", 1000)

                val discovered = discoverCanEcus()
                if (discovered.isEmpty()) {
                    append("· Nenhuma ECU física respondeu ao 0100 nos IDs 7E0–7EF.")
                    append("· O gateway/adaptador pode não permitir esta descoberta por endereço físico.")
                } else {
                    append("✓ ECUs OBD/CAN com resposta: ${discovered.joinToString(", ")}")
                }

                // Identification DIDs are intentionally limited to the public
                // standard/documented range. Do not turn an unknown response
                // into a battery measurement. A positive 0x62 is only recorded
                // as RAW data for later verification.
                val dids = (0xF180..0xF1FF).map { String.format(Locale.US, "%04X", it) }
                val targets = if (discovered.isEmpty()) (0x7E0..0x7E7).toList() else discovered
                var found = 0
                val results = mutableListOf<String>()

                for (requestId in targets) {
                    val req = String.format(Locale.US, "%03X", requestId)
                    val responseId = String.format(Locale.US, "%03X", requestId + 8)
                    elm("ATSH$req", 800)
                    elm("ATCRA$responseId", 800)

                    for (did in dids) {
                        val raw = elm("22$did", 750)
                        val payload = extractUdsDidPayload(raw, did)
                        if (payload.isNotBlank()) {
                            found++
                            val line = "• ECU $req • DID $did → $payload"
                            results.add(line)
                            append("✓ $line")
                        }
                    }
                }

                elm("ATCRA", 800)
                elm("ATH0", 800)
                // Keep the working CAN protocol if one was identified; only
                // fall back to AUTO when the adapter did not answer CAN at all.
                if (detectedProtocol.isBlank() || detectedProtocol == "0") {
                    elm("ATSP0", 1200)
                    detectedProtocol = elm("ATDPN", 1200).trim().uppercase().removePrefix("A")
                }

                runOnUiThread {
                    liveDataLog.append("\n=== HV / UDS DISCOVERY ===\n")
                    liveDataLog.append("• ECUs descobertas: ${if (discovered.isEmpty()) "nenhuma" else discovered.joinToString(", ")}\n")
                    if (results.isEmpty()) {
                        liveDataLog.append("• Nenhuma resposta UDS positiva na janela F180–F1FF.\n")
                        liveDataLog.append("• Isto não prova que o BMS não seja acessível; pode usar outro endereço, gateway ou sessão.\n")
                    } else {
                        liveDataLog.append("• $found resposta(s) UDS encontrada(s).\n")
                        results.forEach { liveDataLog.append(it + "\n") }
                        liveDataLog.append("• Valores apresentados como RAW; ainda não são convertidos para SOC, kW ou kWh.\n")
                    }
                    setStatusText("Estado: LIGADO • SCAN HV/UDS concluído")
                    hvUdsButton.isEnabled = true
                    hvUdsButton.alpha = 1f
                }
            } catch (e: Exception) {
                append("✕ HV/UDS: ${e.message ?: "erro desconhecido"}")
                try { elm("ATCRA", 800); elm("ATH0", 800) } catch (_: Exception) {}
                runOnUiThread {
                    setStatusText("Estado: LIGADO • SCAN HV/UDS com erro")
                    hvUdsButton.isEnabled = true
                    hvUdsButton.alpha = 1f
                }
            }
            append("=== FIM HV / UDS DISCOVERY ===")
        append("=== GPS / TELEMÁTICA DISCOVERY — READ-ONLY ===")
        append("Sem coordenadas ou DIDs GPS assumidos.")
        append("Procurar módulo de telemática apenas através de respostas UDS confirmadas.")
        append("=== FIM GPS / TELEMÁTICA DISCOVERY ===")
        }
    }

    private fun discoverCanEcus(): List<Int> {
        val found = mutableListOf<Int>()
        for (requestId in 0x7E0..0x7EF) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)
            elm("ATSH$req", 600)
            elm("ATCRA$responseId", 600)
            val raw = elm("0100", 1200)
            if (isPositiveObdResponse(raw, 0x41, 0x00)) {
                found.add(requestId)
                append("✓ ECU descoberta: $req → $responseId")
            }
        }
        elm("ATCRA", 700)
        return found
    }

    private fun extractUdsDidPayload(raw: String, did: String): String {
        val hex = raw.uppercase(Locale.US).replace(Regex("[^0-9A-F]"), "")
        val marker = "62${did.uppercase(Locale.US)}"
        val start = hex.indexOf(marker)
        if (start < 0) return ""
        val dataStart = start + marker.length
        if (dataStart >= hex.length) return ""
        // Limit to the first 64 bytes of payload to keep logs manageable.
        val end = minOf(hex.length, dataStart + 128)
        return hex.substring(dataStart, end)
    }

    private fun runScanner() {
        thread {
            if (!isTransportConnected()) {
                append("⚠ OBDII não está ligado.")
                return@thread
            }

            if (liveDataRunning) {
                liveDataRunning = false
                Thread.sleep(250)
            }

            runOnUiThread {
                setStatusText("Estado: SCAN OBD-II em execução…")
                scanButton.isEnabled = false
                scanButton.alpha = 0.55f
            }

            append("=== SCAN OBD-II ===")
            append("A consultar PIDs genéricos...")
            append("")

            val selectedProfile = manufacturerProfiles.getOrNull(manufacturerSpinner.selectedItemPosition)
                ?: manufacturerProfiles.first()

            append("Perfil: ${selectedProfile.name}")
            append("Modo: leitura apenas")
            if (canActive) {
                append("CAN: ativo • protocolo $detectedProtocol")
                append("ISO-TP: leitura através do ELM327")
            } else {
                append("CAN: não identificado pelo adaptador/protocolo atual")
            }
            append("")

            // Discover support once. LIVE DATA then repeatedly reads only these
            // confirmed PIDs, keeping the UI current without rescanning.
            val scanList = discoverSupportedStandardPids()

            runOnUiThread {
                liveDataLog.text = "LIVE DATA — ${selectedProfile.name}\n\n" +
                    if (scanList.isEmpty()) {
                        "Nenhum PID standard confirmado pelo veículo.\n\n" +
                            "O HOMEBD não inventa dados: apenas mostra parâmetros efetivamente suportados.\n"
                    } else {
                        "${scanList.size} PIDs standard suportados detetados.\n\n"
                    }
            }

            if (scanList.isEmpty()) {
                append("· Nenhum PID standard suportado foi confirmado.")
                runOnUiThread {
                    setStatusText("Estado: LIGADO • SCAN concluído")
                    scanButton.isEnabled = true
                    scanButton.alpha = 1f
                    scanButton.text = if (hasScannedOnce) "RESCAN PIDs" else ui(localized("SCAN PIDs", "SCAN PIDs"), localized("SCAN PIDs", "SCAN PIDs"))
                }
                return@thread
            }

            if (canActive) {
                runCanReadOnlyChecks()
                prepareStandardObdSession()
            }

            append("=== LIVE DATA EM TEMPO REAL ===
// Não iniciar SCAN/DISCOVERY novamente durante LIVE DATA. RESCAN é explícito.")
            append("Leitura automática contínua • intervalo aproximado 1 s")
            runOnUiThread {
                setStatusText("Estado: LIGADO • LIVE DATA • tempo real")
                scanButton.isEnabled = true
                scanButton.alpha = 1f
                hvUdsButton.isEnabled = true
                hvUdsButton.alpha = 1f
                hasScannedOnce = true
                scanButton.text = "RESCAN PIDs"
            }

            liveDataRunning = true

            // O ELM327 é um transporte serial: ler os 36 PIDs em sequência em
            // cada ciclo torna impossível que os parâmetros dinâmicos cheguem
            // ao Home Assistant em ~1 s. Os PIDs rápidos são lidos em todos os
            // ciclos; os restantes são intercalados, um por ciclo.
            val fastLivePids = setOf(
                "0104", "0105", "010B", "010C", "010D", "010E", "010F",
                "0110", "0111", "0142", "0149", "014A", "015E"
            )
            val fastList = scanList.filter { fastLivePids.contains(it.first.uppercase()) }
            val slowList = scanList.filterNot { fastLivePids.contains(it.first.uppercase()) }
            val latestValues = linkedMapOf<String, String>()
            var slowIndex = 0

            while (liveDataRunning && isTransportConnected()) {
                try {
                    val readList = buildList {
                        addAll(if (fastList.isNotEmpty()) fastList else scanList.take(6))
                        if (slowList.isNotEmpty()) {
                            add(slowList[slowIndex % slowList.size])
                            slowIndex++
                        }
                    }.distinctBy { it.first }

                    var liveFuelRateLph: Double? = null
                    var liveSpeedKmh: Double? = null
                    var liveFuelType: String? = null

                    for ((pid, label) in readList) {
                        if (!liveDataRunning || !isTransportConnected()) break

                        val raw = readObdPidReliable(pid)
                        val result = if (raw.isBlank()) {
                            "· NO DATA — sem resposta válida 41 ${pid.substring(2).uppercase()}"
                        } else {
                            decodeObdPid(pid, raw)
                        }

                        latestValues[pid] = result
                        homeAssistantBridge.publishPid(pid, label, result)

                        if (pid.equals("015E", ignoreCase = true)) {
                            liveFuelRateLph = result.substringBefore(" ")
                                .replace(",", ".").toDoubleOrNull()
                        }
                        if (pid.equals("0151", ignoreCase = true)) liveFuelType = result.trim()
                        if (pid.equals("010D", ignoreCase = true)) {
                            liveSpeedKmh = result.substringBefore(" ")
                                .replace(",", ".").toDoubleOrNull()
                        }
                    }

                    // Keep the complete dashboard populated with the most recent
                    // value of every PID, while only querying a small dynamic set
                    // on each fast cycle.
                    val lines = scanList.map { (pid, label) ->
                        val value = latestValues[pid]
                            ?: "· A aguardar primeira leitura"
                        "• $label: $value"
                    }.toMutableList()

                    liveFuelRateLph?.let { fuelRate ->
                        lines.add(
                            "• Consumo de combustível: " +
                                if (liveSpeedKmh != null && liveSpeedKmh!! > 0.0) {
                                    "%.2f L/100 km".format(
                                        Locale.US,
                                        fuelRate * 100.0 / liveSpeedKmh!!
                                    )
                                } else {
                                    "— L/100 km (veículo parado)"
                                }
                        )
                    }

                    val electricalVehicle =
                        liveFuelType?.contains("Electric", ignoreCase = true) == true ||
                        liveFuelType?.contains("Bifuel electric", ignoreCase = true) == true

                    if (electricalVehicle) {
                        lines.add("• Consumo elétrico: Não disponível via OBD-II standard")
                        lines.add("• Potência elétrica: Não disponível via OBD-II standard")
                    }

                    val header = "LIVE DATA — ${selectedProfile.name}\n\n" +
                        "${scanList.size} PIDs standard suportados detetados.\n" +
                        "Atualização dinâmica • parâmetros rápidos ≈ 1 s\n\n"

                    runOnUiThread {
                        if (liveDataRunning) {
                            val oldScrollY = liveDataScroll.scrollY
                            liveDataLog.text = header + lines.joinToString("\n")
                            renderGroupedLiveData(header, lines)
                            liveDataContainer.post {
                                liveDataScroll.scrollTo(0, oldScrollY.coerceAtMost(liveDataContainer.height))
                            }
                        }
                    }

                    // Small delay prevents hammering the ELM327 while retaining
                    // near-real-time updates for the dynamic parameters.
                    Thread.sleep(250)
                } catch (e: Exception) {
                    if (liveDataRunning) append("⚠ LIVE DATA: ${e.message ?: "erro de leitura"}")
                    Thread.sleep(600)
                }
            }

            runOnUiThread {
                hvUdsButton.isEnabled = isTransportConnected()
                hvUdsButton.alpha = if (isTransportConnected()) 1f else 0.55f
                setStatusText(if (isTransportConnected())
                    "Estado: LIGADO • LIVE DATA parado"
                else
                    ui(localized("Estado: desligado", "Status: disconnected"), "Status: disconnected"))
                scanButton.isEnabled = isTransportConnected()
                scanButton.alpha = if (isTransportConnected()) 1f else 0.55f
                connectButton.text = if (isTransportConnected()) "DESLIGAR\nOBD-II" else ui(localized("LIGAR\nOBD-II", "CONNECT\nOBD-II"), "CONNECT\nOBD-II")
            }
        }
    }

    /**
     * Read-only CAN/ISO-TP checks.
     *
     * The ELM327 handles ISO 15765-4 segmentation/flow-control for normal
     * OBD-II requests. No ECU write service (2E/31/etc.) is sent here.
     */
    /**
     * Reads the standard Mode 01 supported-PID bitmaps first, then requests
     * only PIDs the vehicle reports as supported. This keeps every manufacturer
     * profile standards-based without copying proprietary manufacturer maps.
     */

    private val homeAssistantPrefs by lazy {
        getSharedPreferences("homebd_home_assistant", MODE_PRIVATE)
    }

    private fun homeAssistantUrl(): String =
        homeAssistantPrefs.getString("url", "")?.trim().orEmpty()

    private fun homeAssistantToken(): String =
        homeAssistantPrefs.getString("token", "")?.trim().orEmpty()

    private fun validWebUrl(value: String): Boolean =
        value.startsWith("http://") || value.startsWith("https://")

    private fun configureHomeAssistantLink() {
        if (!isActivityUsable()) return
        try {
            val urlInput = EditText(this).apply {
                hint = "Endereço Home Assistant (https://...)"
                setText(homeAssistantUrl())
                textSize = 14f
                inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_URI
            }
            val tokenInput = EditText(this).apply {
                hint = "Token de acesso Home Assistant"
                setText(homeAssistantToken())
                textSize = 14f
                inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(20), dp(4), dp(20), 0)
                addView(urlInput, LinearLayout.LayoutParams(-1, dp(52)))
                addView(tokenInput, LinearLayout.LayoutParams(-1, dp(52)))
            }
            AlertDialog.Builder(this)
                .setTitle("HOMEBD • Home Assistant")
                .setMessage("A HOMEBD comunica exclusivamente com a integração através de WebSocket persistente.")
                .setView(box)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("GUARDAR E LIGAR") { _, _ ->
                    val endpoint = urlInput.text.toString().trim().trimEnd('/')
                    val token = tokenInput.text.toString().trim()
                    if (!validWebUrl(endpoint) || token.isBlank()) {
                        Toast.makeText(this, "Introduza o endereço e o token do Home Assistant.", Toast.LENGTH_LONG).show()
                        return@setPositiveButton
                    }
                    homeAssistantPrefs.edit()
                        .putString("url", endpoint)
                        .putString("token", token)
                        .remove("local_url")
                        .remove("external_url")
                        .apply()
                    homeAssistantBridge.save(endpoint, token)
                    homeAssistantStatusView.text = "Home Assistant · a ligar…"
                    homeAssistantConnectButton.isEnabled = false
                    homeAssistantBridge.connect { ok, msg ->
                        safeUi {
                            homeAssistantConnectButton.isEnabled = true
                            homeAssistantStatusView.text = if (ok) "Home Assistant · WebSocket · ligado" else "Home Assistant · $msg"
                            homeAssistantConnectButton.text = if (ok) ui("HOME\nASSISTANT", "HOME\nASSISTANT") else ui(localized("HOME\nASSISTANT", "HOME\nASSISTANT"), "HOME\nASSISTANT")
                            append(if (ok) "✓ $msg" else "⚠ $msg")
                        }
                    }
                }
                .show()
        } catch (t: Throwable) {
            Toast.makeText(this, "Não foi possível configurar o Home Assistant.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openHomeAssistant() {
        try {
            if (!isActivityUsable()) return
            val url = homeAssistantUrl()
            if (url.isBlank()) {
                configureHomeAssistantLink()
                return
            }
            openWebUrl(url)
        } catch (_: Throwable) {
            Toast.makeText(this, "Não foi possível abrir o Home Assistant.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openWebUrl(value: String) {
        if (!validWebUrl(value)) {
            configureHomeAssistantLink()
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(value)))
        } catch (_: Exception) {
            Toast.makeText(this, "Não foi possível abrir o Home Assistant.", Toast.LENGTH_LONG).show()
        }
    }

    private fun renderGroupedLiveData(header: String, lines: List<String>) {
        liveDataContainer.removeAllViews()

        val intro = TextView(this).apply {
            text = header.trimEnd()
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(dp(6), dp(4), dp(6), dp(8))
        }
        liveDataContainer.addView(intro, LinearLayout.LayoutParams(-1, -2))

        val groups = linkedMapOf(
            "MOTOR" to mutableListOf<String>(),
            "TEMPERATURAS" to mutableListOf<String>(),
            "COMBUSTÍVEL" to mutableListOf<String>(),
            "ADMISSÃO / ACELERADOR" to mutableListOf<String>(),
            "ELÉTRICO / HÍBRIDO" to mutableListOf<String>(),
            "EMISSÕES" to mutableListOf<String>(),
            ui(localized("DIAGNÓSTICO", "DIAGNOSTICS"), "DIAGNOSTICS") to mutableListOf<String>()
        )

        fun addGroup(name: String, line: String) { groups[name]?.add(line) }
        lines.forEach { line ->
            val l = line.lowercase(Locale.getDefault())
            when {
                listOf("temperatura", "temperature", "catalisador", "arrefecimento", "admissão", "intake air", "óleo", "oil", "exterior").any { l.contains(it) } -> addGroup("TEMPERATURAS", line)
                listOf("combustível", "fuel", "fuel trim", "pressão de combustível", "fuel pressure", "injeção").any { l.contains(it) } -> addGroup("COMBUSTÍVEL", line)
                listOf("acelerador", "throttle", "borboleta", "map:", "maf", "pressão de admissão", "intake").any { l.contains(it) } -> addGroup("ADMISSÃO / ACELERADOR", line)
                listOf("o2", "lambda", "nox", "emission", "emissões", "egr", "particulate", "dpf", "catalyst").any { l.contains(it) } -> addGroup("EMISSÕES", line)
                listOf("voltagem", "voltage", "potência elétrica", "consumo elétrico", "energia elétrica", "hybrid", "electric", "bateria").any { l.contains(it) } -> addGroup("ELÉTRICO / HÍBRIDO", line)
                listOf("vin", "pid", "dtc", "diagnóstico", "diagnostic", "ecu", "adaptador").any { l.contains(it) } -> addGroup(ui(localized("DIAGNÓSTICO", "DIAGNOSTICS"), "DIAGNOSTICS"), line)
                else -> addGroup("MOTOR", line)
            }
        }

        groups.forEach { (name, items) ->
            if (items.isEmpty()) return@forEach
            val expanded = liveGroupExpanded.getOrPut(name) { true }
            val headerView = TextView(this).apply {
                text = (if (expanded) "▼ " else "▶ ") + name + "  •  ${items.size}"
                textSize = 12f
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.rgb(45, 45, 45))
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(7), dp(8), dp(7))
                isClickable = true
                setOnClickListener {
                    liveGroupExpanded[name] = !(liveGroupExpanded[name] ?: true)
                    renderGroupedLiveData(header, lines)
                }
            }
            liveDataContainer.addView(headerView, LinearLayout.LayoutParams(-1, dp(34)).apply {
                setMargins(0, dp(3), 0, dp(1))
            })

            if (expanded) {
                val body = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(4), dp(2), dp(4), dp(4))
                }
                items.forEach { item ->
                    val lineView = TextView(this).apply {
                        text = item
                        textSize = 13f
                        setTextColor(Color.LTGRAY)
                        setPadding(dp(10), dp(5), dp(8), dp(5))
                        isClickable = true
                        setOnLongClickListener {
                            val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("HOMEBD LIVE DATA", item))
                            Toast.makeText(this@MainActivity, "Dado copiado", Toast.LENGTH_SHORT).show()
                            true
                        }
                    }
                    body.addView(lineView, LinearLayout.LayoutParams(-1, -2))
                }
                body.setOnLongClickListener {
                    val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("HOMEBD $name", items.joinToString("\n")))
                    Toast.makeText(this, "$name copiado", Toast.LENGTH_SHORT).show()
                    true
                }
                liveDataContainer.addView(body, LinearLayout.LayoutParams(-1, -2))
            }
        }
    }

    private fun prepareStandardObdSession() {
        if (!isTransportConnected()) return
        val protocol = detectedProtocol.trim().uppercase(Locale.US)
        if (protocol.isNotBlank() && protocol != "0") elm("ATSP$protocol", 1500)
        elm("ATCAF1", 1000)
        elm("ATCFC1", 1000)
        elm("ATH0", 1000)
        elm("ATCRA", 1000)
        elm("ATSH7DF", 1000)
        elm("ATAT1", 1000)
    }

    private fun discoverSupportedStandardPids(): List<Pair<String, String>> {
        prepareStandardObdSession()
        val blocks = listOf("0100", "0120", "0140", "0160", "0180", "01A0", "01C0")
        val supported = linkedSetOf<Int>()

        blocks.forEach { supportPid ->
            val raw = elm(supportPid, 3000)
            val bytes = obdPayloadBytes(raw, 0x41, supportPid.substring(2).toInt(16))
            if (bytes.size >= 4) {
                val bitmap = (bytes[0] shl 24) or (bytes[1] shl 16) or
                    (bytes[2] shl 8) or bytes[3]
                val base = supportPid.substring(2).toInt(16) + 1
                for (bit in 0..31) {
                    if ((bitmap and (1 shl (31 - bit))) != 0) {
                        supported.add(base + bit)
                    }
                }
            }
        }

        val result = pids.entries.filter { (pid, _) ->
            val value = pid.substring(2).toInt(16)
            value in supported && value !in setOf(0x20, 0x40, 0x60, 0x80, 0xA0, 0xC0)
        }.map { it.key to it.value }

        append("✓ Capacidade OBD-II: ${result.size} PID(s) suportado(s) detetado(s).")
        return result
    }

    private fun obdPayloadBytes(raw: String, service: Int, pid: Int): List<Int> {
        val hex = raw.uppercase().replace(Regex("[^0-9A-F]"), "")
        if (hex.length < 4) return emptyList()

        val bytes = ArrayList<Int>()
        var i = 0
        while (i + 1 < hex.length) {
            hex.substring(i, i + 2).toIntOrNull(16)?.let { bytes.add(it) }
            i += 2
        }

        // ELM327 pode devolver cabeçalhos CAN/ISO-TP e bytes de comprimento
        // antes de 41 <PID>. Localizar o par de resposta evita interpretar
        // esses bytes como parte do valor do PID.
        for (index in 0 until bytes.size - 1) {
            if (bytes[index] == service && bytes[index + 1] == pid) {
                return bytes.drop(index + 2)
            }
        }
        return emptyList()
    }

    /**
     * Lê um PID OBD-II confirmado, com recuperação da sessão quando o
     * adaptador perde temporariamente o filtro/cabeçalho CAN.
     * Apenas respostas positivas 41 <PID> são aceites como dados.
     */
    private fun readObdPidReliable(pid: String): String {
        val pidNum = pid.substring(2).toIntOrNull(16) ?: return ""
        repeat(2) { attempt ->
            val raw = elm(pid, 1800)
            if (obdPayloadBytes(raw, 0x41, pidNum).isNotEmpty()) return raw

            // Recuperar a sessão standard antes da segunda tentativa.
            if (attempt == 0 && isTransportConnected()) {
                prepareStandardObdSession()
                Thread.sleep(80)
            }
        }
        return ""
    }

    private fun decodeObdPid(pid: String, raw: String): String {
        val pidNum = pid.substring(2).toIntOrNull(16) ?: return classifyResponse(raw)
        val payload = obdPayloadBytes(raw, 0x41, pidNum)
        if (payload.isEmpty()) return classifyResponse(raw)

        fun u16(): Int = ((payload.getOrNull(0) ?: 0) shl 8) or (payload.getOrNull(1) ?: 0)
        fun u32(): Long = ((payload.getOrNull(0)?.toLong() ?: 0L) shl 24) or
            ((payload.getOrNull(1)?.toLong() ?: 0L) shl 16) or
            ((payload.getOrNull(2)?.toLong() ?: 0L) shl 8) or
            (payload.getOrNull(3)?.toLong() ?: 0L)
        fun pct(a: Int): String = "%.1f %%".format(Locale.US, a * 100.0 / 255.0)
        fun signedPct(a: Int): String = "%.1f %%".format(Locale.US, a * 100.0 / 128.0 - 100.0)
        fun temp(a: Int): String = "${a - 40} °C"

        return when (pid.uppercase()) {
            "0101" -> decodeMonitorStatus(payload)
            "0102" -> "DTC status: 0x${u16().toString(16).uppercase().padStart(4, '0')}"
            "0103" -> decodeFuelSystemStatus(payload.first())
            "0104" -> pct(payload.first())
            "0105", "010F", "0146", "015C" -> temp(payload.first())
            "0106", "0107", "0108", "0109", "012D", "0155", "0156", "0157", "0158" -> signedPct(payload.first())
            "010A" -> "${payload.first() * 3} kPa"
            "010B" -> "${payload.first()} kPa"
            "010C" -> "%.0f rpm".format(Locale.US, u16() / 4.0)
            "010D" -> "${payload.first()} km/h"
            "010E" -> "%.1f °".format(Locale.US, payload.first() / 2.0 - 64.0)
            "0110" -> "%.2f g/s".format(Locale.US, u16() / 100.0)
            "0111", "0145", "0147", "0148", "0149", "014A", "014B", "015A" -> pct(payload.first())
            "0112" -> decodeSecondaryAirStatus(payload.first())
            "0113", "011D" -> "Sensor presence bitmap: 0x${payload.first().toString(16).uppercase().padStart(2, '0')}"
            in setOf("0114", "0115", "0116", "0117", "0118", "0119", "011A", "011B") ->
                decodeOxygenVoltageTrim(payload)
            "011C" -> decodeObdStandard(payload.first())
            "011E" -> if (payload.first() and 1 == 1) "Active" else "Inactive"
            "011F" -> "${u16()} s (${u16() / 60} min)"
            "0120", "0140", "0160", "0180", "01A0", "01C0" -> "Supported PID bitmap: 0x${u32().toString(16).uppercase().padStart(8, '0')}"
            "0121", "0131" -> "${u16()} km"
            "0122" -> "%.0f kPa".format(Locale.US, u16() * 0.079)
            "0123" -> "${u16() * 10} kPa"
            in setOf("0124", "0125", "0126", "0127", "0128", "0129", "012A", "012B") -> decodeOxygenWideVoltage(payload)
            "012C" -> pct(payload.first())
            "012E" -> pct(payload.first())
            "012F" -> pct(payload.first())
            "0130" -> "${payload.first()} warm-ups"
            "0132" -> "${signedU16(payload) * 0.25} Pa"
            "0133" -> "${payload.first()} kPa"
            in setOf("0134", "0135", "0136", "0137", "0138", "0139", "013A", "013B") -> decodeOxygenWideVoltage(payload)
            "013C", "013D", "013E", "013F" -> "%.1f °C".format(Locale.US, u16() / 10.0 - 40.0)
            "0141" -> decodeMonitorStatus(payload)
            "0142" -> "%.3f V".format(Locale.US, u16() / 1000.0)
            "0143" -> "%.1f %%".format(Locale.US, u16() * 100.0 / 255.0)
            "0144" -> "%.3f ratio".format(Locale.US, u16() / 32768.0)
            "0145" -> pct(payload.first())
            "0146" -> temp(payload.first())
            "014C" -> pct(payload.first())
            "014D", "014E" -> "${u16()} min"
            "0151" -> decodeFuelType(payload.first())
            "0152" -> pct(payload.first())
            "0153" -> "%.3f kPa".format(Locale.US, u16() / 200.0)
            "0154" -> "${signedU16(payload)} Pa"
            "0159" -> "%.0f kPa".format(Locale.US, u16() * 10.0)
            "015B" -> pct(payload.first())
            "015C" -> temp(payload.first())
            "015D" -> "%.2f °".format(Locale.US, u16() / 128.0 - 210.0)
            "015E" -> "%.2f L/h".format(Locale.US, u16() / 20.0)
            "015F", "0161", "0162", "0163" -> "%.1f %% torque".format(Locale.US, payload.first() - 125.0)
            "0165" -> "%.1f mA".format(Locale.US, u16() * 0.001)
            "0166", "0167", "0168", "0169", "0184" -> temp(payload.first())
            "016A", "016E" -> pct(payload.first())
            "016B", "016F" -> "${u16()} kPa"
            "016C" -> "%.1f %%".format(Locale.US, payload.first() * 100.0 / 255.0)
            "016D" -> temp(payload.first())
            "0170", "0171", "0172" -> "Dados multi-byte — não simplificado"
            "0173" -> "${u16()} kPa"
            "0174" -> "${u16()} rpm"
            "0175", "0176", "0177", "0178", "0179", "017A", "017C" -> "Dados multi-byte — não simplificado"
            "017B", "017D", "017E", "017F" -> "Dados multi-byte — não simplificado"
            "0183", "01A1", "01A7", "01A8" -> "NOx: dados multi-byte — não simplificado"
            "0185", "0186", "0187", "0188", "019A", "019D", "01A3" -> "Dados multi-byte — não simplificado"
            else -> "${payload.joinToString(" ") { "%02X".format(it) }} (raw)"
        }
    }

    private fun decodeMonitorStatus(p: List<Int>): String {
        if (p.size < 4) return "Monitor bitmap: ${p.joinToString(" ") { "%02X".format(it) }}"
        val mil = (p[0] and 0x80) != 0
        val dtcCount = p[0] and 0x7F
        val misfireReady = (p[1] and 0x01) != 0
        val fuelReady = (p[1] and 0x02) != 0
        return "MIL=${if (mil) "ON" else "OFF"} • DTC=$dtcCount • monitors=${if (misfireReady || fuelReady) "available" else "not reported"}"
    }

    private fun decodeFuelSystemStatus(code: Int): String = when (code) {
        0x01 -> "Open loop — insufficient engine temperature"
        0x02 -> "Closed loop — using oxygen sensor feedback"
        0x04 -> "Open loop — engine load / fuel cut"
        0x08 -> "Open loop — system fault"
        0x10 -> "Closed loop — fault with at least one sensor"
        else -> "Code 0x${code.toString(16).uppercase().padStart(2, '0')}"
    }

    private fun decodeSecondaryAirStatus(code: Int): String = when (code) {
        0x01 -> "Upstream of catalytic converter"
        0x02 -> "Downstream of catalytic converter"
        0x04 -> "Atmosphere"
        else -> "Code 0x${code.toString(16).uppercase().padStart(2, '0')}"
    }

    private fun decodeObdStandard(code: Int): String = when (code) {
        0x01 -> "OBD-II as defined by CARB"
        0x02 -> "OBD as defined by EPA"
        0x03 -> "OBD and OBD-II"
        0x04 -> "OBD-I"
        0x05 -> "Not intended for OBD"
        0x06 -> "EOBD"
        0x07 -> "EOBD and OBD-II"
        0x08 -> "EOBD and OBD"
        0x09 -> "EOBD, OBD and OBD-II"
        0x0A -> "JOBD"
        else -> "Standard code 0x${code.toString(16).uppercase().padStart(2, '0')}"
    }

    private fun decodeFuelType(code: Int): String = when (code) {
        0x01 -> "Gasoline"
        0x02 -> "Methanol"
        0x03 -> "Ethanol"
        0x04 -> "Diesel"
        0x05 -> "LPG"
        0x06 -> "CNG"
        0x07 -> "Propane"
        0x08 -> "Electric"
        0x09 -> "Bifuel gasoline"
        0x0A -> "Bifuel methanol"
        0x0B -> "Bifuel ethanol"
        0x0C -> "Bifuel LPG"
        0x0D -> "Bifuel CNG"
        0x0E -> "Bifuel propane"
        0x0F -> "Bifuel electric"
        0x10 -> "Bifuel electric + combustion"
        else -> "Fuel type code 0x${code.toString(16).uppercase().padStart(2, '0')}"
    }

    private fun decodeOxygenVoltageTrim(p: List<Int>): String {
        val voltage = p.getOrNull(0)?.times(0.005) ?: 0.0
        val trim = p.getOrNull(1)?.let { it * 100.0 / 128.0 - 100.0 }
        return if (trim == null) "%.3f V".format(Locale.US, voltage)
        else "%.3f V • trim %.1f %%".format(Locale.US, voltage, trim)
    }

    private fun signedU16(p: List<Int>): Int {
        if (p.size < 2) return 0
        val value = (p[0] shl 8) or p[1]
        return if ((value and 0x8000) != 0) value - 0x10000 else value
    }

    private fun decodeOxygenWideVoltage(p: List<Int>): String {
        if (p.size < 4) return "Dados insuficientes"
        val ratioRaw = (p[0] shl 8) or p[1]
        val voltageRaw = (p[2] shl 8) or p[3]
        val ratio = ratioRaw * 2.0 / 65536.0
        val voltage = voltageRaw * 8.0 / 65536.0
        return "lambda %.3f • %.3f V".format(Locale.US, ratio, voltage)
    }

    private fun runCanReadOnlyChecks() {
        append("=== CAN READ-ONLY ===")
        append("ISO-TP: consultar identificação standard OBD-II")

        val selectedProfile = manufacturerProfiles.getOrNull(manufacturerSpinner.selectedItemPosition)
        when (selectedProfile?.name) {
            "Stellantis • Opel / Vauxhall", "Stellantis" -> runStellantisUdsReadOnly()
            "Renault / Dacia" -> runRenaultUdsReadOnly()
            "Volkswagen / Audi / SEAT / Škoda" -> runVagUdsReadOnly()
            "Ford" -> runFordUdsReadOnly()
            "Nissan / INFINITI" -> runNissanUdsReadOnly()
            "Tesla" -> runTeslaUdsReadOnly()
            "Subaru" -> runSubaruReadOnly()
            "Mitsubishi" -> runMitsubishiReadOnly()
            "Lexus" -> runLexusReadOnly()
            "Mazda" -> runMazdaReadOnly()
            "Isuzu" -> runIsuzuReadOnly()
            "BMW" -> runGenericManufacturerUdsReadOnly("BMW", listOf(UdsDid("F190", "VIN")))
            "Mercedes-Benz" -> runGenericManufacturerUdsReadOnly("Mercedes-Benz", listOf(UdsDid("F190", "VIN")))
            "Volvo" -> runGenericManufacturerUdsReadOnly("Volvo", listOf(UdsDid("F190", "VIN")))
            "Honda" -> runGenericManufacturerUdsReadOnly("Honda / Acura", listOf(UdsDid("F190", "VIN")))
            "Hyundai / Kia" -> runGenericManufacturerUdsReadOnly("Hyundai / Kia", listOf(UdsDid("F190", "VIN")))
            "Jaguar / Land Rover" -> runGenericManufacturerUdsReadOnly("Jaguar / Land Rover", listOf(UdsDid("F190", "VIN")))
            "Porsche" -> runGenericManufacturerUdsReadOnly("Porsche", listOf(UdsDid("F190", "VIN")))
            "Suzuki" -> runGenericManufacturerUdsReadOnly("Suzuki", listOf(UdsDid("F190", "VIN")))
            "Geely / Polestar" -> runGenericManufacturerUdsReadOnly("Geely / Polestar", listOf(UdsDid("F190", "VIN")))
        }

        // Universal discovery order (all vehicle queries remain READ-ONLY).
        append("=== DISCOVERY UNIVERSAL ===")
        append("1. OBD-II standard • 2. VIN • 3. HV/BMS • 4. GPS/Telemática • 5. LIVE DATA • 6. Home Assistant")
        append("Perfil: Automático • sem DIDs proprietários assumidos")

        // Mode 09 PID 02: VIN. Retry because ELM327 adapters can occasionally
        // return only part of a multi-frame response on the first request.
        // A complete 17-character VIN is required before accepting the value.
        val vin = readCompleteVin()
        reportCanValue("VIN", if (vin.isNotBlank()) "VIN 17 chars" else "NO DATA", vin)

        // Mode 09 PID 04: calibration ID, when available.
        val calRaw = elm("0904", 5000)
        val cal = extractObdAscii(calRaw, 0x49, 0x04)
        reportCanValue("Calibration ID", calRaw, cal)

        // Mode 01 PID 00 is a standard CAN/OBD capability query.
        val pid00 = elm("0100", 3000)
        append("CAN 0100: ${classifyResponse(pid00)}")

        runOnUiThread {
            liveDataLog.append(
                "• CAN: ${if (canActive) "ATIVO / READ-ONLY" else "não disponível"}\\n"
            )
            if (vin.isNotBlank()) liveDataLog.append("• VIN: $vin\\n")
            if (cal.isNotBlank()) liveDataLog.append("• Calibration ID: $cal\\n")
        }
    }

    /**
     * Stellantis UDS READ-ONLY scanner.
     *
     * This does not unlock or bypass a Secure Gateway. It only sends UDS
     * ReadDataByIdentifier (0x22) requests to common 11-bit diagnostic
     * request IDs and accepts positive responses (0x62).
     */
    private fun runGenericManufacturerUdsReadOnly(name: String, dids: List<UdsDid>) {
        append("=== $name UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("A procurar ECUs nos IDs 7E0–7E7…")
        append("Sem mapa proprietário: apenas DIDs standard configurados.")

        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)
            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)
            for (did in dids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread { liveDataLog.append("• ECU $req — ${did.label}: $value\n") }
                }
            }
        }
        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")
        if (found == 0) append("· Nenhum DID UDS $name respondeu.")
        else append("✓ $found leitura(s) UDS $name obtida(s).")
        append("=== FIM $name UDS ===")
    }

    private fun runStellantisUdsReadOnly() {
        append("=== STELLANTIS UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("A procurar ECUs nos IDs 7E0–7E7…")

        // ELM327: CAN 11-bit, automatic formatting and flow control.
        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)

            // Restrict replies to the matching physical ECU response.
            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in stellantisDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        // Return ELM to automatic protocol/headers for normal OBD-II use.
        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhum DID UDS Stellantis respondeu.")
            append("· Isto pode significar ECU não acessível, DID não suportado ou SGW/rede a bloquear a leitura.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM STELLANTIS UDS ===")
    }

    /**
     * Renault / Dacia UDS READ-ONLY scanner.
     *
     * Uses only standardized identification DIDs from the F18x/F19x range.
     * No security access, session switching, coding or programming is sent.
     */
    private fun runRenaultUdsReadOnly() {
        append("=== RENAULT / DACIA UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("DIDs: identificação ECU standard ISO 14229")
        append("A procurar ECUs nos IDs 7E0–7E7…")

        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)

            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in renaultDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhum DID UDS Renault / Dacia respondeu.")
            append("· Isto pode significar ECU não acessível, DID não suportado ou rede/SGW a bloquear a leitura.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM RENAULT / DACIA UDS ===")
    }

    /**
     * Volkswagen / Audi / SEAT / Škoda UDS READ-ONLY scanner.
     *
     * Only UDS ReadDataByIdentifier (0x22) is transmitted. No security access,
     * coding, adaptation, routine control or ECU programming is attempted.
     */
    private fun runVagUdsReadOnly() {
        append("=== VAG UDS READ-ONLY ===")
        append("Volkswagen / Audi / SEAT / Škoda")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("A procurar ECUs nos IDs 7E0–7E7…")

        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)

            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in vagDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhum DID UDS VAG respondeu.")
            append("· ECU não acessível, DID não suportado ou gateway/rede a bloquear a leitura.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM VAG UDS ===")
    }

    /**
     * Ford UDS READ-ONLY scanner.
     *
     * Only UDS ReadDataByIdentifier (0x22) is transmitted. No security access,
     * coding, adaptation, routine control or ECU programming is attempted.
     */
    private fun runNissanUdsReadOnly() {
        append("=== NISSAN / INFINITI UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("A procurar ECUs nos IDs 7E0–7E7…")
        append("Nota: não são usados mapas proprietários Nissan/INFINITI sem documentação pública verificável.")

        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)
            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in nissanDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhum DID UDS Nissan / INFINITI respondeu.")
            append("· ECU/rede/DID pode não suportar a leitura ou pode exigir ferramenta de diagnóstico específica.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM NISSAN / INFINITI UDS ===")
    }

    /**
     * Tesla conservative READ-ONLY diagnostic profile.
     *
     * The current HOMEBD transport is Bluetooth ELM327/CAN. Some Tesla
     * generations use diagnostic Ethernet/DoIP, so this profile never claims
     * universal Tesla ECU access. It only attempts standard UDS VIN reading
     * over CAN when the connected adapter exposes a compatible CAN path.
     */
    private fun runTeslaUdsReadOnly() {
        append("=== TESLA UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("Perfil conservador: apenas VIN standard F190 sobre CAN")
        append("Nota: alguns Tesla requerem DoIP/Ethernet; ELM327 Bluetooth não fornece essa interface.")

        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)
            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in teslaDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhuma resposta Tesla UDS obtida através do CAN/ELM327.")
            append("· Isto não significa que o veículo não tenha diagnóstico; pode requerer DoIP/Ethernet ou uma interface específica Tesla.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM TESLA UDS ===")
    }

    /**
     * Subaru READ-ONLY profile.
     *
     * Uses standard OBD-II data plus a conservative standard UDS VIN read.
     * No proprietary Subaru CAN/request map is included.
     */
    private fun runSubaruReadOnly() {
        append("=== SUBARU READ-ONLY ===")
        append("OBD-II standard + UDS 0x22 quando suportado")
        append("Sem mapa CAN proprietário Subaru não verificado.")

        val pidList = listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position"
        )

        var found = 0
        for ((pid, label) in pidList) {
            val raw = elm(pid, 3000)
            if (isPositiveObdResponse(raw, pid)) {
                found++
                append("✓ Subaru OBD-II $pid — $label: ${classifyResponse(raw)}")
                runOnUiThread {
                    liveDataLog.append("• Subaru — $label: ${classifyResponse(raw)}\n")
                }
            }
        }

        if (canActive) {
            elm("ATSP6", 2000)
            elm("ATCAF1", 1200)
            elm("ATCFC1", 1200)

            var udsFound = 0
            for (requestId in 0x7E0..0x7E7) {
                val req = String.format(Locale.US, "%03X", requestId)
                val responseId = String.format(Locale.US, "%03X", requestId + 8)
                elm("ATSH$req", 1000)
                elm("ATCRA$responseId", 1000)

                for (did in subaruDids) {
                    val raw = elm("22${did.did}", 3000)
                    val value = parseUdsDid(raw, did.did)
                    if (value.isNotBlank()) {
                        udsFound++
                        append("✓ ECU $req → ${did.label}: $value")
                        runOnUiThread {
                            liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                        }
                    }
                }
            }

            elm("ATCRA", 1000)
            elm("ATSP0", 1500)
            detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

            if (udsFound == 0) {
                append("· Nenhum DID UDS Subaru respondeu.")
            } else {
                append("✓ $udsFound leitura(s) UDS Subaru obtida(s).")
            }
        }

        if (found == 0) {
            append("· Nenhuma resposta OBD-II Subaru obtida para os PIDs selecionados.")
        } else {
            append("✓ $found leitura(s) OBD-II Subaru obtida(s).")
        }
        append("=== FIM SUBARU READ-ONLY ===")
    }

    /**
     * Lexus READ-ONLY profile.
     *
     * Lexus has its own manufacturer diagnostic tooling, so HOMEBD keeps this
     * profile separate from Toyota. Only the standard UDS VIN read is attempted
     * here; no proprietary Lexus request/DID map is assumed.
     */
    private fun runLexusReadOnly() {
        append("=== LEXUS READ-ONLY ===")
        append("OBD-II standard + CAN/ISO-TP quando suportado")
        append("Sem mapa CAN proprietário Lexus não verificado.")

        if (canActive) {
            elm("ATSP6", 2000)
            elm("ATCAF1", 1200)
            elm("ATCFC1", 1200)

            var udsFound = 0
            for (requestId in 0x7E0..0x7E7) {
                val req = String.format(Locale.US, "%03X", requestId)
                val responseId = String.format(Locale.US, "%03X", requestId + 8)
                elm("ATSH$req", 1000)
                elm("ATCRA$responseId", 1000)

                for (did in lexusDids) {
                    val raw = elm("22${did.did}", 3000)
                    val value = parseUdsDid(raw, did.did)
                    if (value.isNotBlank()) {
                        udsFound++
                        append("✓ ECU $req → ${did.label}: $value")
                        runOnUiThread {
                            liveDataLog.append("• Lexus ECU $req — ${did.label}: $value\n")
                        }
                    }
                }
            }

            elm("ATCRA", 1000)
            elm("ATSP0", 1500)
            detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

            if (udsFound == 0) {
                append("· Nenhum DID UDS Lexus respondeu.")
            } else {
                append("✓ $udsFound leitura(s) UDS Lexus obtida(s).")
            }
        } else {
            append("· CAN não disponível no adaptador/protocolo atual.")
        }

        append("=== FIM LEXUS READ-ONLY ===")
    }

    /**
     * Isuzu READ-ONLY profile.
     *
     * Isuzu's official technical portals provide diagnostic tooling and OBD
     * information, while detailed manufacturer-specific diagnostic data are
     * provided through the official Isuzu tools. HOMEBD therefore uses only
     * standard OBD-II data plus a conservative standard UDS VIN read.
     */
    private fun runIsuzuReadOnly() {
        append("=== ISUZU READ-ONLY ===")
        append("OBD-II standard + UDS 0x22 quando suportado")
        append("Sem mapa CAN proprietário Isuzu não verificado.")

        val pidList = listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position",
            "012F" to "Fuel level"
        )

        var found = 0
        for ((pid, label) in pidList) {
            val raw = elm(pid, 3000)
            if (isPositiveObdResponse(raw, pid)) {
                found++
                val value = classifyResponse(raw)
                append("✓ Isuzu OBD-II $pid — $label: $value")
                runOnUiThread {
                    liveDataLog.append("• Isuzu — $label: $value\n")
                }
            }
        }

        if (canActive) {
            elm("ATSP6", 2000)
            elm("ATCAF1", 1200)
            elm("ATCFC1", 1200)

            var udsFound = 0
            for (requestId in 0x7E0..0x7E7) {
                val req = String.format(Locale.US, "%03X", requestId)
                val responseId = String.format(Locale.US, "%03X", requestId + 8)
                elm("ATSH$req", 1000)
                elm("ATCRA$responseId", 1000)

                for (did in isuzuDids) {
                    val raw = elm("22${did.did}", 3000)
                    val value = parseUdsDid(raw, did.did)
                    if (value.isNotBlank()) {
                        udsFound++
                        append("✓ ECU $req → ${did.label}: $value")
                        runOnUiThread {
                            liveDataLog.append("• Isuzu ECU $req — ${did.label}: $value\n")
                        }
                    }
                }
            }

            elm("ATCRA", 1000)
            elm("ATSP0", 1500)
            detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

            if (udsFound == 0) {
                append("· Nenhum DID UDS Isuzu respondeu.")
            } else {
                append("✓ $udsFound leitura(s) UDS Isuzu obtida(s).")
            }
        } else {
            append("· CAN não disponível no adaptador/protocolo atual.")
        }

        if (found == 0) {
            append("· Nenhuma resposta OBD-II Isuzu obtida para os PIDs selecionados.")
        } else {
            append("✓ $found leitura(s) OBD-II Isuzu obtida(s).")
        }
        append("=== FIM ISUZU READ-ONLY ===")
    }

    /**
     * Mazda READ-ONLY profile.
     *
     * Mazda public documentation confirms that operating data are normally
     * read through the mandatory OBD connection for fault diagnosis. No
     * proprietary Mazda UDS DID is assumed without a public, verifiable source.
     */
    /**
     * Mitsubishi READ-ONLY profile.
     *
     * Mitsubishi's official technical-information portal documents OBD-II
     * coverage and CAN-bus diagnosis through MUT-III. Detailed proprietary
     * request maps are subscriber-restricted, so HOMEBD does not copy them.
     * Only standard OBD-II data and a conservative UDS VIN read are attempted.
     */
    private fun runMitsubishiReadOnly() {
        append("=== MITSUBISHI READ-ONLY ===")
        append("OBD-II standard + CAN/ISO-TP quando suportado")
        append("Sem mapa CAN proprietário Mitsubishi não verificado.")

        val pidList = listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position",
            "012F" to "Fuel level"
        )

        var found = 0
        for ((pid, label) in pidList) {
            val raw = elm(pid, 3000)
            if (isPositiveObdResponse(raw, pid)) {
                found++
                append("✓ Mitsubishi OBD-II $pid — $label: ${classifyResponse(raw)}")
                runOnUiThread {
                    liveDataLog.append("• Mitsubishi — $label: ${classifyResponse(raw)}\n")
                }
            }
        }

        if (canActive) {
            elm("ATSP6", 2000)
            elm("ATCAF1", 1200)
            elm("ATCFC1", 1200)

            var udsFound = 0
            for (requestId in 0x7E0..0x7E7) {
                val req = String.format(Locale.US, "%03X", requestId)
                val responseId = String.format(Locale.US, "%03X", requestId + 8)
                elm("ATSH$req", 1000)
                elm("ATCRA$responseId", 1000)

                for (did in mitsubishiDids) {
                    val raw = elm("22${did.did}", 3000)
                    val value = parseUdsDid(raw, did.did)
                    if (value.isNotBlank()) {
                        udsFound++
                        append("✓ ECU $req → ${did.label}: $value")
                        runOnUiThread {
                            liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                        }
                    }
                }
            }

            elm("ATCRA", 1000)
            elm("ATSP0", 1500)
            detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

            if (udsFound == 0) {
                append("· Nenhum DID UDS Mitsubishi respondeu.")
            } else {
                append("✓ $udsFound leitura(s) UDS Mitsubishi obtida(s).")
            }
        }

        if (found == 0) {
            append("· Nenhuma resposta OBD-II Mitsubishi obtida para os PIDs selecionados.")
        } else {
            append("✓ $found leitura(s) OBD-II Mitsubishi obtida(s).")
        }
        append("=== FIM MITSUBISHI READ-ONLY ===")
    }

    private fun runMazdaReadOnly() {
        append("=== MAZDA READ-ONLY ===")
        append("OBD-II standard: leitura de dados e diagnóstico")
        append("Sem DIDs proprietários Mazda não verificados.")

        // The generic OBD-II scan performed by HOMEBD remains the supported
        // manufacturer profile. Mode 09 VIN is also queried by the common CAN
        // read-only layer. No write/coding/programming service is sent.
        val pidList = listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position",
            "012F" to "Fuel level"
        )

        var found = 0
        for ((pid, label) in pidList) {
            val raw = elm(pid, 3000)
            if (isPositiveObdResponse(raw, pid)) {
                found++
                append("✓ Mazda OBD-II $pid — $label: ${classifyResponse(raw)}")
                runOnUiThread {
                    liveDataLog.append("• Mazda — $label: ${classifyResponse(raw)}\n")
                }
            }
        }

        if (found == 0) {
            append("· Nenhuma resposta OBD-II Mazda obtida para os PIDs selecionados.")
        } else {
            append("✓ $found leitura(s) OBD-II Mazda obtida(s).")
        }
        append("=== FIM MAZDA READ-ONLY ===")
    }

    private fun runFordUdsReadOnly() {
        append("=== FORD UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("A procurar ECUs nos IDs 7E0–7E7…")

        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)

            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in fordDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhum DID UDS Ford respondeu.")
            append("· ECU não acessível, DID não suportado ou gateway/rede a bloquear a leitura.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM FORD UDS ===")
    }

    private fun isPositiveObdResponse(raw: String, pid: String): Boolean {
        val hex = raw.uppercase().replace(Regex("[^0-9A-F]"), "")
        val marker = "41${pid.takeLast(2).uppercase()}"
        return hex.contains(marker)
    }

    private fun parseUdsDid(raw: String, did: String): String {
        val hex = raw.uppercase().replace(Regex("[^0-9A-F]"), "")
        if (hex.length < 6) return ""

        val didUpper = did.uppercase()
        val marker = "62$didUpper"
        val start = hex.indexOf(marker)
        if (start < 0) return ""

        val dataStart = start + marker.length
        if (dataStart >= hex.length) return ""

        val dataHex = hex.substring(dataStart)
        val bytes = ArrayList<Int>()
        var i = 0
        while (i + 1 < dataHex.length) {
            bytes.add(dataHex.substring(i, i + 2).toIntOrNull(16) ?: break)
            i += 2
        }

        // Human-readable ECU identification is normally ASCII. Preserve
        // printable characters and ignore padding/non-printable bytes.
        val text = bytes
            .filter { it in 0x20..0x7E }
            .map { it.toChar() }
            .joinToString("")
            .trim()

        return if (text.isNotBlank()) text else dataHex.take(64)
    }

    private fun reportCanValue(label: String, raw: String, value: String) {
        if (value.isNotBlank()) {
            append("CAN $label: $value")
        } else {
            append("CAN $label: não disponível (${clean(raw)})")
        }
    }

    /**
     * Robust read-only VIN acquisition.
     *
     * Mode 09 PID 02 is retried because some ELM327 Bluetooth adapters can
     * expose only a partial ISO-TP response on the first request. If a
     * complete 17-character VIN is not obtained, the standard UDS DID F190
     * is queried on the ECUs already discovered by the scanner.
     *
     * No write, coding, reset or programming service is used.
     */
    private fun readCompleteVin(): String {
        fun normalizeCandidate(value: String): String {
            val cleaned = value.uppercase(Locale.US)
                .replace(Regex("[^A-Z0-9]"), "")
            val match = Regex("[A-HJ-NPR-Z0-9]{17}").find(cleaned)
            return match?.value ?: ""
        }

        // First preference: standard OBD-II Mode 09 PID 02.
        repeat(3) {
            val raw = elm("0902", 5000)
            val parsed = extractObdAscii(raw, 0x49, 0x02)
            val candidate = normalizeCandidate(parsed)
            if (candidate.length == 17) return candidate

            // Some adapters leave useful ASCII in the raw response even when
            // the expected service/PID marker is fragmented.
            val rawAscii = raw.map { ch ->
                if (ch.code in 0x20..0x7E) ch else ' '
            }.joinToString("")
            val rawCandidate = normalizeCandidate(rawAscii)
            if (rawCandidate.length == 17) return rawCandidate
        }

        // Standard UDS VIN DID F190 fallback on the ECUs already found by
        // the CAN discovery. Only 0x22 ReadDataByIdentifier is used.
        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        for (requestId in listOf(0x7E0, 0x7E5)) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)
            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            repeat(2) {
                val raw = elm("22F190", 5000)
                val parsed = extractUdsAscii(raw, 0x62, 0xF1, 0x90)
                val candidate = normalizeCandidate(parsed)
                if (candidate.length == 17) return candidate
            }
        }

        return ""
    }

    private fun extractUdsAscii(raw: String, service: Int, didHigh: Int, didLow: Int): String {
        val hex = raw.uppercase(Locale.US)
            .replace(Regex("[^0-9A-F]"), "")
        if (hex.length < 6) return ""

        val bytes = ArrayList<Int>()
        var i = 0
        while (i + 1 < hex.length) {
            bytes.add(hex.substring(i, i + 2).toIntOrNull(16) ?: -1)
            i += 2
        }

        val start = bytes.indexOfFirst { it == service }
        if (start < 0) return ""

        var pos = start + 1
        if (pos + 1 >= bytes.size || bytes[pos] != didHigh || bytes[pos + 1] != didLow) {
            return ""
        }

        val sb = StringBuilder()
        for (j in pos + 2 until bytes.size) {
            val b = bytes[j]
            if (b in 0x20..0x7E) sb.append(b.toChar())
        }
        return sb.toString().trim()
    }

    private fun extractObdAscii(raw: String, service: Int, pid: Int): String {
        // Convert hex byte pairs from ELM output into bytes. This works with
        // single- and multi-frame ISO-TP payloads after ELM reassembly.
        val hex = raw.uppercase()
            .replace(Regex("[^0-9A-F]"), "")
        if (hex.length < 4) return ""

        val bytes = ArrayList<Int>()
        var i = 0
        while (i + 1 < hex.length) {
            bytes.add(hex.substring(i, i + 2).toIntOrNull(16) ?: -1)
            i += 2
        }

        val start = bytes.indexOfFirst { it == service }
        if (start < 0) return ""

        // Find the PID immediately after the positive response service.
        var pos = start + 1
        while (pos < bytes.size && bytes[pos] < 0) pos++
        if (pos >= bytes.size || bytes[pos] != pid) return ""

        val sb = StringBuilder()
        for (j in pos + 1 until bytes.size) {
            val b = bytes[j]
            if (b in 0x20..0x7E) sb.append(b.toChar())
        }
        return sb.toString().trim()
    }

    private fun classifyResponse(raw: String): String {
        val readable = raw.replace("\r", " ").replace("\n", " ")
            .replace(Regex("\\s+"), " ").trim()
        val compact = readable.uppercase().replace(Regex("[^0-9A-F]"), "")

        return when {
            readable.uppercase().contains("NO DATA") ->
                "· NO DATA — sem resposta desse PID"
            readable.uppercase().contains("ERROR") ->
                "· ERROR — ELM327 recusou o comando"
            readable.uppercase().contains("UNABLE TO CONNECT") ->
                "· SEM LIGAÇÃO ECU"
            Regex("7F[0-9A-F]{4}").find(compact) != null ->
                "✕ Negative Response UDS/OBD: $readable"
            compact.contains("4100") || Regex("\b41[0-9A-F]{2}\b").containsMatchIn(compact) ->
                "✓ Resposta OBD-II: $readable"
            readable.isBlank() ->
                "· SEM RESPOSTA"
            else ->
                "· Resposta: $readable"
        }
    }

    private fun clean(value: String): String =
        value.replace("\n", " ").replace(Regex("\\s+"), " ").trim()

    private fun append(value: String) {
        safeUi {
            if (::log.isInitialized) {
                val current = log.text?.toString().orEmpty()
                log.append(if (current.isEmpty()) value else "\n$value")
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) refreshBluetoothList()
    }

    override fun onDestroy() {
        // Do not tear down an active OBD session merely because the Activity
        // leaves the foreground. The foreground service keeps the process alive.
        super.onDestroy()
    }
    private fun updateAdapterInfo(identification: String, transportName: String = "Bluetooth") {
        val clean = identification
            .replace("\r", " ")
            .replace("\n", " ")
            .trim()
            .ifBlank { "OBD-II compatível — modelo não identificado" }

        val lower = clean.lowercase()
        val maker = when {
            "obdlink" in lower -> "OBDLink"
            "elm327" in lower || "elm electronics" in lower -> "ELM327"
            "stn" in lower -> "STN"
            else -> "OBD-II compatível"
        }

        adapterInfo = "Adaptador: $maker • $clean • $transportName"
        if (::adapterInfoView.isInitialized) {
            runOnUiThread { adapterInfoView.text = adapterInfo }
        }
    }
}
