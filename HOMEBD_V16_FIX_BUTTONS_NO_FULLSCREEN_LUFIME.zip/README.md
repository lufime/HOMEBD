# HOMEBD V12 — BLUETOOTH LIST

- Portrait normal Android window.
- Startup crash fixed: Bluetooth Spinner and ScrollView are initialized before use.
- Vertical scroll.
- LIGAR OBDII and SCAN PIDs clickable.
- Displays paired Bluetooth devices in the OBD-II selector.
- Requests Android 12+ Bluetooth permission and refreshes the list after permission.
- Shows clear states for Bluetooth unavailable, disabled, no paired devices, or permission required.
- Developer: lufime.


V16 layout fix: Bluetooth device selector and LIGAR OBDII / SCAN PIDs are fixed outside the diagnostic ScrollView to prevent overlap.
