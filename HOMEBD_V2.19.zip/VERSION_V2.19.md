# HOMEBD V2.19

Base: HOMEBD V2.18 enviada pelo utilizador.
Alteração principal: preparação ampliada da descoberta UDS HV/BMS READ-ONLY.
Não substituir valores HV por estimativas sem confirmação dos DIDs.
