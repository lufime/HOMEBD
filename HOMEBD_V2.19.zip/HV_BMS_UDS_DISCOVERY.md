# HOMEBD V2.19 — HV/BMS UDS discovery

Esta versão parte diretamente da HOMEBD V2.18 enviada pelo utilizador.

## Objetivo

Preparar a descoberta do sistema HV/BMS do C5 através de UDS, exclusivamente
em modo READ-ONLY.

### Pedido

`22 DID`

### Resposta positiva

`62 DID DATA`

O HOMEBD guarda:

- ECU
- DID
- DATA em hexadecimal

Não atribui automaticamente `SOC`, tensão, corrente, temperatura ou kWh.
Esses significados só devem ser atribuídos depois de confirmar o DID no
veículo.

## Segurança

Não são gerados serviços de:

- escrita
- coding
- adaptation
- routine
- reset
- programação

## Nota de integração

A lista de DIDs é uma lista de sondagem conservadora. O transporte
CAN/ELM327 existente continua a ser responsável pelo envio efetivo.
