package pt.autohome.c5.obd

/**
 * HOMEBD V2.19 - HV/BMS UDS discovery, READ-ONLY.
 *
 * 0x22 ReadDataByIdentifier
 * Positive response: 0x62 + DID + DATA
 *
 * This class only builds read requests and parses positive responses.
 * It never builds or sends write/coding/reset/routine commands.
 */
object HvUdsDiscovery {

    data class Response(
        val ecu: String,
        val did: Int,
        val dataHex: String
    )

    data class Probe(
        val ecu: String,
        val did: Int,
        val request: ByteArray
    )

    fun buildReadDataByIdentifier(did: Int): ByteArray {
        require(did in 0x0000..0xFFFF)
        return byteArrayOf(
            0x22,
            ((did shr 8) and 0xFF).toByte(),
            (did and 0xFF).toByte()
        )
    }

    fun buildProbes(ecu: String, dids: Iterable<Int>): List<Probe> =
        dids.distinct()
            .filter { it in 0x0000..0xFFFF }
            .map { Probe(ecu, it, buildReadDataByIdentifier(it)) }

    fun parsePositiveResponse(ecu: String, bytes: ByteArray): Response? {
        if (bytes.size < 3) return null
        if ((bytes[0].toInt() and 0xFF) != 0x62) return null

        val did = ((bytes[1].toInt() and 0xFF) shl 8) or
            (bytes[2].toInt() and 0xFF)

        val data = bytes.drop(3)
            .joinToString("") { "%02X".format(it.toInt() and 0xFF) }

        return Response(ecu, did, data)
    }

    /**
     * Conservative discovery list. It is deliberately a probe list only;
     * the returned bytes must be validated against the vehicle before
     * assigning meanings such as SOC, HV voltage, current or temperature.
     */
    val conservativeDidProbeList: List<Int> = listOf(
        0xF180, 0xF181, 0xF182, 0xF183, 0xF184,
        0xF185, 0xF186, 0xF187, 0xF188, 0xF189,
        0xF18A, 0xF18B, 0xF18C, 0xF18D, 0xF18E,
        0xF18F, 0xF190, 0xF191, 0xF192, 0xF193,
        0xF194, 0xF195, 0xF196, 0xF197, 0xF198
    )
}
