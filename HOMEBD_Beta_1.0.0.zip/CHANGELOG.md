# HOMEBD CHANGELOG

## Beta 1.0.0

Initial documented HOMEBD Beta release.

### Application
- Read-only OBD-II vehicle monitoring and diagnostics.
- Bluetooth OBD-II adapter connection.
- Diagnostic parameter discovery.
- VIN discovery where supported.
- LIVE DATA monitoring.
- Automatic application language detection.
- English fallback when the Android system language is not supported.

### Home Assistant
- Optional Home Assistant integration.
- HOMEBD telemetry support.
- HOMEBD entity namespace: `sensor.homebd_*`.

### Documentation
- Documentation reset at Beta 1.0.0.
- English installation guide.
- Project overview and About documentation.
- Licensing documentation.
- Original HOMEBD icons, logos and graphics documented as project assets.

### Licensing
- Original HOMEBD source code and documentation released under the MIT License.
- External component licences documented separately in `LICENSES.md`.

## Future releases

Changes made after Beta 1.0.0 will be recorded here.
