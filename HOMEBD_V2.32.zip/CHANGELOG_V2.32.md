# HOMEBD V2.32

## Estabilidade REST / Home Assistant
- Reforçado o tratamento de exceções no Home Assistant REST.
- Falhas de HTTPS, URL, autenticação e rede não encerram a app.
- Callbacks REST protegidos contra corrida com o ciclo de vida da Activity.
- Publicação REST em segundo plano passa a ser best-effort e não pode provocar crash.
- Botão **ABRIR HOME ASSISTANT** protegido contra erros de configuração/Activity.
- Configuração Home Assistant protegida contra falhas de UI.
- Mantido HTTPS e Long-Lived Access Token via Bearer.
- MQTT continua removido.

## Ecrã
- Activity configurada para **landscape**, mantendo o painel full screen horizontal e centrado.
