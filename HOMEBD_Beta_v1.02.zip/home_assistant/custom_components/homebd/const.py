DOMAIN = "homebd"
PLATFORMS = ["sensor"]
WS_TYPE = "homebd/update"
WS_BATCH_TYPE = "homebd/update_batch"
WS_PING_TYPE = "homebd/ping"

ATTR_SOURCE = "source"
ATTR_HOMEBD_PID = "homebd_pid"
