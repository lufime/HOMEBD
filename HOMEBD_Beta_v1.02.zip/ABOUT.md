# About HOMEBD

## Identity

**HOMEBD — Home Assistant Onboard Monitoring & Board Data**

**Version:** Beta v1.02  
**Developer:** Lusano

## Purpose

HOMEBD is an independent Android project focused on read-only vehicle monitoring and daygnostics, with optional Home Assistant integration.

The project provides vehicle data through a dedicated Android interface and can make supported telemetry available to Home Assistant when the optional integration is enabled.

## Design principles

- Read-only monitoring and daygnostics
- Automatic application language detection
- Optional Home Assistant integration
- Clear separation between HOMEBD material and external components
- Original HOMEBD visual assets

## Project assets

The HOMEBD icons, logos and original graphics included with the project were created for HOMEBD and are owned by Lusano.

The HOMEBD name and official visual identity are project branding.

## Copyright

Copyright © 2026 Lusano — HOMEBD

Original HOMEBD source code and documentation are licensed under the MIT License unless otherwise stated.
