package pt.homebd

import android.content.Context
import java.util.Locale

/**
 * Automatic language detection based on the Android system locale.
 *
 * Supported: pt, en, es, fr, de, it.
 * The Android system language is detected automatically. Unknown locales fall back to English.
 */
object HomeBdLanguage {

    enum class Language(val code: String) {
        PT("pt"), EN("en"), ES("es"), FR("fr"), DE("de"), IT("it")
    }

    fun detect(context: Context): Language {
        val locale = if (android.os.Build.VERSION.SDK_INT >= 24) {
            context.resources.configuration.locales[0]
        } else {
            @Suppress("DEPRECATION")
            context.resources.configuration.locale
        }

        return when (locale.language.lowercase(Locale.ROOT)) {
            "pt" -> Language.PT
            "en" -> Language.EN
            "es" -> Language.ES
            "fr" -> Language.FR
            "de" -> Language.DE
            "it" -> Language.IT
            else -> Language.EN
        }
    }

    fun name(context: Context): String = when (detect(context)) {
        Language.PT -> "Português"
        Language.EN -> "English"
        Language.ES -> "Español"
        Language.FR -> "Français"
        Language.DE -> "Deutsch"
        Language.IT -> "Italiano"
    }
}
