package pt.homebd

/**
 * V2.44 CAN stabilization policy.
 *
 * READ-ONLY only. No ECU writes, coding, resets or programming.
 *
 * The standard PID scanner can report protocol 0 / zero PIDs even when
 * the vehicle is answering on ISO 15765-4 CAN. This helper centralizes
 * the retry policy so the calread can stabilize CAN before declaring
 * "0 PIDs".
 */
object ObdCanStabilizer {

    data class Result(
        val protocol: Int,
        val can11Bit500k: Boolean,
        val attempts: Int,
        val note: String
    )

    /**
     * Returns the ordered read-only protocol candidates.
     * The calread should try them in order and stop on the first confirmed
     * CAN response. No write/service commands are included.
     */
    fun candidates(): List<String> = listOf(
        "ATSP6",   // ISO 15765-4 CAN (11 bit, 500 kbaud)
        "ATSP0"    // automatic protocol fallback
    )

    fun result(protocol: Int, attempts: Int, confirmedCan: Boolean): Result =
        Result(
            protocol = protocol,
            can11Bit500k = confirmedCan,
            attempts = attempts,
            note = if (confirmedCan)
                "CAN estabilizado: ISO 15765-4 11-bit / 500 kbit/s"
            else
                "CAN not confirmado após estabilização"
        )
}
