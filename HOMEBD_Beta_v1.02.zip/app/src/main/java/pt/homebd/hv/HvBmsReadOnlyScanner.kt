package pt.homebd.hv

/**
 * HOMEBD HV/BMS READ-ONLY discovery.
 * No SecurityAccess, writes, routines, reset, coding or programming.
 */
object HvBmsReadOnlyScanner {
    data class Probe(
        val requestCanId: Int,
        val responseCanId: Int,
        val did: Int,
        val label: String
    ) {
        fun udsPayload(): ByteArray = byteArrayOf(
            0x03, 0x22, (did shr 8).toByte(), (did and 0xFF).toByte()
        )
    }

    val candidateAddresses = (0x7E0..0x7E7).toList()

    // Discovery candidates only; not declared official C5 DIDs.
    val candidateDids = listOf(
        0xDA02 to "HV/BMS candidate data",
        0xFD73 to "HV/BMS candidate cell data"
    )

    fun buildProbes(): List<Probe> =
        candidateAddresses.flatMap { tx ->
            candidateDids.map { (did, label) ->
                Probe(tx, tx + 8, did, label)
            }
        }

    fun isPositiveReadResponse(frame: ByteArray, did: Int): Boolean =
        frame.size >= 3 &&
        (frame[0].toInt() and 0xFF) == 0x62 &&
        (frame[1].toInt() and 0xFF) == (did shr 8) &&
        (frame[2].toInt() and 0xFF) == (did and 0xFF)

    fun isNegativeResponse(frame: ByteArray): Boolean =
        frame.size >= 3 && (frame[0].toInt() and 0xFF) == 0x7F
}
