package pt.homebd

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * HOMEBD -> Home Assistant integration bridge.
 *
 * WebSocket-only transport. The Android app authenticates against the native
 * Home Assistant WebSocket API with a Long-Lived Access Token and then sends
 * HOMEBD sensor updates through the custom HOMEBD integration command.
 */
class HomeBdHaBridge(private val context: Context) {
    private val webSocket = HomeBdHaWebSocket()
    private val prefs = context.getSharedPreferences("homebd_home_assistant", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())
    private val pending = ConcurrentHashMap<String, JSONObject>()
    private val lastPublishedState = ConcurrentHashMap<String, String>()

    @Volatile var connected: Boolean = false
        private set

    var baseUrl: String = prefs.getString("url", "")?.trim()?.trimEnd('/') ?: ""
        private set

    var token: String = prefs.getString("token", "")?.trim() ?: ""
        private set

    val entityFilter: String = "sensor.homebd_*"

    fun save(url: String, accessToken: String) {
        baseUrl = url.trim().trimEnd('/')
        token = accessToken.trim()
        prefs.edit()
            .putString("url", baseUrl)
            .putString("token", token)
            .apply()
    }

    fun connect(callback: (Boolean, String) -> Unit) {
        if (baseUrl.isBlank() || token.isBlank()) {
            callback(false, "Configure o address e o token do Home Assistant.")
            return
        }
        webSocket.connect(baseUrl, token) { ok, message ->
            connected = ok && webSocket.integrationReady
            if (connected) flushPending()
            main.post {
                callback(connected, message)
            }
        }
    }

    fun disconnect() {
        webSocket.disconnect()
        connected = false
    }

    fun publishPid(pid: String, label: String, value: String, flushNow: Boolean = true) {
        val parsed = parseValue(value) ?: return
        val entityId = entityIdFor(pid, label)
        if (!matchesEntityFilter(entityId)) return

        // Keep only the newest value for each entity while the socket is
        // reconnecting. This guarantees that a network outage never causes a
        // burst of stale telemetry after reconnect.
        val attrs = JSONObject()
            .put("friendly_name", "HOMEBD ${cleanLabel(label)}")
            .put("homebd_pid", pid.uppercase(Locale.ROOT))
            .put("source", "HOMEBD")
            .put("raw_value", value)
            .put("state_class", "measurement")
            .put("last_seen_ms", System.currentTimeMillis())

        parsed.unit?.let { attrs.put("unit_of_measurement", it) }
        parsed.deviceClass?.let { attrs.put("device_class", it) }

        val signature = parsed.state + "|" + (parsed.unit ?: "")
        if (lastPublishedState[entityId] == signature && connected && webSocket.integrationReady) {
            return
        }

        val msg = JSONObject()
            .put("entity_id", entityId)
            .put("state", parsed.state)
            .put("attributes", attrs)
        pending[entityId] = msg

        if (flushNow && connected && webSocket.integrationReady) flushPending()
    }

    fun flush() {
        if (connected && webSocket.integrationReady) flushPending()
    }

    private fun flushPending() {
        if (!connected || !webSocket.integrationReady || pending.isEmpty()) return

        val snapshot = pending.entries.toList()
        val payload = snapshot.map { (entityId, msg) ->
            JSONObject()
                .put("entity_id", entityId)
                .put("state", msg.optString("state"))
                .put("attributes", msg.optJSONObject("attributes") ?: JSONObject())
        }

        // Send the whole pending telemetry set as one WebSocket message.
        // This avoids processing dozens of HA WebSocket commands sequentially
        // when LIVE DATA refreshes.
        if (!webSocket.publishBatch(payload)) return

        snapshot.forEach { (entityId, msg) ->
            pending.remove(entityId, msg)
            val attrs = msg.optJSONObject("attributes") ?: JSONObject()
            val unit = attrs.optString("unit_of_measurement", "")
            lastPublishedState[entityId] = "${msg.optString("state")}|$unit"
        }
    }

    fun publishAggregate(values: List<Triple<String, String, String>>) {
        values.forEach { (pid, label, value) -> publishPid(pid, label, value) }
    }

    private fun matchesEntityFilter(entityId: String): Boolean {
        val id = entityId.lowercase(Locale.ROOT)
        return id.startsWith("sensor.homebd_")
    }

    private data class ParsedValue(
        val state: String,
        val unit: String?,
        val deviceClass: String?
    )

    private fun parseValue(raw: String): ParsedValue? {
        val text = raw.trim()
        if (text.isBlank() || text.contains("NO DATA", ignoreCase = true) || text == "—") return null

        val number = Regex("[-+]?\\d+(?:[.,]\\d+)?").find(text)?.value
            ?.replace(',', '.') ?: return null
        val state = number.toDoubleOrNull()?.let {
            if (it % 1.0 == 0.0) it.toLong().toString() else it.toString()
        } ?: return null

        val lower = text.lowercase(Locale.ROOT)
        val unit = when {
            "km/h" in lower -> "km/h"
            "rpm" in lower -> "rpm"
            "°c" in lower || " c" in lower -> "°C"
            "kpa" in lower -> "kPa"
            "v" in lower && "kv" !in lower -> "V"
            "a" in lower && (lower.contains(" a") || lower.endsWith("a")) -> "A"
            "%" in lower -> "%"
            "g/s" in lower -> "g/s"
            "l/100 km" in lower -> "L/100 km"
            "l/h" in lower -> "L/h"
            "ms" in lower -> "ms"
            else -> null
        }
        val deviceClass = when (unit) {
            "°C" -> "temperature"
            "km/h" -> "speed"
            "V" -> "voltage"
            "A" -> "current"
            "%" -> "percentage"
            "kPa" -> "pressure"
            else -> null
        }
        return ParsedValue(state, unit, deviceClass)
    }

    private fun entityIdFor(pid: String, label: String): String {
        val slug = cleanLabel(label)
            .lowercase(Locale.ROOT)
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
            .ifBlank { "pid_${pid.lowercase(Locale.ROOT)}" }
        return "sensor.homebd_${slug}_${pid.lowercase(Locale.ROOT)}"
    }

    private fun cleanLabel(label: String): String =
        label.trim().replace(Regex("\\s+"), " ")
}
