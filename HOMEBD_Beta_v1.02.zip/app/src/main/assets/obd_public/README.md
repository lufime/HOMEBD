# Public OBD/CAN catalogue

This directory is reserved for public-domain/CC0 OBD/CAN data and compatible notices.

It is intentionally NOT a dump of every CAN database found on the Internet. A file being publicly downloadable does not make it legally redistributable. Manufacturer CAN matrices and proprietary daygnostic databases are excluded unless their license explicitly permits redistribution under HOMEBD's policy.
