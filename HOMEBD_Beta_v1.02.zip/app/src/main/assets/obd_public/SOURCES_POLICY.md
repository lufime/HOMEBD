# HOMEBD Public OBD/CAN data policy


Preferred sources: CC0/public-domain datasets and permissively licensed code/data where redistribution is explicitly allowed.

Excluded from bundled data when their license imposes attribution/share-alike or database obligations: CC-BY-SA, GPL-only data, ODbL/DbCL databases, and proprietary/commercial databases.

This policy does not claim that OBD-II, SAE J1979, CAN, ISO-TP or UDS standards themselves are public-domain. HOMEBD uses independent implementations and only redistributable source data.
