# HOMEBD

**HOMEBD — Home Assistant Onboard Monitoring & Board Data**

Independent Android application for read-only OBD-II vehicle monitoring and daygnostics, with optional Home Assistant integration.

**Current release: Beta v1.02**

## Features

- Bluetooth OBD-II adapter connection
- OBD-II / CAN daygnostic communication
- Read-only vehicle monitoring and daygnostics
- Automatic daygnostic parameter discovery
- VIN discovery where supported
- LIVE DATA
- Optional Home Assistant integration
- Real-time HOMEBD telemetry
- `sensor.homebd_*` entity namespace

## Language

HOMEBD detects the Android system language automatically. When a supported language is available, it is selected automatically. English is used as the fallback language.

## Installation

See [INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md).

## Home Assistant

Home Assistant integration is optional.

See [INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md) for setup information.

## Project documentation

- [ABOUT.md](ABOUT.md)
- [INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md)
- [LICENSES.md](LICENSES.md)
- [LICENSE](LICENSE)

## License

Original HOMEBD source code and documentation are released under the MIT License unless otherwise stated.

The HOMEBD name, logo, icons and original graphics are original project assets created for HOMEBD and owned by Lusano. The MIT software licence does not grant trademark rights to the official HOMEBD visual identity.

See [LICENSES.md](LICENSES.md) for external component licences and official licence links.

## Beta status

HOMEBD Beta v1.02 is a development release. Diagnostic coverage, supported parameters, interface elements and integration behaviour may change in future releases.


## Beta v1.02 features

- Full-width Live Data dashboard with GAUGES, VALUES and GRAPHS views.
- Real-time gauges for RPM, vehicle speed, coolant temperature, throttle, engine load and control-module voltage when supported.
- PID discovery remains explicit and read-only.
- Standard OBD-II DTC reading through Mode 03 when supported. HOMEBD does not clear DTCs or write to ECUs.
- HV / UDS read-only discovery remains available for supported hybrid/EV modules.
- Home Assistant WebSocket integration remains optional.
- Export/share options for Live Data and diagnostics.


## Current release
**Beta v1.02** — UI layout aligned with the reference design. Live Data uses a dedicated full-screen layout with Gauges, Values and Graphs. Core OBD-II/Bluetooth and Home Assistant logic is unchanged.
