# HOMEBD Language Policy — Beta v1.02

The HOMEBD user interface does not contain Portuguese hardcoded UI strings.
The Portuguese-specific resource directory was removed. User-facing text uses
the neutral/base Android resources and supported locale resources.
