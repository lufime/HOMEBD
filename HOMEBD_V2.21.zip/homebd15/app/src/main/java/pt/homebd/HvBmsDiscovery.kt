package pt.homebd

/**
 * HOMEBD V2.20 - HV/BMS discovery.
 *
 * Focus: gateway-aware, read-only UDS discovery.
 *
 * UDS:
 *   0x22 ReadDataByIdentifier
 *   positive response 0x62 DID DATA
 *
 * This module does not perform ECU writes, coding, adaptation, routines,
 * programming or resets.
 */
object HvBmsDiscovery {

    data class Target(
        val requestId: Int,
        val responseId: Int
    )

    data class PositiveResponse(
        val requestId: Int,
        val responseId: Int,
        val did: Int,
        val dataHex: String
    )

    // Common physical/functional diagnostic address pairs to probe.
    // These are candidates only; a positive response is required before
    // considering an ECU reachable.
    val candidateTargets: List<Target> = listOf(
        Target(0x7E0, 0x7E8),
        Target(0x7E1, 0x7E9),
        Target(0x7E2, 0x7EA),
        Target(0x7E3, 0x7EB),
        Target(0x7E4, 0x7EC),
        Target(0x7E5, 0x7ED),
        Target(0x7E6, 0x7EE),
        Target(0x7E7, 0x7EF),
        Target(0x7E8, 0x7F0),
        Target(0x7E9, 0x7F1),
        Target(0x7EA, 0x7F2),
        Target(0x7EB, 0x7F3),
        Target(0x7EC, 0x7F4),
        Target(0x7ED, 0x7F5),
        Target(0x7EE, 0x7F6),
        Target(0x7EF, 0x7F7)
    )

    fun readDid(did: Int): ByteArray {
        require(did in 0x0000..0xFFFF)
        return byteArrayOf(
            0x22,
            ((did ushr 8) and 0xFF).toByte(),
            (did and 0xFF).toByte()
        )
    }

    fun parsePositiveResponse(
        requestId: Int,
        responseId: Int,
        bytes: ByteArray
    ): PositiveResponse? {
        if (bytes.size < 3) return null
        if ((bytes[0].toInt() and 0xFF) != 0x62) return null

        val did = ((bytes[1].toInt() and 0xFF) shl 8) or
            (bytes[2].toInt() and 0xFF)

        val data = bytes.drop(3)
            .joinToString("") { "%02X".format(it.toInt() and 0xFF) }

        return PositiveResponse(requestId, responseId, did, data)
    }

    /**
     * Conservative identity DIDs first. HV-specific DIDs must only be
     * interpreted after an ECU has positively answered.
     */
    val identityDids = listOf(
        0xF180, // boot/software identification candidates
        0xF181,
        0xF182,
        0xF186,
        0xF187,
        0xF188,
        0xF189,
        0xF18A,
        0xF18C,
        0xF190  // VIN DID candidate
    )
}
