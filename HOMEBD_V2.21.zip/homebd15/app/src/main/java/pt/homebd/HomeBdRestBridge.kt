package pt.homebd

import android.content.Context
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * HOMEBD REST bridge.
 *
 * Replaces MQTT completely in the application layer.
 * No MQTT broker, Paho client, topics or MQTT credentials are required.
 *
 * The configured endpoint is an HTTP/REST endpoint that receives JSON.
 */
class HomeBdRestBridge(private val context: Context) {

    enum class Mode { AUTO, LOCAL, EXTERNAL }

    private val prefs = context.getSharedPreferences("homebd_rest", Context.MODE_PRIVATE)

    var connected: Boolean = false
        private set

    var mode: Mode = runCatching {
        Mode.valueOf(prefs.getString("mode", Mode.AUTO.name) ?: Mode.AUTO.name)
    }.getOrDefault(Mode.AUTO)
        private set

    var localBaseUrl: String = prefs.getString("local", "") ?: ""
        private set

    var externalBaseUrl: String = prefs.getString("external", "") ?: ""
        private set

    var username: String = prefs.getString("username", "") ?: ""
        private set

    var password: String = prefs.getString("password", "") ?: ""
        private set

    var basePath: String = prefs.getString("path", "/api/homebd") ?: "/api/homebd"
        private set

    var activeMode: Mode? = null
        private set

    val baseUrl: String
        get() = when (activeMode ?: mode) {
            Mode.LOCAL -> localBaseUrl
            Mode.EXTERNAL -> externalBaseUrl
            Mode.AUTO -> localBaseUrl.ifBlank { externalBaseUrl }
        }

    fun save(
        local: String,
        external: String,
        user: String,
        pass: String,
        path: String,
        selectedMode: Mode
    ) {
        localBaseUrl = normalize(local)
        externalBaseUrl = normalize(external)
        username = user
        password = pass
        basePath = if (path.isBlank()) "/api/homebd" else path.trim()
        mode = selectedMode

        prefs.edit()
            .putString("local", localBaseUrl)
            .putString("external", externalBaseUrl)
            .putString("username", username)
            .putString("password", password)
            .putString("path", basePath)
            .putString("mode", mode.name)
            .apply()
    }

    fun connect(callback: (Boolean, String) -> Unit) {
        Thread {
            val candidates = when (mode) {
                Mode.LOCAL -> listOf(Mode.LOCAL)
                Mode.EXTERNAL -> listOf(Mode.EXTERNAL)
                Mode.AUTO -> listOf(Mode.LOCAL, Mode.EXTERNAL)
            }

            var success = false
            var message = "Nenhum endpoint REST respondeu."

            for (candidate in candidates) {
                val base = when (candidate) {
                    Mode.LOCAL -> localBaseUrl
                    Mode.EXTERNAL -> externalBaseUrl
                    Mode.AUTO -> ""
                }
                if (base.isBlank()) continue

                val result = post(candidate, "/health", JSONObject().put("app", "HOMEBD").toString())
                if (result.isSuccess && (result.getOrNull() ?: 500) in 200..499) {
                    connected = true
                    activeMode = candidate
                    success = true
                    message = "REST ligado • ${candidate.name.lowercase()}"
                    break
                }
            }

            if (!success) {
                connected = false
                activeMode = null
            }

            callback(success, message)
        }.start()
    }

    fun disconnect() {
        connected = false
        activeMode = null
    }

    fun publishPid(pid: String, label: String, value: String) {
        val body = JSONObject()
            .put("type", "pid")
            .put("pid", pid)
            .put("label", label)
            .put("value", value)
        postAsync("/pid", body)
    }

    fun publishAggregate(values: List<Pair<String, String>>) {
        val data = JSONObject()
        values.forEach { (key, value) -> data.put(key, value) }
        val body = JSONObject()
            .put("type", "live_data")
            .put("values", data)
        postAsync("/state", body)
    }

    private fun postAsync(path: String, body: JSONObject) {
        if (!connected || baseUrl.isBlank()) return
        Thread { post(activeMode ?: mode, path, body.toString()) }.start()
    }

    private fun post(which: Mode, path: String, body: String): Result<Int> {
        return runCatching {
            val root = when (which) {
                Mode.LOCAL -> localBaseUrl
                Mode.EXTERNAL -> externalBaseUrl
                Mode.AUTO -> baseUrl
            }.trimEnd('/')

            require(root.isNotBlank())
            val url = URL(root + "/" + path.trimStart('/'))
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 8000
                readTimeout = 8000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
                if (username.isNotBlank()) {
                    val raw = "$username:$password"
                    val encoded = android.util.Base64.encodeToString(
                        raw.toByteArray(StandardCharsets.UTF_8),
                        android.util.Base64.NO_WRAP
                    )
                    setRequestProperty("Authorization", "Basic $encoded")
                }
            }

            OutputStreamWriter(conn.outputStream, StandardCharsets.UTF_8).use { it.write(body) }
            val code = conn.responseCode
            conn.disconnect()
            code
        }
    }

    private fun normalize(value: String): String =
        value.trim().removeSuffix("/")
}
