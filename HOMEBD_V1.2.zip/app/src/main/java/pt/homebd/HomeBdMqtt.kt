package pt.homebd

import android.content.Context
import android.os.Build
import android.util.Log
import org.eclipse.paho.client.mqttv3.*
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence
import org.json.JSONObject
import java.util.Locale

/**
 * HOMEBD MQTT bridge.
 *
 * Two broker profiles are supported:
 *  - LOCAL: plain MQTT on the home LAN (normally tcp://...:1883)
 *  - EXTERNAL: MQTT over TLS (normally ssl://...:8883)
 *  - AUTO: try LOCAL first, then EXTERNAL
 *
 * The OBD data remain local to HOMEBD; MQTT is only an optional transport to
 * Home Assistant. No cloud/API dependency is required.
 */
class HomeBdMqtt(private val context: Context) {
    enum class Mode { AUTO, LOCAL, EXTERNAL }

    private var client: MqttAsyncClient? = null
    @Volatile var connected: Boolean = false
        private set
    @Volatile var activeMode: Mode? = null
        private set

    var localBrokerUri: String = ""
        private set
    var externalBrokerUri: String = ""
        private set
    var username: String = ""
        private set
    var password: String = ""
        private set
    var baseTopic: String = "homebd/live"
        private set
    var mode: Mode = Mode.AUTO
        private set

    private val prefs = context.getSharedPreferences("homebd_mqtt", Context.MODE_PRIVATE)

    init { load() }

    // Backward-compatible getter for the previous single-broker UI.
    val brokerUri: String
        get() = when (mode) {
            Mode.LOCAL -> localBrokerUri
            Mode.EXTERNAL -> externalBrokerUri
            Mode.AUTO -> if (localBrokerUri.isNotBlank()) localBrokerUri else externalBrokerUri
        }

    private fun load() {
        localBrokerUri = prefs.getString("localBroker", "") ?: ""
        externalBrokerUri = prefs.getString("externalBroker", "") ?: ""
        username = prefs.getString("username", "") ?: ""
        password = prefs.getString("password", "") ?: ""
        baseTopic = prefs.getString("baseTopic", "homebd/live") ?: "homebd/live"
        mode = runCatching { Mode.valueOf(prefs.getString("mode", "AUTO") ?: "AUTO") }.getOrDefault(Mode.AUTO)

        // Migrate the V1.1 single broker setting without losing it.
        if (localBrokerUri.isBlank() && externalBrokerUri.isBlank()) {
            val old = prefs.getString("broker", "") ?: ""
            if (old.isNotBlank()) localBrokerUri = old
        }
    }

    fun save(local: String, external: String, user: String, pass: String, topic: String, selectedMode: Mode) {
        localBrokerUri = local.trim()
        externalBrokerUri = external.trim()
        username = user.trim()
        password = pass
        baseTopic = topic.trim().trim('/').ifBlank { "homebd/live" }
        mode = selectedMode
        prefs.edit()
            .putString("localBroker", localBrokerUri)
            .putString("externalBroker", externalBrokerUri)
            .putString("username", username)
            .putString("password", password)
            .putString("baseTopic", baseTopic)
            .putString("mode", mode.name)
            .apply()
    }

    fun connect(onResult: (Boolean, String) -> Unit) {
        if (connected) {
            onResult(true, "MQTT já ligado • ${activeModeLabel()}")
            return
        }

        val candidates = when (mode) {
            Mode.LOCAL -> listOf(Mode.LOCAL)
            Mode.EXTERNAL -> listOf(Mode.EXTERNAL)
            Mode.AUTO -> listOf(Mode.LOCAL, Mode.EXTERNAL)
        }

        Thread {
            var lastError = "Configure um broker MQTT"
            for (candidate in candidates) {
                val raw = if (candidate == Mode.LOCAL) localBrokerUri else externalBrokerUri
                if (raw.isBlank()) continue
                try {
                    connectTo(candidate, raw)
                    activeMode = candidate
                    connected = true
                    publishAvailability(true)
                    publishDiscovery()
                    onResult(true, "MQTT ligado • ${activeModeLabel()} • ${clientBrokerUri()}")
                    return@Thread
                } catch (e: Exception) {
                    lastError = "${candidateLabel(candidate)}: ${e.message ?: "erro de ligação"}"
                    disconnectInternal()
                }
            }
            connected = false
            activeMode = null
            onResult(false, "MQTT: $lastError")
        }.start()
    }

    private fun connectTo(candidate: Mode, rawUri: String) {
        val uri = normalizeUri(rawUri, candidate)
        val id = "HOMEBD-${Build.MODEL.replace(Regex("[^A-Za-z0-9_-]"), "")}-${System.currentTimeMillis() % 100000}"
        val c = MqttAsyncClient(uri, id, MemoryPersistence())
        client = c
        val opts = MqttConnectOptions().apply {
            isAutomaticReconnect = true
            isCleanSession = true
            connectionTimeout = 8
            keepAliveInterval = 20
            if (username.isNotBlank()) {
                userName = username
                password = this@HomeBdMqtt.password.toCharArray()
            }
        }
        c.connect(opts).waitForCompletion(8000)
    }

    private fun normalizeUri(raw: String, candidate: Mode): String {
        var s = raw.trim()
        if (s.isBlank()) throw IllegalArgumentException("broker vazio")
        s = s.removeSuffix("/")
        if (s.startsWith("https://", true)) s = "ssl://" + s.removePrefix("https://")
        if (s.startsWith("http://", true)) s = "tcp://" + s.removePrefix("http://")
        if (!s.contains("://")) {
            val defaultPort = if (candidate == Mode.EXTERNAL) 8883 else 1883
            s = "${if (candidate == Mode.EXTERNAL) "ssl" else "tcp"}://$s"
            if (!s.substringAfter("://").contains(":")) s += ":$defaultPort"
        } else if (candidate == Mode.EXTERNAL && s.startsWith("tcp://", true)) {
            s = "ssl://" + s.removePrefix("tcp://")
        }
        return s
    }

    fun disconnect() {
        try {
            if (connected) publishAvailability(false)
            client?.disconnect()?.waitForCompletion(3000)
        } catch (_: Exception) {}
        disconnectInternal()
    }

    private fun disconnectInternal() {
        connected = false
        activeMode = null
        client = null
    }

    fun publishPid(pid: String, label: String, result: String) {
        if (!connected) return
        val key = pid.lowercase(Locale.US)
        val obj = JSONObject()
        val numeric = parseNumeric(result)
        if (numeric == null) obj.put("value", JSONObject.NULL) else obj.put("value", numeric)
        obj.put("text", result)
        obj.put("pid", pid)
        obj.put("label", label)
        obj.put("available", !result.contains("NO DATA", true) && !result.contains("N/D", true))
        publish("$baseTopic/$key", obj.toString(), false)
        publish("$baseTopic/$key/text", result, false)
    }

    fun publishAggregate(values: List<Pair<String, String>>) {
        if (!connected) return
        val root = JSONObject()
        values.forEach { (pid, value) -> root.put(pid.lowercase(Locale.US), value) }
        publish("$baseTopic/all", root.toString(), false)
    }

    private fun publishAvailability(available: Boolean) {
        publish("$baseTopic/status", if (available) "online" else "offline", true)
    }

    private fun publish(topic: String, payload: String, retained: Boolean) {
        try {
            val msg = MqttMessage(payload.toByteArray(Charsets.UTF_8)).apply {
                qos = 0
                isRetained = retained
            }
            client?.publish(topic, msg)
        } catch (e: Exception) {
            Log.w("HOMEBD_MQTT", "publish failed: ${e.message}")
        }
    }

    private fun parseNumeric(text: String): Double? {
        if (text.contains("NO DATA", true) || text.contains("N/D", true) ||
            text.contains("multi-byte", true) || text.contains("Dados insuficientes", true) ||
            text == "—") return null
        val m = Regex("""[-+]?\d+(?:[.,]\d+)?""").find(text) ?: return null
        return m.value.replace(",", ".").toDoubleOrNull()
    }

    private fun clientBrokerUri(): String = client?.serverURI ?: ""
    private fun candidateLabel(m: Mode): String = if (m == Mode.LOCAL) "Local" else "Externo"
    private fun activeModeLabel(): String = activeMode?.let { candidateLabel(it) } ?: mode.name

    private fun publishDiscovery() {
        val defs = listOf(
            Triple("010C","rpm","rpm"), Triple("010D","speed","km/h"),
            Triple("0105","coolant_temperature","°C"), Triple("010F","intake_air_temperature","°C"),
            Triple("0104","engine_load","%"), Triple("010B","map","kPa"), Triple("0110","maf","g/s"),
            Triple("0106","stft","%"), Triple("0107","ltft","%"), Triple("010E","ignition_timing","°"),
            Triple("0142","control_module_voltage","V"), Triple("015E","fuel_rate","L/h"),
            Triple("0133","barometric_pressure","kPa"), Triple("0123","fuel_rail_pressure","kPa"),
            Triple("0111","throttle_position","%"), Triple("0145","absolute_throttle_position_b","%"),
            Triple("014A","accelerator_pedal_position_d","%"), Triple("014B","accelerator_pedal_position_e","%"),
            Triple("014C","commanded_throttle_actuator","%"), Triple("0134","lambda","ratio")
        )
        defs.forEach { (pid, key, unit) ->
            val payload = JSONObject()
                .put("name", "HOMEBD ${key.replace('_',' ').replaceFirstChar { it.uppercase() }}")
                .put("unique_id", "homebd_$key")
                .put("state_topic", "$baseTopic/${pid.lowercase(Locale.US)}")
                .put("value_template", "{{ value_json.value if value_json.value is not none else 'unknown' }}")
                .put("availability_topic", "$baseTopic/status")
                .put("payload_available", "online")
                .put("payload_not_available", "offline")
                .put("device_class", deviceClass(key))
                .put("unit_of_measurement", unit)
                .put("state_class", "measurement")
                .put("device", JSONObject()
                    .put("identifiers", org.json.JSONArray().put("homebd"))
                    .put("name", "HOMEBD")
                    .put("manufacturer", "lufime")
                    .put("model", "HOMEBD OBD-II"))
            publish("homeassistant/sensor/homebd/$key/config", payload.toString(), true)
        }
        val dtc = JSONObject()
            .put("name", "HOMEBD DTC")
            .put("unique_id", "homebd_dtc")
            .put("state_topic", "$baseTopic/0101")
            .put("value_template", "{{ value_json.text }}")
            .put("availability_topic", "$baseTopic/status")
            .put("payload_available", "online")
            .put("payload_not_available", "offline")
            .put("device", JSONObject().put("identifiers", org.json.JSONArray().put("homebd")).put("name","HOMEBD").put("manufacturer","lufime").put("model","HOMEBD OBD-II"))
        publish("homeassistant/sensor/homebd/dtc/config", dtc.toString(), true)
    }

    private fun deviceClass(key: String): String = when (key) {
        "coolant_temperature", "intake_air_temperature" -> "temperature"
        "control_module_voltage" -> "voltage"
        "speed" -> "speed"
        else -> ""
    }
}
