# HOMEBD 1.2 — MQTT local + externo

A HOMEBD pode publicar os dados OBD-II no Home Assistant através de MQTT, sem REST e sem cloud.

## Modos

- **Automático:** tenta o broker local e, se não conseguir ligar, tenta o broker externo.
- **Só local:** usa normalmente `tcp://IP_DO_HOME_ASSISTANT:1883`.
- **Só externo:** usa MQTT sobre TLS, normalmente `ssl://DOMINIO:8883`.

A app aceita também os formatos sem esquema:

- local: `192.168.1.50:1883`
- externo: `meu-dominio.duckdns.org:8883`

A HOMEBD adiciona automaticamente `tcp://` ao local e `ssl://` ao externo.

## Exemplo

Broker local:
`192.168.1.50:1883`

Broker externo:
`meu-dominio.duckdns.org:8883`

Utilizador/password: credenciais do broker MQTT.

Tópico base:
`homebd/live`

## Segurança

A ligação externa deve usar TLS e um certificado válido para o nome DNS utilizado. Não use a porta HTTP `8123` do Home Assistant como broker MQTT.

## Home Assistant

A descoberta MQTT continua a ser publicada automaticamente em `homeassistant/.../config` e os dados em `homebd/live/...`.
