# HOMEBD

Universal Android OBD-II diagnostic application.

## V35
- Added the latest HOMEBD automotive header image to the app.
- Header includes Bluetooth and engine symbols beside the car.
- Existing Bluetooth device list, OBD connection and PID scan UI retained.
- No GitHub Actions workflow included in this ZIP.

## About
The app includes an in-app About dialog available from the footer.
It shows the HOMEBD meaning, current beta version, developer, platform and OBD-II capabilities.
The About dialog follows the Android system language: Portuguese when the system is Portuguese, otherwise English.


## Operation mode

HOMEBD is exclusively read-only. It does not modify vehicle parameters, perform ECU coding, or program ECUs.
