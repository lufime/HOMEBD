# HOMEBD

Universal Android OBD-II diagnostic application.

## BETA VERSION 1.0
- Universal HOMEBD OBD-II application.
- Bluetooth / ELM327 device list and OBD-II connection.
- Generic OBD-II PID scan and live diagnostic data.
- No GitHub Actions workflow included in this ZIP.

## About
The app includes an in-app About dialog available from the footer.
It shows the HOMEBD meaning, current beta version, developer, platform and OBD-II capabilities.
The About dialog follows the Android system language: Portuguese when the system is Portuguese, otherwise English.


## Operation mode

HOMEBD is exclusively read-only. It does not modify vehicle parameters, perform ECU coding, or program ECUs.


## CAN read-only support

HOMEBD detects CAN-capable ELM327 protocols and uses the adapter's ISO 15765-4/ISO-TP handling for standard OBD-II read requests. The CAN layer is read-only: no ECU write, coding, adaptation, or programming services are sent. Manufacturer-specific CAN data still requires a verified vehicle/ECU request map and is not guessed.


## Stellantis read-only profile
The Stellantis profile adds a controlled UDS read-only layer over CAN/ISO-TP. It uses UDS service `0x22 ReadDataByIdentifier` only for ECU identification DIDs configured in the app:

- F18C — ECU Serial Number
- F187 — ECU Part Number
- F192 — ECU Hardware Number
- F193 — ECU Hardware Version
- F194 — ECU Software Number
- F195 — ECU Software Version

The scanner checks common 11-bit diagnostic request IDs (`7E0`–`7E7`) and matching response IDs. Unsupported or inaccessible data is reported as unavailable. No Secure Gateway bypass is implemented.

### Explicitly blocked
The HOMEBD implementation does not send ECU write/programming services such as `0x2E`, `0x2F`, `0x31`, or `0x27`.

No openDBC database or code is used.
