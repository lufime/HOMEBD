# HOMEBD

**Home Onboard Monitoring Engine Board Data**

Universal Android OBD-II diagnostic application.

## BETA VERSION 1.0

- Bluetooth / ELM327 device discovery and OBD-II connection.
- Generic OBD-II live data and diagnostic scanning.
- Manufacturer profiles with a conservative read-only layer.
- CAN / ISO-TP support through the ELM327 transport where available.
- UDS `0x22 ReadDataByIdentifier` only where a profile has a documented standard identifier configured.
- VIN via standard OBD-II Mode 09 PID 02 and/or UDS `F190` where supported.
- No ECU writing, coding, adaptation, programming or security-access operations.
- No openDBC database or third-party CAN database is used.
- The GitHub Actions workflow is intentionally **not included** in this ZIP.

## Manufacturer profiles

### Stellantis
Includes the Stellantis family represented in the app, including:
- Citroën
- Peugeot
- DS Automobiles
- Opel
- Vauxhall
- Fiat
- Jeep
- Alfa Romeo
- Lancia
- Abarth
- Chrysler
- Dodge
- RAM
- Maserati

Opel and Vauxhall are part of the same Stellantis profile and are not separate profiles in the selector.

The profile uses standard OBD-II data plus the controlled UDS read-only identification layer configured in the application. It does not bypass Secure Gateway protections.

### Renault / Dacia
Standard OBD-II plus documented standard UDS identification reads configured in the application.

### Volkswagen / Audi / SEAT / Škoda
Standard OBD-II plus documented standard UDS identification reads configured in the application.

### BMW
Standard OBD-II plus conservative standard UDS VIN identification when supported by the connected transport. No proprietary BMW CAN map is included.

### Mercedes-Benz
Standard OBD-II plus conservative standard UDS VIN identification when supported. No proprietary Mercedes-Benz CAN map is included.

### Ford
Standard OBD-II plus controlled UDS read-only identification reads configured in the application.

### Toyota
Standard OBD-II profile. Manufacturer-specific data is not guessed.

### Lexus
Separate profile from Toyota. Standard OBD-II plus conservative standard UDS VIN identification when supported.

### Honda / Acura
Standard OBD-II plus conservative standard UDS VIN identification when supported. No proprietary request map is included.

### Hyundai / Kia
Standard OBD-II plus conservative standard UDS VIN identification when supported. No proprietary request map is included.

### Nissan / INFINITI
Standard OBD-II plus controlled UDS read-only identification reads configured in the application.

### Volvo
Standard OBD-II plus conservative standard UDS VIN identification when supported. No proprietary Volvo CAN map is included.

### Tesla
Conservative OBD-II/CAN profile. UDS `F190` may be attempted through the current ELM327/CAN transport. Some Tesla diagnostic architectures require DoIP/Ethernet, which is not provided by a classic Bluetooth ELM327 adapter.

### Mazda
Standard OBD-II read-only profile. No unverified proprietary Mazda DID/CAN map is included.

### Subaru
Standard OBD-II plus conservative UDS VIN identification when supported. No proprietary Subaru DID/request map is included.

### Mitsubishi
Standard OBD-II plus conservative UDS VIN identification when supported. No proprietary Mitsubishi DID/request map is included.

### Jaguar / Land Rover
Standard OBD-II plus conservative UDS VIN identification when supported. Some vehicle generations may require diagnostic interfaces such as DoIP; the app does not claim universal access through ELM327.

### Porsche
Standard OBD-II plus conservative UDS VIN identification when supported. No proprietary Porsche CAN map is included.

### Suzuki
Standard OBD-II plus conservative UDS VIN identification when supported. No proprietary Suzuki CAN map is included.

### Isuzu
Standard OBD-II plus conservative UDS VIN identification when supported. No proprietary Isuzu CAN map is included.

### Geely / Polestar
Standard OBD-II plus conservative UDS VIN identification when supported. No proprietary Geely/Polestar CAN map is included.

### Outros
Generic OBD-II fallback for vehicles that do not match a manufacturer profile.

## READ-ONLY safety model

HOMEBD is intentionally restricted to diagnostic reading. The application does not send ECU control or programming services such as:

- `0x27 SecurityAccess`
- `0x2E WriteDataByIdentifier`
- `0x2F InputOutputControlByIdentifier`
- `0x31 RoutineControl`
- ECU flashing/programming commands

No gateway bypass is implemented.

## Important compatibility note

A manufacturer profile does not guarantee access to every ECU or every proprietary parameter on every model/year. ECU addressing, gateway architecture, transport (CAN/ISO-TP/DoIP), diagnostic session and supported identifiers vary by vehicle. When a requested identifier is not supported, HOMEBD reports it as unavailable instead of guessing.

## Credits

- Developer: **lufime**
- Platform: Android
- Diagnostics: OBD-II
- Version: **BETA VERSION 1.0**
