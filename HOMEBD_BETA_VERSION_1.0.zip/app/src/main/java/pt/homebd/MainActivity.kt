package pt.homebd

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.*
import java.io.InputStream
import java.io.IOException
import java.io.OutputStream
import java.util.UUID
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var scanButton: TextView
    private lateinit var devicesSpinner: Spinner
    private lateinit var manufacturerSpinner: Spinner
    private lateinit var aboutButton: TextView
    private lateinit var liveDataScroll: ScrollView
    private lateinit var liveDataLog: TextView
    private var detectedProtocol = ""
    private var canActive = false

    private data class ManufacturerProfile(
        val name: String,
        val parameters: List<Pair<String, String>>
    )

    private data class UdsDid(
        val did: String,
        val label: String
    )

    // Public/documented ECU identification DIDs selected for the READ-ONLY
    // Stellantis profile. Unknown/unavailable DIDs are simply reported as such.
    private val stellantisDids = listOf(
        UdsDid("F18C", "ECU Serial Number"),
        UdsDid("F187", "ECU Part Number"),
        UdsDid("F192", "ECU Hardware Number"),
        UdsDid("F193", "ECU Hardware Version"),
        UdsDid("F194", "ECU Software Number"),
        UdsDid("F195", "ECU Software Version")
    )

    private val manufacturerProfiles = listOf(
        ManufacturerProfile("Automático", listOf(
            "0100" to "Supported PIDs 01-20",
            "0104" to "Engine load",
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position"
        )),
        ManufacturerProfile("Stellantis", listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position",
            "012F" to "Fuel level",
            "0142" to "Control module voltage"
        )),
        ManufacturerProfile("Renault / Dacia", listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position",
            "012F" to "Fuel level"
        )),
        ManufacturerProfile("Volkswagen / Audi / SEAT / Škoda", listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position",
            "0142" to "Control module voltage"
        )),
        ManufacturerProfile("BMW", listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position",
            "0142" to "Control module voltage"
        )),
        ManufacturerProfile("Mercedes-Benz", listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position",
            "0142" to "Control module voltage"
        )),
        ManufacturerProfile("Ford", listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position",
            "012F" to "Fuel level"
        )),
        ManufacturerProfile("Opel", listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position"
        )),
        ManufacturerProfile("Fiat", listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position",
            "012F" to "Fuel level"
        )),
        ManufacturerProfile("Toyota", listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position"
        )),
        ManufacturerProfile("Honda", listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position"
        )),
        ManufacturerProfile("Hyundai / Kia", listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position"
        )),
        ManufacturerProfile("Nissan", listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position"
        )),
        ManufacturerProfile("Volvo", listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position"
        )),
        ManufacturerProfile("Outros", emptyList())
    )

    private val pids = linkedMapOf(
        "0100" to "Supported PIDs 01-20",
        "0104" to "Engine load",
        "0105" to "Coolant temperature",
        "010B" to "MAP pressure",
        "010C" to "RPM",
        "010D" to "Vehicle speed",
        "010F" to "Intake air temperature",
        "0110" to "MAF",
        "0111" to "Throttle position",
        "012F" to "Fuel level",
        "0142" to "Control module voltage",
        "0146" to "Ambient temperature",
        "015E" to "Engine fuel rate"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(23, 23, 23)
        window.navigationBarColor = Color.rgb(23, 23, 23)

        // Ecrã normal: o conteúdo nunca fica por baixo das barras do sistema.
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(true)
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = 0
        }

        val background = Color.rgb(28, 28, 28)
        val panel = Color.rgb(55, 55, 55)
        val primary = Color.rgb(235, 235, 235)
        val secondary = Color.rgb(190, 190, 190)
        val blue = Color.rgb(20, 145, 245)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(background)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            clipChildren = true
            clipToPadding = true
        }

        val header = ImageView(this).apply {
            setImageResource(pt.homebd.R.drawable.homebd_header)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
            contentDescription = "HOMEBD"
            adjustViewBounds = true
            clipToOutline = true
        }

        status = TextView(this).apply {
            text = "Estado: desligado"
            textSize = 14f
            setTextColor(secondary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        val deviceLabel = TextView(this).apply {
            text = "DISPOSITIVO OBD-II"
            textSize = 14f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        manufacturerSpinner = Spinner(this).apply {
            this.background = GradientDrawable().apply {
                setColor(panel)
                cornerRadius = 2f
            }
            minimumHeight = dp(48)
        }

        devicesSpinner = Spinner(this).apply {
            this.background = GradientDrawable().apply {
                setColor(panel)
                cornerRadius = 2f
            }
            minimumHeight = dp(48)
        }

        val connect = actionButton("LIGAR OBDII", blue, primary)
        scanButton = actionButton("SCAN PIDs", Color.rgb(70, 70, 70), primary).apply {
            isEnabled = false
            alpha = 0.55f
        }

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        buttons.addView(connect, LinearLayout.LayoutParams(0, dp(50), 1f).apply {
            setMargins(dp(0), dp(4), dp(4), dp(4))
        })
        buttons.addView(scanButton, LinearLayout.LayoutParams(0, dp(50), 1f).apply {
            setMargins(dp(4), dp(4), dp(0), dp(4))
        })

        log = TextView(this).apply {
            textSize = 14f
            setTextColor(primary)
            setBackgroundColor(panel)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            includeFontPadding = true
            gravity = Gravity.TOP or Gravity.START
            setLineSpacing(0f, 1.0f)
        }

        logScroll = ScrollView(this).apply {
            setBackgroundColor(panel)
            isFillViewport = true
            isVerticalScrollBarEnabled = true
            scrollBarStyle = View.SCROLLBARS_INSIDE_INSET
            isScrollbarFadingEnabled = false
            addView(log, ViewGroup.LayoutParams(-1, -2))
        }

        val liveLabel = TextView(this).apply {
            text = "LIVE DATA"
            textSize = 14f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        liveDataLog = TextView(this).apply {
            textSize = 14f
            setTextColor(primary)
            setBackgroundColor(panel)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            gravity = Gravity.TOP or Gravity.START
            includeFontPadding = true
            setLineSpacing(0f, 1.0f)
        }

        liveDataScroll = ScrollView(this).apply {
            setBackgroundColor(panel)
            isFillViewport = true
            isVerticalScrollBarEnabled = true
            scrollBarStyle = View.SCROLLBARS_INSIDE_INSET
            isScrollbarFadingEnabled = false
            addView(liveDataLog, ViewGroup.LayoutParams(-1, -2))
        }

        val diagnosticLabel = TextView(this).apply {
            text = "DIAGNÓSTICO"
            textSize = 14f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        aboutButton = TextView(this).apply {
            text = "HOMEBD • BETA VERSION 1.0 • lufime"
            textSize = 11f
            setTextColor(secondary)
            gravity = Gravity.CENTER
            includeFontPadding = false
            isClickable = true
            isFocusable = true
            setPadding(dp(4), dp(2), dp(4), dp(2))
        }

        root.addView(header, LinearLayout.LayoutParams(-1, dp(190)))
        root.addView(status, LinearLayout.LayoutParams(-1, dp(36)))
        root.addView(deviceLabel, LinearLayout.LayoutParams(-1, dp(34)))
        root.addView(devicesSpinner, LinearLayout.LayoutParams(-1, dp(52)))

        val manufacturerLabel = TextView(this).apply {
            text = "FABRICANTE / PERFIL"
            textSize = 14f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }
        root.addView(manufacturerLabel, LinearLayout.LayoutParams(-1, dp(34)))
        root.addView(manufacturerSpinner, LinearLayout.LayoutParams(-1, dp(52)))

        root.addView(buttons, LinearLayout.LayoutParams(-1, dp(62)))
        root.addView(liveLabel, LinearLayout.LayoutParams(-1, dp(36)))
        root.addView(liveDataScroll, LinearLayout.LayoutParams(-1, dp(150)))
        root.addView(diagnosticLabel, LinearLayout.LayoutParams(-1, dp(36)))
        root.addView(logScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(aboutButton, LinearLayout.LayoutParams(-1, dp(28)))

        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener { v, insets ->
                val bars = insets.getInsets(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                v.setPadding(
                    dp(10),
                    bars.top + dp(4),
                    dp(10),
                    bars.bottom + dp(4)
                )
                insets
            }
        }

        setContentView(root)

        manufacturerSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            manufacturerProfiles.map { it.name }
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        manufacturerSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val profile = manufacturerProfiles[position]
                liveDataLog.text =
                    if (profile.parameters.isEmpty()) {
                        "Perfil ${profile.name}: sem parâmetros específicos disponíveis."
                    } else {
                        "Perfil: ${profile.name}\n\n" +
                        profile.parameters.joinToString("\n") { "• ${it.second}" }
                    }
                append("Perfil selecionado: ${profile.name}")
            }
        }

        root.requestApplyInsets()

        connect.setOnClickListener {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            val paired = try {
                adapter?.bondedDevices?.toList() ?: emptyList()
            } catch (_: SecurityException) {
                emptyList()
            }

            val position = devicesSpinner.selectedItemPosition
            val device = paired.getOrNull(position)

            if (device != null) {
                connect(device)
            } else {
                append("⚠ Nenhum dispositivo Bluetooth selecionável.")
                append("Emparelhe o seu ELM327 nas definições Bluetooth do Android.")
            }
        }

        scanButton.setOnClickListener { runScanner() }
        aboutButton.setOnClickListener { showAbout() }

        append("HOMEBD pronto.")
        append("Diagnóstico OBD-II universal para veículos.")
        append("Selecione o seu ELM327 na lista e toque em LIGAR OBDII.")
        liveDataLog.text = "Sem dados — ligue o OBD-II e execute SCAN PIDs."

        requestBtPermissions()
        refreshBluetoothList()
    }

    private fun showAbout() {
        val pt = Locale.getDefault().language.equals("pt", ignoreCase = true)

        val title = if (pt) "Sobre o HOMEBD" else "About HOMEBD"
        val message = if (pt) {
            "HOMEBD\n" +
            "Home Onboard Monitoring Engine Board Data\n\n" +
            "Aplicação Android universal para diagnóstico OBD-II.\n\n" +
            "• Bluetooth / ELM327\n" +
            "• Lista de dispositivos emparelhados\n" +
            "• Ligação OBD-II\n" +
            "• Scan de PIDs genéricos\n" +
            "• Dados de diagnóstico em tempo real\n\n" +
            "Versão: BETA VERSION 1.0\n" +
            "Desenvolvido por: lufime\n" +
            "Plataforma: Android\n" +
            "Diagnóstico: OBD-II"
        } else {
            "HOMEBD\n" +
            "Home Onboard Monitoring Engine Board Data\n\n" +
            "Universal Android application for OBD-II diagnostics.\n\n" +
            "• Bluetooth / ELM327\n" +
            "• Paired device list\n" +
            "• OBD-II connection\n" +
            "• Generic PID scan\n" +
            "• Live diagnostic data\n\n" +
            "Version: BETA VERSION 1.0\n" +
            "Developed by: lufime\n" +
            "Platform: Android\n" +
            "Diagnostics: OBD-II\n\n• A aplicação é exclusivamente de leitura: não altera parâmetros, não faz codificação nem programação de ECU.\n• The app is read-only: it does not modify parameters, code, or program ECUs."
        }

        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton(if (pt) "FECHAR" else "CLOSE", null)
            .show()
    }

    private fun actionButton(label: String, color: Int, textColor: Int): TextView =
        TextView(this).apply {
            text = label
            textSize = 14f
            setTextColor(textColor)
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            this.background = GradientDrawable().apply {
                setColor(color)
                cornerRadius = 8f
            }
        }

    private fun refreshBluetoothList() {
        val adapter = BluetoothAdapter.getDefaultAdapter()

        if (adapter == null) {
            setDevices(listOf("Bluetooth não disponível neste dispositivo"))
            return
        }

        try {
            if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
            ) {
                setDevices(listOf("Permitir Bluetooth para mostrar dispositivos"))
                return
            }

            if (!adapter.isEnabled) {
                setDevices(listOf("Bluetooth desligado — ative o Bluetooth"))
                return
            }

            val paired = adapter.bondedDevices.toList()
            val names = if (paired.isEmpty()) {
                listOf("Nenhum dispositivo emparelhado")
            } else {
                paired.map { device ->
                    val name = try { device.name ?: "Sem nome" } catch (_: SecurityException) { "Sem nome" }
                    "$name  (${device.address})"
                }
            }

            setDevices(names)
            append("✓ Bluetooth: ${paired.size} dispositivo(s) emparelhado(s).")
        } catch (_: SecurityException) {
            setDevices(listOf("Permissão Bluetooth necessária"))
        }
    }

    private fun setDevices(names: List<String>) {
        devicesSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            names
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                ),
                10
            )
        }
    }

    private fun connect(device: BluetoothDevice) {
        thread {
            try {
                runOnUiThread {
                    status.text = "Estado: a ligar…"
                }

                socket?.close()
                socket = device.createRfcommSocketToServiceRecord(spp)
                socket!!.connect()

                input = socket!!.inputStream
                output = socket!!.outputStream

                elm("ATZ", 5000)
                Thread.sleep(1200)
                elm("ATE0", 2500)
                elm("ATL0", 2500)
                elm("ATS0", 2500)
                elm("ATSP0", 2500)

                val protocol = elm("ATDP", 2500)
                val protocolNumber = elm("ATDPN", 2500)
                    .trim()
                    .uppercase()
                    .removePrefix("A")

                if (protocol.isBlank()) {
                    throw IOException("ELM327 não respondeu ao ATDP")
                }

                detectedProtocol = protocolNumber
                canActive = protocolNumber in setOf("6", "7", "8", "9", "A", "B", "C") ||
                    protocol.uppercase().contains("CAN") ||
                    protocol.uppercase().contains("J1939")

                // Read-only CAN setup: keep automatic flow control enabled and
                // do not enable any ECU write/programming command.
                if (canActive) {
                    elm("ATCFC1", 1500)
                    append("✓ CAN detectado: ISO/J1939.")
                    append("✓ CAN em modo READ-ONLY.")
                }

                runOnUiThread {
                    status.text = if (canActive)
                        "Estado: LIGADO • CAN • READ-ONLY"
                    else
                        "Estado: LIGADO • ELM327 pronto"
                    scanButton.isEnabled = true
                    scanButton.alpha = 1f
                }

                append("✓ ELM327 inicializado.")
                append("Protocolo: ${clean(protocol)}")
                append("Número de protocolo: ${if (protocolNumber.isBlank()) "desconhecido" else protocolNumber}")
                append("Pronto para SCAN PIDs.")
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Estado: erro de ligação"
                }
                append("✕ ERRO: ${e.message ?: "erro desconhecido"}")
            }
        }
    }

    private fun elm(cmd: String, timeout: Long = 2500): String {
        val out = output ?: return ""
        val ins = input ?: return ""

        try {
            out.write((cmd + "\r").toByteArray(Charsets.US_ASCII))
            out.flush()
        } catch (e: Exception) {
            throw IOException("Falha ao enviar $cmd: ${e.message}", e)
        }

        val start = System.currentTimeMillis()
        val buf = ByteArray(4096)
        val data = StringBuilder()

        while (System.currentTimeMillis() - start < timeout) {
            if (ins.available() > 0) {
                val n = ins.read(buf)
                if (n > 0) data.append(String(buf, 0, n, Charsets.US_ASCII))
                if (data.contains(">")) break
            } else {
                Thread.sleep(30)
            }
        }

        return data.toString()
            .replace("\r", "\n")
            .replace(">", "")
            .trim()
    }

    private fun runScanner() {
        thread {
            if (output == null) {
                append("⚠ OBDII não está ligado.")
                return@thread
            }

            runOnUiThread {
                status.text = "Estado: SCAN OBD-II em execução…"
                scanButton.isEnabled = false
                scanButton.alpha = 0.55f
            }

            append("=== SCAN OBD-II ===")
            append("A consultar PIDs genéricos...")
            append("")
            runOnUiThread {
                liveDataLog.text = "A atualizar LIVE DATA…"
            }

            val selectedProfile = manufacturerProfiles.getOrNull(manufacturerSpinner.selectedItemPosition)
                ?: manufacturerProfiles.first()

            append("Perfil: ${selectedProfile.name}")
            append("Modo: leitura apenas")
            if (canActive) {
                append("CAN: ativo • protocolo $detectedProtocol")
                append("ISO-TP: leitura através do ELM327")
            } else {
                append("CAN: não identificado pelo adaptador/protocolo atual")
            }
            append("")

            val scanList = if (selectedProfile.parameters.isEmpty()) {
                pids.toList()
            } else {
                selectedProfile.parameters
            }

            runOnUiThread {
                liveDataLog.text = "LIVE DATA — ${selectedProfile.name}\n\n"
            }

            scanList.forEach { (pid, label) ->
                val raw = elm(pid, 2500)
                val result = classifyResponse(raw)
                append("$pid  $label")
                append("   $result")
                append("")
                runOnUiThread {
                    liveDataLog.append(
                        "• $label: $result\n"
                    )
                }
            }

            if (canActive) {
                runCanReadOnlyChecks()
            }

            append("=== FIM OBD-II ===")

            runOnUiThread {
                status.text = "Estado: LIGADO • SCAN concluído"
                scanButton.isEnabled = true
                scanButton.alpha = 1f
            }
        }
    }

    /**
     * Read-only CAN/ISO-TP checks.
     *
     * The ELM327 handles ISO 15765-4 segmentation/flow-control for normal
     * OBD-II requests. No ECU write service (2E/31/etc.) is sent here.
     */
    private fun runCanReadOnlyChecks() {
        append("=== CAN READ-ONLY ===")
        append("ISO-TP: consultar identificação standard OBD-II")

        val selectedProfile = manufacturerProfiles.getOrNull(manufacturerSpinner.selectedItemPosition)
        if (selectedProfile?.name == "Stellantis") {
            runStellantisUdsReadOnly()
        }

        // Mode 09 PID 02: VIN, when the vehicle exposes it.
        val vinRaw = elm("0902", 5000)
        val vin = extractObdAscii(vinRaw, 0x49, 0x02)
        reportCanValue("VIN", vinRaw, vin)

        // Mode 09 PID 04: calibration ID, when available.
        val calRaw = elm("0904", 5000)
        val cal = extractObdAscii(calRaw, 0x49, 0x04)
        reportCanValue("Calibration ID", calRaw, cal)

        // Mode 01 PID 00 is a standard CAN/OBD capability query.
        val pid00 = elm("0100", 3000)
        append("CAN 0100: ${classifyResponse(pid00)}")

        runOnUiThread {
            liveDataLog.append(
                "• CAN: ${if (canActive) "ATIVO / READ-ONLY" else "não disponível"}\\n"
            )
            if (vin.isNotBlank()) liveDataLog.append("• VIN: $vin\\n")
            if (cal.isNotBlank()) liveDataLog.append("• Calibration ID: $cal\\n")
        }
    }

    /**
     * Stellantis UDS READ-ONLY scanner.
     *
     * This does not unlock or bypass a Secure Gateway. It only sends UDS
     * ReadDataByIdentifier (0x22) requests to common 11-bit diagnostic
     * request IDs and accepts positive responses (0x62).
     */
    private fun runStellantisUdsReadOnly() {
        append("=== STELLANTIS UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("A procurar ECUs nos IDs 7E0–7E7…")

        // ELM327: CAN 11-bit, automatic formatting and flow control.
        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)

            // Restrict replies to the matching physical ECU response.
            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in stellantisDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        // Return ELM to automatic protocol/headers for normal OBD-II use.
        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhum DID UDS Stellantis respondeu.")
            append("· Isto pode significar ECU não acessível, DID não suportado ou SGW/rede a bloquear a leitura.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM STELLANTIS UDS ===")
    }

    private fun parseUdsDid(raw: String, did: String): String {
        val hex = raw.uppercase().replace(Regex("[^0-9A-F]"), "")
        if (hex.length < 6) return ""

        val didUpper = did.uppercase()
        val marker = "62$didUpper"
        val start = hex.indexOf(marker)
        if (start < 0) return ""

        val dataStart = start + marker.length
        if (dataStart >= hex.length) return ""

        val dataHex = hex.substring(dataStart)
        val bytes = ArrayList<Int>()
        var i = 0
        while (i + 1 < dataHex.length) {
            bytes.add(dataHex.substring(i, i + 2).toIntOrNull(16) ?: break)
            i += 2
        }

        // Human-readable ECU identification is normally ASCII. Preserve
        // printable characters and ignore padding/non-printable bytes.
        val text = bytes
            .filter { it in 0x20..0x7E }
            .map { it.toChar() }
            .joinToString("")
            .trim()

        return if (text.isNotBlank()) text else dataHex.take(64)
    }

    private fun reportCanValue(label: String, raw: String, value: String) {
        if (value.isNotBlank()) {
            append("CAN $label: $value")
        } else {
            append("CAN $label: não disponível (${clean(raw)})")
        }
    }

    private fun extractObdAscii(raw: String, service: Int, pid: Int): String {
        // Convert hex byte pairs from ELM output into bytes. This works with
        // single- and multi-frame ISO-TP payloads after ELM reassembly.
        val hex = raw.uppercase()
            .replace(Regex("[^0-9A-F]"), "")
        if (hex.length < 4) return ""

        val bytes = ArrayList<Int>()
        var i = 0
        while (i + 1 < hex.length) {
            bytes.add(hex.substring(i, i + 2).toIntOrNull(16) ?: -1)
            i += 2
        }

        val start = bytes.indexOfFirst { it == service }
        if (start < 0) return ""

        // Find the PID immediately after the positive response service.
        var pos = start + 1
        while (pos < bytes.size && bytes[pos] < 0) pos++
        if (pos >= bytes.size || bytes[pos] != pid) return ""

        val sb = StringBuilder()
        for (j in pos + 1 until bytes.size) {
            val b = bytes[j]
            if (b in 0x20..0x7E) sb.append(b.toChar())
        }
        return sb.toString().trim()
    }

    private fun classifyResponse(raw: String): String {
        val readable = raw.replace("\r", " ").replace("\n", " ")
            .replace(Regex("\\s+"), " ").trim()
        val compact = readable.uppercase().replace(Regex("[^0-9A-F]"), "")

        return when {
            readable.uppercase().contains("NO DATA") ->
                "· NO DATA — sem resposta desse PID"
            readable.uppercase().contains("ERROR") ->
                "· ERROR — ELM327 recusou o comando"
            readable.uppercase().contains("UNABLE TO CONNECT") ->
                "· SEM LIGAÇÃO ECU"
            compact.contains("7F0122") || readable.uppercase().contains("7F 01 22") ->
                "✕ 7F 01 22 — Negative Response"
            compact.contains("4100") || Regex("\b41[0-9A-F]{2}\b").containsMatchIn(compact) ->
                "✓ Resposta OBD-II: $readable"
            readable.isBlank() ->
                "· SEM RESPOSTA"
            else ->
                "· Resposta: $readable"
        }
    }

    private fun clean(value: String): String =
        value.replace("\n", " ").replace(Regex("\\s+"), " ").trim()

    private fun append(value: String) {
        runOnUiThread {
            log.append(if (log.text.isEmpty()) value else "\n$value")
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) refreshBluetoothList()
    }

    override fun onDestroy() {
        try { socket?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
