# HOMEBD V11 — BLUETOOTH LIST

- Portrait normal Android window.
- Vertical scroll.
- LIGAR OBDII and SCAN PIDs clickable.
- Displays paired Bluetooth devices in the OBD-II selector.
- Requests Android 12+ Bluetooth permission and refreshes the list after permission.
- Shows clear states for Bluetooth unavailable, disabled, no paired devices, or permission required.
- Developer: lufime.
