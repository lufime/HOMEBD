package pt.homebd

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.*
import java.io.InputStream
import java.io.IOException
import java.io.OutputStream
import java.util.UUID
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var scanButton: TextView
    private lateinit var devicesSpinner: Spinner
    private lateinit var manufacturerSpinner: Spinner
    private lateinit var aboutButton: TextView
    private lateinit var liveDataScroll: ScrollView
    private lateinit var liveDataLog: TextView
    private var detectedProtocol = ""
    private var canActive = false

    private data class ManufacturerProfile(
        val name: String,
        val parameters: List<Pair<String, String>>
    )

    private data class UdsDid(
        val did: String,
        val label: String
    )

    // Public/documented ECU identification DIDs selected for the READ-ONLY
    // Stellantis profile. Unknown/unavailable DIDs are simply reported as such.
    private val stellantisDids = listOf(
        UdsDid("F18C", "ECU Serial Number"),
        UdsDid("F187", "ECU Part Number"),
        UdsDid("F192", "ECU Hardware Number"),
        UdsDid("F193", "ECU Hardware Version"),
        UdsDid("F194", "ECU Software Number"),
        UdsDid("F195", "ECU Software Version")
    )

    // Renault / Dacia: only standardized UDS identification DIDs are used.
    // No proprietary Renault/Dacia DID is guessed or imported from third-party
    // CAN databases. Unsupported DIDs are simply ignored.
    private val renaultDids = listOf(
        UdsDid("F187", "ECU Part Number"),
        UdsDid("F18A", "System Supplier"),
        UdsDid("F18C", "ECU Serial Number"),
        UdsDid("F190", "VIN"),
        UdsDid("F191", "ECU Hardware Number"),
        UdsDid("F194", "ECU Software Number"),
        UdsDid("F195", "ECU Software Version")
    )

    // Volkswagen / Audi / SEAT / Škoda (VAG): only standardized UDS ECU
    // identification DIDs are used. No proprietary VAG CAN database is copied.
    private val vagDids = listOf(
        UdsDid("F187", "ECU Part Number"),
        UdsDid("F18A", "System Supplier"),
        UdsDid("F18C", "ECU Serial Number"),
        UdsDid("F190", "VIN"),
        UdsDid("F191", "ECU Hardware Number"),
        UdsDid("F192", "Supplier ECU Hardware Number"),
        UdsDid("F193", "Supplier ECU Hardware Version"),
        UdsDid("F194", "ECU Software Number"),
        UdsDid("F195", "ECU Software Version")
    )

    // Ford: only standardized UDS identification DIDs are used.
    // No proprietary Ford CAN database is copied or inferred.
    private val fordDids = listOf(
        UdsDid("F187", "ECU Part Number"),
        UdsDid("F18A", "System Supplier"),
        UdsDid("F18C", "ECU Serial Number"),
        UdsDid("F190", "VIN"),
        UdsDid("F191", "ECU Hardware Number"),
        UdsDid("F194", "ECU Software Number"),
        UdsDid("F195", "ECU Software Version")
    )

    // Nissan / INFINITI: only standardized UDS identification DIDs are used.
    // Nissan TechInfo documents ECU identification and VIN fields, but proprietary
    // request maps are not reproduced here. No third-party CAN database is used.
    private val nissanDids = listOf(
        UdsDid("F18C", "ECU Serial Number"),
        UdsDid("F190", "VIN"),
        UdsDid("F187", "ECU Part Number"),
        UdsDid("F194", "ECU Software Number"),
        UdsDid("F195", "ECU Software Version")
    )

    // Tesla: keep the ELM327 profile conservative. Current HOMEBD transport
    // supports Bluetooth ELM327/CAN; Tesla vehicles may require DoIP/Ethernet
    // depending on model and diagnostic architecture. Only standard UDS VIN
    // identification is attempted over CAN here; no proprietary Tesla map is used.
    private val teslaDids = listOf(
        UdsDid("F190", "VIN")
    )

    // Mazda: public Mazda documentation confirms mandatory OBD readout for
    // operating data and fault diagnosis. No proprietary Mazda DID/CAN map is
    // guessed or copied here; manufacturer-specific data remains unavailable
    // unless a public/documented identifier is verified.
    private val mazdaDids = emptyList<UdsDid>()

    // Subaru: conservative public OBD-II read-only profile. No proprietary
    // Subaru DID/request map is guessed or imported from a third-party CAN database.
    private val subaruDids = listOf(
        UdsDid("F190", "VIN")
    )

    // Mitsubishi: the official Mitsubishi technical-information portal documents
    // OBD-II vehicles and CAN-bus diagnosis through MUT-III. Proprietary Mitsubishi
    // request/DID maps are not reproduced here because the detailed service data
    // are subscriber-restricted. HOMEBD therefore uses standard OBD-II plus a
    // conservative standard UDS VIN read when the ECU exposes it.
    private val mitsubishiDids = listOf(
        UdsDid("F190", "VIN")
    )

    // Lexus: separate profile from Toyota so future documented Lexus-specific
    // read-only diagnostics can be added without mixing manufacturer data.
    // Only the standard VIN DID is attempted here; no proprietary Lexus map
    // is guessed or imported from a third-party CAN database.
    private val lexusDids = listOf(
        UdsDid("F190", "VIN")
    )

    // Isuzu: official Isuzu RMI/TruckService documentation confirms OBD/diagnostic
    // support, while detailed manufacturer diagnostic data are provided through
    // Isuzu diagnostic tooling. HOMEBD therefore keeps this profile conservative:
    // standard OBD-II plus a standard UDS VIN read when the ECU exposes it.
    private val isuzuDids = listOf(
        UdsDid("F190", "VIN")
    )


    // OBD-II Mode 01 PID catalogue. These are protocol identifiers and
    // generic concepts, not copied manufacturer code or proprietary CAN maps.
    // The scanner first asks the vehicle which PID blocks it supports and only
    // then requests the supported PIDs. Every manufacturer profile uses this
    // same standards-based catalogue; manufacturer-specific UDS remains
    // separate and is only used when documented.
    private val pids = linkedMapOf(
        "0101" to "Monitor status / DTCs",
        "0102" to "DTC status since clear",
        "0103" to "Fuel system status",
        "0104" to "Calculated engine load",
        "0105" to "Engine coolant temperature",
        "0106" to "Short-term fuel trim — Bank 1",
        "0107" to "Long-term fuel trim — Bank 1",
        "0108" to "Short-term fuel trim — Bank 2",
        "0109" to "Long-term fuel trim — Bank 2",
        "010A" to "Fuel pressure",
        "010B" to "Intake manifold pressure (MAP)",
        "010C" to "Engine RPM",
        "010D" to "Vehicle speed",
        "010E" to "Ignition timing advance",
        "010F" to "Intake air temperature",
        "0110" to "MAF air flow",
        "0111" to "Throttle position",
        "0112" to "Secondary air status",
        "0113" to "Oxygen sensor presence — Bank 1",
        "0114" to "O2 Sensor 1 voltage / trim",
        "0115" to "O2 Sensor 2 voltage / trim",
        "0116" to "O2 Sensor 3 voltage / trim",
        "0117" to "O2 Sensor 4 voltage / trim",
        "0118" to "O2 Sensor 5 voltage / trim",
        "0119" to "O2 Sensor 6 voltage / trim",
        "011A" to "O2 Sensor 7 voltage / trim",
        "011B" to "O2 Sensor 8 voltage / trim",
        "011C" to "OBD standards supported",
        "011D" to "O2 sensors present — Bank 2",
        "011E" to "Auxiliary input status",
        "011F" to "Engine run time since start",
        "0120" to "Supported PIDs 21–40",
        "0121" to "Distance travelled with MIL on",
        "0122" to "Fuel rail pressure",
        "0123" to "Fuel rail pressure (diesel / alternate)",
        "0124" to "O2 Sensor 1 equivalence / voltage",
        "0125" to "O2 Sensor 2 equivalence / voltage",
        "0126" to "O2 Sensor 3 equivalence / voltage",
        "0127" to "O2 Sensor 4 equivalence / voltage",
        "0128" to "O2 Sensor 5 equivalence / voltage",
        "0129" to "O2 Sensor 6 equivalence / voltage",
        "012A" to "O2 Sensor 7 equivalence / voltage",
        "012B" to "O2 Sensor 8 equivalence / voltage",
        "012C" to "Commanded EGR",
        "012D" to "EGR error",
        "012E" to "Commanded evaporative purge",
        "012F" to "Fuel level input",
        "0130" to "Distance since DTCs cleared",
        "0131" to "Evap system vapour pressure",
        "0132" to "Barometric pressure",
        "0133" to "O2 Sensor 1 equivalence ratio",
        "0134" to "O2 Sensor 2 equivalence ratio",
        "0135" to "O2 Sensor 3 equivalence ratio",
        "0136" to "O2 Sensor 4 equivalence ratio",
        "0137" to "O2 Sensor 5 equivalence ratio",
        "0138" to "O2 Sensor 6 equivalence ratio",
        "0139" to "O2 Sensor 7 equivalence ratio",
        "013A" to "O2 Sensor 8 equivalence ratio",
        "013B" to "Catalyst temperature — Bank 1 Sensor 1",
        "013C" to "Catalyst temperature — Bank 2 Sensor 1",
        "013D" to "Catalyst temperature — Bank 1 Sensor 2",
        "013E" to "Catalyst temperature — Bank 2 Sensor 2",
        "013F" to "Control module voltage",
        "0140" to "Supported PIDs 41–60",
        "0141" to "Control module voltage / auxiliary status",
        "0142" to "Control module voltage",
        "0143" to "Absolute load value",
        "0144" to "Commanded equivalence ratio",
        "0145" to "Relative accelerator pedal position",
        "0146" to "Ambient air temperature",
        "0147" to "Absolute throttle position B",
        "0148" to "Absolute throttle position C",
        "0149" to "Accelerator pedal position D",
        "014A" to "Accelerator pedal position E",
        "014B" to "Accelerator pedal position F",
        "014C" to "Commanded throttle actuator",
        "014D" to "Time run with MIL on",
        "014E" to "Time since DTCs cleared",
        "0151" to "Fuel type",
        "0152" to "Ethanol fuel percentage",
        "0153" to "Absolute evaporative system vapour pressure",
        "0154" to "Evap system vapour pressure",
        "0155" to "Short-term secondary O2 trim — Bank 1",
        "0156" to "Long-term secondary O2 trim — Bank 1",
        "0157" to "Short-term secondary O2 trim — Bank 2",
        "0158" to "Long-term secondary O2 trim — Bank 2",
        "0159" to "Fuel rail absolute pressure",
        "015A" to "Relative accelerator pedal position",
        "015B" to "Hybrid battery pack remaining life",
        "015C" to "Engine oil temperature",
        "015D" to "Fuel injection timing",
        "015E" to "Engine fuel rate",
        "015F" to "Engine demand torque",
        "0160" to "Supported PIDs 61–80",
        "0161" to "Engine actual torque",
        "0162" to "Engine reference torque",
        "0163" to "Engine percentage torque",
        "0164" to "Auxiliary input / torque",
        "0165" to "Mass air flow sensor current",
        "0166" to "Engine coolant temperature sensor 1",
        "0167" to "Engine coolant temperature sensor 2",
        "0168" to "Engine coolant temperature sensor 3",
        "0169" to "Engine coolant temperature sensor 4",
        "016A" to "Throttle actuator control",
        "016B" to "Fuel pressure control",
        "016C" to "Commanded diesel intake air flow",
        "016D" to "Exhaust gas recirculation temperature",
        "016E" to "Commanded throttle actuator control",
        "016F" to "Fuel pressure sensor",
        "0170" to "Turbocharger compressor inlet pressure",
        "0171" to "Boost pressure",
        "0172" to "Turbocharger RPM",
        "0173" to "Turbocharger temperature",
        "0174" to "Charge air cooler temperature",
        "0175" to "Exhaust gas temperature — Bank 1",
        "0176" to "Exhaust gas temperature — Bank 2",
        "0177" to "Diesel particulate filter pressure",
        "0178" to "Diesel particulate filter temperature",
        "0179" to "NOx sensor concentration",
        "017A" to "NOx sensor correction",
        "017B" to "Engine friction percentage torque",
        "017C" to "PM sensor output",
        "017D" to "Intake air temperature sensor",
        "017E" to "Engine exhaust flow",
        "017F" to "Exhaust gas temperature",
        "0180" to "Supported PIDs 81–A0"
    )


    private val manufacturerProfiles = listOf(
        ManufacturerProfile("Automático", pids.toList()),
        ManufacturerProfile("Stellantis • Opel / Vauxhall", pids.toList()),
        ManufacturerProfile("Renault / Dacia", pids.toList()),
        ManufacturerProfile("Volkswagen / Audi / SEAT / Škoda", pids.toList()),
        ManufacturerProfile("BMW", pids.toList()),
        ManufacturerProfile("Mercedes-Benz", pids.toList()),
        ManufacturerProfile("Ford", pids.toList()),
        ManufacturerProfile("Toyota", pids.toList()),
        ManufacturerProfile("Lexus", pids.toList()),
        ManufacturerProfile("Honda", pids.toList()),
        ManufacturerProfile("Hyundai / Kia", pids.toList()),
        ManufacturerProfile("Nissan / INFINITI", pids.toList()),
        ManufacturerProfile("Volvo", pids.toList()),
        ManufacturerProfile("Tesla", pids.toList()),
        ManufacturerProfile("Subaru", pids.toList()),
        ManufacturerProfile("Mitsubishi", pids.toList()),
        ManufacturerProfile("Mazda", pids.toList()),
        ManufacturerProfile("Isuzu", pids.toList()),
        ManufacturerProfile("Jaguar / Land Rover", pids.toList()),
        ManufacturerProfile("Porsche", pids.toList()),
        ManufacturerProfile("Suzuki", pids.toList()),
        ManufacturerProfile("Geely / Polestar", pids.toList()),
        ManufacturerProfile("Outros", emptyList())
    )


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(23, 23, 23)
        window.navigationBarColor = Color.rgb(23, 23, 23)

        // Ecrã normal: o conteúdo nunca fica por baixo das barras do sistema.
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(true)
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = 0
        }

        val background = Color.rgb(28, 28, 28)
        val panel = Color.rgb(55, 55, 55)
        val primary = Color.rgb(235, 235, 235)
        val secondary = Color.rgb(190, 190, 190)
        val blue = Color.rgb(20, 145, 245)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(background)
            setPadding(dp(8), dp(2), dp(8), dp(2))
            clipChildren = true
            clipToPadding = true
        }

        val header = ImageView(this).apply {
            setImageResource(pt.homebd.R.drawable.homebd_header)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
            contentDescription = "HOMEBD"
            adjustViewBounds = true
            clipToOutline = true
        }

        status = TextView(this).apply {
            text = "Estado: desligado"
            textSize = 14f
            setTextColor(secondary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        val deviceLabel = TextView(this).apply {
            text = "DISPOSITIVO OBD-II"
            textSize = 12f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        manufacturerSpinner = Spinner(this).apply {
            this.background = GradientDrawable().apply {
                setColor(panel)
                cornerRadius = 2f
            }
            minimumHeight = dp(44)
        }

        devicesSpinner = Spinner(this).apply {
            this.background = GradientDrawable().apply {
                setColor(panel)
                cornerRadius = 2f
            }
            minimumHeight = dp(44)
        }

        val connect = actionButton("LIGAR OBDII", blue, primary)
        scanButton = actionButton("SCAN PIDs", Color.rgb(70, 70, 70), primary).apply {
            isEnabled = false
            alpha = 0.55f
        }

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        buttons.addView(connect, LinearLayout.LayoutParams(0, dp(50), 1f).apply {
            setMargins(dp(0), dp(4), dp(4), dp(4))
        })
        buttons.addView(scanButton, LinearLayout.LayoutParams(0, dp(50), 1f).apply {
            setMargins(dp(4), dp(4), dp(0), dp(4))
        })

        log = TextView(this).apply {
            textSize = 14f
            setTextColor(primary)
            setBackgroundColor(panel)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            includeFontPadding = true
            gravity = Gravity.TOP or Gravity.START
            setLineSpacing(0f, 1.0f)
        }

        logScroll = ScrollView(this).apply {
            setBackgroundColor(panel)
            isFillViewport = true
            isVerticalScrollBarEnabled = true
            scrollBarStyle = View.SCROLLBARS_INSIDE_INSET
            isScrollbarFadingEnabled = false
            addView(log, ViewGroup.LayoutParams(-1, -2))
        }

        val liveLabel = TextView(this).apply {
            text = "LIVE DATA"
            textSize = 13f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        liveDataLog = TextView(this).apply {
            textSize = 14f
            setTextColor(primary)
            setBackgroundColor(panel)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            gravity = Gravity.TOP or Gravity.START
            includeFontPadding = true
            setLineSpacing(0f, 1.0f)
        }

        liveDataScroll = ScrollView(this).apply {
            setBackgroundColor(panel)
            isFillViewport = true
            isVerticalScrollBarEnabled = true
            scrollBarStyle = View.SCROLLBARS_INSIDE_INSET
            isScrollbarFadingEnabled = false
            addView(liveDataLog, ViewGroup.LayoutParams(-1, -2))
        }

        val diagnosticLabel = TextView(this).apply {
            text = "DIAGNÓSTICO"
            textSize = 13f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        aboutButton = TextView(this).apply {
            text = "HOMEBD • BETA VERSION 1.0 • lufime"
            textSize = 11f
            setTextColor(secondary)
            gravity = Gravity.CENTER
            includeFontPadding = false
            isClickable = true
            isFocusable = true
            setPadding(dp(4), dp(2), dp(4), dp(2))
        }

        root.addView(header, LinearLayout.LayoutParams(-1, dp(120)))
        root.addView(status, LinearLayout.LayoutParams(-1, dp(28)))

        val selectors = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val deviceColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(0), dp(0), dp(4), dp(0))
        }
        deviceColumn.addView(deviceLabel, LinearLayout.LayoutParams(-1, dp(22)))
        deviceColumn.addView(devicesSpinner, LinearLayout.LayoutParams(-1, dp(46)))

        val manufacturerLabel = TextView(this).apply {
            text = "FABRICANTE / PERFIL"
            textSize = 12f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }
        val manufacturerColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(0), dp(0), dp(0))
        }
        manufacturerColumn.addView(manufacturerLabel, LinearLayout.LayoutParams(-1, dp(22)))
        manufacturerColumn.addView(manufacturerSpinner, LinearLayout.LayoutParams(-1, dp(46)))

        selectors.addView(deviceColumn, LinearLayout.LayoutParams(0, dp(70), 1f))
        selectors.addView(manufacturerColumn, LinearLayout.LayoutParams(0, dp(70), 1f))
        root.addView(selectors, LinearLayout.LayoutParams(-1, dp(72)))

        root.addView(buttons, LinearLayout.LayoutParams(-1, dp(58)))
        root.addView(liveLabel, LinearLayout.LayoutParams(-1, dp(28)))
        root.addView(liveDataScroll, LinearLayout.LayoutParams(-1, dp(135)))
        root.addView(diagnosticLabel, LinearLayout.LayoutParams(-1, dp(28)))
        root.addView(logScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(aboutButton, LinearLayout.LayoutParams(-1, dp(24)))

        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener { v, insets ->
                val bars = insets.getInsets(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                v.setPadding(
                    dp(8),
                    bars.top + dp(2),
                    dp(8),
                    bars.bottom + dp(2)
                )
                insets
            }
        }

        setContentView(root)

        manufacturerSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            manufacturerProfiles.map { it.name }
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        manufacturerSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val profile = manufacturerProfiles[position]
                liveDataLog.text =
                    "Perfil: ${profile.name}\n\n" +
                    "OBD-II standard\n" +
                    "Os PIDs suportados são detetados automaticamente pelo veículo.\n\n" +
                    "Categorias disponíveis:\n" +
                    "• Motor e carga\n" +
                    "• Combustível e mistura\n" +
                    "• Temperaturas e pressões\n" +
                    "• Sensores O2 / emissões\n" +
                    "• Acelerador / pedal\n" +
                    "• Estado OBD / readiness\n" +
                    "• Tensão e dados auxiliares\n" +
                    "• VIN / informação do veículo"
                append("Perfil selecionado: ${profile.name} • catálogo OBD-II standard ativo")
            }
        }

        root.requestApplyInsets()

        connect.setOnClickListener {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            val paired = try {
                adapter?.bondedDevices?.toList() ?: emptyList()
            } catch (_: SecurityException) {
                emptyList()
            }

            val position = devicesSpinner.selectedItemPosition
            val device = paired.getOrNull(position)

            if (device != null) {
                connect(device)
            } else {
                append("⚠ Nenhum dispositivo Bluetooth selecionável.")
                append("Emparelhe o seu ELM327 nas definições Bluetooth do Android.")
            }
        }

        scanButton.setOnClickListener { runScanner() }
        aboutButton.setOnClickListener { showAbout() }

        append("HOMEBD pronto.")
        append("Diagnóstico OBD-II universal para veículos.")
        append("Selecione o seu ELM327 na lista e toque em LIGAR OBDII.")
        liveDataLog.text = "Sem dados — ligue o OBD-II e execute SCAN PIDs."

        requestBtPermissions()
        refreshBluetoothList()
    }

    private fun showAbout() {
        val pt = Locale.getDefault().language.equals("pt", ignoreCase = true)
        val title = if (pt) "Sobre o HOMEBD" else "About HOMEBD"
        val message = if (pt) {
            "HOMEBD\n" +
            "Home Onboard Monitoring Engine Board Data\n\n" +
            "HOMEBD — Funcionalidades desenvolvidas\n\n" +
            "• Aplicação Android para diagnóstico OBD-II\n" +
            "• Ligação a adaptadores OBD-II através de Bluetooth\n" +
            "• Deteção e seleção de dispositivos Bluetooth emparelhados\n" +
            "• Comunicação com interfaces compatíveis com ELM327\n" +
            "• Deteção automática do protocolo OBD-II\n" +
            "• Identificação dos PIDs suportados pelo veículo\n" +
            "• Leitura dinâmica e conversão dos parâmetros\n" +
            "• Live Data em tempo real\n" +
            "• Leitura de DTCs quando suportada\n" +
            "• Leitura de VIN quando disponível\n" +
            "• CAN / ISO-TP / UDS quando suportado\n" +
            "• Perfis específicos de fabricantes\n" +
            "• Operação 100% READ-ONLY\n\n" +
            "Nota de desenvolvimento:\n" +
            "O HOMEBD foi desenvolvido de raiz, com arquitetura, funcionalidades e soluções técnicas concebidas especificamente para este projeto e desenvolvidas para a própria aplicação.\n\n" +
            "Versão: BETA VERSION 1.0\n" +
            "Desenvolvido por: lufime"
        } else {
            "HOMEBD\n" +
            "Home Onboard Monitoring Engine Board Data\n\n" +
            "HOMEBD — Developed Features\n\n" +
            "• Android application for OBD-II diagnostics\n" +
            "• Bluetooth connection to OBD-II adapters\n" +
            "• Detection and selection of paired Bluetooth devices\n" +
            "• Communication with ELM327-compatible interfaces\n" +
            "• Automatic OBD-II protocol detection\n" +
            "• Identification of vehicle-supported PIDs\n" +
            "• Dynamic reading and conversion of parameters\n" +
            "• Real-time Live Data\n" +
            "• DTC reading when supported\n" +
            "• VIN reading when available\n" +
            "• CAN / ISO-TP / UDS when supported\n" +
            "• Manufacturer-specific profiles\n" +
            "• 100% READ-ONLY operation\n\n" +
            "Development Note:\n" +
            "HOMEBD was developed from the ground up, with its architecture, features, and technical solutions specifically designed and developed for this project and its application.\n\n" +
            "Version: BETA VERSION 1.0\n" +
            "Developed by: lufime"
        }

        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton(if (pt) "FECHAR" else "CLOSE", null)
            .show()
    }

    private fun actionButton(label: String, color: Int, textColor: Int): TextView =
        TextView(this).apply {
            text = label
            textSize = 14f
            setTextColor(textColor)
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            this.background = GradientDrawable().apply {
                setColor(color)
                cornerRadius = 8f
            }
        }

    private fun refreshBluetoothList() {
        val adapter = BluetoothAdapter.getDefaultAdapter()

        if (adapter == null) {
            setDevices(listOf("Bluetooth não disponível neste dispositivo"))
            return
        }

        try {
            if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
            ) {
                setDevices(listOf("Permitir Bluetooth para mostrar dispositivos"))
                return
            }

            if (!adapter.isEnabled) {
                setDevices(listOf("Bluetooth desligado — ative o Bluetooth"))
                return
            }

            val paired = adapter.bondedDevices.toList()
            val names = if (paired.isEmpty()) {
                listOf("Nenhum dispositivo emparelhado")
            } else {
                paired.map { device ->
                    val name = try { device.name ?: "Sem nome" } catch (_: SecurityException) { "Sem nome" }
                    "$name  (${device.address})"
                }
            }

            setDevices(names)
            append("✓ Bluetooth: ${paired.size} dispositivo(s) emparelhado(s).")
        } catch (_: SecurityException) {
            setDevices(listOf("Permissão Bluetooth necessária"))
        }
    }

    private fun setDevices(names: List<String>) {
        devicesSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            names
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                ),
                10
            )
        }
    }

    private fun connect(device: BluetoothDevice) {
        thread {
            try {
                runOnUiThread {
                    status.text = "Estado: a ligar…"
                }

                socket?.close()
                socket = device.createRfcommSocketToServiceRecord(spp)
                socket!!.connect()

                input = socket!!.inputStream
                output = socket!!.outputStream

                elm("ATZ", 5000)
                Thread.sleep(1200)
                elm("ATE0", 2500)
                elm("ATL0", 2500)
                elm("ATS0", 2500)
                elm("ATSP0", 2500)

                val protocol = elm("ATDP", 2500)
                val protocolNumber = elm("ATDPN", 2500)
                    .trim()
                    .uppercase()
                    .removePrefix("A")

                if (protocol.isBlank()) {
                    throw IOException("ELM327 não respondeu ao ATDP")
                }

                detectedProtocol = protocolNumber
                canActive = protocolNumber in setOf("6", "7", "8", "9", "A", "B", "C") ||
                    protocol.uppercase().contains("CAN") ||
                    protocol.uppercase().contains("J1939")

                // Read-only CAN setup: keep automatic flow control enabled and
                // do not enable any ECU write/programming command.
                if (canActive) {
                    elm("ATCFC1", 1500)
                    append("✓ CAN detectado: ISO/J1939.")
                    append("✓ CAN em modo READ-ONLY.")
                }

                runOnUiThread {
                    status.text = if (canActive)
                        "Estado: LIGADO • CAN • READ-ONLY"
                    else
                        "Estado: LIGADO • ELM327 pronto"
                    scanButton.isEnabled = true
                    scanButton.alpha = 1f
                }

                append("✓ ELM327 inicializado.")
                append("Protocolo: ${clean(protocol)}")
                append("Número de protocolo: ${if (protocolNumber.isBlank()) "desconhecido" else protocolNumber}")
                append("Pronto para SCAN PIDs.")
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Estado: erro de ligação"
                }
                append("✕ ERRO: ${e.message ?: "erro desconhecido"}")
            }
        }
    }

    private fun elm(cmd: String, timeout: Long = 2500): String {
        val out = output ?: return ""
        val ins = input ?: return ""

        try {
            out.write((cmd + "\r").toByteArray(Charsets.US_ASCII))
            out.flush()
        } catch (e: Exception) {
            throw IOException("Falha ao enviar $cmd: ${e.message}", e)
        }

        val start = System.currentTimeMillis()
        val buf = ByteArray(4096)
        val data = StringBuilder()

        while (System.currentTimeMillis() - start < timeout) {
            if (ins.available() > 0) {
                val n = ins.read(buf)
                if (n > 0) data.append(String(buf, 0, n, Charsets.US_ASCII))
                if (data.contains(">")) break
            } else {
                Thread.sleep(30)
            }
        }

        return data.toString()
            .replace("\r", "\n")
            .replace(">", "")
            .trim()
    }

    private fun runScanner() {
        thread {
            if (output == null) {
                append("⚠ OBDII não está ligado.")
                return@thread
            }

            runOnUiThread {
                status.text = "Estado: SCAN OBD-II em execução…"
                scanButton.isEnabled = false
                scanButton.alpha = 0.55f
            }

            append("=== SCAN OBD-II ===")
            append("A consultar PIDs genéricos...")
            append("")
            runOnUiThread {
                liveDataLog.text = "A atualizar LIVE DATA…"
            }

            val selectedProfile = manufacturerProfiles.getOrNull(manufacturerSpinner.selectedItemPosition)
                ?: manufacturerProfiles.first()

            append("Perfil: ${selectedProfile.name}")
            append("Modo: leitura apenas")
            if (canActive) {
                append("CAN: ativo • protocolo $detectedProtocol")
                append("ISO-TP: leitura através do ELM327")
            } else {
                append("CAN: não identificado pelo adaptador/protocolo atual")
            }
            append("")

            val scanList = discoverSupportedStandardPids()

            runOnUiThread {
                liveDataLog.text = "LIVE DATA — ${selectedProfile.name}\n\n" +
                    if (scanList.isEmpty()) {
                        "Nenhum PID standard confirmado pelo veículo.\n\n" +
                        "O HOMEBD não inventa dados: apenas mostra parâmetros efetivamente suportados.\n"
                    } else {
                        "${scanList.size} PIDs standard suportados detetados.\n\n"
                    }
            }

            if (scanList.isEmpty()) {
                append("· Nenhum PID standard suportado foi confirmado.")
            } else {
                scanList.forEach { (pid, label) ->
                    val raw = elm(pid, 2500)
                    val result = decodeObdPid(pid, raw)
                    append("$pid  $label")
                    append("   $result")
                    append("")
                    runOnUiThread {
                        liveDataLog.append("• $label: $result\n")
                    }
                }
            }

            if (canActive) {
                runCanReadOnlyChecks()
            }

            append("=== FIM OBD-II ===")

            runOnUiThread {
                status.text = "Estado: LIGADO • SCAN concluído"
                scanButton.isEnabled = true
                scanButton.alpha = 1f
            }
        }
    }

    /**
     * Read-only CAN/ISO-TP checks.
     *
     * The ELM327 handles ISO 15765-4 segmentation/flow-control for normal
     * OBD-II requests. No ECU write service (2E/31/etc.) is sent here.
     */
    /**
     * Reads the standard Mode 01 supported-PID bitmaps first, then requests
     * only PIDs the vehicle reports as supported. This keeps every manufacturer
     * profile standards-based without copying proprietary manufacturer maps.
     */
    private fun discoverSupportedStandardPids(): List<Pair<String, String>> {
        val blocks = listOf("0100", "0120", "0140", "0160", "0180")
        val supported = linkedSetOf<Int>()

        blocks.forEach { supportPid ->
            val raw = elm(supportPid, 3000)
            val bytes = obdPayloadBytes(raw, 0x41, supportPid.substring(2).toInt(16))
            if (bytes.size >= 4) {
                val bitmap = (bytes[0] shl 24) or (bytes[1] shl 16) or
                    (bytes[2] shl 8) or bytes[3]
                val base = supportPid.substring(2).toInt(16) + 1
                for (bit in 0..31) {
                    if ((bitmap and (1 shl (31 - bit))) != 0) {
                        supported.add(base + bit)
                    }
                }
            }
        }

        val result = pids.entries.filter { (pid, _) ->
            val value = pid.substring(2).toInt(16)
            value in supported && value !in setOf(0x20, 0x40, 0x60, 0x80)
        }.map { it.key to it.value }

        append("✓ Capacidade OBD-II: ${result.size} PID(s) suportado(s) detetado(s).")
        return result
    }

    private fun obdPayloadBytes(raw: String, service: Int, pid: Int): List<Int> {
        val hex = raw.uppercase().replace(Regex("[^0-9A-F]"), "")
        if (hex.length < 8) return emptyList()
        val bytes = ArrayList<Int>()
        var i = 0
        while (i + 1 < hex.length) {
            bytes.add(hex.substring(i, i + 2).toIntOrNull(16) ?: -1)
            i += 2
        }
        val start = bytes.indexOfFirst { it == service }
        if (start < 0 || start + 1 >= bytes.size || bytes[start + 1] != pid) return emptyList()
        return bytes.drop(start + 2).filter { it in 0..255 }
    }

    private fun decodeObdPid(pid: String, raw: String): String {
        val pidNum = pid.substring(2).toIntOrNull(16) ?: return classifyResponse(raw)
        val payload = obdPayloadBytes(raw, 0x41, pidNum)
        if (payload.isEmpty()) return classifyResponse(raw)

        fun u16(): Int = ((payload.getOrNull(0) ?: 0) shl 8) or (payload.getOrNull(1) ?: 0)
        fun u32(): Long = ((payload.getOrNull(0)?.toLong() ?: 0L) shl 24) or
            ((payload.getOrNull(1)?.toLong() ?: 0L) shl 16) or
            ((payload.getOrNull(2)?.toLong() ?: 0L) shl 8) or
            (payload.getOrNull(3)?.toLong() ?: 0L)
        fun pct(a: Int): String = "%.1f %%".format(Locale.US, a * 100.0 / 255.0)
        fun signedPct(a: Int): String = "%.1f %%".format(Locale.US, a * 100.0 / 128.0 - 100.0)
        fun temp(a: Int): String = "${a - 40} °C"

        return when (pid.uppercase()) {
            "0101" -> decodeMonitorStatus(payload)
            "0102" -> "DTC status: 0x${u16().toString(16).uppercase().padStart(4, '0')}"
            "0103" -> decodeFuelSystemStatus(payload.first())
            "0104" -> pct(payload.first())
            "0105", "010F", "0146", "015C" -> temp(payload.first())
            "0106", "0107", "0108", "0109", "012D", "0155", "0156", "0157", "0158" -> signedPct(payload.first())
            "010A" -> "${payload.first() * 3} kPa"
            "010B" -> "${payload.first()} kPa"
            "010C" -> "%.0f rpm".format(Locale.US, u16() / 4.0)
            "010D" -> "${payload.first()} km/h"
            "010E" -> "%.1f °".format(Locale.US, payload.first() / 2.0 - 64.0)
            "0110" -> "%.2f g/s".format(Locale.US, u16() / 100.0)
            "0111", "0145", "0147", "0148", "0149", "014A", "014B", "015A" -> pct(payload.first())
            "0112" -> decodeSecondaryAirStatus(payload.first())
            "0113", "011D" -> "Sensor presence bitmap: 0x${payload.first().toString(16).uppercase().padStart(2, '0')}"
            in setOf("0114", "0115", "0116", "0117", "0118", "0119", "011A", "011B") ->
                decodeOxygenVoltageTrim(payload)
            "011C" -> decodeObdStandard(payload.first())
            "011E" -> if (payload.first() and 1 == 1) "Active" else "Inactive"
            "011F" -> "${u16()} s (${u16() / 60} min)"
            "0120", "0140", "0160", "0180" -> "Supported PID bitmap: 0x${u32().toString(16).uppercase().padStart(8, '0')}"
            "0121", "0130" -> "${u16()} km"
            "0122" -> "%.0f kPa".format(Locale.US, u16() * 0.079)
            "0123" -> "${u16()} kPa"
            in setOf("0124", "0125", "0126", "0127", "0128", "0129", "012A", "012B") ->
                decodeOxygenEquivalence(payload)
            "012C" -> pct(payload.first())
            "012E" -> pct(payload.first())
            "012F" -> pct(payload.first())
            "0131" -> "${u16()} km"
            "0132" -> "${u16()} Pa"
            in setOf("0133", "0134", "0135", "0136", "0137", "0138", "0139", "013A") ->
                decodeOxygenEquivalence(payload)
            "013B", "013C", "013D", "013E" -> "%.1f °C".format(Locale.US, u16() / 10.0 - 40.0)
            "013F", "0142" -> "%.2f V".format(Locale.US, u16() / 1000.0)
            "0141" -> "Monitor status since DTC clear: 0x${u32().toString(16).uppercase().padStart(8, '0')}"
            "0143" -> "%.1f %%".format(Locale.US, u16() * 100.0 / 255.0)
            "0144" -> "%.3f ratio".format(Locale.US, u16() / 32768.0)
            "014C" -> pct(payload.first())
            "014D", "014E" -> "${u16()} min"
            "0151" -> decodeFuelType(payload.first())
            "0152" -> pct(payload.first())
            "0153", "0154" -> "${u16()} Pa"
            "0159" -> "%.0f kPa".format(Locale.US, u16() * 10.0)
            "015B" -> pct(payload.first())
            "015D" -> "%.2f °".format(Locale.US, u16() / 128.0 - 210.0)
            "015E" -> "%.2f L/h".format(Locale.US, u16() / 20.0)
            "015F", "0161", "0162", "0163", "017B" -> "%.1f %% torque".format(Locale.US, payload.first() - 125.0)
            "0165" -> "%.1f mA".format(Locale.US, u16() * 0.001)
            "0166", "0167", "0168", "0169", "0173", "0174", "0175", "0176", "0178", "017F" -> temp(payload.first())
            "016A", "016E" -> pct(payload.first())
            "016B", "016F" -> "${u16()} kPa"
            "016C" -> "%.1f %%".format(Locale.US, payload.first() * 100.0 / 255.0)
            "016D" -> temp(payload.first())
            "0170" -> "${u16()} kPa"
            "0171" -> "${u16()} kPa"
            "0172" -> "${u16()} rpm"
            "0177" -> "${u16()} kPa"
            "0179", "017A" -> "${u16()} ppm"
            "017C" -> "${u16()} ppm"
            "017D" -> temp(payload.first())
            "017E" -> "${u16()} g/s"
            else -> "${payload.joinToString(" ") { "%02X".format(it) }} (raw)"
        }
    }

    private fun decodeMonitorStatus(p: List<Int>): String {
        if (p.size < 4) return "Monitor bitmap: ${p.joinToString(" ") { "%02X".format(it) }}"
        val mil = (p[0] and 0x80) != 0
        val dtcCount = p[0] and 0x7F
        val misfireReady = (p[1] and 0x01) != 0
        val fuelReady = (p[1] and 0x02) != 0
        return "MIL=${if (mil) "ON" else "OFF"} • DTC=$dtcCount • monitors=${if (misfireReady || fuelReady) "available" else "not reported"}"
    }

    private fun decodeFuelSystemStatus(code: Int): String = when (code) {
        0x01 -> "Open loop — insufficient engine temperature"
        0x02 -> "Closed loop — using oxygen sensor feedback"
        0x04 -> "Open loop — engine load / fuel cut"
        0x08 -> "Open loop — system fault"
        0x10 -> "Closed loop — fault with at least one sensor"
        else -> "Code 0x${code.toString(16).uppercase().padStart(2, '0')}"
    }

    private fun decodeSecondaryAirStatus(code: Int): String = when (code) {
        0x01 -> "Upstream of catalytic converter"
        0x02 -> "Downstream of catalytic converter"
        0x04 -> "Atmosphere"
        else -> "Code 0x${code.toString(16).uppercase().padStart(2, '0')}"
    }

    private fun decodeObdStandard(code: Int): String = when (code) {
        0x01 -> "OBD-II as defined by CARB"
        0x02 -> "OBD as defined by EPA"
        0x03 -> "OBD and OBD-II"
        0x04 -> "OBD-I"
        0x05 -> "Not intended for OBD"
        0x06 -> "EOBD"
        0x07 -> "EOBD and OBD-II"
        0x08 -> "EOBD and OBD"
        0x09 -> "EOBD, OBD and OBD-II"
        0x0A -> "JOBD"
        else -> "Standard code 0x${code.toString(16).uppercase().padStart(2, '0')}"
    }

    private fun decodeFuelType(code: Int): String = when (code) {
        0x01 -> "Gasoline"
        0x02 -> "Methanol"
        0x03 -> "Ethanol"
        0x04 -> "Diesel"
        0x05 -> "LPG"
        0x06 -> "CNG"
        0x07 -> "Propane"
        0x08 -> "Electric"
        0x09 -> "Bifuel gasoline"
        0x0A -> "Bifuel methanol"
        0x0B -> "Bifuel ethanol"
        0x0C -> "Bifuel LPG"
        0x0D -> "Bifuel CNG"
        0x0E -> "Bifuel propane"
        0x0F -> "Bifuel electric"
        0x10 -> "Bifuel electric + combustion"
        else -> "Fuel type code 0x${code.toString(16).uppercase().padStart(2, '0')}"
    }

    private fun decodeOxygenVoltageTrim(p: List<Int>): String {
        val voltage = p.getOrNull(0)?.times(0.005) ?: 0.0
        val trim = p.getOrNull(1)?.let { it * 100.0 / 128.0 - 100.0 }
        return if (trim == null) "%.3f V".format(Locale.US, voltage)
        else "%.3f V • trim %.1f %%".format(Locale.US, voltage, trim)
    }

    private fun decodeOxygenEquivalence(p: List<Int>): String {
        if (p.size < 2) return "Dados insuficientes"
        val ratio = ((p[0] shl 8) or p[1]) / 32768.0
        return "equivalence ratio %.3f".format(Locale.US, ratio)
    }

    private fun runCanReadOnlyChecks() {
        append("=== CAN READ-ONLY ===")
        append("ISO-TP: consultar identificação standard OBD-II")

        val selectedProfile = manufacturerProfiles.getOrNull(manufacturerSpinner.selectedItemPosition)
        when (selectedProfile?.name) {
            "Stellantis • Opel / Vauxhall", "Stellantis" -> runStellantisUdsReadOnly()
            "Renault / Dacia" -> runRenaultUdsReadOnly()
            "Volkswagen / Audi / SEAT / Škoda" -> runVagUdsReadOnly()
            "Ford" -> runFordUdsReadOnly()
            "Nissan / INFINITI" -> runNissanUdsReadOnly()
            "Tesla" -> runTeslaUdsReadOnly()
            "Subaru" -> runSubaruReadOnly()
            "Mitsubishi" -> runMitsubishiReadOnly()
            "Lexus" -> runLexusReadOnly()
            "Mazda" -> runMazdaReadOnly()
            "Isuzu" -> runIsuzuReadOnly()
            "BMW" -> runGenericManufacturerUdsReadOnly("BMW", listOf(UdsDid("F190", "VIN")))
            "Mercedes-Benz" -> runGenericManufacturerUdsReadOnly("Mercedes-Benz", listOf(UdsDid("F190", "VIN")))
            "Volvo" -> runGenericManufacturerUdsReadOnly("Volvo", listOf(UdsDid("F190", "VIN")))
            "Honda" -> runGenericManufacturerUdsReadOnly("Honda / Acura", listOf(UdsDid("F190", "VIN")))
            "Hyundai / Kia" -> runGenericManufacturerUdsReadOnly("Hyundai / Kia", listOf(UdsDid("F190", "VIN")))
            "Jaguar / Land Rover" -> runGenericManufacturerUdsReadOnly("Jaguar / Land Rover", listOf(UdsDid("F190", "VIN")))
            "Porsche" -> runGenericManufacturerUdsReadOnly("Porsche", listOf(UdsDid("F190", "VIN")))
            "Suzuki" -> runGenericManufacturerUdsReadOnly("Suzuki", listOf(UdsDid("F190", "VIN")))
            "Geely / Polestar" -> runGenericManufacturerUdsReadOnly("Geely / Polestar", listOf(UdsDid("F190", "VIN")))
        }

        // Mode 09 PID 02: VIN, when the vehicle exposes it.
        val vinRaw = elm("0902", 5000)
        val vin = extractObdAscii(vinRaw, 0x49, 0x02)
        reportCanValue("VIN", vinRaw, vin)

        // Mode 09 PID 04: calibration ID, when available.
        val calRaw = elm("0904", 5000)
        val cal = extractObdAscii(calRaw, 0x49, 0x04)
        reportCanValue("Calibration ID", calRaw, cal)

        // Mode 01 PID 00 is a standard CAN/OBD capability query.
        val pid00 = elm("0100", 3000)
        append("CAN 0100: ${classifyResponse(pid00)}")

        runOnUiThread {
            liveDataLog.append(
                "• CAN: ${if (canActive) "ATIVO / READ-ONLY" else "não disponível"}\\n"
            )
            if (vin.isNotBlank()) liveDataLog.append("• VIN: $vin\\n")
            if (cal.isNotBlank()) liveDataLog.append("• Calibration ID: $cal\\n")
        }
    }

    /**
     * Stellantis UDS READ-ONLY scanner.
     *
     * This does not unlock or bypass a Secure Gateway. It only sends UDS
     * ReadDataByIdentifier (0x22) requests to common 11-bit diagnostic
     * request IDs and accepts positive responses (0x62).
     */
    private fun runGenericManufacturerUdsReadOnly(name: String, dids: List<UdsDid>) {
        append("=== $name UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("A procurar ECUs nos IDs 7E0–7E7…")
        append("Sem mapa proprietário: apenas DIDs standard configurados.")

        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)
            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)
            for (did in dids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread { liveDataLog.append("• ECU $req — ${did.label}: $value\n") }
                }
            }
        }
        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")
        if (found == 0) append("· Nenhum DID UDS $name respondeu.")
        else append("✓ $found leitura(s) UDS $name obtida(s).")
        append("=== FIM $name UDS ===")
    }

    private fun runStellantisUdsReadOnly() {
        append("=== STELLANTIS UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("A procurar ECUs nos IDs 7E0–7E7…")

        // ELM327: CAN 11-bit, automatic formatting and flow control.
        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)

            // Restrict replies to the matching physical ECU response.
            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in stellantisDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        // Return ELM to automatic protocol/headers for normal OBD-II use.
        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhum DID UDS Stellantis respondeu.")
            append("· Isto pode significar ECU não acessível, DID não suportado ou SGW/rede a bloquear a leitura.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM STELLANTIS UDS ===")
    }

    /**
     * Renault / Dacia UDS READ-ONLY scanner.
     *
     * Uses only standardized identification DIDs from the F18x/F19x range.
     * No security access, session switching, coding or programming is sent.
     */
    private fun runRenaultUdsReadOnly() {
        append("=== RENAULT / DACIA UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("DIDs: identificação ECU standard ISO 14229")
        append("A procurar ECUs nos IDs 7E0–7E7…")

        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)

            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in renaultDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhum DID UDS Renault / Dacia respondeu.")
            append("· Isto pode significar ECU não acessível, DID não suportado ou rede/SGW a bloquear a leitura.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM RENAULT / DACIA UDS ===")
    }

    /**
     * Volkswagen / Audi / SEAT / Škoda UDS READ-ONLY scanner.
     *
     * Only UDS ReadDataByIdentifier (0x22) is transmitted. No security access,
     * coding, adaptation, routine control or ECU programming is attempted.
     */
    private fun runVagUdsReadOnly() {
        append("=== VAG UDS READ-ONLY ===")
        append("Volkswagen / Audi / SEAT / Škoda")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("A procurar ECUs nos IDs 7E0–7E7…")

        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)

            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in vagDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhum DID UDS VAG respondeu.")
            append("· ECU não acessível, DID não suportado ou gateway/rede a bloquear a leitura.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM VAG UDS ===")
    }

    /**
     * Ford UDS READ-ONLY scanner.
     *
     * Only UDS ReadDataByIdentifier (0x22) is transmitted. No security access,
     * coding, adaptation, routine control or ECU programming is attempted.
     */
    private fun runNissanUdsReadOnly() {
        append("=== NISSAN / INFINITI UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("A procurar ECUs nos IDs 7E0–7E7…")
        append("Nota: não são usados mapas proprietários Nissan/INFINITI sem documentação pública verificável.")

        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)
            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in nissanDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhum DID UDS Nissan / INFINITI respondeu.")
            append("· ECU/rede/DID pode não suportar a leitura ou pode exigir ferramenta de diagnóstico específica.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM NISSAN / INFINITI UDS ===")
    }

    /**
     * Tesla conservative READ-ONLY diagnostic profile.
     *
     * The current HOMEBD transport is Bluetooth ELM327/CAN. Some Tesla
     * generations use diagnostic Ethernet/DoIP, so this profile never claims
     * universal Tesla ECU access. It only attempts standard UDS VIN reading
     * over CAN when the connected adapter exposes a compatible CAN path.
     */
    private fun runTeslaUdsReadOnly() {
        append("=== TESLA UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("Perfil conservador: apenas VIN standard F190 sobre CAN")
        append("Nota: alguns Tesla requerem DoIP/Ethernet; ELM327 Bluetooth não fornece essa interface.")

        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)
            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in teslaDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhuma resposta Tesla UDS obtida através do CAN/ELM327.")
            append("· Isto não significa que o veículo não tenha diagnóstico; pode requerer DoIP/Ethernet ou uma interface específica Tesla.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM TESLA UDS ===")
    }

    /**
     * Subaru READ-ONLY profile.
     *
     * Uses standard OBD-II data plus a conservative standard UDS VIN read.
     * No proprietary Subaru CAN/request map is included.
     */
    private fun runSubaruReadOnly() {
        append("=== SUBARU READ-ONLY ===")
        append("OBD-II standard + UDS 0x22 quando suportado")
        append("Sem mapa CAN proprietário Subaru não verificado.")

        val pidList = listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position"
        )

        var found = 0
        for ((pid, label) in pidList) {
            val raw = elm(pid, 3000)
            if (isPositiveObdResponse(raw, pid)) {
                found++
                append("✓ Subaru OBD-II $pid — $label: ${classifyResponse(raw)}")
                runOnUiThread {
                    liveDataLog.append("• Subaru — $label: ${classifyResponse(raw)}\n")
                }
            }
        }

        if (canActive) {
            elm("ATSP6", 2000)
            elm("ATCAF1", 1200)
            elm("ATCFC1", 1200)

            var udsFound = 0
            for (requestId in 0x7E0..0x7E7) {
                val req = String.format(Locale.US, "%03X", requestId)
                val responseId = String.format(Locale.US, "%03X", requestId + 8)
                elm("ATSH$req", 1000)
                elm("ATCRA$responseId", 1000)

                for (did in subaruDids) {
                    val raw = elm("22${did.did}", 3000)
                    val value = parseUdsDid(raw, did.did)
                    if (value.isNotBlank()) {
                        udsFound++
                        append("✓ ECU $req → ${did.label}: $value")
                        runOnUiThread {
                            liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                        }
                    }
                }
            }

            elm("ATCRA", 1000)
            elm("ATSP0", 1500)
            detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

            if (udsFound == 0) {
                append("· Nenhum DID UDS Subaru respondeu.")
            } else {
                append("✓ $udsFound leitura(s) UDS Subaru obtida(s).")
            }
        }

        if (found == 0) {
            append("· Nenhuma resposta OBD-II Subaru obtida para os PIDs selecionados.")
        } else {
            append("✓ $found leitura(s) OBD-II Subaru obtida(s).")
        }
        append("=== FIM SUBARU READ-ONLY ===")
    }

    /**
     * Lexus READ-ONLY profile.
     *
     * Lexus has its own manufacturer diagnostic tooling, so HOMEBD keeps this
     * profile separate from Toyota. Only the standard UDS VIN read is attempted
     * here; no proprietary Lexus request/DID map is assumed.
     */
    private fun runLexusReadOnly() {
        append("=== LEXUS READ-ONLY ===")
        append("OBD-II standard + CAN/ISO-TP quando suportado")
        append("Sem mapa CAN proprietário Lexus não verificado.")

        if (canActive) {
            elm("ATSP6", 2000)
            elm("ATCAF1", 1200)
            elm("ATCFC1", 1200)

            var udsFound = 0
            for (requestId in 0x7E0..0x7E7) {
                val req = String.format(Locale.US, "%03X", requestId)
                val responseId = String.format(Locale.US, "%03X", requestId + 8)
                elm("ATSH$req", 1000)
                elm("ATCRA$responseId", 1000)

                for (did in lexusDids) {
                    val raw = elm("22${did.did}", 3000)
                    val value = parseUdsDid(raw, did.did)
                    if (value.isNotBlank()) {
                        udsFound++
                        append("✓ ECU $req → ${did.label}: $value")
                        runOnUiThread {
                            liveDataLog.append("• Lexus ECU $req — ${did.label}: $value\n")
                        }
                    }
                }
            }

            elm("ATCRA", 1000)
            elm("ATSP0", 1500)
            detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

            if (udsFound == 0) {
                append("· Nenhum DID UDS Lexus respondeu.")
            } else {
                append("✓ $udsFound leitura(s) UDS Lexus obtida(s).")
            }
        } else {
            append("· CAN não disponível no adaptador/protocolo atual.")
        }

        append("=== FIM LEXUS READ-ONLY ===")
    }

    /**
     * Isuzu READ-ONLY profile.
     *
     * Isuzu's official technical portals provide diagnostic tooling and OBD
     * information, while detailed manufacturer-specific diagnostic data are
     * provided through the official Isuzu tools. HOMEBD therefore uses only
     * standard OBD-II data plus a conservative standard UDS VIN read.
     */
    private fun runIsuzuReadOnly() {
        append("=== ISUZU READ-ONLY ===")
        append("OBD-II standard + UDS 0x22 quando suportado")
        append("Sem mapa CAN proprietário Isuzu não verificado.")

        val pidList = listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position",
            "012F" to "Fuel level"
        )

        var found = 0
        for ((pid, label) in pidList) {
            val raw = elm(pid, 3000)
            if (isPositiveObdResponse(raw, pid)) {
                found++
                val value = classifyResponse(raw)
                append("✓ Isuzu OBD-II $pid — $label: $value")
                runOnUiThread {
                    liveDataLog.append("• Isuzu — $label: $value\n")
                }
            }
        }

        if (canActive) {
            elm("ATSP6", 2000)
            elm("ATCAF1", 1200)
            elm("ATCFC1", 1200)

            var udsFound = 0
            for (requestId in 0x7E0..0x7E7) {
                val req = String.format(Locale.US, "%03X", requestId)
                val responseId = String.format(Locale.US, "%03X", requestId + 8)
                elm("ATSH$req", 1000)
                elm("ATCRA$responseId", 1000)

                for (did in isuzuDids) {
                    val raw = elm("22${did.did}", 3000)
                    val value = parseUdsDid(raw, did.did)
                    if (value.isNotBlank()) {
                        udsFound++
                        append("✓ ECU $req → ${did.label}: $value")
                        runOnUiThread {
                            liveDataLog.append("• Isuzu ECU $req — ${did.label}: $value\n")
                        }
                    }
                }
            }

            elm("ATCRA", 1000)
            elm("ATSP0", 1500)
            detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

            if (udsFound == 0) {
                append("· Nenhum DID UDS Isuzu respondeu.")
            } else {
                append("✓ $udsFound leitura(s) UDS Isuzu obtida(s).")
            }
        } else {
            append("· CAN não disponível no adaptador/protocolo atual.")
        }

        if (found == 0) {
            append("· Nenhuma resposta OBD-II Isuzu obtida para os PIDs selecionados.")
        } else {
            append("✓ $found leitura(s) OBD-II Isuzu obtida(s).")
        }
        append("=== FIM ISUZU READ-ONLY ===")
    }

    /**
     * Mazda READ-ONLY profile.
     *
     * Mazda public documentation confirms that operating data are normally
     * read through the mandatory OBD connection for fault diagnosis. No
     * proprietary Mazda UDS DID is assumed without a public, verifiable source.
     */
    /**
     * Mitsubishi READ-ONLY profile.
     *
     * Mitsubishi's official technical-information portal documents OBD-II
     * coverage and CAN-bus diagnosis through MUT-III. Detailed proprietary
     * request maps are subscriber-restricted, so HOMEBD does not copy them.
     * Only standard OBD-II data and a conservative UDS VIN read are attempted.
     */
    private fun runMitsubishiReadOnly() {
        append("=== MITSUBISHI READ-ONLY ===")
        append("OBD-II standard + CAN/ISO-TP quando suportado")
        append("Sem mapa CAN proprietário Mitsubishi não verificado.")

        val pidList = listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position",
            "012F" to "Fuel level"
        )

        var found = 0
        for ((pid, label) in pidList) {
            val raw = elm(pid, 3000)
            if (isPositiveObdResponse(raw, pid)) {
                found++
                append("✓ Mitsubishi OBD-II $pid — $label: ${classifyResponse(raw)}")
                runOnUiThread {
                    liveDataLog.append("• Mitsubishi — $label: ${classifyResponse(raw)}\n")
                }
            }
        }

        if (canActive) {
            elm("ATSP6", 2000)
            elm("ATCAF1", 1200)
            elm("ATCFC1", 1200)

            var udsFound = 0
            for (requestId in 0x7E0..0x7E7) {
                val req = String.format(Locale.US, "%03X", requestId)
                val responseId = String.format(Locale.US, "%03X", requestId + 8)
                elm("ATSH$req", 1000)
                elm("ATCRA$responseId", 1000)

                for (did in mitsubishiDids) {
                    val raw = elm("22${did.did}", 3000)
                    val value = parseUdsDid(raw, did.did)
                    if (value.isNotBlank()) {
                        udsFound++
                        append("✓ ECU $req → ${did.label}: $value")
                        runOnUiThread {
                            liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                        }
                    }
                }
            }

            elm("ATCRA", 1000)
            elm("ATSP0", 1500)
            detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

            if (udsFound == 0) {
                append("· Nenhum DID UDS Mitsubishi respondeu.")
            } else {
                append("✓ $udsFound leitura(s) UDS Mitsubishi obtida(s).")
            }
        }

        if (found == 0) {
            append("· Nenhuma resposta OBD-II Mitsubishi obtida para os PIDs selecionados.")
        } else {
            append("✓ $found leitura(s) OBD-II Mitsubishi obtida(s).")
        }
        append("=== FIM MITSUBISHI READ-ONLY ===")
    }

    private fun runMazdaReadOnly() {
        append("=== MAZDA READ-ONLY ===")
        append("OBD-II standard: leitura de dados e diagnóstico")
        append("Sem DIDs proprietários Mazda não verificados.")

        // The generic OBD-II scan performed by HOMEBD remains the supported
        // manufacturer profile. Mode 09 VIN is also queried by the common CAN
        // read-only layer. No write/coding/programming service is sent.
        val pidList = listOf(
            "0105" to "Coolant temperature",
            "010C" to "RPM",
            "010D" to "Vehicle speed",
            "0111" to "Throttle position",
            "012F" to "Fuel level"
        )

        var found = 0
        for ((pid, label) in pidList) {
            val raw = elm(pid, 3000)
            if (isPositiveObdResponse(raw, pid)) {
                found++
                append("✓ Mazda OBD-II $pid — $label: ${classifyResponse(raw)}")
                runOnUiThread {
                    liveDataLog.append("• Mazda — $label: ${classifyResponse(raw)}\n")
                }
            }
        }

        if (found == 0) {
            append("· Nenhuma resposta OBD-II Mazda obtida para os PIDs selecionados.")
        } else {
            append("✓ $found leitura(s) OBD-II Mazda obtida(s).")
        }
        append("=== FIM MAZDA READ-ONLY ===")
    }

    private fun runFordUdsReadOnly() {
        append("=== FORD UDS READ-ONLY ===")
        append("Serviço permitido: 0x22 ReadDataByIdentifier")
        append("A procurar ECUs nos IDs 7E0–7E7…")

        elm("ATSP6", 2000)
        elm("ATCAF1", 1200)
        elm("ATCFC1", 1200)

        var found = 0
        for (requestId in 0x7E0..0x7E7) {
            val req = String.format(Locale.US, "%03X", requestId)
            val responseId = String.format(Locale.US, "%03X", requestId + 8)

            elm("ATSH$req", 1000)
            elm("ATCRA$responseId", 1000)

            for (did in fordDids) {
                val raw = elm("22${did.did}", 3000)
                val value = parseUdsDid(raw, did.did)
                if (value.isNotBlank()) {
                    found++
                    append("✓ ECU $req → ${did.label}: $value")
                    runOnUiThread {
                        liveDataLog.append("• ECU $req — ${did.label}: $value\n")
                    }
                }
            }
        }

        elm("ATCRA", 1000)
        elm("ATSP0", 1500)
        detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

        if (found == 0) {
            append("· Nenhum DID UDS Ford respondeu.")
            append("· ECU não acessível, DID não suportado ou gateway/rede a bloquear a leitura.")
        } else {
            append("✓ $found leitura(s) UDS obtida(s).")
        }
        append("=== FIM FORD UDS ===")
    }

    private fun isPositiveObdResponse(raw: String, pid: String): Boolean {
        val hex = raw.uppercase().replace(Regex("[^0-9A-F]"), "")
        val marker = "41${pid.takeLast(2).uppercase()}"
        return hex.contains(marker)
    }

    private fun parseUdsDid(raw: String, did: String): String {
        val hex = raw.uppercase().replace(Regex("[^0-9A-F]"), "")
        if (hex.length < 6) return ""

        val didUpper = did.uppercase()
        val marker = "62$didUpper"
        val start = hex.indexOf(marker)
        if (start < 0) return ""

        val dataStart = start + marker.length
        if (dataStart >= hex.length) return ""

        val dataHex = hex.substring(dataStart)
        val bytes = ArrayList<Int>()
        var i = 0
        while (i + 1 < dataHex.length) {
            bytes.add(dataHex.substring(i, i + 2).toIntOrNull(16) ?: break)
            i += 2
        }

        // Human-readable ECU identification is normally ASCII. Preserve
        // printable characters and ignore padding/non-printable bytes.
        val text = bytes
            .filter { it in 0x20..0x7E }
            .map { it.toChar() }
            .joinToString("")
            .trim()

        return if (text.isNotBlank()) text else dataHex.take(64)
    }

    private fun reportCanValue(label: String, raw: String, value: String) {
        if (value.isNotBlank()) {
            append("CAN $label: $value")
        } else {
            append("CAN $label: não disponível (${clean(raw)})")
        }
    }

    private fun extractObdAscii(raw: String, service: Int, pid: Int): String {
        // Convert hex byte pairs from ELM output into bytes. This works with
        // single- and multi-frame ISO-TP payloads after ELM reassembly.
        val hex = raw.uppercase()
            .replace(Regex("[^0-9A-F]"), "")
        if (hex.length < 4) return ""

        val bytes = ArrayList<Int>()
        var i = 0
        while (i + 1 < hex.length) {
            bytes.add(hex.substring(i, i + 2).toIntOrNull(16) ?: -1)
            i += 2
        }

        val start = bytes.indexOfFirst { it == service }
        if (start < 0) return ""

        // Find the PID immediately after the positive response service.
        var pos = start + 1
        while (pos < bytes.size && bytes[pos] < 0) pos++
        if (pos >= bytes.size || bytes[pos] != pid) return ""

        val sb = StringBuilder()
        for (j in pos + 1 until bytes.size) {
            val b = bytes[j]
            if (b in 0x20..0x7E) sb.append(b.toChar())
        }
        return sb.toString().trim()
    }

    private fun classifyResponse(raw: String): String {
        val readable = raw.replace("\r", " ").replace("\n", " ")
            .replace(Regex("\\s+"), " ").trim()
        val compact = readable.uppercase().replace(Regex("[^0-9A-F]"), "")

        return when {
            readable.uppercase().contains("NO DATA") ->
                "· NO DATA — sem resposta desse PID"
            readable.uppercase().contains("ERROR") ->
                "· ERROR — ELM327 recusou o comando"
            readable.uppercase().contains("UNABLE TO CONNECT") ->
                "· SEM LIGAÇÃO ECU"
            compact.contains("7F0122") || readable.uppercase().contains("7F 01 22") ->
                "✕ 7F 01 22 — Negative Response"
            compact.contains("4100") || Regex("\b41[0-9A-F]{2}\b").containsMatchIn(compact) ->
                "✓ Resposta OBD-II: $readable"
            readable.isBlank() ->
                "· SEM RESPOSTA"
            else ->
                "· Resposta: $readable"
        }
    }

    private fun clean(value: String): String =
        value.replace("\n", " ").replace(Regex("\\s+"), " ").trim()

    private fun append(value: String) {
        runOnUiThread {
            log.append(if (log.text.isEmpty()) value else "\n$value")
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) refreshBluetoothList()
    }

    override fun onDestroy() {
        try { socket?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
