# HOMEBD — CHANGELOG

## Beta 1.0.0.0

Initial public beta baseline.

### Application
- HOMEBD universal OBD-II / CAN diagnostics application.
- Portrait dashboard with centered, full-width cards.
- LIVE DATA with its own vertical scroll area.
- DIAGNOSTICS with an independent vertical scroll area.
- Bluetooth OBD-II device selection.
- Automatic vehicle profile.
- OBD-II PID scanning.
- HV / UDS scan area.
- Home Assistant connection and configuration.

### Home Assistant
- Native HOMEBD custom integration.
- WebSocket communication.
- HOMEBD entities use the `sensor.homebd_*` namespace.
- REST transport is not part of the project architecture.

### Safety
- READ-ONLY diagnostic operation.
- No coding, programming, reset or parameter-writing functions.

### Project
- Developer: **lufime**
- Copyright © 2026 lufime.
- Beta version: **1.0.0.0**
