from __future__ import annotations

from homeassistant import config_entries
import voluptuous as vol

from .const import DOMAIN


class HomeBdConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Config flow for the single HOMEBD hub."""

    VERSION = 1

    async def async_step_user(self, user_input=None):
        """Create one HOMEBD hub."""
        await self.async_set_unique_id("homebd")
        self._abort_if_unique_id_configured()

        if user_input is not None:
            return self.async_create_entry(title="HOMEBD", data={})

        return self.async_show_form(
            step_id="user",
            data_schema=vol.Schema({vol.Required("name", default="HOMEBD"): str}),
        )
