from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from homeassistant.components.sensor import SensorEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.entity import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN


@dataclass
class _State:
    entity_id: str
    state: str
    attributes: dict[str, Any]


class HomeBdManager:
    """Owns the dynamic HOMEBD sensor entities for one config entry."""

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry):
        self.hass = hass
        self.entry = entry
        self.entities: dict[str, HomeBdSensor] = {}
        self._add_entities: AddEntitiesCallback | None = None
        self._pending: dict[str, _State] = {}
        self._ready = False

    @callback
    def set_add_entities(self, add_entities: AddEntitiesCallback) -> None:
        self._add_entities = add_entities
        self._ready = True

    def mark_ready(self) -> None:
        """Mark the hub ready without requiring an initial sensor."""
        self._ready = True

    async def async_update(
        self, entity_id: str, state: str, attributes: dict[str, Any]
    ) -> None:
        """Create or update one HOMEBD sensor."""
        if not entity_id.startswith("sensor.homebd_"):
            return

        entity = self.entities.get(entity_id)
        if entity is None:
            if self._add_entities is None:
                # Keep the first values until the sensor platform callback is
                # available. This prevents the first WebSocket packet from
                # being silently lost during Home Assistant startup.
                self._pending[entity_id] = _State(entity_id, state, dict(attributes))
                return

            entity = HomeBdSensor(self, entity_id)
            self.entities[entity_id] = entity
            self._add_entities([entity], update_before_add=False)

        entity.set_state(state, attributes)
        entity.async_write_ha_state()

    @callback
    def flush_pending(self) -> None:
        """Create any sensors received before the platform was ready."""
        if self._add_entities is None or not self._pending:
            return

        created = []
        for entity_id, pending in list(self._pending.items()):
            if entity_id in self.entities:
                continue
            entity = HomeBdSensor(self, entity_id)
            self.entities[entity_id] = entity
            entity.set_state(pending.state, pending.attributes)
            created.append(entity)
            self._pending.pop(entity_id, None)

        if created:
            self._add_entities(created, update_before_add=False)


async def async_setup_entry(
    hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback
) -> None:
    """Set up the HOMEBD sensor platform."""
    manager: HomeBdManager = hass.data[DOMAIN][entry.entry_id]
    manager.set_add_entities(async_add_entities)
    manager.flush_pending()


class HomeBdSensor(SensorEntity):
    """One dynamic HOMEBD sensor."""

    _attr_should_poll = False
    _attr_has_entity_name = False

    def __init__(self, manager: HomeBdManager, entity_id: str):
        super().__init__()
        self.manager = manager
        self.entity_id = entity_id
        self._attr_unique_id = entity_id
        self._attr_native_value = None
        self._attr_extra_state_attributes = {}
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, "homebd")},
            name="HOMEBD",
            manufacturer="lufime",
            model="Universal OBD-II / CAN",
        )

    @property
    def name(self) -> str:
        return self.entity_id.replace("sensor.homebd_", "HOMEBD ").replace("_", " ").title()

    def set_state(self, state: str, attributes: dict[str, Any]) -> None:
        try:
            self._attr_native_value = float(state)
        except (ValueError, TypeError):
            self._attr_native_value = state

        self._attr_extra_state_attributes = dict(attributes)
        unit = attributes.get("unit_of_measurement")
        if unit:
            self._attr_native_unit_of_measurement = unit
        device_class = attributes.get("device_class")
        if device_class:
            self._attr_device_class = device_class
        state_class = attributes.get("state_class")
        if state_class:
            self._attr_state_class = state_class
