# HOMEBD — COPYRIGHT AND LICENSE

Copyright © 2026 lufime. All rights reserved.

HOMEBD is an independent project developed by **lufime**.

The HOMEBD source code, application, documentation, original graphics,
icons and other original project materials are protected by applicable
copyright laws.

No permission is granted to copy, modify, distribute, publish,
sublicense, sell or create derivative works from the original HOMEBD
materials without prior written authorization from the copyright holder.

This notice does not replace or override the licenses of third-party
components. Third-party components remain subject to their respective
licenses and terms.

## Third-party components

The project documentation identifies third-party technologies and
components used by HOMEBD. Their respective rights remain with their
respective copyright holders.

## Project status

HOMEBD Beta 1.0.0.0

Developer: **lufime**
