# HOMEBD

## Universal OBD-II / CAN Diagnostics

**HOMEBD Beta 1.0.0.0** is an independent diagnostic and monitoring application developed by **lufime**.

### Features

- Bluetooth OBD-II
- OBD-II / CAN diagnostics
- Live vehicle data
- HV / UDS scan support
- Home Assistant native integration
- Persistent WebSocket communication
- `sensor.homebd_*` entities
- READ-ONLY operation

### Home Assistant

HOMEBD communicates with its custom Home Assistant integration through WebSocket. REST and MQTT are not used by the current project architecture.

### Copyright

**Copyright © 2026 lufime. All rights reserved.**

The original HOMEBD code, documentation, graphics, icons and project materials are protected by copyright. Third-party components remain subject to their respective licenses.

See:

- `LICENSE.md` — copyright and usage terms
- `LICENSES.md` — license audit
- `THIRD_PARTY_NOTICES.md` — third-party notices
- `CHANGELOG.md` — project history

### Developer

**lufime**

### Version

**Beta 1.0.0.0**
