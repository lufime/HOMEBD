# HOMEBD — Integração Home Assistant

**Versão do projeto: Beta 1.0.0.0**


A HOMEBD inclui uma integração customizada do Home Assistant no mesmo repositório:

`home_assistant/custom_components/homebd/`

## Arquitetura

```text
OBD/CAN
  ↓
HOMEBD Android
  ↓ WebSocket persistente
Home Assistant
  ↓
Integração HOMEBD
  ↓
sensor.homebd_*
```

O WebSocket nativo do Home Assistant é o único transporte de telemetria da HOMEBD. A aplicação autentica com um Long-Lived Access Token e envia `homebd/ping` para confirmar que a integração está configurada. Depois envia cada atualização através do comando `homebd/update`.

## Instalação

Copiar:

`home_assistant/custom_components/homebd/`

para:

`/config/custom_components/homebd/`

Reiniciar o Home Assistant e abrir:

**Definições → Dispositivos e serviços → Adicionar integração → HOMEBD**

A integração usa Config Flow e cria um único hub/dispositivo HOMEBD.

## Configuração na aplicação

Na HOMEBD Android, em **Home Assistant**, configurar:

- Endereço do Home Assistant (`http://` ou `https://`)
- Long-Lived Access Token

A app abre `/api/websocket`, autentica e verifica `homebd/ping`.

## Entidades

A integração aceita exclusivamente entidades cujo ID começa por:

`sensor.homebd_`

Os sensores são criados dinamicamente quando a aplicação envia o primeiro valor correspondente. Todos ficam associados ao dispositivo HOMEBD.

## Atualização em tempo real

A HOMEBD envia as leituras diretamente pelo WebSocket persistente. A integração usa entidades push (`should_poll = false`) e escreve o estado assim que recebe cada atualização. Não existe polling individual nem segundo transporte de telemetria.

## Segurança

- Comunicação autenticada pelo Long-Lived Access Token do Home Assistant.
- A HOMEBD envia apenas dados de diagnóstico em modo READ-ONLY.
- A integração não envia comandos para ECUs.
- Apenas `sensor.homebd_*` é aceite pelo comando WebSocket.

## Branding

A integração inclui imagens locais em `custom_components/homebd/brand/` para apresentar o ícone HOMEBD em versões do Home Assistant que suportem branding local de custom integrations.
