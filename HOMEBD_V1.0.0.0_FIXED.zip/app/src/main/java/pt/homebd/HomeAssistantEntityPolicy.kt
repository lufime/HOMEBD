package pt.homebd

object HomeAssistantEntityPolicy {
    const val PREFIX = "sensor.homebd_"

    fun isHomeBdEntity(entityId: String?): Boolean =
        entityId?.trim()?.lowercase()?.startsWith(PREFIX) == true
}
