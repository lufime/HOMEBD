package pt.homebd

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.*
import java.io.InputStream
import java.io.IOException
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var scanButton: TextView
    private lateinit var devicesSpinner: Spinner

    private val pids = linkedMapOf(
        "0100" to "Supported PIDs 01-20",
        "0104" to "Engine load",
        "0105" to "Coolant temperature",
        "010B" to "MAP pressure",
        "010C" to "RPM",
        "010D" to "Vehicle speed",
        "010F" to "Intake air temperature",
        "0110" to "MAF",
        "0111" to "Throttle position",
        "012F" to "Fuel level",
        "0142" to "Control module voltage",
        "0146" to "Ambient temperature",
        "015E" to "Engine fuel rate"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(23, 23, 23)
        window.navigationBarColor = Color.rgb(23, 23, 23)

        // Ecrã normal: o conteúdo nunca fica por baixo das barras do sistema.
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(true)
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = 0
        }

        val background = Color.rgb(28, 28, 28)
        val panel = Color.rgb(55, 55, 55)
        val primary = Color.rgb(235, 235, 235)
        val secondary = Color.rgb(190, 190, 190)
        val blue = Color.rgb(20, 145, 245)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(background)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            clipChildren = true
            clipToPadding = true
        }

        val title = TextView(this).apply {
            text = "HOMEBD  •  DIAGNÓSTICO OBD-II"
            textSize = 18f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            maxLines = 1
            includeFontPadding = false
        }

        status = TextView(this).apply {
            text = "Estado: desligado"
            textSize = 14f
            setTextColor(secondary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        val deviceLabel = TextView(this).apply {
            text = "DISPOSITIVO OBD-II"
            textSize = 14f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        devicesSpinner = Spinner(this).apply {
            this.background = GradientDrawable().apply {
                setColor(panel)
                cornerRadius = 2f
            }
            minimumHeight = dp(48)
        }

        val connect = actionButton("LIGAR OBDII", blue, primary)
        scanButton = actionButton("SCAN PIDs", Color.rgb(70, 70, 70), primary).apply {
            isEnabled = false
            alpha = 0.55f
        }

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        buttons.addView(connect, LinearLayout.LayoutParams(0, dp(50), 1f).apply {
            setMargins(dp(0), dp(4), dp(4), dp(4))
        })
        buttons.addView(scanButton, LinearLayout.LayoutParams(0, dp(50), 1f).apply {
            setMargins(dp(4), dp(4), dp(0), dp(4))
        })

        log = TextView(this).apply {
            textSize = 14f
            setTextColor(primary)
            setBackgroundColor(panel)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            includeFontPadding = true
            gravity = Gravity.TOP or Gravity.START
            setLineSpacing(0f, 1.0f)
        }

        val diagnosticLabel = TextView(this).apply {
            text = "DIAGNÓSTICO"
            textSize = 14f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        root.addView(title, LinearLayout.LayoutParams(-1, dp(44)))
        root.addView(status, LinearLayout.LayoutParams(-1, dp(36)))
        root.addView(deviceLabel, LinearLayout.LayoutParams(-1, dp(34)))
        root.addView(devicesSpinner, LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(buttons, LinearLayout.LayoutParams(-1, dp(62)))
        root.addView(diagnosticLabel, LinearLayout.LayoutParams(-1, dp(36)))
        root.addView(log, LinearLayout.LayoutParams(-1, 0, 1f))

        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener { v, insets ->
                val bars = insets.getInsets(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                v.setPadding(
                    dp(10),
                    bars.top + dp(4),
                    dp(10),
                    bars.bottom + dp(4)
                )
                insets
            }
        }

        setContentView(root)
        root.requestApplyInsets()

        connect.setOnClickListener {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            val paired = try {
                adapter?.bondedDevices?.toList() ?: emptyList()
            } catch (_: SecurityException) {
                emptyList()
            }

            val position = devicesSpinner.selectedItemPosition
            val device = paired.getOrNull(position)

            if (device != null) {
                connect(device)
            } else {
                append("⚠ Nenhum dispositivo Bluetooth selecionável.")
                append("Emparelhe o seu ELM327 nas definições Bluetooth do Android.")
            }
        }

        scanButton.setOnClickListener { runScanner() }

        append("HOMEBD pronto.")
        append("Diagnóstico OBD-II universal para veículos.")
        append("Selecione o seu ELM327 na lista e toque em LIGAR OBDII.")

        requestBtPermissions()
        refreshBluetoothList()
    }

    private fun actionButton(label: String, color: Int, textColor: Int): TextView =
        TextView(this).apply {
            text = label
            textSize = 14f
            setTextColor(textColor)
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            this.background = GradientDrawable().apply {
                setColor(color)
                cornerRadius = 8f
            }
        }

    private fun refreshBluetoothList() {
        val adapter = BluetoothAdapter.getDefaultAdapter()

        if (adapter == null) {
            setDevices(listOf("Bluetooth não disponível neste dispositivo"))
            return
        }

        try {
            if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
            ) {
                setDevices(listOf("Permitir Bluetooth para mostrar dispositivos"))
                return
            }

            if (!adapter.isEnabled) {
                setDevices(listOf("Bluetooth desligado — ative o Bluetooth"))
                return
            }

            val paired = adapter.bondedDevices.toList()
            val names = if (paired.isEmpty()) {
                listOf("Nenhum dispositivo emparelhado")
            } else {
                paired.map { device ->
                    val name = try { device.name ?: "Sem nome" } catch (_: SecurityException) { "Sem nome" }
                    "$name  (${device.address})"
                }
            }

            setDevices(names)
            append("✓ Bluetooth: ${paired.size} dispositivo(s) emparelhado(s).")
        } catch (_: SecurityException) {
            setDevices(listOf("Permissão Bluetooth necessária"))
        }
    }

    private fun setDevices(names: List<String>) {
        devicesSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            names
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                ),
                10
            )
        }
    }

    private fun connect(device: BluetoothDevice) {
        thread {
            try {
                runOnUiThread {
                    status.text = "Estado: a ligar…"
                }

                socket?.close()
                socket = device.createRfcommSocketToServiceRecord(spp)
                socket!!.connect()

                input = socket!!.inputStream
                output = socket!!.outputStream

                elm("ATZ", 5000)
                Thread.sleep(1200)
                elm("ATE0", 2500)
                elm("ATL0", 2500)
                elm("ATS0", 2500)
                elm("ATSP0", 2500)

                val protocol = elm("ATDP", 2500)

                if (protocol.isBlank()) {
                    throw IOException("ELM327 não respondeu ao ATDP")
                }

                runOnUiThread {
                    status.text = "Estado: LIGADO • ELM327 pronto"
                    scanButton.isEnabled = true
                    scanButton.alpha = 1f
                }

                append("✓ ELM327 inicializado.")
                append("Protocolo: ${clean(protocol)}")
                append("Pronto para SCAN PIDs.")
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Estado: erro de ligação"
                }
                append("✕ ERRO: ${e.message ?: "erro desconhecido"}")
            }
        }
    }

    private fun elm(cmd: String, timeout: Long = 2500): String {
        val out = output ?: return ""
        val ins = input ?: return ""

        try {
            out.write((cmd + "\r").toByteArray(Charsets.US_ASCII))
            out.flush()
        } catch (e: Exception) {
            throw IOException("Falha ao enviar $cmd: ${e.message}", e)
        }

        val start = System.currentTimeMillis()
        val buf = ByteArray(4096)
        val data = StringBuilder()

        while (System.currentTimeMillis() - start < timeout) {
            if (ins.available() > 0) {
                val n = ins.read(buf)
                if (n > 0) data.append(String(buf, 0, n, Charsets.US_ASCII))
                if (data.contains(">")) break
            } else {
                Thread.sleep(30)
            }
        }

        return data.toString()
            .replace("\r", "\n")
            .replace(">", "")
            .trim()
    }

    private fun runScanner() {
        thread {
            if (output == null) {
                append("⚠ OBDII não está ligado.")
                return@thread
            }

            runOnUiThread {
                status.text = "Estado: SCAN OBD-II em execução…"
                scanButton.isEnabled = false
                scanButton.alpha = 0.55f
            }

            append("=== SCAN OBD-II ===")
            append("A consultar PIDs genéricos...")
            append("")

            pids.forEach { (pid, label) ->
                val raw = elm(pid, 2500)
                append("$pid  $label")
                append("   ${classifyResponse(raw)}")
                append("")
            }

            append("=== FIM OBD-II ===")

            runOnUiThread {
                status.text = "Estado: LIGADO • SCAN concluído"
                scanButton.isEnabled = true
                scanButton.alpha = 1f
            }
        }
    }

    private fun classifyResponse(raw: String): String {
        val readable = raw.replace("\r", " ").replace("\n", " ")
            .replace(Regex("\\s+"), " ").trim()
        val compact = readable.uppercase().replace(Regex("[^0-9A-F]"), "")

        return when {
            readable.uppercase().contains("NO DATA") ->
                "· NO DATA — sem resposta desse PID"
            readable.uppercase().contains("ERROR") ->
                "· ERROR — ELM327 recusou o comando"
            readable.uppercase().contains("UNABLE TO CONNECT") ->
                "· SEM LIGAÇÃO ECU"
            compact.contains("7F0122") || readable.uppercase().contains("7F 01 22") ->
                "✕ 7F 01 22 — Negative Response"
            compact.contains("4100") || Regex("\b41[0-9A-F]{2}\b").containsMatchIn(compact) ->
                "✓ Resposta OBD-II: $readable"
            readable.isBlank() ->
                "· SEM RESPOSTA"
            else ->
                "· Resposta: $readable"
        }
    }

    private fun clean(value: String): String =
        value.replace("\n", " ").replace(Regex("\\s+"), " ").trim()

    private fun append(value: String) {
        runOnUiThread {
            log.append(if (log.text.isEmpty()) value else "\n$value")
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) refreshBluetoothList()
    }

    override fun onDestroy() {
        try { socket?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
