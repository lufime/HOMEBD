# HOMEBD

Universal OBD-II diagnostic Android application.

The ZIP contains the complete Android project and GitHub Actions workflow.
After extracting the ZIP into the repository root, `.github/workflows/build.yml` is automatically available to GitHub Actions.

Developer: lufime
