plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "pt.homebd"
    compileSdk = 35

    defaultConfig {
        applicationId = "pt.homebd"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.1"
    }
}

kotlin {
    jvmToolchain(17)
}
