package pt.homebd

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.util.Locale

/**
 * HOMEBD -> Home Assistant integration bridge.
 *
 * WebSocket-only transport. The Android app authenticates against the native
 * Home Assistant WebSocket API with a Long-Lived Access Token and then sends
 * HOMEBD sensor updates through the custom HOMEBD integration command.
 */
class HomeBdHaBridge(private val context: Context) {
    private val webSocket = HomeBdHaWebSocket()
    private val prefs = context.getSharedPreferences("homebd_home_assistant", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())

    @Volatile var connected: Boolean = false
        private set

    var baseUrl: String = prefs.getString("url", "")?.trim()?.trimEnd('/') ?: ""
        private set

    var token: String = prefs.getString("token", "")?.trim() ?: ""
        private set

    val entityFilter: String = "sensor.homebd_*"

    fun save(url: String, accessToken: String) {
        baseUrl = url.trim().trimEnd('/')
        token = accessToken.trim()
        prefs.edit()
            .putString("url", baseUrl)
            .putString("token", token)
            .apply()
    }

    fun connect(callback: (Boolean, String) -> Unit) {
        if (baseUrl.isBlank() || token.isBlank()) {
            callback(false, "Configure o endereço e o token do Home Assistant.")
            return
        }
        webSocket.connect(baseUrl, token) { ok, message ->
            connected = ok && webSocket.integrationReady
            main.post {
                callback(connected, message)
            }
        }
    }

    fun disconnect() {
        webSocket.disconnect()
        connected = false
    }

    fun publishPid(pid: String, label: String, value: String) {
        if (!connected || !webSocket.integrationReady) return
        val parsed = parseValue(value) ?: return
        val entityId = entityIdFor(pid, label)
        if (!matchesEntityFilter(entityId)) return

        val attrs = JSONObject()
            .put("friendly_name", "HOMEBD ${cleanLabel(label)}")
            .put("homebd_pid", pid.uppercase(Locale.ROOT))
            .put("source", "HOMEBD")
            .put("raw_value", value)
            .put("state_class", "measurement")

        parsed.unit?.let { attrs.put("unit_of_measurement", it) }
        parsed.deviceClass?.let { attrs.put("device_class", it) }

        webSocket.publish(entityId, parsed.state, attrs)
    }

    fun publishAggregate(values: List<Triple<String, String, String>>) {
        values.forEach { (pid, label, value) -> publishPid(pid, label, value) }
    }

    private fun matchesEntityFilter(entityId: String): Boolean {
        val id = entityId.lowercase(Locale.ROOT)
        return id.startsWith("sensor.homebd_")
    }

    private data class ParsedValue(
        val state: String,
        val unit: String?,
        val deviceClass: String?
    )

    private fun parseValue(raw: String): ParsedValue? {
        val text = raw.trim()
        if (text.isBlank() || text.contains("NO DATA", ignoreCase = true) || text == "—") return null

        val number = Regex("[-+]?\\d+(?:[.,]\\d+)?").find(text)?.value
            ?.replace(',', '.') ?: return null
        val state = number.toDoubleOrNull()?.let {
            if (it % 1.0 == 0.0) it.toLong().toString() else it.toString()
        } ?: return null

        val lower = text.lowercase(Locale.ROOT)
        val unit = when {
            "km/h" in lower -> "km/h"
            "rpm" in lower -> "rpm"
            "°c" in lower || " c" in lower -> "°C"
            "kpa" in lower -> "kPa"
            "v" in lower && "kv" !in lower -> "V"
            "a" in lower && (lower.contains(" a") || lower.endsWith("a")) -> "A"
            "%" in lower -> "%"
            "g/s" in lower -> "g/s"
            "l/100 km" in lower -> "L/100 km"
            "l/h" in lower -> "L/h"
            "ms" in lower -> "ms"
            else -> null
        }
        val deviceClass = when (unit) {
            "°C" -> "temperature"
            "km/h" -> "speed"
            "V" -> "voltage"
            "A" -> "current"
            "%" -> "percentage"
            "kPa" -> "pressure"
            else -> null
        }
        return ParsedValue(state, unit, deviceClass)
    }

    private fun entityIdFor(pid: String, label: String): String {
        val slug = cleanLabel(label)
            .lowercase(Locale.ROOT)
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
            .ifBlank { "pid_${pid.lowercase(Locale.ROOT)}" }
        return "sensor.homebd_${slug}_${pid.lowercase(Locale.ROOT)}"
    }

    private fun cleanLabel(label: String): String =
        label.trim().replace(Regex("\\s+"), " ")
}
