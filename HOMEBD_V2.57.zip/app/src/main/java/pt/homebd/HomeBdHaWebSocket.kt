package pt.homebd

import android.os.Handler
import android.os.Looper
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Persistent Home Assistant WebSocket transport for HOMEBD.
 *
 * Protocol: HA native /api/websocket + Long-Lived Access Token, followed by
 * the custom `homebd/update` command exposed by the HOMEBD HA integration.
 * The HOMEBD integration is required for telemetry.
 */
class HomeBdHaWebSocket {
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .writeTimeout(5, TimeUnit.SECONDS)
        .pingInterval(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val main = Handler(Looper.getMainLooper())
    private var socket: WebSocket? = null
    private var url = ""
    private var token = ""
    private var nextId = 1
    private var stateCallback: ((Boolean, String) -> Unit)? = null
    private var reconnectEnabled = false
    private var reconnectAttempt = 0
    private var pingId = -1
    @Volatile var integrationReady = false
        private set
    @Volatile var connected = false
        private set
    @Volatile private var authenticated = false

    fun connect(baseUrl: String, accessToken: String, onState: ((Boolean, String) -> Unit)? = null) {
        disconnect()
        stateCallback = onState
        reconnectEnabled = true
        reconnectAttempt = 0
        url = baseUrl.trimEnd('/') + "/api/websocket"
        token = accessToken.trim()
        if (token.isBlank()) {
            notifyState(false, "Token HOMEBD vazio", onState)
            return
        }
        val request = Request.Builder().url(url).build()
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                connected = true
                authenticated = false
                integrationReady = false
                reconnectAttempt = 0
                notifyState(true, "WebSocket Home Assistant ligado", stateCallback)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val msg = JSONObject(text)
                    when (msg.optString("type")) {
                        "auth_required" -> {
                            webSocket.send(JSONObject()
                                .put("type", "auth")
                                .put("access_token", token).toString())
                        }
                        "auth_ok" -> {
                            authenticated = true
                            integrationReady = false
                            pingId = nextId++
                            webSocket.send(JSONObject()
                                .put("id", pingId)
                                .put("type", "homebd/ping").toString())
                            notifyState(true, "Home Assistant autenticado; a verificar HOMEBD", stateCallback)
                        }
                        "result" -> {
                            if (msg.optInt("id", -1) == pingId) {
                                integrationReady = msg.optBoolean("success", false) && msg.optJSONObject("result")?.optBoolean("ok", false) == true
                                if (integrationReady) {
                                    notifyState(true, "Integração HOMEBD ligada", stateCallback)
                                } else {
                                    notifyState(false, "Integração HOMEBD não disponível", stateCallback)
                                }
                            }
                        }
                        "error" -> {
                            if (msg.optInt("id", -1) == pingId) {
                                integrationReady = false
                                notifyState(false, "Integração HOMEBD não disponível", stateCallback)
                            }
                        }
                        "auth_invalid" -> {
                            authenticated = false
                            connected = false
                            integrationReady = false
                            notifyState(false, "Token Home Assistant recusado", stateCallback)
                            reconnectEnabled = false
                            webSocket.close(1000, "auth invalid")
                        }
                    }
                } catch (_: Throwable) { }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                connected = false
                authenticated = false
                integrationReady = false
                notifyState(false, "WebSocket: ${t.message ?: "ligação perdida"}", stateCallback)
                scheduleReconnect()
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                connected = false
                authenticated = false
                integrationReady = false
                notifyState(false, "WebSocket desligado", stateCallback)
                if (reconnectEnabled) scheduleReconnect()
            }
        })
    }

    fun publish(entityId: String, state: String, attributes: JSONObject): Boolean {
        if (!connected || !authenticated || !integrationReady) return false
        val msg = JSONObject()
            .put("id", nextId++)
            .put("type", "homebd/update")
            .put("entity_id", entityId)
            .put("state", state)
            .put("attributes", attributes)
        return try { socket?.send(msg.toString()) == true } catch (_: Throwable) { false }
    }

    fun disconnect() {
        reconnectEnabled = false
        try { socket?.close(1000, "HOMEBD disconnect") } catch (_: Throwable) { }
        socket = null
        connected = false
        authenticated = false
        integrationReady = false
    }

    private fun scheduleReconnect() {
        if (!reconnectEnabled || token.isBlank() || url.isBlank()) return
        val delay = minOf(30_000L, 1_000L * (1L shl minOf(reconnectAttempt, 5)))
        reconnectAttempt++
        main.postDelayed({
            if (reconnectEnabled) connect(url.removeSuffix("/api/websocket"), token, stateCallback)
        }, delay)
    }

    private fun notifyState(ok: Boolean, message: String, callback: ((Boolean, String) -> Unit)?) {
        if (callback == null) return
        main.post { try { callback(ok, message) } catch (_: Throwable) {} }
    }
}
