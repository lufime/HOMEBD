# HOMEBD — THIRD PARTY NOTICES

HOMEBD inclui componentes de plataforma/ferramentas identificados na documentação. Os direitos e licenças desses componentes permanecem com os respetivos titulares.


## Kotlin 2.0.21
Linguagem de programação utilizada no projeto. Aplicam-se os termos de licença do Kotlin/JetBrains.

## Android SDK / Android APIs
APIs da plataforma Android utilizadas pela aplicação. Aplicam-se os respetivos termos e licenças da plataforma.

## Android Gradle Plugin 8.7.3
Ferramenta de compilação Android configurada no projeto. Aplicam-se os respetivos termos/licença.

## Gradle
Sistema de compilação utilizado pelo projeto. Aplicam-se os respetivos termos/licença.

## Protocolos automóveis
OBD-II, CAN, ISO-TP e UDS são utilizados como referências/protocolos técnicos.

## HOMEBD
Código original e materiais próprios: Copyright © 2026 lufime, salvo componentes de terceiros identificados acima.
