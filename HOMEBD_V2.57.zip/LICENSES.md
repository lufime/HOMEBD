# HOMEBD — AUDITORIA DE LICENÇAS E CRÉDITOS

## HOMEBD
- Projeto e código original: **lufime**
- Copyright © 2026 lufime, exceto componentes de terceiros sujeitos às respetivas licenças.

## Bibliotecas de terceiros incorporadas

## Tecnologias de desenvolvimento e plataforma

### Kotlin
- Versão configurada no projeto: 2.0.21.
- Linguagem utilizada no código da aplicação.
- Aplicam-se os termos de licença do projeto Kotlin/JetBrains.

### Android SDK / Android APIs
- Plataforma e APIs utilizadas pela aplicação.
- Aplicam-se as respetivas licenças e termos da plataforma Android.

### Android Gradle Plugin
- Plugin de compilação Android configurado no projeto.
- Aplicam-se os respetivos termos/licença do projeto Android/Google.

### Gradle
- Sistema de compilação utilizado pelo projeto.
- Aplicam-se os respetivos termos/licença do projeto Gradle.

## Protocolos e standards automóveis

HOMEBD implementa lógica própria para protocolos/interfaces de diagnóstico, incluindo OBD-II, CAN, ISO-TP e UDS quando aplicável.

Estas referências técnicas não representam bibliotecas de software de terceiros incorporadas na aplicação.

## Componentes que NÃO são utilizados

- **Bases CAN de terceiros:** não utilizadas.
- **Mapas CAN proprietários de fabricantes:** não incorporados.

## Integrações externas

### Home Assistant
- Integração customizada HOMEBD incluída no próprio repositório.

## Recursos gráficos

- `homebd_header.png`
- `homebd_icon.png`

A origem/autoria dos recursos gráficos deve permanecer documentada pelo proprietário do projeto. Não devem ser adicionados recursos de terceiros sem a respetiva licença/autorização.

## Nota
Esta documentação é uma auditoria técnica do conteúdo do projeto e não constitui aconselhamento jurídico. A lista deve ser atualizada sempre que uma nova dependência, recurso ou código de terceiros seja incorporado.
