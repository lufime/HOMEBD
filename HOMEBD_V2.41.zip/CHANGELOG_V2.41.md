# HOMEBD V2.41

- Corrigido erro de compilação em `HomeBdRestBridge.kt`: `postAsync` estava em falta.
- Publicação dos sensores OBD via Home Assistant REST agora usa um POST assíncrono seguro.
- Falhas de rede/REST durante a publicação são ignoradas e não podem encerrar a aplicação.
- Mantido REST/HTTPS, sem MQTT/Mosquitto.
- Mantida orientação vertical (portrait).
