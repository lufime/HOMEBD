# HOMEBD V2.47

- Adicionado campo **Filtro de entidades** na configuração Home Assistant REST.
- Filtro predefinido: `sensor.homebd_*`.
- Apenas entidades que correspondam ao filtro são publicadas pela HOMEBD.
- Mantida a comunicação REST/HTTPS sem MQTT/Mosquitto.
- Mantida a orientação vertical.
- Mantida a estabilização CAN e o fluxo OBD/HV READ-ONLY.
