# HOMEBD V2.48

- Corrigida a leitura incompleta do VIN.
- O VIN standard OBD-II 09 02 passa a ser tentado até 3 vezes.
- A app só aceita o VIN quando encontra uma sequência completa de 17 caracteres válidos.
- Adicionado fallback READ-ONLY para UDS DID F190 nas ECUs CAN já descobertas (7E0 e 7E5).
- Adicionado parser de resposta UDS 62 F1 90.
- Sem comandos de escrita, coding, reset ou programação.
- Mantidos CAN 6 / ISO 15765-4 11-bit / 500 kbit/s, REST/HTTPS, sensores `sensor.homebd_*` e orientação vertical.
