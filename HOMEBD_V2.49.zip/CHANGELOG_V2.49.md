# HOMEBD V2.49 — consolidação

Consolidação da versão universal solicitada.

- Mantida a correção de VIN completo da V2.48:
  - Mode 09 PID 02 com retries;
  - fallback UDS F190;
  - só aceita VIN completo de 17 caracteres.
- Mantido CAN 6 / ISO 15765-4 11-bit / 500 kbit/s e READ-ONLY.
- Mantido OBD-II standard e LIVE DATA.
- Mantido REST/HTTPS para Home Assistant, sem MQTT/Mosquitto.
- Mantido namespace `sensor.homebd_*`.
- Adicionada política universal de perfil por VIN, sem assumir DIDs proprietários.
- Adicionada fase explícita de GPS/Telemática READ-ONLY.
- Mantida fase HV/BMS READ-ONLY.
- Mantida orientação vertical.
- O filtro de entidades HOMEBD continua separado das restantes entidades do Home Assistant.

Nota: a identificação detalhada de modelo/ano e os dados GPS só são preenchidos
quando forem efetivamente fornecidos pelo VIN/ECU; não são inventados.
