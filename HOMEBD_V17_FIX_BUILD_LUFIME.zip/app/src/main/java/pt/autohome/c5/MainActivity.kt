package pt.autohome.c5

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.*
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var scanButton: Button
    private lateinit var devicesSpinner: Spinner
    private lateinit var scroll: ScrollView

    private val pids = linkedMapOf(
        "0100" to "Supported PIDs 01-20",
        "0104" to "Engine load",
        "0105" to "Coolant temperature",
        "010B" to "MAP pressure",
        "010C" to "RPM",
        "010D" to "Vehicle speed",
        "010F" to "Intake air temperature",
        "0110" to "MAF",
        "0111" to "Throttle position",
        "012F" to "Fuel level",
        "0142" to "Control module voltage",
        "0146" to "Ambient temperature",
        "015E" to "Engine fuel rate"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val background = Color.rgb(28, 28, 28)
        val panel = Color.rgb(55, 55, 55)
        val primaryText = Color.rgb(235, 235, 235)
        val secondary = Color.rgb(185, 185, 185)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(background)
            setPadding(18, 12, 18, 12)
        }

        val title = TextView(this).apply {
            this.text = "C5 AIRCROSS HYBRID  •  OBD DIAGNÓSTICO V2"
            textSize = 21f
            setTextColor(primaryText)
            setPadding(0, 0, 0, 4)
        }

        status = TextView(this).apply {
            this.text = "Estado: desligado"
            textSize = 16f
            setTextColor(secondary)
            setPadding(0, 0, 0, 12)
        }

        // Área superior fixa: dispositivo + botões.
        // A lista Bluetooth e os botões ficam fora do ScrollView para nunca
        // serem comprimidos ou sobrepostos pelo painel de diagnóstico.
        val deviceLabel = TextView(this).apply {
            text = "DISPOSITIVO OBD-II"
            textSize = 14f
            setTextColor(primaryText)
            setPadding(4, 2, 4, 4)
        }

        devicesSpinner = Spinner(this).apply {
            setBackgroundColor(panel)
        }

        scanButton = Button(this).apply {
            text = "SCAN PIDs"
            textSize = 17f
            isAllCaps = false
            minHeight = 68
            minimumHeight = 68
            setPadding(20, 8, 20, 8)
            isEnabled = false
        }

        val connect = Button(this).apply {
            text = "LIGAR OBDII"
            textSize = 17f
            isAllCaps = false
            minHeight = 68
            minimumHeight = 68
            setPadding(20, 8, 20, 8)
        }

        log = TextView(this).apply {
            textSize = 15f
            setTextColor(primaryText)
            setBackgroundColor(panel)
            setPadding(16, 14, 16, 14)
            isVerticalScrollBarEnabled = false
            setTextIsSelectable(true)
            setLineSpacing(0f, 1.05f)
        }

        val diagnosisScroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = true
            addView(
                log,
                ViewGroup.LayoutParams(-1, -2)
            )
        }
        scroll = diagnosisScroll

        root.addView(title)
        root.addView(status)
        root.addView(deviceLabel)
        root.addView(
            devicesSpinner,
            LinearLayout.LayoutParams(-1, 62).apply {
                setMargins(0, 2, 0, 8)
            }
        )
        root.addView(
            connect,
            LinearLayout.LayoutParams(-1, 68).apply {
                setMargins(0, 0, 0, 8)
            }
        )
        root.addView(
            scanButton,
            LinearLayout.LayoutParams(-1, 68).apply {
                setMargins(0, 0, 0, 12)
            }
        )
        root.addView(section("DIAGNÓSTICO", Color.rgb(235, 235, 235)))
        root.addView(
            diagnosisScroll,
            LinearLayout.LayoutParams(-1, 0, 1f).apply {
                setMargins(0, 4, 0, 0)
            }
        )

        setContentView(root)

        connect.setOnClickListener {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            val paired = try {
                adapter?.bondedDevices?.toList() ?: emptyList()
            } catch (_: SecurityException) {
                emptyList()
            }

            val position = devicesSpinner.selectedItemPosition
            val d = paired.getOrNull(position)
            if (d != null) {
                connect(d)
            } else {
                append("⚠ Nenhum dispositivo Bluetooth emparelhado selecionável.")
                append("Emparelhe o ELM327 nas definições Bluetooth do Android e volte a atualizar a lista.")
            }
        }

        scanButton.setOnClickListener { runScanner() }

        append("HOMEBD V2 pronto.")
        append("Interface vertical com scroll no diagnóstico.")
        append("Lista Bluetooth e botões fixos e clicáveis.")

        requestBtPermissions()

        refreshBluetoothList()


    }

    private fun section(label: String, color: Int): TextView =
        TextView(this).apply {
            text = label
            textSize = 14f
            setTextColor(color)
            setPadding(4, 6, 4, 6)
        }

    private fun space(px: Int): Space =
        Space(this).apply {
            minimumHeight = px
        }

    private fun refreshBluetoothList() {
        val adapter = BluetoothAdapter.getDefaultAdapter()

        if (adapter == null) {
            devicesSpinner.adapter = ArrayAdapter(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("Bluetooth não disponível neste dispositivo")
            )
            return
        }

        try {
            if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
            ) {
                devicesSpinner.adapter = ArrayAdapter(
                    this,
                    android.R.layout.simple_spinner_dropdown_item,
                    listOf("Permitir Bluetooth para mostrar dispositivos")
                )
                return
            }

            if (!adapter.isEnabled) {
                devicesSpinner.adapter = ArrayAdapter(
                    this,
                    android.R.layout.simple_spinner_dropdown_item,
                    listOf("Bluetooth desligado — ative o Bluetooth")
                )
                return
            }

            val paired = adapter.bondedDevices.toList()

            val names = if (paired.isEmpty()) {
                listOf("Nenhum dispositivo emparelhado")
            } else {
                paired.map { device ->
                    val name = try { device.name ?: "Sem nome" } catch (_: SecurityException) { "Sem nome" }
                    "$name  (${device.address})"
                }
            }

            devicesSpinner.adapter = ArrayAdapter(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                names
            )

            append("✓ Bluetooth: ${paired.size} dispositivo(s) emparelhado(s).")
            if (paired.isNotEmpty()) {
                append("Selecione o ELM327 na lista e toque em LIGAR OBDII.")
            }
        } catch (_: SecurityException) {
            devicesSpinner.adapter = ArrayAdapter(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("Permissão Bluetooth necessária")
            )
        }
    }

    private fun requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                ),
                10
            )
        }
    }

    private fun connect(device: BluetoothDevice) {
        thread {
            try {
                runOnUiThread {
                    status.text = "Estado: a ligar a ${device.name ?: device.address}…"
                }

                socket?.close()
                socket = device.createRfcommSocketToServiceRecord(spp)
                socket!!.connect()

                input = socket!!.inputStream
                output = socket!!.outputStream

                // ELM327 reset e configuração.
                elm("ATZ", 5000)
                Thread.sleep(1200)
                elm("ATE0", 2500)
                elm("ATL0", 2500)
                elm("ATS0", 2500)
                elm("ATSP0", 2500)

                val protocol = elm("ATDP", 2500)
                runOnUiThread {
                    status.text = "Estado: LIGADO • ELM327 pronto"
                    scanButton.isEnabled = true
                }

                append("✓ ELM327 inicializado.")
                append("Protocolo: ${clean(protocol)}")
                append("Pronto para SCAN PIDs.")

            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Estado: erro de ligação"
                }
                append("✕ ERRO: ${e.message ?: "erro desconhecido"}")
            }
        }
    }

    private fun elm(cmd: String, timeout: Long = 2500): String {
        val out = output ?: return ""
        val ins = input ?: return ""

        out.write((cmd + "\r").toByteArray(Charsets.US_ASCII))
        out.flush()

        val start = System.currentTimeMillis()
        val buf = ByteArray(4096)
        val data = StringBuilder()

        while (System.currentTimeMillis() - start < timeout) {
            if (ins.available() > 0) {
                val n = ins.read(buf)
                if (n > 0) {
                    data.append(String(buf, 0, n, Charsets.US_ASCII))
                }
                if (data.contains(">")) break
            } else {
                Thread.sleep(30)
            }
        }

        return data.toString()
            .replace("\r", "\n")
            .replace(">", "")
            .trim()
    }

    private fun runScanner() {
        thread {
            if (output == null) {
                append("⚠ OBDII não está ligado.")
                append("Toque em LIGAR OBDII e depois em SCAN PIDs.")
                return@thread
            }

            runOnUiThread {
                status.text = "Estado: SCAN OBD-II em execução…"
                scanButton.isEnabled = false
            }

            append("=== SCAN OBD-II ===")
            append("A consultar PIDs genéricos...")
            append("")

            pids.forEach { (pid, label) ->
                val raw = elm(pid, 2500)
                val result = classifyResponse(raw)

                append("$pid  $label")
                append("   $result")
                append("")
            }

            append("=== FIM OBD-II ===")
            append("")

            runOnUiThread {
                status.text = "Estado: LIGADO • SCAN concluído"
                scanButton.isEnabled = true
            }
            append("Se vários PIDs devolverem 7F 01 22:")
            append("• a ECU recusou o serviço 01")
            append("• não é um valor válido do sensor")
            append("• próxima fase: pesquisa PSA/Stellantis")
            append("  (ECU motor / híbrido / BMS / gateway)")
        }
    }

    private fun classifyResponse(raw: String): String {
        val compact = raw
            .uppercase()
            .replace(Regex("[^0-9A-F]"), "")

        return when {
            compact.contains("7F0122") ->
                "✕ 7F 01 22 — Negative Response: Conditions Not Correct"

            compact.contains("NO DATA") ->
                "· NO DATA — sem resposta"

            compact.contains("ERROR") ->
                "· ERROR — ELM327 recusou o comando"

            compact.isBlank() ->
                "· SEM RESPOSTA"

            compact.contains("4100") || compact.contains("41") ->
                "✓ Resposta OBD-II: ${clean(raw)}"

            else ->
                "· Resposta: ${clean(raw)}"
        }
    }

    private fun clean(value: String): String =
        value.replace("\n", " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun append(s: String) {
        runOnUiThread {
            log.append(if (log.text.isEmpty()) s else "\n$s")
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) {
            refreshBluetoothList()
        }
    }

    override fun onDestroy() {
        try {
            socket?.close()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }
}
