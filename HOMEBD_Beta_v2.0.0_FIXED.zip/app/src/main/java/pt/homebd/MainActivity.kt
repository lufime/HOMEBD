package pt.homebd

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.content.pm.PackageManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import java.net.NetworkInterface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.*
import android.widget.FrameLayout
import java.io.InputStream
import java.io.IOException
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.LinkedBlockingQueue
import java.util.Locale
import kotlin.concurrent.thread

/**
 * Scroll area used inside the dashboard. A swipe that starts on this panel
 * stays in the panel while there is content to scroll. When the panel reaches
 * its top or bottom, the gesture is handed back to the dashboard ScrollView.
 * This avoids the usual nested-ScrollView fight and makes finger scrolling
 * predictable.
 */
private class PanelScrollView(context: android.content.Context) : ScrollView(context) {
 override fun onTouchEvent(event: MotionEvent): Boolean {
 when (event.actionMasked) {
 MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
 // The finger is inside this panel: keep the gesture here.
 parent?.requestDisallowInterceptTouchEvent(true)
 }
 MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
 parent?.requestDisallowInterceptTouchEvent(false)
 }
 }
 return super.onTouchEvent(event)
 }
}


/*
 * HOMEBD connection safety:
 * - A dead Bluetooth socket must stop LIVE DATA immedaytely.
 * - Only one HA WebSocket reconnect loop may exist.
 * - Reconnect delays: 2s -> 5s -> 10s -> 30s -> 60s.
 */
private class HomebdReconnectBackoff {
 private val delays = longArrayOf(2_000L, 5_000L, 10_000L, 30_000L, 60_000L)
 private var index = 0

 @Synchronized
 fun nextDelayMs(): Long {
 val value = delays[index]
 if (index < delays.lastIndex) index++
 return value
 }

 @Synchronized
 fun reset() {
 index = 0
 }
}

private fun isBrokenPipeOrSocketErrorrrrr(t: Throwable): Boolean {
 val m = (t.message ?: "").lowercase()
 return m.contains("broken pipe") ||
 m.contains("software caused connection abort") ||
 m.contains("socket is closed") ||
 m.contains("socket closed") ||
 m.contains("connection reset") ||
 m.contains("connection aborted")
}

/** Strict OBD VIN validation. A 17-char arbitrary payload is not enough. */
private fun isValidVinCandidate(value: String?): Boolean {
 if (value == null) return false
 val vin = value.trim().uppercase()
 if (vin.length != 17) return false
 if (!vin.all { it in 'A'..'Z' || it in '0'..'9' }) return false
 // VINs do not use I, O or Q.
 if (vin.any { it == 'I' || it == 'O' || it == 'Q' }) return false
 return true
}



private fun ensureHomebdNotificationPermission(context: android.content.Context): Boolean {
 if (Build.VERSION.SDK_INT < 33) return true
 if (context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
 return true
 }
 return false
}

private fun openHomebdNotificationSettings(context: android.content.Context) {
 val intent = Intent().apply {
 action = "android.settings.APP_NOTIFICATION_SETTINGS"
 putExtra("android.provider.extra.APP_PACKAGE", context.packageName)
 data = Uri.parse("package:${context.packageName}")
 }
 context.startActivity(intent)
}


class MainActivity : Activity() {
 @Volatile
 private var homebdLiveDataSocketHealthy: Boolean = true

 @Volatile
 private var homebdLiveDataRunning: Boolean = false

 private val homebdHaReconnectBackoff = HomebdReconnectBackoff()
 @Volatile
 private var homebdHaReconnectScheduled: Boolean = false


 private fun ui(pt: String, en: String): String =
 if (HomeBdLanguage.detect(this) == HomeBdLanguage.Language.PT) pt else en

 private fun dp(value: Int): Int =
 (value * resources.displayMetrics.density).toInt()

 private fun isActivityUsable(): Boolean =
 !isFinishing && (Build.VERSION.SDK_INT < 17 || !isDestroyed)

 private fun safeUi(action: () -> Unit) {
 if (!isActivityUsable()) return
 runOnUiThread {
 if (isActivityUsable()) {
 try { action() } catch (_: Throwable) { /* UI callback must never crash HOMEBD */ }
 }
 }
 }

 private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
 private var socket: BluetoothSocket? = null
 private var input: InputStream? = null
 private var output: OutputStream? = null
 private var bleGatt: BluetoothGatt? = null
 private var bleWriteCharacteristic: BluetoothGattCharacteristic? = null
 private var bleNotifyCharacteristic: BluetoothGattCharacteristic? = null
 private val bleRx = LinkedBlockingQueue<Byte>(8192)
 @Volatile private var usingBle = false
 private var bleConnectedLatch: CountDownLatch? = null
 private var bleServicesLatch: CountDownLatch? = null
 private var bleNotificationLatch: CountDownLatch? = null
 private var bleWriteLatch: CountDownLatch? = null

 private val bleUartServices = listOf(
 UUID.fromString("6E400001-B5A3-F393-E0A9-E50E24DCCA9E"),
 UUID.fromString("0000FFE0-0000-1000-8000-00805F9B34FB"),
 UUID.fromString("49535343-FE7D-4AE5-8FA9-9FAFD205E455")
 )
 private val bleWriteUuids = setOf(
 UUID.fromString("6E400002-B5A3-F393-E0A9-E50E24DCCA9E"),
 UUID.fromString("0000FFE1-0000-1000-8000-00805F9B34FB"),
 UUID.fromString("49535343-8841-43F4-A8D4-ECBE34729BB3")
 )
 private val bleNotifyUuids = setOf(
 UUID.fromString("6E400003-B5A3-F393-E0A9-E50E24DCCA9E"),
 UUID.fromString("0000FFE1-0000-1000-8000-00805F9B34FB"),
 UUID.fromString("49535343-1E4D-4BD9-BA61-23C647249616")
 )

 private lateinit var status: TextView
 private lateinit var statusDot: TextView
 private lateinit var log: TextView
 private lateinit var logScroll: ScrollView
 private lateinit var scanButton: TextView
 private lateinit var connectButton: TextView
 private var adapterInfo = "Adapter: not identified"
 private lateinit var adapterInfoView: TextView
 private lateinit var devicesSpinner: Spinner
 private lateinit var manufacturerSpinner: Spinner
 private lateinit var aboutButton: TextView
 private lateinit var faqButton: TextView
 private lateinit var homeAssistantConnectButton: TextView
 private lateinit var hvUdsButton: TextView
 private lateinit var homeAssistantStatusView: TextView
 private lateinit var homeAssistantBridge: HomeBdHaBridge
 private lateinit var vehicleFuelConsumptionView: TextView
 private lateinit var vehicleElectricConsumptionView: TextView
 private lateinit var liveDataScroll: PanelScrollView
 private lateinit var liveDataLog: TextView
 private lateinit var liveDataContainer: LinearLayout
 private val liveGroupExpanded = mutableMapOf<String, Boolean>()
 private var hasScannedOnce = false
 private var detectedProtocol = ""
 private var canActive = false
 private var pendingExportText = ""
 private var pendingExportLabel = "HOMEBD"
 private var adapterKind = "Unknown"
 private var adapterIdentity = ""

 // Dynamic dashboard state used by the visual Live Data tabs.
 private val liveDashboardValues = linkedMapOf<String, String>()
 private val liveDashboardHistory = linkedMapOf<String, MutableList<Float>>()
 private lateinit var liveDashboardContainer: LinearLayout
 private lateinit var liveValuesScroll: PanelScrollView
 private lateinit var liveGraphsScroll: PanelScrollView

 private data class ManufacturerProfile(
 val name: String,
 val parameters: List<Pair<String, String>>
 )

 private data class UdsDid(
 val did: String,
 val label: String
 )

 // Public/documented ECU identification DIDs selected for the READ-ONLY
 // Stellantis profile. Unknown/unavailable DIDs are properly reported as such.
 private val stellantisDids = listOf(
 UdsDid("F18C", "ECU Serial Number"),
 UdsDid("F187", "ECU Part Number"),
 UdsDid("F192", "ECU Hardware Number"),
 UdsDid("F193", "ECU Hardware Version"),
 UdsDid("F194", "ECU Software Number"),
 UdsDid("F195", "ECU Software Version")
 )

 // Renault / Dacia: only standardized UDS identification DIDs are used.
 // No proprietary Renault/Dacia DID is guessed or imported from third-party
 // CAN databases. Unsupported DIDs are properly ignored.
 private val renaultDids = listOf(
 UdsDid("F187", "ECU Part Number"),
 UdsDid("F18A", "System Supplier"),
 UdsDid("F18C", "ECU Serial Number"),
 UdsDid("F190", "VIN"),
 UdsDid("F191", "ECU Hardware Number"),
 UdsDid("F194", "ECU Software Number"),
 UdsDid("F195", "ECU Software Version")
 )

 // Volkswagen / Audi / SEAT / Škoda (VAG): only standardized UDS ECU
 // identification DIDs are used. No proprietary VAG CAN database is copied.
 private val vagDids = listOf(
 UdsDid("F187", "ECU Part Number"),
 UdsDid("F18A", "System Supplier"),
 UdsDid("F18C", "ECU Serial Number"),
 UdsDid("F190", "VIN"),
 UdsDid("F191", "ECU Hardware Number"),
 UdsDid("F192", "Supplier ECU Hardware Number"),
 UdsDid("F193", "Supplier ECU Hardware Version"),
 UdsDid("F194", "ECU Software Number"),
 UdsDid("F195", "ECU Software Version")
 )

 // Ford: only standardized UDS identification DIDs are used.
 // No proprietary Ford CAN database is copied or inferred.
 private val fordDids = listOf(
 UdsDid("F187", "ECU Part Number"),
 UdsDid("F18A", "System Supplier"),
 UdsDid("F18C", "ECU Serial Number"),
 UdsDid("F190", "VIN"),
 UdsDid("F191", "ECU Hardware Number"),
 UdsDid("F194", "ECU Software Number"),
 UdsDid("F195", "ECU Software Version")
 )

 // Nissan / INFINITI: only standardized UDS identification DIDs are used.
 // Nissan TechInfo documents ECU identification and VIN fields, but proprietary
 // request maps are not reproduced here. No third-party CAN database is used.
 private val nissanDids = listOf(
 UdsDid("F18C", "ECU Serial Number"),
 UdsDid("F190", "VIN"),
 UdsDid("F187", "ECU Part Number"),
 UdsDid("F194", "ECU Software Number"),
 UdsDid("F195", "ECU Software Version")
 )

 // Tesla: keep the ELM327 profile conservative. Current HOMEBD transport
 // supports Bluetooth ELM327/CAN; Tesla vehicles may require DoIP/Ethernet
 // depending on model and diagnostic architecture. Only standard UDS VIN
 // identification is attempted over CAN here; no proprietary Tesla map is used.
 private val teslaDids = listOf(
 UdsDid("F190", "VIN")
 )

 // Mazda: public Mazda documentation confirms mandatory OBD readout for
 // operating data and fault daygnosis. No proprietary Mazda DID/CAN map is
 // guessed or copied here; manufacturer-specific data remains unavailable
 // unless a public/documented identifier is verified.
 private val mazdaDids = emptyList<UdsDid>()

 // Subaru: conservative public OBD-II read-only profile. No proprietary
 // Subaru DID/request map is guessed or imported from a third-party CAN database.
 private val subaruDids = listOf(
 UdsDid("F190", "VIN")
 )

 // Mitsubishi: the official Mitsubishi technical-information portl documents
 // OBD-II vehicles and CAN-bus daygnosis through MUT-III. Proprietary Mitsubishi
 // request/DID maps are not reproduced here because the detailed service data
 // are subscriber-restricted. HOMEBD therefore uses standard OBD-II plus a
 // conservative standard UDS VIN read when the ECU exposes it.
 private val mitsubishiDids = listOf(
 UdsDid("F190", "VIN")
 )

 // Lexus: separate profile from Toyota so future documented Lexus-specific
 // read-only diagnostics can be added without mixing manufacturer data.
 // Only the standard VIN DID is attempted here; no proprietary Lexus map
 // is guessed or imported from a third-party CAN database.
 private val lexusDids = listOf(
 UdsDid("F190", "VIN")
 )

 // Isuzu: official Isuzu RMI/TruckService documentation confirms OBD/diagnostic
 // support, while detailed manufacturer diagnostic data are provided through
 // Isuzu diagnostic tooling. HOMEBD therefore keeps this profile conservative:
 // standard OBD-II plus a standard UDS VIN read when the ECU exposes it.
 private val isuzuDids = listOf(
 UdsDid("F190", "VIN")
 )


 // OBD-II Mode 01 PID catalogue. These are protocol identifiers and
 // generic concepts, not copied manufacturer code or proprietary CAN maps.
 // The scanner first asks the vehicle which PID blocks it supports and only
 // then requests the supported PIDs. Every manufacturer profile uses this
 // same standards-based catalogue; manufacturer-specific UDS remains
 // separate and is only used when documented.
 private val pids = linkedMapOf(
 "0101" to "Monitor status / DTCs",
 "0102" to "DTC status since clear",
 "0103" to "Fuel system status",
 "0104" to "Calculated engine load",
 "0105" to "Engine coolant temperature",
 "0106" to "Short-term fuel trim — Bank 1",
 "0107" to "Long-term fuel trim — Bank 1",
 "0108" to "Short-term fuel trim — Bank 2",
 "0109" to "Long-term fuel trim — Bank 2",
 "010A" to "Fuel pressure",
 "010B" to "Intake manifold pressure (MAP)",
 "010C" to "Engine RPM",
 "010D" to "Vehicle speed",
 "010E" to "Ignition timing advance",
 "010F" to "Intake air temperature",
 "0110" to "MAF air flow",
 "0111" to "Throttle position",
 "0112" to "Secondary air status",
 "0113" to "Oxygen sensor presence — Bank 1",
 "0114" to "O2 Sensor 1 voltage / trim",
 "0115" to "O2 Sensor 2 voltage / trim",
 "0116" to "O2 Sensor 3 voltage / trim",
 "0117" to "O2 Sensor 4 voltage / trim",
 "0118" to "O2 Sensor 5 voltage / trim",
 "0119" to "O2 Sensor 6 voltage / trim",
 "011A" to "O2 Sensor 7 voltage / trim",
 "011B" to "O2 Sensor 8 voltage / trim",
 "011C" to "OBD standards supported",
 "011D" to "O2 sensors present — Bank 2",
 "011E" to "Auxiliary input status",
 "011F" to "Engine run time since start",
 "0120" to "Supported PIDs 21–40",
 "0121" to "Distance travelled with MIL on",
 "0122" to "Fuel rail pressure",
 "0123" to "Fuel rail pressure (diesel / alternate)",
 "0124" to "O2 Sensor 1 equivalence / voltage",
 "0125" to "O2 Sensor 2 equivalence / voltage",
 "0126" to "O2 Sensor 3 equivalence / voltage",
 "0127" to "O2 Sensor 4 equivalence / voltage",
 "0128" to "O2 Sensor 5 equivalence / voltage",
 "0129" to "O2 Sensor 6 equivalence / voltage",
 "012A" to "O2 Sensor 7 equivalence / voltage",
 "012B" to "O2 Sensor 8 equivalence / voltage",
 "012C" to "Commanded EGR",
 "012D" to "EGR error",
 "012E" to "Commanded evaporative purge",
 "012F" to "Fuel level input",
 "0130" to "Warm-ups since DTCs cleared",
 "0131" to "Distance since DTCs cleared",
 "0132" to "Evap system vapour pressure",
 "0133" to "Absolute barometric pressure",
 "0134" to "O2 Sensor 1 equivalence ratio / voltage",
 "0135" to "O2 Sensor 2 equivalence ratio / voltage",
 "0136" to "O2 Sensor 3 equivalence ratio / voltage",
 "0137" to "O2 Sensor 4 equivalence ratio / voltage",
 "0138" to "O2 Sensor 5 equivalence ratio / voltage",
 "0139" to "O2 Sensor 6 equivalence ratio / voltage",
 "013A" to "O2 Sensor 7 equivalence ratio / voltage",
 "013B" to "O2 Sensor 8 equivalence ratio / voltage",
 "013C" to "Catalyst temperature — Bank 2 Sensor 1",
 "013D" to "Catalyst temperature — Bank 1 Sensor 2",
 "013E" to "Catalyst temperature — Bank 2 Sensor 2",
 "013F" to "Catalyst temperature — Bank 2 Sensor 2",
 "0140" to "Supported PIDs 41–60",
 "0141" to "Monitor status this drive cycle",
 "0142" to "Control module voltage",
 "0143" to "Absolute load value",
 "0144" to "Commanded equivalence ratio",
 "0145" to "Relative throttle position",
 "0146" to "Ambient / exterior air temperature",
 "0147" to "Absolute throttle position B",
 "0148" to "Absolute throttle position C",
 "0149" to "Accereadator pedal position D",
 "014A" to "Accereadator pedal position E",
 "014B" to "Accereadator pedal position F",
 "014C" to "Commanded throttle actuator",
 "014D" to "Time run with MIL on",
 "014E" to "Time since DTCs cleared",
 "0151" to "Fuel type",
 "0152" to "Ethanol fuel percentage",
 "0153" to "Absolute evaporative system vapour pressure",
 "0154" to "Evap system vapour pressure",
 "0155" to "Short-term secondary O2 trim — Bank 1",
 "0156" to "Long-term secondary O2 trim — Bank 1",
 "0157" to "Short-term secondary O2 trim — Bank 2",
 "0158" to "Long-term secondary O2 trim — Bank 2",
 "0159" to "Fuel rail absolute pressure",
 "015A" to "Relative accereadator pedal position",
 "015B" to "Hybrid battery pack remaining life",
 "015C" to "Engine oil temperature",
 "015D" to "Fuel injection timing",
 "015E" to "Engine fuel rate",
 "015F" to "Engine demand torque",
 "0160" to "Supported PIDs 61–80",
 "0161" to "Engine actual torque",
 "0162" to "Engine reference torque",
 "0163" to "Engine percentage torque",
 "0164" to "Auxiliary input / torque",
 "0165" to "Mass air flow sensor current",
 "0166" to "Engine coolant temperature sensor 1",
 "0167" to "Engine coolant temperature sensor 2",
 "0168" to "Engine coolant temperature sensor 3",
 "0169" to "Engine coolant temperature sensor 4",
 "016A" to "Throttle actuator control",
 "016B" to "Fuel pressure control",
 "016C" to "Commanded diesel intake air flow",
 "016D" to "Exhaust gas recirculation temperature",
 "016E" to "Commanded throttle actuator control",
 "016F" to "Fuel pressure sensor",
 "0170" to "Boost pressure control",
 "0171" to "Variable geometry turbo (VGT) control",
 "0172" to "Wastegate control",
 "0173" to "Exhaust pressure",
 "0174" to "Turbocharger RPM",
 "0175" to "Turbocharger temperature",
 "0176" to "Turbocharger temperature — second set",
 "0177" to "Charge air cooread temperature",
 "0178" to "Exhaust gas temperature — Bank 1",
 "0179" to "Exhaust gas temperature — Bank 2",
 "017A" to "DPF differential pressure",
 "017B" to "DPF status",
 "017C" to "DPF temperature",
 "017D" to "NOx NTE control area status",
 "017E" to "PM NTE control area status",
 "017F" to "Extended engine run time",
 "0180" to "Supported PIDs 81–A0",
 "0183" to "NOx sensor",
 "0184" to "Manifold surface temperature",
 "0185" to "NOx reagent system",
 "0186" to "Particulate matter sensor",
 "0187" to "Intake manifold absolute pressure (later)",
 "0188" to "SCR inducement system",
 "019A" to "Hybrid / EV vehicle system data — battery voltage",
 "019D" to "Engine fuel rate (mass)",
 "01A1" to "NOx sensor corrected data",
 "01A3" to "Evap system vapour pressure (later)",
 "01A7" to "NOx sensor concentration — sensors 3 and 4",
 "01A8" to "NOx sensor corrected concentration — sensors 3 and 4"
 )

 private val manufacturerProfiles = listOf(
 ManufacturerProfile("Automatic", pids.toList()),
 ManufacturerProfile("vehicle", pids.toList()),
 ManufacturerProfile("Peugeot", pids.toList()),
 ManufacturerProfile("DS Automobiles", pids.toList()),
 ManufacturerProfile("Opel", pids.toList()),
 ManufacturerProfile("Vauxhall", pids.toList()),
 ManufacturerProfile("Fiat", pids.toList()),
 ManufacturerProfile("Alfa Romeo", pids.toList()),
 ManufacturerProfile("Jeep", pids.toList()),
 ManufacturerProfile("Lancia", pids.toList()),
 ManufacturerProfile("Abarth", pids.toList()),
 ManufacturerProfile("Toyota", pids.toList()),
 ManufacturerProfile("Lexus", pids.toList()),
 ManufacturerProfile("Volkswagen", pids.toList()),
 ManufacturerProfile("Audi", pids.toList()),
 ManufacturerProfile("SEAT", pids.toList()),
 ManufacturerProfile("Škoda", pids.toList()),
 ManufacturerProfile("CUPRA", pids.toList()),
 ManufacturerProfile("Porsche", pids.toList()),
 ManufacturerProfile("BMW", pids.toList()),
 ManufacturerProfile("MINI", pids.toList()),
 ManufacturerProfile("Mercedes-Benz", pids.toList()),
 ManufacturerProfile("Renault", pids.toList()),
 ManufacturerProfile("Nissan", pids.toList()),
 ManufacturerProfile("Hyundai", pids.toList()),
 ManufacturerProfile("Kia", pids.toList()),
 ManufacturerProfile("Ford", pids.toList()),
 ManufacturerProfile("Volvo", pids.toList()),
 ManufacturerProfile("Polestar", pids.toList()),
 ManufacturerProfile("Tesla", pids.toList()),
 ManufacturerProfile("Honda", pids.toList()),
 ManufacturerProfile("Mazda", pids.toList()),
 ManufacturerProfile("Subaru", pids.toList()),
 ManufacturerProfile("Suzuki", pids.toList()),
 ManufacturerProfile("Mitsubishi", pids.toList()),
 ManufacturerProfile("Jaguar", pids.toList()),
 ManufacturerProfile("Land Rover", pids.toList()),
 ManufacturerProfile("BYD", pids.toList()),
 ManufacturerProfile("MG", pids.toList()),
 ManufacturerProfile("Geely", pids.toList()),
 ManufacturerProfile("Chery", pids.toList()),
 ManufacturerProfile("Isuzu", pids.toList()),
 ManufacturerProfile("OBD-II Universal", pids.toList())
 )


 private fun localized(pt: String, en: String): String {
 return if (HomeBdLanguage.name(this).equals("Português", ignoreCase = true)) pt else en
 }

 private fun diagnosticIntro(): String = localized("HOMEBD ready.\nUniversal OBD-II diagnostics for vehicles.\nSelect a paired Bluetooth OBD-II adapter and tap CONNECT OBD-II.\n", "HOMEBD ready.\nUniversal OBD-II diagnostics for vehicles.\nSelect a paired Bluetooth OBD-II adapter and tap CONNECT OBD-II.\n")




 private fun showLiveDataScreen(
 root: FrameLayout,
 background: Int,
 panel: Int,
 panel2: Int,
 primary: Int,
 secondary: Int,
 blue: Int,
 border: Int
 ) {
 fun rounded(color: Int, radius: Int = 12, stroke: Int = border): GradientDrawable =
 GradientDrawable().apply {
 setColor(color)
 cornerRadius = dp(radius).toFloat()
 setStroke(dp(1), stroke)
 }

 val screen = LinearLayout(this).apply {
 orientation = LinearLayout.VERTICAL
 setBackgroundColor(background)
 setPadding(dp(10), dp(8), dp(10), dp(8))
 }

 val header = LinearLayout(this).apply {
 orientation = LinearLayout.HORIZONTAL
 gravity = Gravity.CENTER_VERTICAL
 setPadding(dp(4), 0, dp(4), 0)
 }
 val back = TextView(this).apply {
 text = "‹"
 textSize = 30f
 setTextColor(blue)
 gravity = Gravity.CENTER
 isClickable = true
 setOnClickListener { root.removeView(screen) }
 }
 header.addView(back, LinearLayout.LayoutParams(dp(44), dp(52)))
 val title = TextView(this).apply {
 text = "LIVE DATA"
 textSize = 19f
 setTextColor(primary)
 gravity = Gravity.CENTER_VERTICAL
 }
 header.addView(title, LinearLayout.LayoutParams(0, dp(52), 1f))
 val export = TextView(this).apply {
 text = "EXPORT"
 textSize = 11f
 setTextColor(primary)
 gravity = Gravity.CENTER
 setPadding(dp(12), 0, dp(12), 0)
 this.background = rounded(panel2, 9, Color.TRANSPARENT)
 isClickable = true
 setOnClickListener { showExportOptions(true) }
 }
 header.addView(export, LinearLayout.LayoutParams(dp(92), dp(40)))
 screen.addView(header, LinearLayout.LayoutParams(-1, dp(56)))

 val tabs = LinearLayout(this).apply {
 orientation = LinearLayout.HORIZONTAL
 setPadding(dp(4), dp(2), dp(4), dp(6))
 }
 fun tab(text: String) = TextView(this).apply {
 this.text = text
 textSize = 12f
 setTextColor(primary)
 gravity = Gravity.CENTER
 this.background = rounded(panel2, 8, Color.TRANSPARENT)
 isClickable = true
 }
 val gauges = tab("GAUGES")
 val values = tab("VALUES")
 val graphs = tab("GRAPHS")
 listOf(gauges, values, graphs).forEach { tabs.addView(it, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(2), 0, dp(2), 0) }) }
 screen.addView(tabs, LinearLayout.LayoutParams(-1, dp(48)))

 val body = FrameLayout(this)
 body.addView(liveDashboardContainer, FrameLayout.LayoutParams(-1, -1))
 body.addView(liveValuesScroll, FrameLayout.LayoutParams(-1, -1))
 body.addView(liveGraphsScroll, FrameLayout.LayoutParams(-1, -1))
 screen.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))

 val pause = TextView(this).apply {
 text = "Ⅱ PAUSE"
 textSize = 13f
 setTextColor(primary)
 gravity = Gravity.CENTER
 this.background = rounded(blue, 9, Color.TRANSPARENT)
 isClickable = true
 setOnClickListener {
 if (liveDataRunning) {
 stopLiveData()
 text = "▶ RESUME"
 }
 }
 }
 screen.addView(pause, LinearLayout.LayoutParams(-1, dp(48)).apply { setMargins(0, dp(6), 0, 0) })

 fun select(index: Int) {
 liveDashboardContainer.visibility = if (index == 0) View.VISIBLE else View.GONE
 liveValuesScroll.visibility = if (index == 1) View.VISIBLE else View.GONE
 liveGraphsScroll.visibility = if (index == 2) View.VISIBLE else View.GONE
 listOf(gauges, values, graphs).forEachIndexed { i, v ->
 v.background = rounded(if (i == index) blue else panel2, 8, Color.TRANSPARENT)
 }
 }
 gauges.setOnClickListener { select(0) }
 values.setOnClickListener { select(1) }
 graphs.setOnClickListener { select(2) }
 select(0)

 root.addView(screen, FrameLayout.LayoutParams(-1, -1))
 }

 override fun onCreate(savedInstanceState: Bundle?) {
 super.onCreate(savedInstanceState)
 val detectedLanguage = HomeBdLanguage.detect(this)
 homeAssistantBridge = HomeBdHaBridge(this)

 window.statusBarColor = Color.rgb(23, 23, 23)
 window.navigationBarColor = Color.rgb(23, 23, 23)

 // Ecrã normal: o conteúdo nunca fica por baixo das barras do sistema.
 if (Build.VERSION.SDK_INT >= 30) {
 window.setDecorFitsSystemWindows(true)
 } else {
 @Suppress("DEPRECATION")
 window.decorView.systemUiVisibility = 0
 }

 // HOMEBD premium portrait layout. The main page is a centered, full-width
 // vertical dashboard. LIVE DATA and DIAGNOSTICS each keep their own scroll.
 val background = Color.rgb(6, 15, 24)
 val panel = Color.rgb(18, 31, 44)
 val panel2 = Color.rgb(25, 41, 56)
 val primary = Color.rgb(245, 248, 252)
 val secondary = Color.rgb(165, 184, 201)
 val blue = Color.rgb(20, 150, 245)
 val green = Color.rgb(10, 125, 75)
 val purple = Color.rgb(65, 42, 125)
 val border = Color.rgb(38, 73, 98)

 fun rounded(color: Int, radius: Int = 12, stroke: Int = border): GradientDrawable =
 GradientDrawable().apply {
 setColor(color)
 cornerRadius = dp(radius).toFloat()
 setStroke(dp(1), stroke)
 }

 fun addCardHeader(parent: LinearLayout, icon: String, title: String, action: String? = null, onAction: (() -> Unit)? = null) {
 val row = LinearLayout(this).apply {
 orientation = LinearLayout.HORIZONTAL
 gravity = Gravity.CENTER_VERTICAL
 setPadding(dp(12), dp(8), dp(8), dp(8))
 }
 val iconView = TextView(this).apply {
 text = icon
 textSize = 18f
 setTextColor(blue)
 gravity = Gravity.CENTER
 includeFontPadding = false
 }
 row.addView(iconView, LinearLayout.LayoutParams(dp(30), dp(30)))
 val label = TextView(this).apply {
 text = title
 textSize = 17f
 setTextColor(primary)
 gravity = Gravity.CENTER_VERTICAL
 includeFontPadding = false
 }
 row.addView(label, LinearLayout.LayoutParams(0, dp(42), 1f))
 if (action != null && onAction != null) {
 val actionView = TextView(this).apply {
 text = action
 textSize = 11f
 setTextColor(primary)
 gravity = Gravity.CENTER
 setPadding(dp(12), 0, dp(12), 0)
 this.background = rounded(Color.rgb(28, 47, 63), 9, Color.TRANSPARENT)
 isClickable = true
 isFocusable = true
 setOnClickListener { onAction() }
 }
 row.addView(actionView, LinearLayout.LayoutParams(dp(96), dp(38)))
 }
 parent.addView(row, LinearLayout.LayoutParams(-1, dp(50)))
 }

 val root = FrameLayout(this).apply {
 setBackgroundColor(background)
 setPadding(0, 0, 0, 0)
 }
 val mainShell = LinearLayout(this).apply {
 orientation = LinearLayout.VERTICAL
 setBackgroundColor(background)
 }
 val mainScroll = ScrollView(this).apply {
 isFillViewport = true
 isVerticalScrollBarEnabled = false
 }
 val content = LinearLayout(this).apply {
 orientation = LinearLayout.VERTICAL
 setPadding(dp(10), dp(8), dp(10), dp(8))
 }
 mainScroll.addView(content, ViewGroup.LayoutParams(-1, -2))
 mainShell.addView(mainScroll, LinearLayout.LayoutParams(-1, 0, 1f))

 // Header
 val header = LinearLayout(this).apply {
 orientation = LinearLayout.HORIZONTAL
 gravity = Gravity.CENTER_VERTICAL
 setPadding(dp(4), dp(4), dp(4), dp(4))
 this.background = rounded(Color.rgb(3, 10, 17), 12, Color.TRANSPARENT)
 }
 val appIcon = ImageView(this).apply {
 setImageResource(pt.homebd.R.drawable.homebd_header)
 scaleType = ImageView.ScaleType.CENTER_INSIDE
 contentDescription = "HOMEBD"
 }
 header.addView(appIcon, LinearLayout.LayoutParams(dp(154), dp(72)).apply {
 setMargins(dp(0), 0, dp(6), 0)
 })
 val headerText = LinearLayout(this).apply {
 orientation = LinearLayout.VERTICAL
 gravity = Gravity.CENTER_VERTICAL
 }
 headerText.addView(TextView(this).apply {
 text = ui("Universal OBD-II diagnostics for vehicles", "Universal OBD-II diagnostics for vehicles")
 textSize = 11f
 setTextColor(secondary)
 gravity = Gravity.CENTER_VERTICAL
 includeFontPadding = false
 }, LinearLayout.LayoutParams(-1, dp(48)))
 header.addView(headerText, LinearLayout.LayoutParams(0, -1, 1f))
 content.addView(header, LinearLayout.LayoutParams(-1, dp(72)).apply {
 setMargins(0, 0, 0, dp(6))
 })

 // Main vehicle visual — presentation-only UI, no vehicle-specific logic.
 val vehicleVisual = LinearLayout(this).apply {
 orientation = LinearLayout.VERTICAL
 gravity = Gravity.CENTER
 this.background = rounded(Color.rgb(2, 8, 14), 12, Color.TRANSPARENT)
 setPadding(dp(4), dp(2), dp(4), dp(2))
 }
 val vehicleImage = ImageView(this).apply {
 setImageResource(pt.homebd.R.drawable.homebd_vehicle_front)
 scaleType = ImageView.ScaleType.CENTER_INSIDE
 contentDescription = "HOMEBD vehicle overview"
 }
 vehicleVisual.addView(vehicleImage, LinearLayout.LayoutParams(-1, dp(184)))
 vehicleVisual.isClickable = true
 vehicleVisual.isFocusable = true
 vehicleVisual.setOnClickListener {
  showLiveDataScreen(root, background, panel, panel2, primary, secondary, blue, border)
 }
 content.addView(vehicleVisual, LinearLayout.LayoutParams(-1, dp(190)).apply {
  setMargins(0, 0, 0, dp(4))
 })

 // Interactive vehicle consumption summary. Values are derived from detected
 // OBD-II data; no vehicle-specific assumptions are used.
 val consumptionRow = LinearLayout(this).apply {
  orientation = LinearLayout.HORIZONTAL
  gravity = Gravity.CENTER
 }
 vehicleFuelConsumptionView = TextView(this).apply {
  text = "FUEL  — L/100 km"
  textSize = 11f
  setTextColor(primary)
  gravity = Gravity.CENTER
  background = rounded(panel2, 10)
  setPadding(dp(6), 0, dp(6), 0)
  isClickable = true
  setOnClickListener { showLiveDataScreen(root, background, panel, panel2, primary, secondary, blue, border) }
 }
 vehicleElectricConsumptionView = TextView(this).apply {
  text = "ELECTRIC  — kWh/100 km"
  textSize = 11f
  setTextColor(primary)
  gravity = Gravity.CENTER
  background = rounded(panel2, 10)
  setPadding(dp(6), 0, dp(6), 0)
  isClickable = true
  setOnClickListener { showLiveDataScreen(root, background, panel, panel2, primary, secondary, blue, border) }
 }
 consumptionRow.addView(vehicleFuelConsumptionView, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
  setMargins(0, 0, dp(3), 0)
 })
 consumptionRow.addView(vehicleElectricConsumptionView, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
  setMargins(dp(3), 0, 0, 0)
 })
 content.addView(consumptionRow, LinearLayout.LayoutParams(-1, dp(44)).apply {
  setMargins(0, 0, 0, dp(5))
 })

 // Status card
 val statusCard = LinearLayout(this).apply {
 orientation = LinearLayout.HORIZONTAL
 gravity = Gravity.CENTER_VERTICAL
 this.background = rounded(panel, 12)
 setPadding(dp(10), dp(3), dp(10), dp(3))
 }
 statusDot = TextView(this).apply {
 text = "●"
 textSize = 20f
 setTextColor(Color.rgb(255, 175, 195))
 gravity = Gravity.CENTER
 includeFontPadding = false
 }
 statusCard.addView(statusDot, LinearLayout.LayoutParams(dp(28), dp(54)))
 status = TextView(this).apply {
 text = ui(getString(R.string.obd_disconnected), "OBD-II DISCONNECTED")
 textSize = 14.5f
 setTextColor(primary)
 gravity = Gravity.CENTER_VERTICAL
 includeFontPadding = false
 maxLines = 2
 }
 statusCard.addView(status, LinearLayout.LayoutParams(0, dp(54), 1f))
 val btSummary = TextView(this).apply {
 text = ui("Bluetooth", "Bluetooth")
 textSize = 11.5f
 setTextColor(secondary)
 gravity = Gravity.CENTER
 includeFontPadding = false
 }
 statusCard.addView(btSummary, LinearLayout.LayoutParams(dp(76), dp(54)))
 content.addView(statusCard, LinearLayout.LayoutParams(-1, dp(60)).apply {
 setMargins(0, 0, 0, dp(5))
 })

 // Selectors
 val selectors = LinearLayout(this).apply {
 orientation = LinearLayout.HORIZONTAL
 gravity = Gravity.CENTER_VERTICAL
 }
 val deviceCard = LinearLayout(this).apply {
 orientation = LinearLayout.VERTICAL
 this.background = rounded(panel, 12)
 setPadding(dp(10), dp(4), dp(10), dp(6))
 }
 val deviceLabel = TextView(this).apply {
 text = ui(localized("OBD-II DEVICE", "OBD-II DEVICE"), "OBD-II DEVICE")
 textSize = 11f
 setTextColor(secondary)
 gravity = Gravity.CENTER_VERTICAL
 includeFontPadding = false
 }
 deviceCard.addView(deviceLabel, LinearLayout.LayoutParams(-1, dp(24)))
 devicesSpinner = Spinner(this).apply {
 this.background = rounded(panel2, 8, Color.TRANSPARENT)
 minimumHeight = dp(44)
 }
 deviceCard.addView(devicesSpinner, LinearLayout.LayoutParams(-1, dp(48)))
 selectors.addView(deviceCard, LinearLayout.LayoutParams(0, dp(80), 1f).apply { setMargins(0, 0, dp(4), 0) })

 val manufacturerCard = LinearLayout(this).apply {
 orientation = LinearLayout.VERTICAL
 this.background = rounded(panel, 12)
 setPadding(dp(10), dp(4), dp(10), dp(6))
 }
 val manufacturerLabel = TextView(this).apply {
 text = ui(localized("MANUFACTURER / PROFILE", "MANUFACTURER / PROFILE"), "MANUFACTURER / PROFILE")
 textSize = 11f
 setTextColor(secondary)
 gravity = Gravity.CENTER_VERTICAL
 includeFontPadding = false
 }
 manufacturerCard.addView(manufacturerLabel, LinearLayout.LayoutParams(-1, dp(24)))
 manufacturerSpinner = Spinner(this).apply {
 this.background = rounded(panel2, 8, Color.TRANSPARENT)
 minimumHeight = dp(44)
 }
 manufacturerCard.addView(manufacturerSpinner, LinearLayout.LayoutParams(-1, dp(48)))
 selectors.addView(manufacturerCard, LinearLayout.LayoutParams(0, dp(80), 1f).apply { setMargins(dp(4), 0, 0, 0) })
 content.addView(selectors, LinearLayout.LayoutParams(-1, dp(84)).apply { setMargins(0, 0, 0, dp(6)) })

 // Four primary actions
 connectButton = actionButton(ui(localized("CONNECT\nOBD-II", "CONNECT\nOBD-II"), "CONNECT\nOBD-II"), blue, primary)
 val connect = connectButton
 scanButton = actionButton(ui(localized("RESCAN\nPIDs", "RESCAN\nPIDs"), "RESCAN\nPIDs"), Color.rgb(24, 42, 58), primary).apply {
 isEnabled = false
 alpha = 0.55f
 }
 hvUdsButton = actionButton(ui(localized("HV / UDS\nSCAN", "HV / UDS\nSCAN"), "HV / UDS\nSCAN"), purple, primary).apply {
 isEnabled = false
 alpha = 0.55f
 }
 homeAssistantConnectButton = actionButton(ui(localized("HOME\nASSISTANT", "HOME\nASSISTANT"), "HOME\nASSISTANT"), green, primary)

 val buttons = LinearLayout(this).apply {
 orientation = LinearLayout.HORIZONTAL
 gravity = Gravity.CENTER
 }
 fun addAction(view: View, left: Int, right: Int) = buttons.addView(view, LinearLayout.LayoutParams(0, dp(68), 1f).apply {
 setMargins(dp(left), 0, dp(right), 0)
 })
 addAction(connect, 0, 3)
 addAction(scanButton, 3, 3)
 addAction(hvUdsButton, 3, 3)
 addAction(homeAssistantConnectButton, 3, 0)
 content.addView(buttons, LinearLayout.LayoutParams(-1, dp(68)).apply { setMargins(0, 0, 0, dp(5)) })

 // Home Assistant card
 val homeCard = LinearLayout(this).apply {
 orientation = LinearLayout.HORIZONTAL
 gravity = Gravity.CENTER_VERTICAL
 this.background = rounded(panel, 12)
 setPadding(dp(10), dp(2), dp(10), dp(2))
 }
 homeAssistantStatusView = TextView(this).apply {
 text = if (homeAssistantBridge.baseUrl.isBlank()) ui("Home Assistant · not configured", "Home Assistant · not configured")
 else ui("Home Assistant · WebSocket · connected", "Home Assistant · WebSocket · connected")
 textSize = 11.5f
 setTextColor(secondary)
 gravity = Gravity.CENTER_VERTICAL
 includeFontPadding = false
 maxLines = 1
 ellipsize = android.text.TextUtils.TruncateAt.END
 }
 homeCard.addView(homeAssistantStatusView, LinearLayout.LayoutParams(0, dp(38), 1f))
 // Compact status only. Configuration is handled by the HOME ASSISTANT action.
 content.addView(homeCard, LinearLayout.LayoutParams(-1, dp(44)).apply { setMargins(0, 0, 0, dp(5)) })

 // Live Data backing views. They are kept out of the main dashboard and
 // mounted only by the dedicated Live Data screen. No OBD/transport logic
 // is changed here; this is UI-only layout separation.
 liveDashboardContainer = LinearLayout(this).apply {
 orientation = LinearLayout.VERTICAL
 setPadding(dp(6), dp(4), dp(6), dp(6))
 }
 liveDataLog = TextView(this).apply {
 textSize = 13f
 setTextColor(primary)
 setPadding(dp(8), dp(8), dp(8), dp(8))
 gravity = Gravity.TOP or Gravity.START
 includeFontPadding = true
 setLineSpacing(0f, 1.0f)
 isLongClickable = true
 }
 liveDataContainer = LinearLayout(this).apply {
 orientation = LinearLayout.VERTICAL
 setPadding(dp(4), dp(2), dp(4), dp(4))
 setBackgroundColor(panel)
 }
 liveDataScroll = PanelScrollView(this).apply {
 setBackgroundColor(panel)
 isFillViewport = true
 isVerticalScrollBarEnabled = true
 scrollBarStyle = View.SCROLLBARS_INSIDE_INSET
 isScrollbarFadingEnabled = false
 scrollBarSize = dp(5)
 addView(liveDataContainer, ViewGroup.LayoutParams(-1, -2))
 }
 liveValuesScroll = liveDataScroll
 liveGraphsScroll = PanelScrollView(this).apply {
 setBackgroundColor(panel)
 isFillViewport = true
 addView(TextView(this@MainActivity).apply {
 text = "GRAPHS\n\nWaiting for live telemetry…"
 textSize = 13f
 setTextColor(Color.LTGRAY)
 setPadding(dp(12), dp(10), dp(12), dp(10))
 }, ViewGroup.LayoutParams(-1, -1))
 }
 renderLiveDashboard()

 // LIVE DATA: compact entry on the main dashboard. The full Live Data UI
 // opens in its own full-width screen, matching the reference layout.
 val liveCard = LinearLayout(this).apply {
 orientation = LinearLayout.HORIZONTAL
 gravity = Gravity.CENTER_VERTICAL
 this.background = rounded(panel, 12)
 isClickable = true
 isFocusable = true
 setPadding(dp(10), dp(2), dp(8), dp(2))
 }
 val liveIcon = TextView(this).apply {
 text = "⌁"
 textSize = 22f
 setTextColor(blue)
 gravity = Gravity.CENTER
 }
 liveCard.addView(liveIcon, LinearLayout.LayoutParams(dp(42), dp(54)))
 liveCard.addView(TextView(this).apply {
 text = "LIVE DATA"
 textSize = 17f
 setTextColor(primary)
 gravity = Gravity.CENTER_VERTICAL
 }, LinearLayout.LayoutParams(0, dp(54), 1f))
 liveCard.addView(TextView(this).apply {
 text = "›"
 textSize = 28f
 setTextColor(secondary)
 gravity = Gravity.CENTER
 }, LinearLayout.LayoutParams(dp(40), dp(54)))
 liveCard.setOnClickListener { showLiveDataScreen(root, background, panel, panel2, primary, secondary, blue, border) }
 content.addView(liveCard, LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, 0, 0, dp(5)) })

 // Keep the diagnostics log initialized for the existing diagnostic/export
 // logic, while the dashboard itself uses a compact navigation card.
 log = TextView(this).apply {
 textSize = 13f
 setTextColor(primary)
 setPadding(dp(10), dp(8), dp(10), dp(8))
 includeFontPadding = true
 gravity = Gravity.TOP or Gravity.START
 setLineSpacing(0f, 1.0f)
 }
 logScroll = PanelScrollView(this).apply {
 setBackgroundColor(panel)
 isFillViewport = true
 isVerticalScrollBarEnabled = true
 addView(log, ViewGroup.LayoutParams(-1, -2))
 }

 // DIAGNOSTICS: compact entry on the main dashboard.
 val diagnosticCard = LinearLayout(this).apply {
 orientation = LinearLayout.HORIZONTAL
 gravity = Gravity.CENTER_VERTICAL
 this.background = rounded(panel, 12)
 isClickable = true
 isFocusable = true
 setPadding(dp(10), dp(2), dp(8), dp(2))
 }
 diagnosticCard.addView(TextView(this).apply {
 text = "▣"
 textSize = 20f
 setTextColor(blue)
 gravity = Gravity.CENTER
 }, LinearLayout.LayoutParams(dp(42), dp(54)))
 diagnosticCard.addView(TextView(this).apply {
 text = "DIAGNOSTICS"
 textSize = 17f
 setTextColor(primary)
 gravity = Gravity.CENTER_VERTICAL
 }, LinearLayout.LayoutParams(0, dp(54), 1f))
 diagnosticCard.addView(TextView(this).apply {
 text = "›"
 textSize = 28f
 setTextColor(secondary)
 gravity = Gravity.CENTER
 }, LinearLayout.LayoutParams(dp(40), dp(54)))
 diagnosticCard.setOnClickListener {
 val dialog = AlertDialog.Builder(this)
 .setTitle("DIAGNOSTICS")
 .setView(logScroll)
 .setPositiveButton("CLOSE", null)
 .create()
 dialog.show()
 }
 content.addView(diagnosticCard, LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, 0, 0, dp(5)) })

 // Footer
 val footer = LinearLayout(this).apply {
 orientation = LinearLayout.HORIZONTAL
 gravity = Gravity.CENTER_VERTICAL
 setPadding(dp(4), 0, dp(4), 0)
 }
 faqButton = TextView(this).apply {
 text = "FAQ"
 textSize = 12f
 setTextColor(blue)
 gravity = Gravity.CENTER
 isClickable = true
 isFocusable = true
 }
 aboutButton = TextView(this).apply {
 text = "ABOUT"
 textSize = 12f
 setTextColor(blue)
 gravity = Gravity.CENTER
 isClickable = true
 isFocusable = true
 }
 footer.addView(faqButton, LinearLayout.LayoutParams(0, dp(40), 1f))
 footer.addView(TextView(this).apply {
 text = "HOMEBD Beta v2.0.0\nlufime"
 textSize = 11f
 setTextColor(secondary)
 gravity = Gravity.CENTER
 includeFontPadding = false
 }, LinearLayout.LayoutParams(0, dp(40), 1f))
 footer.addView(aboutButton, LinearLayout.LayoutParams(0, dp(40), 1f))
 content.addView(footer, LinearLayout.LayoutParams(-1, dp(44)))
 root.addView(mainShell, FrameLayout.LayoutParams(-1, -1))

 if (Build.VERSION.SDK_INT >= 30) {
 root.setOnApplyWindowInsetsListener { v, insets ->
 val bars = insets.getInsets(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
 content.setPadding(dp(10), bars.top + dp(8), dp(10), bars.bottom + dp(4))
 insets
 }
 }

 setContentView(root)

 append("🌐 " + ui("Automatic language", "Automatic language") + ": ${HomeBdLanguage.name(this)}")

 // Pressure longa nos dois painéis copia todo o conteúdo.
 installCopyOnLongPress(liveDataLog, ui(localized("LIVE DATA", "LIVE DATA"), localized("LIVE DATA", "LIVE DATA")))
 installCopyOnLongPress(log, ui(localized(getString(R.string.diagnostics), "DIAGNOSTICS"), "DIAGNOSTICS"))

 manufacturerSpinner.adapter = ArrayAdapter(
 this,
 android.R.layout.simple_spinner_item,
 manufacturerProfiles.map { if (it.name == "Automatic") ui("Automatic", "Automatic") else it.name }
 ).apply {
 setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
 }

 manufacturerSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
 override fun onNothingSelected(parent: AdapterView<*>?) = Unit
 override fun onItemSelected(
 parent: AdapterView<*>?,
 view: View?,
 position: Int,
 id: Long
 ) {
 val profile = manufacturerProfiles[position]
 liveDataLog.text = englishRuntimeText(
 "Perfil: ${profile.name}\n\n" +
 "OBD-II standard\n" +
 "Os PIDs suportdos são detetados automaticamente pelo vehicle.\n\n" +
 "Categorias disponíveis:\n" +
 "• Engine e carga\n" +
 "• Fuel e mistura\n" +
 "• Temperatures e pressões\n" +
 "• Sensores O2 / emissões\n" +
 "• Acereadador / pedal\n" +
 "• Status OBD / readiness\n" +
 "• Voltage e data auxiliares\n" +
 "• VIN / information do vehicle"
 )
 append(ui("Perfil selected: ${if (profile.name == "Automatic") "Automatic" else profile.name} • catálogo OBD-II standard active", "Selected profile: ${profile.name} • standard OBD-II catalogue active"))
 }
 }

 root.requestApplyInsets()

 connect.setOnClickListener {
 if (isTransportConnected()) {
 // Explicit disconnect: stop polling and close Classic/BLE transport.
 stopLiveData()
 closeTransport()
 setStatusText(ui("Status: disconnected", "Status: disconnected"))
 scanButton.isEnabled = false
 scanButton.alpha = 0.55f
 connectButton.text = ui(localized("CONNECT\nOBD-II", "CONNECT\nOBD-II"), "CONNECT\nOBD-II")
 append(ui("✓ OBD-II disconnected.", "✓ OBD-II disconnected."))
 return@setOnClickListener
 }

 val adapter = BluetoothAdapter.getDefaultAdapter()
 val paired = try {
 adapter?.bondedDevices?.toList() ?: emptyList()
 } catch (_: SecurityException) {
 emptyList()
 }

 val position = devicesSpinner.selectedItemPosition
 val device = paired.getOrNull(position)

 if (device != null) {
 connect(device)
 } else {
 append(ui("⚠ No selectable Bluetooth device.", "⚠ No selectable Bluetooth device."))
 append(ui("Pair a Bluetooth OBD-II adapter in Android Bluetooth settings.", "Pair a Bluetooth OBD-II adapter in Android Bluetooth settings."))
 }
 }

 homeAssistantConnectButton.setOnClickListener {
 try {
 if (!isActivityUsable()) return@setOnClickListener
 if (homeAssistantBridge.connected) {
 homeAssistantBridge.disconnect()
 homeAssistantStatusView.text = ui("Home Assistant · disconnected", "Home Assistant · disconnected")
 homeAssistantConnectButton.text = ui(localized("HOME\nASSISTANT", "HOME\nASSISTANT"), "HOME\nASSISTANT")
 append(ui("✓ Home Assistant disconnected.", "✓ Home Assistant disconnected."))
 } else if (homeAssistantBridge.baseUrl.isBlank() || homeAssistantBridge.token.isBlank()) {
 configureHomeAssistantLink()
 } else {
 homeAssistantConnectButton.isEnabled = false
 homeAssistantStatusView.text = ui("Home Assistant · connecting…", "Home Assistant · connecting…")
 homeAssistantBridge.connect { ok, msg ->
 safeUi {
 homeAssistantConnectButton.isEnabled = true
 homeAssistantStatusView.text = if (ok) ui("Home Assistant · WebSocket · connected", "Home Assistant · WebSocket · connected") else "Home Assistant · ${englishRuntimeText(msg)}"
 homeAssistantConnectButton.text = if (ok) ui("HOME\nASSISTANT", "HOME\nASSISTANT") else ui(localized("HOME\nASSISTANT", "HOME\nASSISTANT"), "HOME\nASSISTANT")
 append(if (ok) "✓ $msg" else "⚠ $msg")
 }
 }
 }
 } catch (t: Throwable) {
 safeUi {
 homeAssistantConnectButton.isEnabled = true
 homeAssistantStatusView.text = ui("Home Assistant · error", "Home Assistant · error")
 append(ui("⚠ Home Assistant error: ${t.message ?: t.javaClass.simpleName}", "⚠ Home Assistant error: ${t.message ?: t.javaClass.simpleName}"))
 }
 }
 }

 scanButton.setOnClickListener { runScanner() }
 hvUdsButton.setOnClickListener { runHvUdsDiscovery() }
 aboutButton.setOnClickListener { showAbout() }
 faqButton.setOnClickListener { showFaq() }

 append(ui("HOMEBD ready.", "HOMEBD ready."))
 append(localized("Universal OBD-II diagnostics for vehicles.", "Universal OBD-II diagnostics for vehicles."))
 append(localized("Select a paired Bluetooth OBD-II adapter and tap CONNECT OBD-II.", "Select a paired Bluetooth OBD-II adapter and tap CONNECT OBD-II."))
 liveDataLog.text = ui("No data — connect OBD-II and run SCAN PIDs.", "No data — connect OBD-II and run SCAN PIDs.")

 requestBtPermissions()
 refreshBluetoothList()
 }

 private fun sectionHeader(title: String, action: String, onAction: () -> Unit): LinearLayout {
 val row = LinearLayout(this).apply {
 orientation = LinearLayout.HORIZONTAL
 gravity = Gravity.CENTER_VERTICAL
 }

 val label = TextView(this).apply {
 text = title
 textSize = 13f
 setTextColor(Color.WHITE)
 gravity = Gravity.CENTER_VERTICAL
 includeFontPadding = false
 }

 val button = TextView(this).apply {
 text = action
 textSize = 10f
 setTextColor(Color.WHITE)
 gravity = Gravity.CENTER
 setPadding(dp(8), 0, dp(8), 0)
 isClickable = true
 isFocusable = true
 this.background = GradientDrawable().apply {
 setColor(Color.rgb(55, 55, 55))
 cornerRadius = dp(3).toFloat()
 }
 setOnClickListener { onAction() }
 }

 row.addView(label, LinearLayout.LayoutParams(0, -1, 1f))
 row.addView(button, LinearLayout.LayoutParams(dp(88), dp(26)))
 return row
 }

 private fun installCopyOnLongPress(view: TextView, label: String) {
 view.setOnLongClickListener {
 val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
 clipboard.setPrimaryClip(ClipData.newPlainText(label, view.text.toString()))
 Toast.makeText(this, ui("$label copied", "$label copied"), Toast.LENGTH_SHORT).show()
 true
 }
 }

 private fun exportText(label: String, text: String, requestCode: Int) {
 if (text.isBlank()) {
 Toast.makeText(this, ui("There is no data to export.", "There is no data to export."), Toast.LENGTH_SHORT).show()
 return
 }

 pendingExportText = text
 pendingExportLabel = label

 val safeName = label.replace(Regex("[^A-Za-z0-9_-]"), "_")
 val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
 addCategory(Intent.CATEGORY_OPENABLE)
 type = "text/plain"
 putExtra(Intent.EXTRA_TITLE, "HOMEBD_${safeName}.txt")
 }
 try {
 startActivityForResult(intent, requestCode)
 } catch (_: Exception) {
 Toast.makeText(this, ui("Unable to open the exporter.", "Unable to open the exporter."), Toast.LENGTH_SHORT).show()
 }
 }

 override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
 super.onActivityResult(requestCode, resultCode, data)
 if ((requestCode == 101 || requestCode == 102) &&
 resultCode == RESULT_OK &&
 data?.data != null
 ) {
 val uri: Uri = data.data!!
 try {
 contentResolver.openOutputStream(uri)?.use { out ->
 out.write(pendingExportText.toByteArray(Charsets.UTF_8))
 out.flush()
 }
 Toast.makeText(this, ui("$pendingExportLabel exported.", "$pendingExportLabel exported."), Toast.LENGTH_SHORT).show()
 } catch (e: Exception) {
 Toast.makeText(this, ui("Export error: ${e.message ?: "unknown"}", "Export error: ${e.message ?: "unknown"}"), Toast.LENGTH_LONG).show()
 } finally {
 pendingExportText = ""
 pendingExportLabel = "HOMEBD"
 }
 }
 }

 private fun showAbout() {
 val pt = Locale.getDefault().language.equals("pt", ignoreCase = true)
 val title = if (pt) "About o HOMEBD" else "About HOMEBD"
 val message = if (pt) {
 "HOMEBD\n" +
 "Home Onboard Monitoring Engine Board Data\n\n" +
 "HOMEBD — Funcionalidades desenvolvidas\n\n" +
 "• Android application for OBD-II diagnostics\n" +
 "• Connection a adaptadores OBD-II através de Bluetooth\n" +
 "• Deteção e seleção de devices Bluetooth emparelhados\n" +
 "• Comunicação com interfaces compatíveis com ELM327\n" +
 "• Deteção automática do protocol OBD-II\n" +
 "• Identificação dos PIDs suportdos pelo vehicle\n" +
 "• Reading dinâmica e conversion dos parâmetros\n" +
 "• Live Data in live\n" +
 "• Reading de DTCs quando suportda\n" +
 "• Reading de VIN quando available\n" +
 "• CAN / ISO-TP / UDS quando suportdo\n" +
 "• Perfis específicos de fabricantes\n" +
 "• Operação 100% READ-ONLY\n\n" +
 "Nota de desenvolvimento:\n" +
 "O HOMEBD foi desenvolvido de raiz, com arquitetura, funcionalidades e soluções técnicas concebidas especificamente para este projeto e desenvolvidas para a própria application.\n\n" +
 "Version: Beta v2.0.0\n" +
 "Desenvolvido por: lufime"
 } else {
 "HOMEBD\n" +
 "Home Onboard Monitoring Engine Board Data\n\n" +
 "HOMEBD — Developed Features\n\n" +
 "• Android application for OBD-II diagnostics\n" +
 "• Bluetooth connection to OBD-II adapters\n • Adapter layer designed for ELM327-compatible, STN and OBDLink interfaces\n" +
 "• Detection and selection of paired Bluetooth devices\n" +
 "• Communication with ELM327-compatible interfaces\n" +
 "• Automatic OBD-II protocol detection\n" +
 "• Identification of vehicle-supported PIDs\n" +
 "• Dynamic reading and conversion of parameters\n" +
 "• Real-time Live Data\n" +
 "• DTC reading when supported\n" +
 "• VIN reading when available\n" +
 "• CAN / ISO-TP / UDS when supported\n" +
 "• Manufacturer-specific profiles\n" +
 "• 100% READ-ONLY operation\n\n" +
 "Development Note:\n" +
 "HOMEBD was developed from the ground up, with its architecture, features, and technical solutions specifically designed and developed for this project and its application.\n\n" +
 "Version: Beta v2.0.0\n" +
 "Developed by: lufime"
 }

 AlertDialog.Builder(this)
 .setTitle(title)
 .setMessage(message)
 .setPositiveButton(if (pt) "FECHAR" else "CLOSE", null)
 .show()
 }

 private fun showFaq() {
 val pt = Locale.getDefault().language.equals("pt", ignoreCase = true)
 val title = if (pt) "HOMEBD • FAQ" else "HOMEBD • FAQ"
 val faqText = if (pt) {
 "PERGUNTAS FREQUENTES\n\n" +
 "1. O que é o HOMEBD?\n" +
 "Android application for OBD-II diagnostics, reading of Live Data e integração WebSocket com Home Assistant.\n\n" +
 "2. Que adaptadores são suportdos?\n" +
 "A application foi desenhada para adaptadores Bluetooth compatíveis com ELM327 e transportes equivalentes suportdos pela application. A compatibilidade real depende do adaptador e do vehicle.\n\n" +
 "3. O HOMEBD altera a ECU?\n" +
 "No. A operação de diagnostics da application é READ-ONLY. No são enviados commands de escrita, programação, codificação ou adaptação.\n\n" +
 "4. O que means 'Unknown' num sensor?\n" +
 "Means que o value not yet foi recebido, not está available no ECU ou not foi possível converter a response. No means zero.\n\n" +
 "5. Como funciona a integração Home Assistant?\n" +
 "A HOMEBD usa uma integração própria no Home Assistant e uma connection WebSocket persistente to send as entidades sensor.homebd_*.\n\n" +
 "7. O que faço se o Home Assistant does not update?\n" +
 "Confirma a integração HOMEBD em Settings > Devices e serviços, o address of Home Assistant e o Long-Lived Access Token.\n\n" +
 "8. Para que serve SCAN PIDs?\n" +
 "Identifica os PIDs OBD-II que o vehicle declara support e depois permite apresentar os parâmetros disponíveis.\n\n" +
 "10. O FAQ vai ser atualizado?\n" +
 "Yes. O FAQ deve ser atualizado a cada version relevante, refletindo funcionalidades implementadas, alterações de OBD, compatibilidade e limitações conhecidas.\n\n" +
 "VERSÃO — Beta v2.0.0\n" +
 "• FAQ integrado na application\n" +
 "• Connection Home Assistant por WebSocket persistente\n" +
 "" +
 "• Integração HOMEBD dedicada no Home Assistant\n\n" +
 "Desenvolvido por: lufime"
 } else {
 "FREQUENTLY ASKED QUESTIONS\n\n" +
 "1. What is HOMEBD?\n" +
 "An Android application for OBD-II diagnostics, Live Data and Home Assistant WebSocket integration.\n\n" +
 "2. Which adapters are supported?\n" +
 "The application is designed for Bluetooth adapters compatible with ELM327 and supported equivalent transports. Actual compatibility depends on the adapter and vehicle.\n\n" +
 "3. Does HOMEBD modify the ECU?\n" +
 "No. Diagnostic operation is READ-ONLY. No write, programming, coding or adaptation commands are sent.\n\n" +
 "4. What does 'Unknown' mean for a sensor?\n" +
 "The value has not been received, is unavailable from the ECU, or could not be converted. It does not mean zero.\n\n" +
 "5. How does the Home Assistant integration work?\n" +
 "HOMEBD uses its own Home Assistant integration and a persistent WebSocket connection to publish sensor.homebd_* entities.\n\n" +
 "7. What if Home Assistant does does not update?\n" +
 "Check the HOMEBD integration under Settings > Devices & services, the Home Assistant address and the Long-Lived Access Token.\n\n" +
 "8. What does SCAN PIDs do?\n" +
 "It identifies OBD-II PIDs declared as supported by the vehicle and then allows available parameters to be displayed.\n\n" +
 "10. Will the FAQ be updated?\n" +
 "Yes. The FAQ should be updated with each relevant release to reflect implemented features, OBD changes, compatibility and known limitations.\n\n" +
 "VERSION — Beta v2.0.0\n" +
 "• FAQ integrated in the application\n" +
 "• Persistent Home Assistant WebSocket connection\n" +
 "" +
 "• Dedicated HOMEBD Home Assistant integration\n\n" +
 "Developed by: lufime"
 }

 val textView = TextView(this).apply {
 text = faqText
 textSize = 14f
 setTextColor(Color.LTGRAY)
 setPadding(dp(18), dp(8), dp(18), dp(8))
 setLineSpacing(0f, 1.08f)
 }
 val scroll = ScrollView(this).apply {
 isFillViewport = true
 addView(textView, ViewGroup.LayoutParams(-1, -2))
 }
 AlertDialog.Builder(this)
 .setTitle(title)
 .setView(scroll)
 .setPositiveButton(if (pt) "FECHAR" else "CLOSE", null)
 .show()
 }

 private fun setStatusText(value: String) {
 val lower = value.lowercase(Locale.ROOT)
 val isErrorrrrr = lower.contains("error") || lower.contains("error")
 val connected = isTransportConnected() || lower.contains("connected")
 status.text = when {
 isErrorrrrr -> ui("OBD-II · ERROR", "OBD-II · ERROR")
 lower.contains("live data") -> ui("OBD-II CONNECTED\nLIVE DATA · 1 s", "OBD-II CONNECTED\nLIVE DATA · 1 s")
 connected -> ui(getString(R.string.obd_connected), "OBD-II CONNECTED")
 lower.contains("connecting") || lower.contains("connecting") -> ui("OBD-II CONNECTING…", "OBD-II CONNECTING…")
 else -> ui(getString(R.string.obd_disconnected), "OBD-II DISCONNECTED")
 }
 val dotColor = when {
 isErrorrrrr -> Color.rgb(235, 65, 80)
 connected -> Color.rgb(120, 225, 160)
 else -> Color.rgb(255, 175, 195)
 }
 statusDot.setTextColor(dotColor)
 }

 private fun actionButton(label: String, color: Int, textColor: Int): TextView =
 TextView(this).apply {
 text = label
 textSize = 12f
 setTextColor(textColor)
 gravity = Gravity.CENTER
 includeFontPadding = false
 setPadding(dp(6), dp(4), dp(6), dp(4))
 isClickable = true
 isFocusable = true
 this.background = GradientDrawable().apply {
 setColor(color)
 cornerRadius = dp(8).toFloat()
 setStroke(dp(1), Color.rgb(38, 73, 98))
 }
 }

 private fun refreshBluetoothList() {
 val adapter = BluetoothAdapter.getDefaultAdapter()

 if (adapter == null) {
 setDevices(listOf(ui("Bluetooth is not available on this device", "Bluetooth is not available on this device")))
 return
 }

 try {
 if (Build.VERSION.SDK_INT >= 31 &&
 checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
 ) {
 setDevices(listOf(ui("Allow Bluetooth permission to show devices", "Allow Bluetooth permission to show devices")))
 return
 }

 if (!adapter.isEnabled) {
 setDevices(listOf(ui(getString(R.string.bluetooth_disabled), "Bluetooth is off — enable Bluetooth")))
 return
 }

 val paired = adapter.bondedDevices.toList()
 val names = if (paired.isEmpty()) {
 listOf(ui("No paired devices", "No paired devices"))
 } else {
 paired.map { device ->
 val name = try { device.name ?: ui("Unnamed", "Unnamed") } catch (_: SecurityException) { ui("Unnamed", "Unnamed") }
 "$name (${device.address})"
 }
 }

 setDevices(names)
 append(ui("✓ Bluetooth: ${paired.size} paired device(s).", "✓ Bluetooth: ${paired.size} paired device(s)."))
 } catch (_: SecurityException) {
 setDevices(listOf(ui("Bluetooth permission required", "Bluetooth permission required")))
 }
 }

 private fun setDevices(names: List<String>) {
 devicesSpinner.adapter = ArrayAdapter(
 this,
 android.R.layout.simple_spinner_item,
 names
 ).apply {
 setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
 }
 }

 private fun requestBtPermissions() {
 val permissions = mutableListOf<String>()

 if (Build.VERSION.SDK_INT >= 31) {
 if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
 permissions += Manifest.permission.BLUETOOTH_SCAN
 }
 if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
 permissions += Manifest.permission.BLUETOOTH_CONNECT
 }
 }

 if (Build.VERSION.SDK_INT >= 33 &&
 checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
 ) {
 permissions += Manifest.permission.POST_NOTIFICATIONS
 }

 if (permissions.isNotEmpty()) {
 requestPermissions(permissions.toTypedArray(), 10)
 }
 }

 private fun connect(device: BluetoothDevice) {
 stopLiveData()
 thread {
 try {
 runOnUiThread { setStatusText(ui(getString(R.string.status_connecting), "Status: connecting…")) }
 closeTransport()

 var classicErrorrrrr: Exception? = null
 try {
 if (Build.VERSION.SDK_INT >= 31 &&
 checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
 ) throw SecurityException("Permission Bluetooth required")

 socket = device.createRfcommSocketToServiceRecord(spp)
 socket!!.connect()
 input = socket!!.inputStream
 output = socket!!.outputStream
 usingBle = false
 adapterKind = "OBD-II Bluetooth Classic"
 } catch (e: Exception) {
 classicErrorrrrr = e
 try { socket?.close() } catch (_: Exception) {}
 socket = null
 input = null
 output = null

 runOnUiThread { setStatusText(ui("Status: connecting via BLE…", "Status: connecting via BLE…")) }
 connectBle(device)
 usingBle = true
 adapterKind = "OBD-II Bluetooth BLE"
 }

 elm("ATZ", 5000)
 Thread.sleep(1200)
 elm("ATE0", 2500)
 adapterIdentity = elm("ATI", 2500)
 adapterKind = identifyAdapter(adapterIdentity) + if (usingBle) " • BLE" else " • Bluetooth Classic"
 elm("ATL0", 2500)
 elm("ATS0", 2500)
 elm("ATSP0", 2500)

 val protocol = elm("ATDP", 2500)
 var protocolNumber = elm("ATDPN", 2500)
 .trim().uppercase().removePrefix("A")

 if (protocol.isBlank()) throw IOException(ui("Adapter did not respond to ATDP", "Adapter did not respond to ATDP"))

 detectedProtocol = protocolNumber
 canActive = protocolNumber in setOf("6", "7", "8", "9", "A", "B", "C") ||
 protocol.uppercase().contains("CAN") || protocol.uppercase().contains("J1939")

 // Some ELM327-compatible adapters report protocol 0/AUTO even
 // when the vehicle is already on CAN. Before giving up, test the
 // standard CAN variants with a harmless OBD-II capability query.
 // Keep the first protocol that produces a valid 0100 response
 // selected for the rest of the session.
 if (!canActive || protocolNumber == "0") {
 val stable = stabilizeCanProtocol()
 if (stable != null) {
 protocolNumber = stable
 detectedProtocol = stable
 canActive = true
 append(ui("✓ CAN stabilized: protocol $stable (0100 responded).", "✓ CAN stabilized: protocol $stable (0100 responded)."))
 }
 }

 if (canActive) {
 elm("ATCFC1", 1500)
 append("✓ CAN detectado: ISO 15765-4 CAN 11-bit / 500 kbit/s.")
 append(ui("✓ CAN in READ-ONLY mode.", "✓ CAN in READ-ONLY mode."))
 }

 // Keep the HOMEBD process alive while the OBD session is active.
 // The foreground service is intentionally started only after the transport
 // and CAN/OBD initialization succeeded.
 HomeBdForegroundService.start(this@MainActivity)

 runOnUiThread {
 setStatusText(if (canActive)
 ui("Status: CONNECTED • $adapterKind • CAN • READ-ONLY", "Status: CONNECTED • $adapterKind • CAN • READ-ONLY")
 else
 ui("Status: CONNECTED • $adapterKind • READ-ONLY", "Status: CONNECTED • $adapterKind • READ-ONLY"))
 scanButton.isEnabled = true
 scanButton.alpha = 1f
 hvUdsButton.isEnabled = true
 hvUdsButton.alpha = 1f
 connectButton.text = ui("DISCONNECT\nOBD-II", "DISCONNECT\nOBD-II")
 }

 append("✓ Interface inicializada: $adapterKind")
 if (adapterIdentity.isNotBlank()) append("Identificação: ${clean(adapterIdentity)}")
 append("Transporte: ${if (usingBle) "Bluetooth Low Energy (BLE)" else "Bluetooth Classic / SPP"}")
 append("Protocol: ${clean(protocol)}")
 append("Número de protocol: ${if (protocolNumber.isBlank()) "unknown" else protocolNumber}")
 append(ui("Ready for PID SCAN.", "Ready for PID SCAN."))
 } catch (e: Exception) {
 runOnUiThread {
 setStatusText(ui("Status: connection error", "Status: connection error"))
 connectButton.text = ui(localized("CONNECT\nOBD-II", "CONNECT\nOBD-II"), "CONNECT\nOBD-II")
 scanButton.isEnabled = false
 scanButton.alpha = 0.55f
 hvUdsButton.isEnabled = false
 hvUdsButton.alpha = 0.55f
 }
 append(ui("✕ ERROR: ${e.message ?: "error unknown"}", "✕ ERROR: ${e.message ?: "unknown error"}"))
 }
 }
 }

 /**
 * Try the standard 11/29-bit CAN variants without sending any write or
 * diagnostic-control service. PID 0100 is a standard OBD-II capability
 * query and is used only as a transport validation.
 */
 private fun stabilizeCanProtocol(): String? {
 val candidates = listOf("6", "7", "8", "9")
 for (candidate in candidates) {
 try {
 elm("ATSP$candidate", 1800)
 elm("ATCAF1", 1000)
 elm("ATCFC1", 1000)
 val raw = elm("0100", 3000)
 if (isPositiveObdResponse(raw, 0x41, 0x00)) {
 return candidate
 }
 } catch (_: Exception) {
 // Continue with the next standard CAN variant.
 }
 }
 elm("ATSP0", 1200)
 return null
 }

 private fun isPositiveObdResponse(raw: String, service: Int, pid: Int): Boolean {
 val hex = raw.uppercase(Locale.US).replace(Regex("[^0-9A-F]"), "")
 val marker = String.format(Locale.US, "%02X%02X", service, pid)
 return hex.contains(marker)
 }

 private fun connectBle(device: BluetoothDevice) {
 if (Build.VERSION.SDK_INT >= 31 &&
 checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
 ) throw SecurityException("Permission Bluetooth required")

 bleConnectedLatch = CountDownLatch(1)
 bleServicesLatch = CountDownLatch(1)
 bleNotificationLatch = CountDownLatch(1)
 bleGatt = device.connectGatt(this, false, bleCallback, BluetoothDevice.TRANSPORT_LE)

 if (bleConnectedLatch?.await(8, TimeUnit.SECONDS) != true) {
 closeBle()
 throw IOException(ui("BLE: timeout while connecting to the adapter", "BLE: timeout while connecting to the adapter"))
 }
 if (bleServicesLatch?.await(8, TimeUnit.SECONDS) != true || bleWriteCharacteristic == null) {
 closeBle()
 throw IOException(ui("BLE: OBD/UART service not found", "BLE: OBD/UART service not found"))
 }
 // Notifications must be enabled before any OBD command is sent.
 if (bleNotifyCharacteristic != null &&
 bleNotificationLatch?.await(5, TimeUnit.SECONDS) != true) {
 closeBle()
 throw IOException(ui("BLE: notifications were not enabled", "BLE: notifications were not enabled"))
 }
 }

 private val bleCallback = object : BluetoothGattCallback() {
 override fun onConnectionStateChange(gatt: BluetoothGatt, statusCode: Int, newState: Int) {
 if (newState == BluetoothProfile.STATE_CONNECTED) {
 bleConnectedLatch?.countDown()
 if (Build.VERSION.SDK_INT >= 31 &&
 checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
 ) return
 gatt.discoverServices()
 } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
 bleConnectedLatch?.countDown()
 bleServicesLatch?.countDown()
 bleNotificationLatch?.countDown()
 bleWriteLatch?.countDown()
 }
 }

 override fun onServicesDiscovered(gatt: BluetoothGatt, statusCode: Int) {
 if (statusCode != BluetoothGatt.GATT_SUCCESS) {
 bleServicesLatch?.countDown()
 return
 }

 var write: BluetoothGattCharacteristic? = null
 var notify: BluetoothGattCharacteristic? = null

 for (service in gatt.services) {
 val serviceMatches = bleUartServices.contains(service.uuid)
 for (characteristic in service.characteristics) {
 val props = characteristic.properties
 val canWrite = props and BluetoothGattCharacteristic.PROPERTY_WRITE != 0 ||
 props and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0
 val canNotify = props and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0 ||
 props and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0

 if (canWrite && (serviceMatches || bleWriteUuids.contains(characteristic.uuid))) write = characteristic
 if (canNotify && (serviceMatches || bleNotifyUuids.contains(characteristic.uuid))) notify = characteristic
 }
 }

 bleWriteCharacteristic = write
 bleNotifyCharacteristic = notify

 if (notify != null && Build.VERSION.SDK_INT >= 31 &&
 checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
 ) {
 gatt.setCharacteristicNotification(notify, true)
 val descriptor = notify.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
 if (descriptor != null) {
 descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
 gatt.writeDescriptor(descriptor)
 }
 }
 bleServicesLatch?.countDown()
 }

 override fun onDescriptorWrite(
 gatt: BluetoothGatt,
 descriptor: BluetoothGattDescriptor,
 statusCode: Int
 ) {
 if (descriptor.uuid == UUID.fromString("00002902-0000-1000-8000-00805F9B34FB")) {
 bleNotificationLatch?.countDown()
 }
 }

 override fun onCharacteristicWrite(
 gatt: BluetoothGatt,
 characteristic: BluetoothGattCharacteristic,
 statusCode: Int
 ) {
 bleWriteLatch?.countDown()
 }

 override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
 characteristic.value?.forEach { bleRx.offer(it) }
 }

 @Deprecated("Deprecated in API 33")
 override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
 value.forEach { bleRx.offer(it) }
 }
 }

 private fun writeBle(data: ByteArray) {
 val gatt = bleGatt ?: throw IOException(ui("BLE not connected", "BLE not connected"))
 val characteristic = bleWriteCharacteristic ?: throw IOException(ui("BLE: write characteristic not found", "BLE: write characteristic not found"))
 if (Build.VERSION.SDK_INT >= 31 &&
 checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
 ) throw SecurityException("Permission Bluetooth required")

 // Android GATT writes are asynchronous. Serialise every command so a
 // new OBD request can never overwrite the previous characteristic write.
 val latch = CountDownLatch(1)
 bleWriteLatch = latch
 characteristic.value = data
 characteristic.writeType =
 if (characteristic.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0)
 BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
 else
 BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT

 if (!gatt.writeCharacteristic(characteristic)) {
 bleWriteLatch = null
 throw IOException("BLE: failure ao send command")
 }

 if (characteristic.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE == 0) {
 if (!latch.await(3, TimeUnit.SECONDS)) {
 bleWriteLatch = null
 throw IOException("BLE: time limite na escrita")
 }
 } else {
 // Give the controlread a short scheduling window before waiting for
 // its notification response.
 Thread.sleep(25)
 }
 bleWriteLatch = null
 }

 private fun closeBle() {
 try {
 if (Build.VERSION.SDK_INT >= 31 &&
 checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
 ) return
 bleGatt?.disconnect()
 bleGatt?.close()
 } catch (_: Exception) {}
 bleGatt = null
 bleWriteCharacteristic = null
 bleNotifyCharacteristic = null
 bleRx.clear()
 usingBle = false
 }

 private fun closeTransport() {
 HomeBdForegroundService.stop(this)
 try { socket?.close() } catch (_: Exception) {}
 socket = null
 input = null
 output = null
 closeBle()
 if (::connectButton.isInitialized) {
 runOnUiThread {
 connectButton.text = ui(localized("CONNECT\nOBD-II", "CONNECT\nOBD-II"), "CONNECT\nOBD-II")
 scanButton.text = ui(localized("SCAN PIDs", "SCAN PIDs"), localized("SCAN PIDs", "SCAN PIDs"))
 hvUdsButton.isEnabled = false
 hvUdsButton.alpha = 0.55f
 hasScannedOnce = false
 }
 }
 }

 private fun identifyAdapter(identity: String): String {
 val id = identity.uppercase(Locale.US)
 return when {
 id.contains("STN") -> "STN / OBDLink"
 id.contains("OBDLINK") || id.contains("SCANTOOL") -> "OBDLink / compatível"
 id.contains("ELM327") -> "ELM327 compatível"
 id.isBlank() -> "OBD-II Bluetooth"
 else -> "OBD-II compatível"
 }
 }

 private fun elm(cmd: String, timeout: Long = 2500): String {
 if (usingBle) return elmBle(cmd, timeout)

 val out = output ?: return ""
 val ins = input ?: return ""
 try {
 out.write((cmd + "\r").toByteArray(Charsets.US_ASCII))
 out.flush()
 } catch (e: Exception) {
 throw IOException("Failure ao send $cmd: ${e.message}", e)
 }

 val start = System.currentTimeMillis()
 val buf = ByteArray(4096)
 val data = StringBuilder()
 while (System.currentTimeMillis() - start < timeout) {
 if (ins.available() > 0) {
 val n = ins.read(buf)
 if (n > 0) data.append(String(buf, 0, n, Charsets.US_ASCII))
 if (data.contains(">")) break
 } else Thread.sleep(30)
 }
 return data.toString().replace("\r", "\n").replace(">", "").trim()
 }

 private fun elmBle(cmd: String, timeout: Long): String {
 if (bleWriteCharacteristic == null) return ""
 bleRx.clear()
 writeBle((cmd + "\r").toByteArray(Charsets.US_ASCII))
 val deadline = System.currentTimeMillis() + timeout
 val data = StringBuilder()
 while (System.currentTimeMillis() < deadline) {
 val remaining = deadline - System.currentTimeMillis()
 val b = bleRx.poll(minOf(remaining, 100), TimeUnit.MILLISECONDS)
 if (b != null) {
 data.append(b.toInt().and(0xFF).toChar())
 if (data.contains(">")) break
 }
 }
 return data.toString().replace("\r", "\n").replace(">", "").trim()
 }

 @Volatile
 private var liveDataRunning = false

 private fun isTransportConnected(): Boolean = usingBle && bleWriteCharacteristic != null || output != null

 private fun stopLiveData() {
 liveDataRunning = false
 }

 /**
 * Experimental read-only UDS discovery for hybrid/high-voltage ECUs.
 *
 * This deliberately does NOT assume a proprietary battery DID or scaling.
 * It probes a small, conservative DID window on common physical CAN
 * diagnostic request IDs and reports only positive 0x62 responses as RAW
 * hexadecimal payloads. No SecurityAccess, writes, coding or programming
 * services are sent. A positive response is evidence that an identifier is
 * readable; it is not interpreted as a battery value until its definition
 * is verified for the vehicle.
 */
 private fun runHvUdsDiscovery() {
 thread {
 if (!isTransportConnected()) {
 append(ui("⚠ OBD-II is not connected.", "⚠ OBD-II is not connected."))
 return@thread
 }
 runOnUiThread {
 hvUdsButton.isEnabled = false
 hvUdsButton.alpha = 0.55f
 setStatusText(ui("Status: HV/UDS SCAN running…", "Status: HV/UDS SCAN running…"))
 }

 append("=== HV / UDS DISCOVERY — READ-ONLY ===")
 append("Sem DIDs proprietários assumidos e sem commands de escrita.")
 append("1. Estabilizar CAN • 2. Descobrir ECUs • 3. Search responses UDS 0x62.")

 try {
 // Force the standard 11-bit 500 kbit/s CAN profile first. If it
 // fails, the normal transport remains available and the scan
 // reports the failure instead of fabricating an ECU.
 elm("ATSP6", 2000)
 elm("ATCAF1", 1200)
 elm("ATCFC1", 1200)
 elm("ATH1", 1000)

 val discovered = discoverCanEcus()
 if (discovered.isEmpty()) {
 append("· Noa ECU physical respondeu ao 0100 nos IDs 7E0–7EF.")
 append("· O gateway/adaptador pode not permitir esta descoberta por physical address.")
 } else {
 append("✓ ECUs OBD/CAN com response: ${discovered.joinToString(", ")}")
 }

 // Identification DIDs are intentionally limited to the public
 // standard/documented range. Do not turn an unknown response
 // into a battery measurement. A positive 0x62 is only recorded
 // as RAW data for later verification.
 val dids = (0xF180..0xF1FF).map { String.format(Locale.US, "%04X", it) }
 val targets = if (discovered.isEmpty()) (0x7E0..0x7E7).toList() else discovered
 var found = 0
 val results = mutableListOf<String>()

 for (requestId in targets) {
 val req = String.format(Locale.US, "%03X", requestId)
 val responseId = String.format(Locale.US, "%03X", requestId + 8)
 elm("ATSH$req", 800)
 elm("ATCRA$responseId", 800)

 for (did in dids) {
 val raw = elm("22$did", 750)
 val payload = extractUdsDidPayload(raw, did)
 if (payload.isNotBlank()) {
 found++
 val line = "• ECU $req • DID $did → $payload"
 results.add(line)
 append("✓ $line")
 }
 }
 }

 elm("ATCRA", 800)
 elm("ATH0", 800)
 // Keep the working CAN protocol if one was identified; only
 // fall back to AUTO when the adapter did not answer CAN at all.
 if (detectedProtocol.isBlank() || detectedProtocol == "0") {
 elm("ATSP0", 1200)
 detectedProtocol = elm("ATDPN", 1200).trim().uppercase().removePrefix("A")
 }

 runOnUiThread {
 liveDataAppend("\n=== HV / UDS DISCOVERY ===\n")
 liveDataAppend("• ECUs descobertas: ${if (discovered.isEmpty()) "nonea" else discovered.joinToString(", ")}\n")
 if (results.isEmpty()) {
 liveDataAppend("• No response UDS positive na janela F180–F1FF.\n")
 liveDataAppend("• Isto does not prove que o BMS not seja acessível; may use outro address, gateway or session.\n")
 } else {
 liveDataAppend("• $found response(s) UDS found(s).\n")
 results.forEach { liveDataAppend(it + "\n") }
 liveDataAppend("• Valuees displayed como RAW; not yet são converted para SOC, kW ou kWh.\n")
 }
 setStatusText(ui("Status: CONNECTED • HV/UDS SCAN completed", "Status: CONNECTED • HV/UDS SCAN completed"))
 hvUdsButton.isEnabled = true
 hvUdsButton.alpha = 1f
 }
 } catch (e: Exception) {
 append(ui("✕ HV/UDS: ${e.message ?: "error unknown"}", "✕ HV/UDS: ${e.message ?: "unknown error"}"))
 try { elm("ATCRA", 800); elm("ATH0", 800) } catch (_: Exception) {}
 runOnUiThread {
 setStatusText(ui("Status: CONNECTED • HV/UDS SCAN error", "Status: CONNECTED • HV/UDS SCAN error"))
 hvUdsButton.isEnabled = true
 hvUdsButton.alpha = 1f
 }
 }
 append("=== FIM HV / UDS DISCOVERY ===")
 append("=== GPS / TELEMÁTICA DISCOVERY — READ-ONLY ===")
 append("Sem coordenadas ou DIDs GPS assumidos.")
 append("Search module de telemática apenas através de responses UDS confirmadas.")
 append("=== FIM GPS / TELEMÁTICA DISCOVERY ===")
 }
 }

 private fun discoverCanEcus(): List<Int> {
 val found = mutableListOf<Int>()
 for (requestId in 0x7E0..0x7EF) {
 val req = String.format(Locale.US, "%03X", requestId)
 val responseId = String.format(Locale.US, "%03X", requestId + 8)
 elm("ATSH$req", 600)
 elm("ATCRA$responseId", 600)
 val raw = elm("0100", 1200)
 if (isPositiveObdResponse(raw, 0x41, 0x00)) {
 found.add(requestId)
 append("✓ ECU descoberta: $req → $responseId")
 }
 }
 elm("ATCRA", 700)
 return found
 }

 private fun extractUdsDidPayload(raw: String, did: String): String {
 val hex = raw.uppercase(Locale.US).replace(Regex("[^0-9A-F]"), "")
 val marker = "62${did.uppercase(Locale.US)}"
 val start = hex.indexOf(marker)
 if (start < 0) return ""
 val dataStart = start + marker.length
 if (dataStart >= hex.length) return ""
 // Limit to the first 64 bytes of payload to keep logs manageable.
 val end = minOf(hex.length, dataStart + 128)
 return hex.substring(dataStart, end)
 }

 private fun runScanner() {
 thread {
 if (!isTransportConnected()) {
 append(ui("⚠ OBD-II is not connected.", "⚠ OBD-II is not connected."))
 return@thread
 }

 if (liveDataRunning) {
 liveDataRunning = false
 Thread.sleep(250)
 }

 runOnUiThread {
 setStatusText(ui("Status: OBD-II SCAN running…", "Status: OBD-II SCAN running…"))
 scanButton.isEnabled = false
 scanButton.alpha = 0.55f
 }

 append("=== SCAN OBD-II ===")
 append("A consultar PIDs genéricos...")
 append("")

 val selectedProfile = manufacturerProfiles.getOrNull(manufacturerSpinner.selectedItemPosition)
 ?: manufacturerProfiles.first()

 append("Perfil: ${selectedProfile.name}")
 append("Modo: reading apenas")
 if (canActive) {
 append("CAN: active • protocol $detectedProtocol")
 append("ISO-TP: reading através do ELM327")
 } else {
 append("CAN: not identificado pelo adaptador/protocol atual")
 }
 append("")

 // Discover support once. LIVE DATA then repeatedly reads only these
 // confirmed PIDs, keeping the UI current without rescanning.
 val scanList = discoverSupportedStandardPids()

 runOnUiThread {
 liveDataLog.text = englishRuntimeText("LIVE DATA — ${selectedProfile.name}\n\n" +
 if (scanList.isEmpty()) {
 ui("No standard PID confirmed by the vehicle.\n\nHOMEBD does not invent data: it only displays parameters actually supported.\n", "No standard PID confirmed by the vehicle.\n\nHOMEBD does not invent data: it only displays parameters actually supported.\n")
 } else {
 ui("${scanList.size} supported standard PIDs detected.\n\n", "${scanList.size} supported standard PIDs detected.\n\n")
 }
 ) }

 if (scanList.isEmpty()) {
 append(ui("· No supported standard PID was confirmed.", "· No supported standard PID was confirmed."))
 runOnUiThread {
 setStatusText(ui("Status: CONNECTED • SCAN completed", "Status: CONNECTED • SCAN completed"))
 scanButton.isEnabled = true
 scanButton.alpha = 1f
 scanButton.text = if (hasScannedOnce) "RESCAN PIDs" else ui(localized("SCAN PIDs", "SCAN PIDs"), localized("SCAN PIDs", "SCAN PIDs"))
 }
 return@thread
 }

 if (canActive) {
 runCanReadOnlyChecks()
 prepareStandardObdSession()
 }

 append(ui("=== REAL-TIME LIVE DATA ===\nDo not start SCAN/DISCOVERY again during LIVE DATA. RESCAN is explicit.", "=== REAL-TIME LIVE DATA ===\nDo not start SCAN/DISCOVERY again during LIVE DATA. RESCAN is explicit."))
 append(ui("Continuous automatic reading • approximate interval 1 s", "Continuous automatic reading • approximate interval 1 s"))
 runOnUiThread {
 setStatusText(ui("Status: CONNECTED • LIVE DATA • real time", "Status: CONNECTED • LIVE DATA • real time"))
 scanButton.isEnabled = true
 scanButton.alpha = 1f
 hvUdsButton.isEnabled = true
 hvUdsButton.alpha = 1f
 hasScannedOnce = true
 scanButton.text = "RESCAN PIDs"
 }

 liveDataRunning = true

 // O ELM327 é um transporte serial: read os 36 PIDs em sequência em
 // cada ciclo torna impossível que os parâmetros dinâmicos cheguem
 // to Home Assistant em ~1 s. Os PIDs rápidos são lidos in all cycles
 // ciclos; os restantes são intercalados, um por ciclo.
 // Keep the high-value dashboard parameters in the fast lane.
 // Fewer serial ELM327 requests mean the first telemetry batch
 // reaches Home Assistant much sooner.
 val fastLivePids = setOf(
 "010C", // Engine RPM
 "010D", // Vehicle speed
 "0105", // Coolant temperature
 "0111", // Throttle position
 "0104", // Engine load
 "0142" // Control module voltage
 )
 val fastList = scanList.filter { fastLivePids.contains(it.first.uppercase()) }
 val slowList = scanList.filterNot { fastLivePids.contains(it.first.uppercase()) }
 val latestValues = linkedMapOf<String, String>()
 var slowIndex = 0

 while (liveDataRunning && isTransportConnected()) {
 try {
 val readList = buildList {
 addAll(if (fastList.isNotEmpty()) fastList else scanList.take(6))
 if (slowList.isNotEmpty()) {
 add(slowList[slowIndex % slowList.size])
 slowIndex++
 }
 }.distinctBy { it.first }

 var liveFuelRateLph: Double? = null
 var liveSpeedKmh: Double? = null
 var liveFuelType: String? = null

 for ((pid, label) in readList) {
 if (!liveDataRunning || !isTransportConnected()) break

 val raw = readObdPidReliable(pid)
 val result = if (raw.isBlank()) {
 ui("· NO DATA — no valid response 41 ${pid.substring(2).uppercase()}", "· NO DATA — no valid response 41 ${pid.substring(2).uppercase()}")
 } else {
 decodeObdPid(pid, raw)
 }

 latestValues[pid] = result
 liveDashboardValues[label] = result
 updateVehicleConsumption()
 result.substringBefore(" ").replace(",", ".").toFloatOrNull()?.let { numeric ->
 val history = liveDashboardHistory.getOrPut(label) { mutableListOf() }
 history.add(numeric)
 if (history.size > 36) history.removeAt(0)
 }
 homeAssistantBridge.publishPid(pid, label, result, flushNow = false)

 if (pid.equals("015E", ignoreCase = true)) {
 liveFuelRateLph = result.substringBefore(" ")
 .replace(",", ".").toDoubleOrNull()
 }
 if (pid.equals("0151", ignoreCase = true)) liveFuelType = result.trim()
 if (pid.equals("010D", ignoreCase = true)) {
 liveSpeedKmh = result.substringBefore(" ")
 .replace(",", ".").toDoubleOrNull()
 }
 }

 // Publish the fast lane immedaytely. This removes the
 // latency caused by waiting for the slow/background PID.
 homeAssistantBridge.flush()

 // Keep the complete dashboard populated with the most recent
 // value of every PID, while only querying a small dynamic set
 // on each fast cycle.
 val lines = scanList.map { (pid, label) ->
 val value = latestValues[pid]
 ?: ui("· Waiting for first reading", "· Waiting for first reading")
 "• $label: $value"
 }.toMutableList()

 liveFuelRateLph?.let { fuelRate ->
 lines.add(
 ui("• Fuel consumption: ", "• Fuel consumption: ") +
 if (liveSpeedKmh != null && liveSpeedKmh!! > 0.0) {
 "%.2f L/100 km".format(
 Locale.US,
 fuelRate * 100.0 / liveSpeedKmh!!
 )
 } else {
 ui("— L/100 km (vehicle stationary)", "— L/100 km (vehicle stationary)")
 }
 )
 }

 val electricalVehicle =
 liveFuelType?.contains("Electric", ignoreCase = true) == true ||
 liveFuelType?.contains("Bifuel electric", ignoreCase = true) == true

 if (electricalVehicle) {
 lines.add(ui("• Electric consumption: Not available via standard OBD-II", "• Electric consumption: Not available via standard OBD-II"))
 lines.add(ui("• Electric power: Not available via standard OBD-II", "• Electric power: Not available via standard OBD-II"))
 }

 val header = "LIVE DATA — ${selectedProfile.name}\n\n" +
 ui("${scanList.size} supported standard PIDs detected.\nDynamic update • fast parameters ≈ 1 s\n\n", "${scanList.size} supported standard PIDs detected.\nDynamic update • fast parameters ≈ 1 s\n\n")

 runOnUiThread {
 if (liveDataRunning) {
 val oldScrollY = liveDataScroll.scrollY
 liveDataLog.text = englishRuntimeText(header + lines.joinToString("\n"))
 renderGroupedLiveData(header, lines)
 renderLiveDashboard()
 liveDataContainer.post {
 liveDataScroll.scrollTo(0, oldScrollY.coerceAtMost(liveDataContainer.height))
 }
 }
 }

 // Short guard interval. The ELM327 serial transaction itself
 // remains the main pacing mechanism.
 Thread.sleep(75)
 } catch (e: Exception) {
 if (liveDataRunning) append(ui("⚠ LIVE DATA: ${e.message ?: "error de reading"}", "⚠ LIVE DATA: ${e.message ?: "reading error"}"))
 Thread.sleep(600)
 }
 }

 runOnUiThread {
 hvUdsButton.isEnabled = isTransportConnected()
 hvUdsButton.alpha = if (isTransportConnected()) 1f else 0.55f
 setStatusText(if (isTransportConnected())
 ui("Status: CONNECTED • LIVE DATA stopped", "Status: CONNECTED • LIVE DATA stopped")
 else
 ui("Status: disconnected", "Status: disconnected"))
 scanButton.isEnabled = isTransportConnected()
 scanButton.alpha = if (isTransportConnected()) 1f else 0.55f
 connectButton.text = if (isTransportConnected()) ui("DISCONNECT\nOBD-II", "DISCONNECT\nOBD-II") else ui("CONNECT\nOBD-II", "CONNECT\nOBD-II")
 }
 }
 }

 /**
 * Read-only CAN/ISO-TP checks.
 *
 * The ELM327 handles ISO 15765-4 segmentation/flow-control for normal
 * OBD-II requests. No ECU write service (2E/31/etc.) is sent here.
 */
 /**
 * Reads the standard Mode 01 supported-PID bitmaps first, then requests
 * only PIDs the vehicle reports as supported. This keeps every manufacturer
 * profile standards-based without copying proprietary manufacturer maps.
 */

 private val homeAssistantPrefs by lazy {
 getSharedPreferences("homebd_home_assistant", MODE_PRIVATE)
 }

 private fun homeAssistantUrl(): String =
 homeAssistantPrefs.getString("url", "")?.trim().orEmpty()

 private fun homeAssistantToken(): String =
 homeAssistantPrefs.getString("token", "")?.trim().orEmpty()

 private fun validWebUrl(value: String): Boolean =
 value.startsWith("http://") || value.startsWith("https://")

 private fun configureHomeAssistantLink() {
 if (!isActivityUsable()) return
 try {
 val urlInput = EditText(this).apply {
 hint = ui("Home Assistant address (https://...)", "Home Assistant address (https://...)")
 setText(homeAssistantUrl())
 textSize = 14f
 inputType = android.text.InputType.TYPE_CLASS_TEXT or
 android.text.InputType.TYPE_TEXT_VARIATION_URI
 }
 val tokenInput = EditText(this).apply {
 hint = ui("Home Assistant access token", "Home Assistant access token")
 setText(homeAssistantToken())
 textSize = 14f
 inputType = android.text.InputType.TYPE_CLASS_TEXT or
 android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
 }
 val box = LinearLayout(this).apply {
 orientation = LinearLayout.VERTICAL
 setPadding(dp(20), dp(4), dp(20), 0)
 addView(urlInput, LinearLayout.LayoutParams(-1, dp(52)))
 addView(tokenInput, LinearLayout.LayoutParams(-1, dp(52)))
 }
 AlertDialog.Builder(this)
 .setTitle("HOMEBD • Home Assistant")
 .setMessage(ui("HOMEBD communicates exclusively with the integration through a persistent WebSocket connection.", "HOMEBD communicates exclusively with the integration through a persistent WebSocket connection."))
 .setView(box)
 .setNegativeButton(ui("CANCEL", "CANCEL"), null)
 .setPositiveButton(ui(getString(R.string.save_and_connect), "SAVE & CONNECT")) { _, _ ->
 val endpoint = urlInput.text.toString().trim().trimEnd('/')
 val token = tokenInput.text.toString().trim()
 if (!validWebUrl(endpoint) || token.isBlank()) {
 Toast.makeText(this, ui("Enter the Home Assistant address and access token.", "Enter the Home Assistant address and access token."), Toast.LENGTH_LONG).show()
 return@setPositiveButton
 }
 homeAssistantPrefs.edit()
 .putString("url", endpoint)
 .putString("token", token)
 .remove("local_url")
 .remove("external_url")
 .apply()
 homeAssistantBridge.save(endpoint, token)
 homeAssistantStatusView.text = ui("Home Assistant · connecting…", "Home Assistant · connecting…")
 homeAssistantConnectButton.isEnabled = false
 homeAssistantBridge.connect { ok, msg ->
 safeUi {
 homeAssistantConnectButton.isEnabled = true
 homeAssistantStatusView.text = if (ok) ui("Home Assistant · WebSocket · connected", "Home Assistant · WebSocket · connected") else "Home Assistant · ${englishRuntimeText(msg)}"
 homeAssistantConnectButton.text = if (ok) ui("HOME\nASSISTANT", "HOME\nASSISTANT") else ui(localized("HOME\nASSISTANT", "HOME\nASSISTANT"), "HOME\nASSISTANT")
 append(if (ok) "✓ $msg" else "⚠ $msg")
 }
 }
 }
 .show()
 } catch (t: Throwable) {
 Toast.makeText(this, ui("Unable to configure Home Assistant.", "Unable to configure Home Assistant."), Toast.LENGTH_LONG).show()
 }
 }

 private fun openHomeAssistant() {
 try {
 if (!isActivityUsable()) return
 val url = homeAssistantUrl()
 if (url.isBlank()) {
 configureHomeAssistantLink()
 return
 }
 openWebUrl(url)
 } catch (_: Throwable) {
 Toast.makeText(this, ui("Unable to open Home Assistant.", "Unable to open Home Assistant."), Toast.LENGTH_LONG).show()
 }
 }

 private fun openWebUrl(value: String) {
 if (!validWebUrl(value)) {
 configureHomeAssistantLink()
 return
 }
 try {
 startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(value)))
 } catch (_: Exception) {
 Toast.makeText(this, ui("Unable to open Home Assistant.", "Unable to open Home Assistant."), Toast.LENGTH_LONG).show()
 }
 }

 private fun showExportOptions(live: Boolean) {
 val options = if (live) {
 arrayOf("Live Data (TXT)", "Live Data (CSV)", "Share current Live Data")
 } else {
 arrayOf("Diagnostics (TXT)", "Diagnostics (CSV)", "Share current Diagnostics")
 }
 AlertDialog.Builder(this)
 .setTitle(if (live) "Export Live Data" else "Export Diagnostics")
 .setItems(options) { _, which ->
 val text = if (live) liveDataLog.text.toString() else log.text.toString()
 if (text.isBlank()) {
 Toast.makeText(this, "There is no data to export", Toast.LENGTH_SHORT).show()
 return@setItems
 }
 val label = if (live) "LIVE_DATA" else "DIAGNOSTICS"
 when (which) {
 0 -> exportText(label, text, if (live) 101 else 102)
 1 -> exportText(label, text.lines().joinToString(",\n") { it.replace(",", ";") }, if (live) 101 else 102)
 2 -> shareText(label, text)
 }
 }
 .setNegativeButton("CANCEL", null)
 .show()
 }

 private fun shareText(label: String, text: String) {
 if (text.isBlank()) {
 Toast.makeText(this, "There is no data to share", Toast.LENGTH_SHORT).show()
 return
 }
 try {
 startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
 type = "text/plain"
 putExtra(Intent.EXTRA_SUBJECT, "HOMEBD $label")
 putExtra(Intent.EXTRA_TEXT, text)
 }, "Share HOMEBD data"))
 } catch (_: Throwable) {
 Toast.makeText(this, "Unable to share data", Toast.LENGTH_LONG).show()
 }
 }

 private fun numericLive(labelPart: String): Float? {
 val entry = liveDashboardValues.entries.firstOrNull { it.key.contains(labelPart, true) } ?: return null
 return entry.value.substringBefore(" ").replace(",", ".").toFloatOrNull()
 }

 private fun numericLiveByPatterns(patterns: List<String>): Float? {
 val entry = liveDashboardValues.entries.firstOrNull { entry ->
 patterns.any { entry.key.contains(it, true) }
 } ?: return null
 val raw = entry.value.trim()
 val number = raw.substringBefore(" ").replace(",", ".").toFloatOrNull() ?: return null
 return if (raw.contains("mW", true)) number / 1_000_000f
 else if (raw.contains("W", true) && !raw.contains("kW", true)) number / 1000f
 else number
 }

 private fun updateVehicleConsumption() {
 if (!::vehicleFuelConsumptionView.isInitialized || !::vehicleElectricConsumptionView.isInitialized) return

 val speed = numericLive("Vehicle speed")
 val fuelRate = numericLiveByPatterns(listOf("engine fuel rate", "fuel rate"))
 val fuelText = if (fuelRate != null && speed != null && speed > 0.1f) {
  "%.2f L/100 km".format(Locale.US, fuelRate * 100f / speed)
 } else "— L/100 km"

 // Instantaneous electric consumption:
 // kWh/100 km = electrical power (kW) × 100 / vehicle speed (km/h).
 // If a direct power PID is unavailable, estimate power from voltage × current.
 var electricPowerKw = numericLiveByPatterns(
  listOf("electric power", "battery power", "hv power", "traction power", "motor power")
 )
 if (electricPowerKw == null) {
  val voltage = numericLiveByPatterns(listOf("control voltage", "battery voltage", "system voltage"))
  val current = numericLiveByPatterns(listOf("battery current", "motor current", "traction current"))
  if (voltage != null && current != null) {
   electricPowerKw = (voltage * kotlin.math.abs(current)) / 1000f
  }
 }
 val electricText = if (electricPowerKw != null && electricPowerKw > 0f && speed != null && speed > 0.1f) {
  "%.2f kWh/100 km".format(Locale.US, electricPowerKw * 100f / speed)
 } else "— kWh/100 km"

 vehicleFuelConsumptionView.text = "FUEL  $fuelText"
 vehicleElectricConsumptionView.text = "ELECTRIC  $electricText"
 }

 private fun gaugeCard(title: String, value: String, progress: Int, unit: String): LinearLayout {
 val card = LinearLayout(this).apply {
 orientation = LinearLayout.VERTICAL
 setPadding(dp(10), dp(8), dp(10), dp(8))
 background = GradientDrawable().apply {
 setColor(Color.rgb(17, 34, 48))
 cornerRadius = dp(10).toFloat()
 setStroke(dp(1), Color.rgb(35, 70, 94))
 }
 }
 card.addView(TextView(this).apply {
 text = title
 textSize = 11f
 setTextColor(Color.LTGRAY)
 }, LinearLayout.LayoutParams(-1, dp(24)))
 card.addView(TextView(this).apply {
 text = value
 textSize = 21f
 setTextColor(Color.WHITE)
 gravity = Gravity.CENTER
 }, LinearLayout.LayoutParams(-1, dp(42)))
 val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
 max = 100
 this.progress = progress.coerceIn(0, 100)
 progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(0, 157, 245))
 progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(35, 53, 68))
 }
 card.addView(bar, LinearLayout.LayoutParams(-1, dp(5)))
 card.addView(TextView(this).apply {
 text = unit
 textSize = 9f
 setTextColor(Color.GRAY)
 gravity = Gravity.END
 }, LinearLayout.LayoutParams(-1, dp(18)))
 return card
 }

 private fun renderLiveDashboard() {
 if (!::liveDashboardContainer.isInitialized) return
 liveDashboardContainer.removeAllViews()
 val rpm = numericLive("RPM")
 val speed = numericLive("Vehicle speed")
 val coolant = numericLive("coolant")
 val throttle = numericLive("throttle")
 val load = numericLive("Engine load")
 val voltage = numericLive("voltage")

 val grid = LinearLayout(this).apply {
 orientation = LinearLayout.VERTICAL
 }
 fun row(vararg cards: LinearLayout) {
 val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
 cards.forEachIndexed { i, c ->
 r.addView(c, LinearLayout.LayoutParams(0, dp(118), 1f).apply {
 setMargins(if (i == 0) 0 else dp(3), dp(3), if (i == cards.lastIndex) 0 else dp(3), dp(3))
 })
 }
 grid.addView(r, LinearLayout.LayoutParams(-1, dp(124)))
 }
 row(
 gaugeCard("Engine RPM", rpm?.let { "%.0f rpm".format(Locale.US, it) } ?: "—", ((rpm ?: 0f) / 1800f * 100).toInt(), "0–1800 rpm"),
 gaugeCard("Vehicle Speed", speed?.let { "%.0f km/h".format(Locale.US, it) } ?: "—", ((speed ?: 0f) / 130f * 100).toInt(), "0–130 km/h")
 )
 row(
 gaugeCard("Coolant Temp", coolant?.let { "%.0f °C".format(Locale.US, it) } ?: "—", (((coolant ?: 0f) / 120f) * 100).toInt(), "0–120 °C"),
 gaugeCard("Throttle", throttle?.let { "%.1f %%".format(Locale.US, it) } ?: "—", throttle?.toInt() ?: 0, "0–100 %")
 )
 row(
 gaugeCard("Engine Load", load?.let { "%.1f %%".format(Locale.US, it) } ?: "—", load?.toInt() ?: 0, "0–100 %"),
 gaugeCard("Control Voltage", voltage?.let { "%.2f V".format(Locale.US, it) } ?: "—", (((voltage ?: 0f) / 16f) * 100).toInt(), "0–16 V")
 )
 liveDashboardContainer.addView(grid, LinearLayout.LayoutParams(-1, -2))

 val hint = TextView(this).apply {
 text = if (liveDashboardValues.isEmpty()) "Connect the OBD-II adapter and run SCAN PIDs to start real-time gauges." else "Real-time telemetry • fast parameters target ≈ 1 s • READ-ONLY"
 textSize = 11f
 setTextColor(Color.LTGRAY)
 gravity = Gravity.CENTER
 setPadding(dp(8), dp(6), dp(8), dp(6))
 }
 liveDashboardContainer.addView(hint, LinearLayout.LayoutParams(-1, dp(42)))

 val graphText = buildString {
 append("REAL-TIME GRAPHS\n\n")
 listOf("RPM", "Vehicle speed", "coolant", "throttle", "Engine load", "voltage").forEach { key ->
 val history = liveDashboardHistory.entries.firstOrNull { it.key.contains(key, true) }?.value ?: emptyList()
 append(String.format("%-16s ", key.take(15)))
 if (history.isEmpty()) append("──────── —\n")
 else {
 val min = history.minOrNull() ?: 0f
 val max = history.maxOrNull() ?: min + 1f
 history.takeLast(24).forEach { v ->
 val n = if (max > min) ((v - min) / (max - min) * 7).toInt().coerceIn(0, 7) else 3
 append("▁▂▃▄▅▆▇█"[n])
 }
 append("\n")
 }
 }
 }
 liveGraphsScroll.removeAllViews()
 liveGraphsScroll.addView(TextView(this).apply {
 text = graphText
 textSize = 12f
 setTextColor(Color.LTGRAY)
 typeface = android.graphics.Typeface.MONOSPACE
 setPadding(dp(10), dp(10), dp(10), dp(10))
 }, ViewGroup.LayoutParams(-1, -2))
 }

 private fun readDiagnosticTroubleCodes() {
 thread {
 if (!isTransportConnected()) {
 append("⚠ OBD-II is not connected.")
 return@thread
 }
 setStatusText("Status: READING DIAGNOSTIC CODES…")
 append("=== DIAGNOSTIC TROUBLE CODES ===")
 val raw = elm("03", 3500)
 val hex = raw.uppercase(Locale.US).replace(Regex("[^0-9A-F]"), "")
 val marker = hex.indexOf("43")
 val data = if (marker >= 0) hex.substring(marker + 2) else ""
 val codes = mutableListOf<String>()
 var i = 0
 while (i + 3 < data.length) {
 val b1 = data.substring(i, i + 2).toIntOrNull(16) ?: 0
 val b2 = data.substring(i + 2, i + 4).toIntOrNull(16) ?: 0
 i += 4
 if (b1 == 0 && b2 == 0) continue
 val type = when ((b1 shr 6) and 0x03) { 0 -> 'P'; 1 -> 'C'; 2 -> 'B'; else -> 'U' }
 val digit = ((b1 shr 4) and 0x03).toString()
 val code = "$type$digit%02X%02X".format(Locale.US, b1 and 0x0F, b2)
 codes.add(code)
 }
 if (codes.isEmpty()) append("✓ No diagnostic trouble codes reported by standard OBD-II.")
 else codes.forEachIndexed { idx, code -> append("⚠ ${idx + 1}. $code") }
 append("READ-ONLY: HOMEBD does not clear DTCs or write to the vehicle ECU.")
 setStatusText("Status: CONNECTED • DIAGNOSTICS READY")
 }
 }

 private fun renderGroupedLiveData(header: String, lines: List<String>) {
 liveDataContainer.removeAllViews()

 val intro = TextView(this).apply {
 text = header.trimEnd()
 textSize = 13f
 setTextColor(Color.LTGRAY)
 setPadding(dp(6), dp(4), dp(6), dp(8))
 }
 liveDataContainer.addView(intro, LinearLayout.LayoutParams(-1, -2))

 val groups = linkedMapOf(
 "MOTOR" to mutableListOf<String>(),
 ui(getString(R.string.temperatures), "TEMPERATURES") to mutableListOf<String>(),
 ui(getString(R.string.fuel), "FUEL") to mutableListOf<String>(),
 ui("INTAKE / THROTTLE", "INTAKE / THROTTLE") to mutableListOf<String>(),
 ui(getString(R.string.electric_hybrid), "ELECTRIC / HYBRID") to mutableListOf<String>(),
 "EMISSÕES" to mutableListOf<String>(),
 ui(localized(getString(R.string.diagnostics), "DIAGNOSTICS"), "DIAGNOSTICS") to mutableListOf<String>()
 )

 fun addGroup(name: String, line: String) { groups[name]?.add(line) }
 lines.forEach { line ->
 val l = line.lowercase(Locale.getDefault())
 when {
 listOf("temperature", "temperature", "catalisador", "arrefecimento", "admissão", "intake air", "óleo", "oil", "exterior").any { l.contains(it) } -> addGroup(ui(getString(R.string.temperatures), "TEMPERATURES"), line)
 listOf("fuel", "fuel", "fuel trim", "pressure de fuel", "fuel pressure", "injeção").any { l.contains(it) } -> addGroup(ui(getString(R.string.fuel), "FUEL"), line)
 listOf("acereadador", "throttle", "borboleta", "map:", "maf", "pressure de admissão", "intake").any { l.contains(it) } -> addGroup(ui("INTAKE / THROTTLE", "INTAKE / THROTTLE"), line)
 listOf("o2", "lambda", "nox", "emission", "emissões", "egr", "particulate", "dpf", "catalyst").any { l.contains(it) } -> addGroup("EMISSÕES", line)
 listOf("voltagem", "voltage", "potência elétrica", "consumption electric", "energia elétrica", "hybrid", "electric", "battery").any { l.contains(it) } -> addGroup(ui(getString(R.string.electric_hybrid), "ELECTRIC / HYBRID"), line)
 listOf("vin", "pid", "dtc", "diagnostics", "diagnostic", "ecu", "adaptador").any { l.contains(it) } -> addGroup(ui(localized(getString(R.string.diagnostics), "DIAGNOSTICS"), "DIAGNOSTICS"), line)
 else -> addGroup("MOTOR", line)
 }
 }

 groups.forEach { (name, items) ->
 if (items.isEmpty()) return@forEach
 val expanded = liveGroupExpanded.getOrPut(name) { true }
 val headerView = TextView(this).apply {
 text = (if (expanded) "▼ " else "▶ ") + name + " • ${items.size}"
 textSize = 12f
 setTextColor(Color.WHITE)
 setBackgroundColor(Color.rgb(45, 45, 45))
 gravity = Gravity.CENTER_VERTICAL
 setPadding(dp(8), dp(7), dp(8), dp(7))
 isClickable = true
 setOnClickListener {
 liveGroupExpanded[name] = !(liveGroupExpanded[name] ?: true)
 renderGroupedLiveData(header, lines)
 }
 }
 liveDataContainer.addView(headerView, LinearLayout.LayoutParams(-1, dp(34)).apply {
 setMargins(0, dp(3), 0, dp(1))
 })

 if (expanded) {
 val body = LinearLayout(this).apply {
 orientation = LinearLayout.VERTICAL
 setPadding(dp(4), dp(2), dp(4), dp(4))
 }
 items.forEach { item ->
 val lineView = TextView(this).apply {
 text = item
 textSize = 13f
 setTextColor(Color.LTGRAY)
 setPadding(dp(10), dp(5), dp(8), dp(5))
 isClickable = true
 setOnLongClickListener {
 val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
 clipboard.setPrimaryClip(ClipData.newPlainText("HOMEBD LIVE DATA", item))
 Toast.makeText(this@MainActivity, ui("Data copied", "Data copied"), Toast.LENGTH_SHORT).show()
 true
 }
 }
 body.addView(lineView, LinearLayout.LayoutParams(-1, -2))
 }
 body.setOnLongClickListener {
 val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
 clipboard.setPrimaryClip(ClipData.newPlainText("HOMEBD $name", items.joinToString("\n")))
 Toast.makeText(this, ui("$name copied", "$name copied"), Toast.LENGTH_SHORT).show()
 true
 }
 liveDataContainer.addView(body, LinearLayout.LayoutParams(-1, -2))
 }
 }
 }

 private fun prepareStandardObdSession() {
 if (!isTransportConnected()) return
 val protocol = detectedProtocol.trim().uppercase(Locale.US)
 if (protocol.isNotBlank() && protocol != "0") elm("ATSP$protocol", 1500)
 elm("ATCAF1", 1000)
 elm("ATCFC1", 1000)
 elm("ATH0", 1000)
 elm("ATCRA", 1000)
 elm("ATSH7DF", 1000)
 elm("ATAT1", 1000)
 }

 private fun discoverSupportedStandardPids(): List<Pair<String, String>> {
 prepareStandardObdSession()
 val blocks = listOf("0100", "0120", "0140", "0160", "0180", "01A0", "01C0")
 val supported = linkedSetOf<Int>()

 blocks.forEach { supportPid ->
 val raw = elm(supportPid, 3000)
 val bytes = obdPayloadBytes(raw, 0x41, supportPid.substring(2).toInt(16))
 if (bytes.size >= 4) {
 val bitmap = (bytes[0] shl 24) or (bytes[1] shl 16) or
 (bytes[2] shl 8) or bytes[3]
 val base = supportPid.substring(2).toInt(16) + 1
 for (bit in 0..31) {
 if ((bitmap and (1 shl (31 - bit))) != 0) {
 supported.add(base + bit)
 }
 }
 }
 }

 val result = pids.entries.filter { (pid, _) ->
 val value = pid.substring(2).toInt(16)
 value in supported && value !in setOf(0x20, 0x40, 0x60, 0x80, 0xA0, 0xC0)
 }.map { it.key to it.value }

 append(ui("✓ OBD-II capability: ${result.size} supported PID(s) detected.", "✓ OBD-II capability: ${result.size} supported PID(s) detected."))
 return result
 }

 private fun obdPayloadBytes(raw: String, service: Int, pid: Int): List<Int> {
 val hex = raw.uppercase().replace(Regex("[^0-9A-F]"), "")
 if (hex.length < 4) return emptyList()

 val bytes = ArrayList<Int>()
 var i = 0
 while (i + 1 < hex.length) {
 hex.substring(i, i + 2).toIntOrNull(16)?.let { bytes.add(it) }
 i += 2
 }

 // ELM327 pode devolver cabeçalhos CAN/ISO-TP e bytes de comprimento
 // antes de 41 <PID>. Localizar o par de response evita interpretar
 // esses bytes como parte do value do PID.
 for (index in 0 until bytes.size - 1) {
 if (bytes[index] == service && bytes[index + 1] == pid) {
 return bytes.drop(index + 2)
 }
 }
 return emptyList()
 }

 /**
 * Lê um PID OBD-II confirmado, com recuperação da session quando o
 * adaptador perde timerariamente o filtro/cabeçalho CAN.
 * Apenas responses positives 41 <PID> são aceites como data.
 */
 private fun readObdPidReliable(pid: String): String {
 val pidNum = pid.substring(2).toIntOrNull(16) ?: return ""
 repeat(2) { attempt ->
 val raw = elm(pid, 1800)
 if (obdPayloadBytes(raw, 0x41, pidNum).isNotEmpty()) return raw

 // Recuperar a session standard antes da segunda tentativa.
 if (attempt == 0 && isTransportConnected()) {
 prepareStandardObdSession()
 Thread.sleep(80)
 }
 }
 return ""
 }

 private fun decodeObdPid(pid: String, raw: String): String {
 val pidNum = pid.substring(2).toIntOrNull(16) ?: return classifyResponse(raw)
 val payload = obdPayloadBytes(raw, 0x41, pidNum)
 if (payload.isEmpty()) return classifyResponse(raw)

 fun u16(): Int = ((payload.getOrNull(0) ?: 0) shl 8) or (payload.getOrNull(1) ?: 0)
 fun u32(): Long = ((payload.getOrNull(0)?.toLong() ?: 0L) shl 24) or
 ((payload.getOrNull(1)?.toLong() ?: 0L) shl 16) or
 ((payload.getOrNull(2)?.toLong() ?: 0L) shl 8) or
 (payload.getOrNull(3)?.toLong() ?: 0L)
 fun pct(a: Int): String = "%.1f %%".format(Locale.US, a * 100.0 / 255.0)
 fun signedPct(a: Int): String = "%.1f %%".format(Locale.US, a * 100.0 / 128.0 - 100.0)
 fun temp(a: Int): String = "${a - 40} °C"

 return when (pid.uppercase()) {
 "0101" -> decodeMonitorStatus(payload)
 "0102" -> "DTC status: 0x${u16().toString(16).uppercase().padStart(4, '0')}"
 "0103" -> decodeFuelSystemStatus(payload.first())
 "0104" -> pct(payload.first())
 "0105", "010F", "0146", "015C" -> temp(payload.first())
 "0106", "0107", "0108", "0109", "012D", "0155", "0156", "0157", "0158" -> signedPct(payload.first())
 "010A" -> "${payload.first() * 3} kPa"
 "010B" -> "${payload.first()} kPa"
 "010C" -> "%.0f rpm".format(Locale.US, u16() / 4.0)
 "010D" -> "${payload.first()} km/h"
 "010E" -> "%.1f °".format(Locale.US, payload.first() / 2.0 - 64.0)
 "0110" -> "%.2f g/s".format(Locale.US, u16() / 100.0)
 "0111", "0145", "0147", "0148", "0149", "014A", "014B", "015A" -> pct(payload.first())
 "0112" -> decodeSecondaryAirStatus(payload.first())
 "0113", "011D" -> "Sensor presence bitmap: 0x${payload.first().toString(16).uppercase().padStart(2, '0')}"
 in setOf("0114", "0115", "0116", "0117", "0118", "0119", "011A", "011B") ->
 decodeOxygenVoltageTrim(payload)
 "011C" -> decodeObdStandard(payload.first())
 "011E" -> if (payload.first() and 1 == 1) "Active" else "Inactive"
 "011F" -> "${u16()} s (${u16() / 60} min)"
 "0120", "0140", "0160", "0180", "01A0", "01C0" -> "Supported PID bitmap: 0x${u32().toString(16).uppercase().padStart(8, '0')}"
 "0121", "0131" -> "${u16()} km"
 "0122" -> "%.0f kPa".format(Locale.US, u16() * 0.079)
 "0123" -> "${u16() * 10} kPa"
 in setOf("0124", "0125", "0126", "0127", "0128", "0129", "012A", "012B") -> decodeOxygenWideVoltage(payload)
 "012C" -> pct(payload.first())
 "012E" -> pct(payload.first())
 "012F" -> pct(payload.first())
 "0130" -> "${payload.first()} warm-ups"
 "0132" -> "${signedU16(payload) * 0.25} Pa"
 "0133" -> "${payload.first()} kPa"
 in setOf("0134", "0135", "0136", "0137", "0138", "0139", "013A", "013B") -> decodeOxygenWideVoltage(payload)
 "013C", "013D", "013E", "013F" -> "%.1f °C".format(Locale.US, u16() / 10.0 - 40.0)
 "0141" -> decodeMonitorStatus(payload)
 "0142" -> "%.3f V".format(Locale.US, u16() / 1000.0)
 "0143" -> "%.1f %%".format(Locale.US, u16() * 100.0 / 255.0)
 "0144" -> "%.3f ratio".format(Locale.US, u16() / 32768.0)
 "0145" -> pct(payload.first())
 "0146" -> temp(payload.first())
 "014C" -> pct(payload.first())
 "014D", "014E" -> "${u16()} min"
 "0151" -> decodeFuelType(payload.first())
 "0152" -> pct(payload.first())
 "0153" -> "%.3f kPa".format(Locale.US, u16() / 200.0)
 "0154" -> "${signedU16(payload)} Pa"
 "0159" -> "%.0f kPa".format(Locale.US, u16() * 10.0)
 "015B" -> pct(payload.first())
 "015C" -> temp(payload.first())
 "015D" -> "%.2f °".format(Locale.US, u16() / 128.0 - 210.0)
 "015E" -> "%.2f L/h".format(Locale.US, u16() / 20.0)
 "015F", "0161", "0162", "0163" -> "%.1f %% torque".format(Locale.US, payload.first() - 125.0)
 "0165" -> "%.1f mA".format(Locale.US, u16() * 0.001)
 "0166", "0167", "0168", "0169", "0184" -> temp(payload.first())
 "016A", "016E" -> pct(payload.first())
 "016B", "016F" -> "${u16()} kPa"
 "016C" -> "%.1f %%".format(Locale.US, payload.first() * 100.0 / 255.0)
 "016D" -> temp(payload.first())
 "0170", "0171", "0172" -> ui("Multi-byte data — not yesplified", "Multi-byte data — not yesplified")
 "0173" -> "${u16()} kPa"
 "0174" -> "${u16()} rpm"
 "0175", "0176", "0177", "0178", "0179", "017A", "017C" -> ui("Multi-byte data — not yesplified", "Multi-byte data — not yesplified")
 "017B", "017D", "017E", "017F" -> ui("Multi-byte data — not yesplified", "Multi-byte data — not yesplified")
 "0183", "01A1", "01A7", "01A8" -> ui("NOx: multi-byte data — not yesplified", "NOx: multi-byte data — not yesplified")
 "0185", "0186", "0187", "0188", "019A", "019D", "01A3" -> ui("Multi-byte data — not yesplified", "Multi-byte data — not yesplified")
 else -> "${payload.joinToString(" ") { "%02X".format(it) }} (raw)"
 }
 }

 private fun decodeMonitorStatus(p: List<Int>): String {
 if (p.size < 4) return "Monitor bitmap: ${p.joinToString(" ") { "%02X".format(it) }}"
 val mil = (p[0] and 0x80) != 0
 val dtcCount = p[0] and 0x7F
 val misfireReady = (p[1] and 0x01) != 0
 val fuelReady = (p[1] and 0x02) != 0
 return "MIL=${if (mil) "ON" else "OFF"} • DTC=$dtcCount • monitors=${if (misfireReady || fuelReady) "available" else "not reported"}"
 }

 private fun decodeFuelSystemStatus(code: Int): String = when (code) {
 0x01 -> "Open loop — insufficient engine temperature"
 0x02 -> "Closed loop — using oxygen sensor feedback"
 0x04 -> "Open loop — engine load / fuel cut"
 0x08 -> "Open loop — system fault"
 0x10 -> "Closed loop — fault with at least one sensor"
 else -> "Code 0x${code.toString(16).uppercase().padStart(2, '0')}"
 }

 private fun decodeSecondaryAirStatus(code: Int): String = when (code) {
 0x01 -> "Upstream of catalytic converter"
 0x02 -> "Downstream of catalytic converter"
 0x04 -> "Atmosphere"
 else -> "Code 0x${code.toString(16).uppercase().padStart(2, '0')}"
 }

 private fun decodeObdStandard(code: Int): String = when (code) {
 0x01 -> "OBD-II as defined by CARB"
 0x02 -> "OBD as defined by EPA"
 0x03 -> "OBD and OBD-II"
 0x04 -> "OBD-I"
 0x05 -> "Not intended for OBD"
 0x06 -> "EOBD"
 0x07 -> "EOBD and OBD-II"
 0x08 -> "EOBD and OBD"
 0x09 -> "EOBD, OBD and OBD-II"
 0x0A -> "JOBD"
 else -> "Standard code 0x${code.toString(16).uppercase().padStart(2, '0')}"
 }

 private fun decodeFuelType(code: Int): String = when (code) {
 0x01 -> "Gasoline"
 0x02 -> "Methanol"
 0x03 -> "Ethanol"
 0x04 -> "Diesel"
 0x05 -> "LPG"
 0x06 -> "CNG"
 0x07 -> "Propane"
 0x08 -> "Electric"
 0x09 -> "Bifuel gasoline"
 0x0A -> "Bifuel methanol"
 0x0B -> "Bifuel ethanol"
 0x0C -> "Bifuel LPG"
 0x0D -> "Bifuel CNG"
 0x0E -> "Bifuel propane"
 0x0F -> "Bifuel electric"
 0x10 -> "Bifuel electric + combustion"
 else -> "Fuel type code 0x${code.toString(16).uppercase().padStart(2, '0')}"
 }

 private fun decodeOxygenVoltageTrim(p: List<Int>): String {
 val voltage = p.getOrNull(0)?.times(0.005) ?: 0.0
 val trim = p.getOrNull(1)?.let { it * 100.0 / 128.0 - 100.0 }
 return if (trim == null) "%.3f V".format(Locale.US, voltage)
 else "%.3f V • trim %.1f %%".format(Locale.US, voltage, trim)
 }

 private fun signedU16(p: List<Int>): Int {
 if (p.size < 2) return 0
 val value = (p[0] shl 8) or p[1]
 return if ((value and 0x8000) != 0) value - 0x10000 else value
 }

 private fun decodeOxygenWideVoltage(p: List<Int>): String {
 if (p.size < 4) return ui(getString(R.string.insufficient_data), "Insufficient data")
 val ratioRaw = (p[0] shl 8) or p[1]
 val voltageRaw = (p[2] shl 8) or p[3]
 val ratio = ratioRaw * 2.0 / 65536.0
 val voltage = voltageRaw * 8.0 / 65536.0
 return "lambda %.3f • %.3f V".format(Locale.US, ratio, voltage)
 }

 private fun runCanReadOnlyChecks() {
 append("=== CAN READ-ONLY ===")
 append(ui("ISO-TP: query standard OBD-II identification", "ISO-TP: query standard OBD-II identification"))

 val selectedProfile = manufacturerProfiles.getOrNull(manufacturerSpinner.selectedItemPosition)
 when (selectedProfile?.name) {
 "Stellantis • Opel / Vauxhall", "Stellantis" -> runStellantisUdsReadOnly()
 "Renault / Dacia" -> runRenaultUdsReadOnly()
 "Volkswagen / Audi / SEAT / Škoda" -> runVagUdsReadOnly()
 "Ford" -> runFordUdsReadOnly()
 "Nissan / INFINITI" -> runNissanUdsReadOnly()
 "Tesla" -> runTeslaUdsReadOnly()
 "Subaru" -> runSubaruReadOnly()
 "Mitsubishi" -> runMitsubishiReadOnly()
 "Lexus" -> runLexusReadOnly()
 "Mazda" -> runMazdaReadOnly()
 "Isuzu" -> runIsuzuReadOnly()
 "BMW" -> runGenericManufacturerUdsReadOnly("BMW", listOf(UdsDid("F190", "VIN")))
 "Mercedes-Benz" -> runGenericManufacturerUdsReadOnly("Mercedes-Benz", listOf(UdsDid("F190", "VIN")))
 "Volvo" -> runGenericManufacturerUdsReadOnly("Volvo", listOf(UdsDid("F190", "VIN")))
 "Honda" -> runGenericManufacturerUdsReadOnly("Honda / Acura", listOf(UdsDid("F190", "VIN")))
 "Hyundai / Kia" -> runGenericManufacturerUdsReadOnly("Hyundai / Kia", listOf(UdsDid("F190", "VIN")))
 "Jaguar / Land Rover" -> runGenericManufacturerUdsReadOnly("Jaguar / Land Rover", listOf(UdsDid("F190", "VIN")))
 "Porsche" -> runGenericManufacturerUdsReadOnly("Porsche", listOf(UdsDid("F190", "VIN")))
 "Suzuki" -> runGenericManufacturerUdsReadOnly("Suzuki", listOf(UdsDid("F190", "VIN")))
 "Geely / Polestar" -> runGenericManufacturerUdsReadOnly("Geely / Polestar", listOf(UdsDid("F190", "VIN")))
 }

 // Universal discovery order (all vehicle queries remain READ-ONLY).
 append("=== DISCOVERY UNIVERSAL ===")
 append("1. OBD-II standard • 2. VIN • 3. HV/BMS • 4. GPS/Telemática • 5. LIVE DATA • 6. Home Assistant")
 append(ui("Profile: Automatic • no proprietary DIDs assumed", "Profile: Automatic • no proprietary DIDs assumed"))

 // Mode 09 PID 02: VIN. Retry because ELM327 adapters can occasionally
 // return only part of a multi-frame response on the first request.
 // A complete 17-character VIN is required before accepting the value.
 val vin = readCompleteVin()
 reportCanValue("VIN", if (vin.isNotBlank()) "VIN 17 chars" else "NO DATA", vin)

 // Mode 09 PID 04: calibration ID, when available.
 val calRaw = elm("0904", 5000)
 val cal = extractObdAscii(calRaw, 0x49, 0x04)
 reportCanValue("Calibration ID", calRaw, cal)

 // Mode 01 PID 00 is a standard CAN/OBD capability query.
 val pid00 = elm("0100", 3000)
 append("CAN 0100: ${classifyResponse(pid00)}")

 runOnUiThread {
 liveDataAppend(
 "• CAN: ${if (canActive) ui("ACTIVE / READ-ONLY", "ACTIVE / READ-ONLY") else ui("not available", "not available")}\\n"
 )
 if (vin.isNotBlank()) liveDataAppend("• VIN: $vin\\n")
 if (cal.isNotBlank()) liveDataAppend("• Calibration ID: $cal\\n")
 }
 }

 /**
 * Stellantis UDS READ-ONLY scanner.
 *
 * This does not unlock or bypass a Secure Gateway. It only sends UDS
 * ReadDataByIdentifier (0x22) requests to common 11-bit diagnostic
 * request IDs and accepts positive responses (0x62).
 */
 private fun runGenericManufacturerUdsReadOnly(name: String, dids: List<UdsDid>) {
 append("=== $name UDS READ-ONLY ===")
 append(ui("Allowed service: 0x22 ReadDataByIdentifier", "Allowed service: 0x22 ReadDataByIdentifier"))
 append(ui("Searching for ECUs on IDs 7E0–7E7…", "Searching for ECUs on IDs 7E0–7E7…"))
 append(ui("No proprietary map: standard configured DIDs only.", "No proprietary map: standard configured DIDs only."))

 elm("ATSP6", 2000)
 elm("ATCAF1", 1200)
 elm("ATCFC1", 1200)

 var found = 0
 for (requestId in 0x7E0..0x7E7) {
 val req = String.format(Locale.US, "%03X", requestId)
 val responseId = String.format(Locale.US, "%03X", requestId + 8)
 elm("ATSH$req", 1000)
 elm("ATCRA$responseId", 1000)
 for (did in dids) {
 val raw = elm("22${did.did}", 3000)
 val value = parseUdsDid(raw, did.did)
 if (value.isNotBlank()) {
 found++
 append("✓ ECU $req → ${did.label}: $value")
 runOnUiThread { liveDataAppend("• ECU $req — ${did.label}: $value\n") }
 }
 }
 }
 elm("ATCRA", 1000)
 elm("ATSP0", 1500)
 detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")
 if (found == 0) append("· No DID UDS $name respondeu.")
 else append("✓ $found reading(s) UDS $name obtida(s).")
 append("=== FIM $name UDS ===")
 }

 private fun runStellantisUdsReadOnly() {
 append("=== STELLANTIS UDS READ-ONLY ===")
 append(ui("Allowed service: 0x22 ReadDataByIdentifier", "Allowed service: 0x22 ReadDataByIdentifier"))
 append(ui("Searching for ECUs on IDs 7E0–7E7…", "Searching for ECUs on IDs 7E0–7E7…"))

 // ELM327: CAN 11-bit, automatic formatting and flow control.
 elm("ATSP6", 2000)
 elm("ATCAF1", 1200)
 elm("ATCFC1", 1200)

 var found = 0
 for (requestId in 0x7E0..0x7E7) {
 val req = String.format(Locale.US, "%03X", requestId)
 val responseId = String.format(Locale.US, "%03X", requestId + 8)

 // Restrict replies to the matching physical ECU response.
 elm("ATSH$req", 1000)
 elm("ATCRA$responseId", 1000)

 for (did in stellantisDids) {
 val raw = elm("22${did.did}", 3000)
 val value = parseUdsDid(raw, did.did)
 if (value.isNotBlank()) {
 found++
 append("✓ ECU $req → ${did.label}: $value")
 runOnUiThread {
 liveDataAppend("• ECU $req — ${did.label}: $value\n")
 }
 }
 }
 }

 // Return ELM to automatic protocol/headers for normal OBD-II use.
 elm("ATCRA", 1000)
 elm("ATSP0", 1500)
 detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

 if (found == 0) {
 append("· No DID UDS Stellantis respondeu.")
 append("· Isto pode meansr ECU not acessível, DID not suportdo ou SGW/rede a bloquear a reading.")
 } else {
 append("✓ $found reading(s) UDS obtida(s).")
 }
 append("=== FIM STELLANTIS UDS ===")
 }

 /**
 * Renault / Dacia UDS READ-ONLY scanner.
 *
 * Uses only standardized identification DIDs from the F18x/F19x range.
 * No security access, session switching, coding or programming is sent.
 */
 private fun runRenaultUdsReadOnly() {
 append("=== RENAULT / DACIA UDS READ-ONLY ===")
 append(ui("Allowed service: 0x22 ReadDataByIdentifier", "Allowed service: 0x22 ReadDataByIdentifier"))
 append("DIDs: identificação ECU standard ISO 14229")
 append(ui("Searching for ECUs on IDs 7E0–7E7…", "Searching for ECUs on IDs 7E0–7E7…"))

 elm("ATSP6", 2000)
 elm("ATCAF1", 1200)
 elm("ATCFC1", 1200)

 var found = 0
 for (requestId in 0x7E0..0x7E7) {
 val req = String.format(Locale.US, "%03X", requestId)
 val responseId = String.format(Locale.US, "%03X", requestId + 8)

 elm("ATSH$req", 1000)
 elm("ATCRA$responseId", 1000)

 for (did in renaultDids) {
 val raw = elm("22${did.did}", 3000)
 val value = parseUdsDid(raw, did.did)
 if (value.isNotBlank()) {
 found++
 append("✓ ECU $req → ${did.label}: $value")
 runOnUiThread {
 liveDataAppend("• ECU $req — ${did.label}: $value\n")
 }
 }
 }
 }

 elm("ATCRA", 1000)
 elm("ATSP0", 1500)
 detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

 if (found == 0) {
 append("· No DID UDS Renault / Dacia respondeu.")
 append("· Isto pode meansr ECU not acessível, DID not suportdo ou rede/SGW a bloquear a reading.")
 } else {
 append("✓ $found reading(s) UDS obtida(s).")
 }
 append("=== FIM RENAULT / DACIA UDS ===")
 }

 /**
 * Volkswagen / Audi / SEAT / Škoda UDS READ-ONLY scanner.
 *
 * Only UDS ReadDataByIdentifier (0x22) is transmitted. No security access,
 * coding, adaptation, routine control or ECU programming is attempted.
 */
 private fun runVagUdsReadOnly() {
 append("=== VAG UDS READ-ONLY ===")
 append("Volkswagen / Audi / SEAT / Škoda")
 append(ui("Allowed service: 0x22 ReadDataByIdentifier", "Allowed service: 0x22 ReadDataByIdentifier"))
 append(ui("Searching for ECUs on IDs 7E0–7E7…", "Searching for ECUs on IDs 7E0–7E7…"))

 elm("ATSP6", 2000)
 elm("ATCAF1", 1200)
 elm("ATCFC1", 1200)

 var found = 0
 for (requestId in 0x7E0..0x7E7) {
 val req = String.format(Locale.US, "%03X", requestId)
 val responseId = String.format(Locale.US, "%03X", requestId + 8)

 elm("ATSH$req", 1000)
 elm("ATCRA$responseId", 1000)

 for (did in vagDids) {
 val raw = elm("22${did.did}", 3000)
 val value = parseUdsDid(raw, did.did)
 if (value.isNotBlank()) {
 found++
 append("✓ ECU $req → ${did.label}: $value")
 runOnUiThread {
 liveDataAppend("• ECU $req — ${did.label}: $value\n")
 }
 }
 }
 }

 elm("ATCRA", 1000)
 elm("ATSP0", 1500)
 detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

 if (found == 0) {
 append("· No DID UDS VAG respondeu.")
 append("· ECU not acessível, DID not suportdo ou gateway/rede a bloquear a reading.")
 } else {
 append("✓ $found reading(s) UDS obtida(s).")
 }
 append("=== FIM VAG UDS ===")
 }

 /**
 * Ford UDS READ-ONLY scanner.
 *
 * Only UDS ReadDataByIdentifier (0x22) is transmitted. No security access,
 * coding, adaptation, routine control or ECU programming is attempted.
 */
 private fun runNissanUdsReadOnly() {
 append("=== NISSAN / INFINITI UDS READ-ONLY ===")
 append(ui("Allowed service: 0x22 ReadDataByIdentifier", "Allowed service: 0x22 ReadDataByIdentifier"))
 append(ui("Searching for ECUs on IDs 7E0–7E7…", "Searching for ECUs on IDs 7E0–7E7…"))
 append(ui("Note: proprietary Nissan/INFINITI maps are not used without verifiable public documentation.", "Note: proprietary Nissan/INFINITI maps are not used without verifiable public documentation."))

 elm("ATSP6", 2000)
 elm("ATCAF1", 1200)
 elm("ATCFC1", 1200)

 var found = 0
 for (requestId in 0x7E0..0x7E7) {
 val req = String.format(Locale.US, "%03X", requestId)
 val responseId = String.format(Locale.US, "%03X", requestId + 8)
 elm("ATSH$req", 1000)
 elm("ATCRA$responseId", 1000)

 for (did in nissanDids) {
 val raw = elm("22${did.did}", 3000)
 val value = parseUdsDid(raw, did.did)
 if (value.isNotBlank()) {
 found++
 append("✓ ECU $req → ${did.label}: $value")
 runOnUiThread {
 liveDataAppend("• ECU $req — ${did.label}: $value\n")
 }
 }
 }
 }

 elm("ATCRA", 1000)
 elm("ATSP0", 1500)
 detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

 if (found == 0) {
 append("· No DID UDS Nissan / INFINITI respondeu.")
 append("· ECU/rede/DID pode not support a reading ou pode exigir ferramenta de diagnostics específica.")
 } else {
 append("✓ $found reading(s) UDS obtida(s).")
 }
 append("=== FIM NISSAN / INFINITI UDS ===")
 }

 /**
 * Tesla conservative READ-ONLY diagnostic profile.
 *
 * The current HOMEBD transport is Bluetooth ELM327/CAN. Some Tesla
 * generations use diagnostic Ethernet/DoIP, so this profile never claims
 * universal Tesla ECU access. It only attempts standard UDS VIN reading
 * over CAN when the connected adapter exposes a compatible CAN path.
 */
 private fun runTeslaUdsReadOnly() {
 append("=== TESLA UDS READ-ONLY ===")
 append(ui("Allowed service: 0x22 ReadDataByIdentifier", "Allowed service: 0x22 ReadDataByIdentifier"))
 append(ui("Conservative profile: standard VIN F190 over CAN only", "Conservative profile: standard VIN F190 over CAN only"))
 append(ui("Note: some Tesla vehicles require DoIP/Ethernet; Bluetooth ELM327 does not provide that interface.", "Note: some Tesla vehicles require DoIP/Ethernet; Bluetooth ELM327 does not provide that interface."))

 elm("ATSP6", 2000)
 elm("ATCAF1", 1200)
 elm("ATCFC1", 1200)

 var found = 0
 for (requestId in 0x7E0..0x7E7) {
 val req = String.format(Locale.US, "%03X", requestId)
 val responseId = String.format(Locale.US, "%03X", requestId + 8)
 elm("ATSH$req", 1000)
 elm("ATCRA$responseId", 1000)

 for (did in teslaDids) {
 val raw = elm("22${did.did}", 3000)
 val value = parseUdsDid(raw, did.did)
 if (value.isNotBlank()) {
 found++
 append("✓ ECU $req → ${did.label}: $value")
 runOnUiThread {
 liveDataAppend("• ECU $req — ${did.label}: $value\n")
 }
 }
 }
 }

 elm("ATCRA", 1000)
 elm("ATSP0", 1500)
 detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

 if (found == 0) {
 append("· No response Tesla UDS obtida através do CAN/ELM327.")
 append("· Isto not means que o vehicle not tenha diagnostics; pode requerer DoIP/Ethernet ou uma interface específica Tesla.")
 } else {
 append("✓ $found reading(s) UDS obtida(s).")
 }
 append("=== FIM TESLA UDS ===")
 }

 /**
 * Subaru READ-ONLY profile.
 *
 * Uses standard OBD-II data plus a conservative standard UDS VIN read.
 * No proprietary Subaru CAN/request map is included.
 */
 private fun runSubaruReadOnly() {
 append("=== SUBARU READ-ONLY ===")
 append("OBD-II standard + UDS 0x22 quando suportdo")
 append(ui("No verified proprietary Subaru CAN map.", "No verified proprietary Subaru CAN map."))

 val pidList = listOf(
 "0105" to "Coolant temperature",
 "010C" to "RPM",
 "010D" to "Vehicle speed",
 "0111" to "Throttle position"
 )

 var found = 0
 for ((pid, label) in pidList) {
 val raw = elm(pid, 3000)
 if (isPositiveObdResponse(raw, pid)) {
 found++
 append("✓ Subaru OBD-II $pid — $label: ${classifyResponse(raw)}")
 runOnUiThread {
 liveDataAppend("• Subaru — $label: ${classifyResponse(raw)}\n")
 }
 }
 }

 if (canActive) {
 elm("ATSP6", 2000)
 elm("ATCAF1", 1200)
 elm("ATCFC1", 1200)

 var udsFound = 0
 for (requestId in 0x7E0..0x7E7) {
 val req = String.format(Locale.US, "%03X", requestId)
 val responseId = String.format(Locale.US, "%03X", requestId + 8)
 elm("ATSH$req", 1000)
 elm("ATCRA$responseId", 1000)

 for (did in subaruDids) {
 val raw = elm("22${did.did}", 3000)
 val value = parseUdsDid(raw, did.did)
 if (value.isNotBlank()) {
 udsFound++
 append("✓ ECU $req → ${did.label}: $value")
 runOnUiThread {
 liveDataAppend("• ECU $req — ${did.label}: $value\n")
 }
 }
 }
 }

 elm("ATCRA", 1000)
 elm("ATSP0", 1500)
 detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

 if (udsFound == 0) {
 append("· No DID UDS Subaru respondeu.")
 } else {
 append("✓ $udsFound reading(s) UDS Subaru obtida(s).")
 }
 }

 if (found == 0) {
 append("· No response OBD-II Subaru obtida para os PIDs selecteds.")
 } else {
 append("✓ $found reading(s) OBD-II Subaru obtida(s).")
 }
 append("=== FIM SUBARU READ-ONLY ===")
 }

 /**
 * Lexus READ-ONLY profile.
 *
 * Lexus has its own manufacturer diagnostic tooling, so HOMEBD keeps this
 * profile separate from Toyota. Only the standard UDS VIN read is attempted
 * here; no proprietary Lexus request/DID map is assumed.
 */
 private fun runLexusReadOnly() {
 append("=== LEXUS READ-ONLY ===")
 append("OBD-II standard + CAN/ISO-TP quando suportdo")
 append(ui("No verified proprietary Lexus CAN map.", "No verified proprietary Lexus CAN map."))

 if (canActive) {
 elm("ATSP6", 2000)
 elm("ATCAF1", 1200)
 elm("ATCFC1", 1200)

 var udsFound = 0
 for (requestId in 0x7E0..0x7E7) {
 val req = String.format(Locale.US, "%03X", requestId)
 val responseId = String.format(Locale.US, "%03X", requestId + 8)
 elm("ATSH$req", 1000)
 elm("ATCRA$responseId", 1000)

 for (did in lexusDids) {
 val raw = elm("22${did.did}", 3000)
 val value = parseUdsDid(raw, did.did)
 if (value.isNotBlank()) {
 udsFound++
 append("✓ ECU $req → ${did.label}: $value")
 runOnUiThread {
 liveDataAppend("• Lexus ECU $req — ${did.label}: $value\n")
 }
 }
 }
 }

 elm("ATCRA", 1000)
 elm("ATSP0", 1500)
 detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

 if (udsFound == 0) {
 append("· No DID UDS Lexus respondeu.")
 } else {
 append("✓ $udsFound reading(s) UDS Lexus obtida(s).")
 }
 } else {
 append("· CAN not available no adaptador/protocol atual.")
 }

 append("=== FIM LEXUS READ-ONLY ===")
 }

 /**
 * Isuzu READ-ONLY profile.
 *
 * Isuzu's official technical portals provide diagnostic tooling and OBD
 * information, while detailed manufacturer-specific diagnostic data are
 * provided through the official Isuzu tools. HOMEBD therefore uses only
 * standard OBD-II data plus a conservative standard UDS VIN read.
 */
 private fun runIsuzuReadOnly() {
 append("=== ISUZU READ-ONLY ===")
 append("OBD-II standard + UDS 0x22 quando suportdo")
 append(ui("No verified proprietary Isuzu CAN map.", "No verified proprietary Isuzu CAN map."))

 val pidList = listOf(
 "0105" to "Coolant temperature",
 "010C" to "RPM",
 "010D" to "Vehicle speed",
 "0111" to "Throttle position",
 "012F" to "Fuel level"
 )

 var found = 0
 for ((pid, label) in pidList) {
 val raw = elm(pid, 3000)
 if (isPositiveObdResponse(raw, pid)) {
 found++
 val value = classifyResponse(raw)
 append("✓ Isuzu OBD-II $pid — $label: $value")
 runOnUiThread {
 liveDataAppend("• Isuzu — $label: $value\n")
 }
 }
 }

 if (canActive) {
 elm("ATSP6", 2000)
 elm("ATCAF1", 1200)
 elm("ATCFC1", 1200)

 var udsFound = 0
 for (requestId in 0x7E0..0x7E7) {
 val req = String.format(Locale.US, "%03X", requestId)
 val responseId = String.format(Locale.US, "%03X", requestId + 8)
 elm("ATSH$req", 1000)
 elm("ATCRA$responseId", 1000)

 for (did in isuzuDids) {
 val raw = elm("22${did.did}", 3000)
 val value = parseUdsDid(raw, did.did)
 if (value.isNotBlank()) {
 udsFound++
 append("✓ ECU $req → ${did.label}: $value")
 runOnUiThread {
 liveDataAppend("• Isuzu ECU $req — ${did.label}: $value\n")
 }
 }
 }
 }

 elm("ATCRA", 1000)
 elm("ATSP0", 1500)
 detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

 if (udsFound == 0) {
 append("· No DID UDS Isuzu respondeu.")
 } else {
 append("✓ $udsFound reading(s) UDS Isuzu obtida(s).")
 }
 } else {
 append("· CAN not available no adaptador/protocol atual.")
 }

 if (found == 0) {
 append("· No response OBD-II Isuzu obtida para os PIDs selecteds.")
 } else {
 append("✓ $found reading(s) OBD-II Isuzu obtida(s).")
 }
 append("=== FIM ISUZU READ-ONLY ===")
 }

 /**
 * Mazda READ-ONLY profile.
 *
 * Mazda public documentation confirms that operating data are normally
 * read through the mandatory OBD connection for fault daygnosis. No
 * proprietary Mazda UDS DID is assumed without a public, verifiable source.
 */
 /**
 * Mitsubishi READ-ONLY profile.
 *
 * Mitsubishi's official technical-information portl documents OBD-II
 * coverage and CAN-bus daygnosis through MUT-III. Detailed proprietary
 * request maps are subscriber-restricted, so HOMEBD does not copy them.
 * Only standard OBD-II data and a conservative UDS VIN read are attempted.
 */
 private fun runMitsubishiReadOnly() {
 append("=== MITSUBISHI READ-ONLY ===")
 append("OBD-II standard + CAN/ISO-TP quando suportdo")
 append(ui("No verified proprietary Mitsubishi CAN map.", "No verified proprietary Mitsubishi CAN map."))

 val pidList = listOf(
 "0105" to "Coolant temperature",
 "010C" to "RPM",
 "010D" to "Vehicle speed",
 "0111" to "Throttle position",
 "012F" to "Fuel level"
 )

 var found = 0
 for ((pid, label) in pidList) {
 val raw = elm(pid, 3000)
 if (isPositiveObdResponse(raw, pid)) {
 found++
 append("✓ Mitsubishi OBD-II $pid — $label: ${classifyResponse(raw)}")
 runOnUiThread {
 liveDataAppend("• Mitsubishi — $label: ${classifyResponse(raw)}\n")
 }
 }
 }

 if (canActive) {
 elm("ATSP6", 2000)
 elm("ATCAF1", 1200)
 elm("ATCFC1", 1200)

 var udsFound = 0
 for (requestId in 0x7E0..0x7E7) {
 val req = String.format(Locale.US, "%03X", requestId)
 val responseId = String.format(Locale.US, "%03X", requestId + 8)
 elm("ATSH$req", 1000)
 elm("ATCRA$responseId", 1000)

 for (did in mitsubishiDids) {
 val raw = elm("22${did.did}", 3000)
 val value = parseUdsDid(raw, did.did)
 if (value.isNotBlank()) {
 udsFound++
 append("✓ ECU $req → ${did.label}: $value")
 runOnUiThread {
 liveDataAppend("• ECU $req — ${did.label}: $value\n")
 }
 }
 }
 }

 elm("ATCRA", 1000)
 elm("ATSP0", 1500)
 detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

 if (udsFound == 0) {
 append("· No DID UDS Mitsubishi respondeu.")
 } else {
 append("✓ $udsFound reading(s) UDS Mitsubishi obtida(s).")
 }
 }

 if (found == 0) {
 append("· No response OBD-II Mitsubishi obtida para os PIDs selecteds.")
 } else {
 append("✓ $found reading(s) OBD-II Mitsubishi obtida(s).")
 }
 append("=== FIM MITSUBISHI READ-ONLY ===")
 }

 private fun runMazdaReadOnly() {
 append("=== MAZDA READ-ONLY ===")
 append(ui("OBD-II standard: data reading and diagnostics", "OBD-II standard: data reading and diagnostics"))
 append(ui("No unverified proprietary Mazda DIDs.", "No unverified proprietary Mazda DIDs."))

 // The generic OBD-II scan performed by HOMEBD remains the supported
 // manufacturer profile. Mode 09 VIN is also queried by the common CAN
 // read-only layer. No write/coding/programming service is sent.
 val pidList = listOf(
 "0105" to "Coolant temperature",
 "010C" to "RPM",
 "010D" to "Vehicle speed",
 "0111" to "Throttle position",
 "012F" to "Fuel level"
 )

 var found = 0
 for ((pid, label) in pidList) {
 val raw = elm(pid, 3000)
 if (isPositiveObdResponse(raw, pid)) {
 found++
 append("✓ Mazda OBD-II $pid — $label: ${classifyResponse(raw)}")
 runOnUiThread {
 liveDataAppend("• Mazda — $label: ${classifyResponse(raw)}\n")
 }
 }
 }

 if (found == 0) {
 append("· No response OBD-II Mazda obtida para os PIDs selecteds.")
 } else {
 append("✓ $found reading(s) OBD-II Mazda obtida(s).")
 }
 append("=== FIM MAZDA READ-ONLY ===")
 }

 private fun runFordUdsReadOnly() {
 append("=== FORD UDS READ-ONLY ===")
 append(ui("Allowed service: 0x22 ReadDataByIdentifier", "Allowed service: 0x22 ReadDataByIdentifier"))
 append(ui("Searching for ECUs on IDs 7E0–7E7…", "Searching for ECUs on IDs 7E0–7E7…"))

 elm("ATSP6", 2000)
 elm("ATCAF1", 1200)
 elm("ATCFC1", 1200)

 var found = 0
 for (requestId in 0x7E0..0x7E7) {
 val req = String.format(Locale.US, "%03X", requestId)
 val responseId = String.format(Locale.US, "%03X", requestId + 8)

 elm("ATSH$req", 1000)
 elm("ATCRA$responseId", 1000)

 for (did in fordDids) {
 val raw = elm("22${did.did}", 3000)
 val value = parseUdsDid(raw, did.did)
 if (value.isNotBlank()) {
 found++
 append("✓ ECU $req → ${did.label}: $value")
 runOnUiThread {
 liveDataAppend("• ECU $req — ${did.label}: $value\n")
 }
 }
 }
 }

 elm("ATCRA", 1000)
 elm("ATSP0", 1500)
 detectedProtocol = elm("ATDPN", 1500).trim().uppercase().removePrefix("A")

 if (found == 0) {
 append("· No DID UDS Ford respondeu.")
 append("· ECU not acessível, DID not suportdo ou gateway/rede a bloquear a reading.")
 } else {
 append("✓ $found reading(s) UDS obtida(s).")
 }
 append("=== FIM FORD UDS ===")
 }

 private fun isPositiveObdResponse(raw: String, pid: String): Boolean {
 val hex = raw.uppercase().replace(Regex("[^0-9A-F]"), "")
 val marker = "41${pid.takeLast(2).uppercase()}"
 return hex.contains(marker)
 }

 private fun parseUdsDid(raw: String, did: String): String {
 val hex = raw.uppercase().replace(Regex("[^0-9A-F]"), "")
 if (hex.length < 6) return ""

 val didUpper = did.uppercase()
 val marker = "62$didUpper"
 val start = hex.indexOf(marker)
 if (start < 0) return ""

 val dataStart = start + marker.length
 if (dataStart >= hex.length) return ""

 val dataHex = hex.substring(dataStart)
 val bytes = ArrayList<Int>()
 var i = 0
 while (i + 1 < dataHex.length) {
 bytes.add(dataHex.substring(i, i + 2).toIntOrNull(16) ?: break)
 i += 2
 }

 // Human-readable ECU identification is normally ASCII. Preserve
 // printable characters and ignore padding/non-printable bytes.
 val text = bytes
 .filter { it in 0x20..0x7E }
 .map { it.toChar() }
 .joinToString("")
 .trim()

 return if (text.isNotBlank()) text else dataHex.take(64)
 }

 private fun reportCanValue(label: String, raw: String, value: String) {
 if (value.isNotBlank()) {
 append("CAN $label: $value")
 } else {
 append(ui("CAN $label: not available (${clean(raw)})", "CAN $label: not available (${clean(raw)})"))
 }
 }

 /**
 * Robust read-only VIN acquisition.
 *
 * Mode 09 PID 02 is retried because some ELM327 Bluetooth adapters can
 * expose only a partial ISO-TP response on the first request. If a
 * complete 17-character VIN is not obtained, the standard UDS DID F190
 * is queried on the ECUs already discovered by the scanner.
 *
 * No write, coding, reset or programming service is used.
 */
 private fun readCompleteVin(): String {
 fun normalizeCandidate(value: String): String {
 val cleaned = value.uppercase(Locale.US)
 .replace(Regex("[^A-Z0-9]"), "")
 val match = Regex("[A-HJ-NPR-Z0-9]{17}").find(cleaned)
 return match?.value ?: ""
 }

 // First preference: standard OBD-II Mode 09 PID 02.
 repeat(3) {
 val raw = elm("0902", 5000)
 val parsed = extractObdAscii(raw, 0x49, 0x02)
 val candidate = normalizeCandidate(parsed)
 if (candidate.length == 17) return candidate

 // Some adapters leave useful ASCII in the raw response even when
 // the expected service/PID marker is fragmented.
 val rawAscii = raw.map { ch ->
 if (ch.code in 0x20..0x7E) ch else ' '
 }.joinToString("")
 val rawCandidate = normalizeCandidate(rawAscii)
 if (rawCandidate.length == 17) return rawCandidate
 }

 // Standard UDS VIN DID F190 fallback on the ECUs already found by
 // the CAN discovery. Only 0x22 ReadDataByIdentifier is used.
 elm("ATSP6", 2000)
 elm("ATCAF1", 1200)
 elm("ATCFC1", 1200)

 for (requestId in listOf(0x7E0, 0x7E5)) {
 val req = String.format(Locale.US, "%03X", requestId)
 val responseId = String.format(Locale.US, "%03X", requestId + 8)
 elm("ATSH$req", 1000)
 elm("ATCRA$responseId", 1000)

 repeat(2) {
 val raw = elm("22F190", 5000)
 val parsed = extractUdsAscii(raw, 0x62, 0xF1, 0x90)
 val candidate = normalizeCandidate(parsed)
 if (candidate.length == 17) return candidate
 }
 }

 return ""
 }

 private fun extractUdsAscii(raw: String, service: Int, didHigh: Int, didLow: Int): String {
 val hex = raw.uppercase(Locale.US)
 .replace(Regex("[^0-9A-F]"), "")
 if (hex.length < 6) return ""

 val bytes = ArrayList<Int>()
 var i = 0
 while (i + 1 < hex.length) {
 bytes.add(hex.substring(i, i + 2).toIntOrNull(16) ?: -1)
 i += 2
 }

 val start = bytes.indexOfFirst { it == service }
 if (start < 0) return ""

 var pos = start + 1
 if (pos + 1 >= bytes.size || bytes[pos] != didHigh || bytes[pos + 1] != didLow) {
 return ""
 }

 val sb = StringBuilder()
 for (j in pos + 2 until bytes.size) {
 val b = bytes[j]
 if (b in 0x20..0x7E) sb.append(b.toChar())
 }
 return sb.toString().trim()
 }

 private fun extractObdAscii(raw: String, service: Int, pid: Int): String {
 // Convert hex byte pairs from ELM output into bytes. This works with
 // single- and multi-frame ISO-TP payloads after ELM reassembly.
 val hex = raw.uppercase()
 .replace(Regex("[^0-9A-F]"), "")
 if (hex.length < 4) return ""

 val bytes = ArrayList<Int>()
 var i = 0
 while (i + 1 < hex.length) {
 bytes.add(hex.substring(i, i + 2).toIntOrNull(16) ?: -1)
 i += 2
 }

 val start = bytes.indexOfFirst { it == service }
 if (start < 0) return ""

 // Find the PID immedaytely after the positive response service.
 var pos = start + 1
 while (pos < bytes.size && bytes[pos] < 0) pos++
 if (pos >= bytes.size || bytes[pos] != pid) return ""

 val sb = StringBuilder()
 for (j in pos + 1 until bytes.size) {
 val b = bytes[j]
 if (b in 0x20..0x7E) sb.append(b.toChar())
 }
 return sb.toString().trim()
 }

 private fun classifyResponse(raw: String): String {
 val readable = raw.replace("\r", " ").replace("\n", " ")
 .replace(Regex("\\s+"), " ").trim()
 val compact = readable.uppercase().replace(Regex("[^0-9A-F]"), "")

 return when {
 readable.uppercase().contains("NO DATA") ->
 "· NO DATA — sem response desse PID"
 readable.uppercase().contains("ERROR") ->
 "· ERROR — ELM327 recusou o command"
 readable.uppercase().contains("UNABLE TO CONNECT") ->
 "· SEM LIGAÇÃO ECU"
 Regex("7F[0-9A-F]{4}").find(compact) != null ->
 "✕ Negative Response UDS/OBD: $readable"
 compact.contains("4100") || Regex("\b41[0-9A-F]{2}\b").containsMatchIn(compact) ->
 "✓ Response OBD-II: $readable"
 readable.isBlank() ->
 "· SEM RESPOSTA"
 else ->
 "· Response: $readable"
 }
 }

 private fun clean(value: String): String =
 value.replace("\n", " ").replace(Regex("\\s+"), " ").trim()

 private fun englishRuntimeText(value: String): String {
 if (HomeBdLanguage.name(this).equals("Português", ignoreCase = true)) return value

 val replacements = linkedMapOf(
 "time limite ao connect ao adaptador" to "timeout while connecting to the adapter",
 "not configured" to "not configured",
 "not available" to "not available",
 "not identificado" to "not identified",
 "not respondeu" to "did not respond",
 "not foram ativadas" to "were not enabled",
 "not foi possível" to "unable to",
 "not available via OBD-II standard" to "not available via standard OBD-II",
 "not available no adaptador/protocol atual" to "not available with the current adapter/protocol",
 "not está connected" to "is not connected",
 "not está available" to "is not available",
 "sem response válida" to "no valid response",
 "sem response desse PID" to "no response from this PID",
 "sem response" to "no response",
 "connection perdida" to "connection lost",
 "connection ECU" to "ECU connection",
 "error de connection" to "connection error",
 "adaptador not respondeu" to "adapter did not respond",
 "adaptador/protocol atual" to "current adapter/protocol",
 "Permission Bluetooth required" to "Bluetooth permission required",
 "Bluetooth is not available on this device" to "Bluetooth is not available on this device",
 getString(R.string.bluetooth_disabled) to "Bluetooth is off — enable Bluetooth",
 "No device emparelhado" to "No paired devices",
 "device(s) emparelhado(s)" to "paired device(s)",
 "Emparelhe um adaptador" to "Pair an adapter",
 "nas settings Bluetooth do Android" to "in Android Bluetooth settings",
 "Introduza" to "Enter",
 "No foi possível abrir o exportdor." to "Unable to open the exporter.",
 "There is no data to export." to "There is no data to export.",
 "Status:" to "Status:",
 "LIGADO" to "CONNECTED",
 "DESLIGADO" to "DISCONNECTED",
 "A CONNECT" to "CONNECTING",
 "error" to "ERROR",
 "connected" to "connected",
 "disconnected" to "disconnected",
 "connect" to "connect",
 "connection" to "connection",
 "unknown" to "unknown",
 ui("Multi-byte data — not yesplified", "Multi-byte data — not yesplified") to "Multi-byte data — not yesplified",
 "not identificado pelo adaptador/protocol atual" to "not identified by the current adapter/protocol",
 "not confirmado após estabilização" to "not confirmed after stabilization",
 "A consultar PIDs genéricos..." to "Querying generic PIDs...",
 getString(R.string.continuous_auto_reading) to "Continuous automatic reading",
 "intervalo aproximado" to "approximate interval",
 "No standard PID confirmed by the vehicle." to "No standard PID confirmed by the vehicle.",
 "O HOMEBD not inventa data: apenas mostra parâmetros efetivamente suportdos." to "HOMEBD does not invent data: it only displays parameters actually supported.",
 "SCAN completed" to "SCAN completed",
 "em execução" to "running",
 "completed" to "completed",
 "Sem DIDs proprietários assumidos e sem commands de escrita." to "No proprietary DIDs assumed and no write commands.",
 "Noa ECU physical respondeu" to "No physical ECU responded",
 "O gateway/adaptador pode not permitir esta descoberta por physical address." to "The gateway/adapter may not allow this discovery by physical address.",
 "Isto does not prove" to "This does not prove",
 "may use outro address, gateway or session." to "it may use another address, gateway or session.",
 "Valuees displayed como RAW; not yet são converted para SOC, kW ou kWh." to "Values are shown as RAW; they are not yet converted to SOC, kW or kWh.",
 "Search module de telemática apenas através de responses UDS confirmadas." to "Search for the telematics module only through confirmed UDS responses.",
 "FIM" to "END",
 "DISCOVERY" to "DISCOVERY",
 "SEM LIGAÇÃO ECU" to "NO ECU CONNECTION",
 "No start SCAN/DISCOVERY novamente durante LIVE DATA. RESCAN é explícito." to "Do not start SCAN/DISCOVERY again during LIVE DATA. RESCAN is explicit.",
 "Update dinâmica" to "Dynamic update",
 "parâmetros rápidos" to "fast parameters",
 "Consumption electric: Unavailable" to "Electric consumption: Not available",
 "Potência elétrica: Unavailable" to "Electric power: Not available",
 "Consumption de fuel:" to "Fuel consumption:",
 "vehicle parado" to "vehicle stationary"
 )
 val extraReplacements = linkedMapOf(
 "Adaptador: " to "Adapter: ",
 "adaptador not identificado" to "adapter not identified",
 "OBD-II ready." to "OBD-II ready.",
 "OBD-II universal para vehicles." to "universal OBD-II diagnostics for vehicles.",
 "Selecione um adaptador OBD-II Bluetooth emparelhado e toque em CONNECT OBDII." to "Select a paired Bluetooth OBD-II adapter and tap CONNECT OBD-II.",
 "Os PIDs suportdos são detetados automaticamente pelo vehicle." to "Supported PIDs are detected automatically by the vehicle.",
 "Fuel e mistura" to "Fuel and mixture",
 "Temperatures e pressões" to "Temperatures and pressures",
 "Acereadador / pedal" to "Throttle / pedal",
 "Status OBD / readiness" to "OBD status / readiness",
 "Voltage e data auxiliares" to "Voltage and auxiliary data",
 "VIN / information do vehicle" to "VIN / vehicle information",
 "Perfil selected:" to "Selected profile:",
 "Automatic" to "Automatic",
 "catálogo OBD-II standard active" to "standard OBD-II catalogue active",
 "OBD-II disconnected." to "OBD-II disconnected.",
 "No device Bluetooth selecionável." to "No selectable Bluetooth device.",
 "Emparelhe um adaptador OBD-II Bluetooth nas settings Bluetooth do Android." to "Pair a Bluetooth OBD-II adapter in Android Bluetooth settings.",
 "Home Assistant · error" to "Home Assistant · error",
 "Home Assistant error:" to "Home Assistant error:",
 "No data — ligue o OBD-II e execute SCAN PIDs." to "No data — connect OBD-II and run PID SCAN.",
 "Nota de desenvolvimento:" to "Development note:",
 "O HOMEBD foi desenvolvido de raiz, com arquitetura, funcionalidades e soluções técnicas concebidas especificamente para este projeto e desenvolvidas para a própria application." to "HOMEBD was developed from scratch, with architecture, features and technical solutions specifically designed and developed for this application.",
 "Desenvolvido por:" to "Developed by:",
 getString(R.string.app_description) to "Android application for OBD-II diagnostics",
 "Connection a adaptadores OBD-II através de Bluetooth" to "Connection to OBD-II adapters via Bluetooth",
 "Identificação dos PIDs suportdos pelo vehicle" to "Identification of PIDs supported by the vehicle",
 "Reading dinâmica e conversion dos parâmetros" to "Dynamic reading and conversion of parameters",
 "Reading de DTCs quando suportda" to "DTC reading when supported",
 "Reading de VIN quando available" to "VIN reading when available",
 "Reading de Live Data" to "Live Data reading",
 "There is no data to export." to "There is no data to export.",
 "No foi possível abrir o exportdor." to "Unable to open the exporter.",
 "Export error:" to "Export error:",
 "unknown" to "unknown",
 "copiado" to "copied",
 "exportdo." to "exported.",
 "connecting por BLE" to "connecting via BLE",
 "Adaptador not respondeu ao ATDP" to "Adapter did not respond to ATDP",
 "CAN estabilizado: protocol" to "CAN stabilized: protocol",
 "respondeu)." to "responded).",
 "CAN em modo READ-ONLY." to "CAN in READ-ONLY mode.",
 "Ready para SCAN PIDs." to "Ready for PID SCAN.",
 "time limite ao connect ao adaptador" to "timeout while connecting to the adapter",
 "serviço OBD/UART not found" to "OBD/UART service not found",
 "notificações not foram ativadas" to "notifications were not enabled",
 "BLE not connected" to "BLE not connected",
 "característica de escrita not found" to "write characteristic not found",
 "SCAN HV/UDS em execução" to "HV/UDS SCAN running",
 "Sem coordenadas ou DIDs GPS assumidos." to "No GPS coordinates or assumed GPS DIDs.",
 "Search module de telemática apenas através de responses UDS confirmadas." to "Search for the telematics module only through confirmed UDS responses.",
 "Perfil: " to "Profile: ",
 "Modo: reading apenas" to "Mode: read-only",
 "reading através do ELM327" to "reading through ELM327",
 "not identificado pelo adaptador/protocol atual" to "not identified by the current adapter/protocol",
 "A consultar PIDs genéricos..." to "Querying generic PIDs...",
 "No start SCAN/DISCOVERY novamente durante LIVE DATA. RESCAN é explícito." to "Do not start SCAN/DISCOVERY again during LIVE DATA. RESCAN is explicit.",
 getString(R.string.continuous_auto_reading) to "Continuous automatic reading",
 "intervalo aproximado" to "approximate interval",
 getString(R.string.waiting_first_reading) to "Waiting for first reading",
 "Consumption de fuel:" to "Fuel consumption:",
 "vehicle parado" to "vehicle stationary",
 "PIDs standard suportdos detetados." to "supported standard PIDs detected.",
 "Update dinâmica" to "Dynamic update",
 "parâmetros rápidos" to "fast parameters",
 "parado" to "stopped",
 "not available via OBD-II standard" to "not available via standard OBD-II",
 getString(R.string.temperatures) to "TEMPERATURES",
 getString(R.string.fuel) to "FUEL",
 "ADMISSÃO / ACELERADOR" to "INTAKE / THROTTLE",
 getString(R.string.electric_hybrid) to "ELECTRIC / HYBRID",
 "Data multi-byte — not yesplificado" to "Multi-byte data — not yesplified",
 getString(R.string.insufficient_data) to "Insufficient data",
 "A search ECUs nos IDs 7E0–7E7…" to "Searching for ECUs on IDs 7E0–7E7…",
 "Serviço permitido: 0x22 ReadDataByIdentifier" to "Allowed service: 0x22 ReadDataByIdentifier",
 "No DID UDS" to "No UDS DID",
 "No response" to "No response",
 "Noa ECU" to "No ECU",
 "No PID" to "No PID",
 "No device" to "No device",
 "obtida(s)" to "obtained",
 "reading(s)" to "reading(s)",
 "respondeu" to "responded",
 "not acessível" to "not accessible",
 "not suportdo" to "not supported",
 "bloquear a reading" to "block reading",
 "not fornece" to "does not provide",
 "not means" to "does not mean",
 "pode requerer" to "may require",
 "apenas" to "only",
 "not verificado" to "not verified",
 "Nota:" to "Note:",
 "not são usados" to "are not used",
 "mapas proprietários" to "proprietary maps",
 "sem documentação pública verificável" to "without verifiable public documentation",
 "not available" to "not available",
 "not confirmado" to "not confirmed",
 "not inventa data: apenas mostra parâmetros efetivamente suportdos." to "does not invent data: it only displays parameters actually supported.",
 "Valuees displayed como RAW; not yet são converted para SOC, kW ou kWh." to "Values are shown as RAW; they are not yet converted to SOC, kW or kWh.",
 "O gateway/adaptador pode not permitir esta descoberta por physical address." to "The gateway/adapter may not allow this discovery by physical address.",
 "Isto does not prove que o BMS not seja acessível; may use outro address, gateway or session." to "This does not prove that the BMS is inaccessible; it may use another address, gateway or session.",
 "Sem mapa proprietário: apenas DIDs standard configurados." to "No proprietary map: standard configured DIDs only.",
 "CAN not available no adaptador/protocol atual" to "CAN not available with the current adapter/protocol",
 "CAN \$label: not available" to "CAN \$label: not available",
 "SEM LIGAÇÃO ECU" to "NO ECU CONNECTION",
 "SEM RESPOSTA" to "NO RESPONSE",
 "NO DATA — sem response desse PID" to "NO DATA — no response from this PID",
 "Response OBD-II:" to "OBD-II response:",
 "Response:" to "Response:",
 "CAN not confirmado após estabilização" to "CAN not confirmed after stabilization",
 "CAN estabilizado: ISO 15765-4 11-bit / 500 kbit/s" to "CAN stabilized: ISO 15765-4 11-bit / 500 kbit/s",
 "Adaptador:" to "Adapter:",
 "OBD-II compatível — modelo not identificado" to "OBD-II compatible — model not identified"
 )
 replacements.putAll(extraReplacements)
 replacements.putAll(linkedMapOf(
 "nonea" to "none",
 "Noa" to "No",
 "No" to "No",
 "Sem " to "No ",
 "sem " to "without ",
 "not " to "not ",
 "No " to "No ",
 "detetado(s)" to "detected",
 "detetados" to "detected",
 "suportdo(s)" to "supported",
 "suportdos" to "supported",
 "suportda" to "supported",
 "obtida(s)" to "obtained",
 "reading(s)" to "reading(s)",
 "respondeu" to "responded",
 "responses" to "responses",
 "acessível" to "accessible",
 "bloquear" to "block",
 "reading" to "reading",
 "data" to "data",
 "diagnostics" to "diagnostics",
 "Diagnostics" to "Diagnostics",
 "serviço" to "service",
 "Serviço" to "Service",
 "permitido" to "allowed",
 "proprietário" to "proprietary",
 "proprietários" to "proprietary",
 "mapa" to "map",
 "verificado" to "verified",
 "verificados" to "verified",
 "acessível" to "accessible",
 "requerem" to "require",
 "requer" to "requires",
 "fornece" to "provides",
 "apenas" to "only",
 "information" to "information",
 "vehicle" to "vehicle",
 "vehicles" to "vehicles",
 "pressões" to "pressures",
 "mistura" to "mixture",
 "voltage" to "voltage",
 "temperatures" to "temperatures",
 "fuel" to "fuel",
 "electric" to "electric",
 "elétrica" to "electric",
 "hybrid" to "hybrid",
 "admissão" to "intake",
 "acereadador" to "throttle",
 "pressure" to "pressure",
 "identificação" to "identification",
 "information" to "information",
 "modo" to "mode",
 "automatic" to "automatic",
 "completed" to "completed",
 "execução" to "running",
 "live" to "real time",
 "parado" to "stationary",
 "primeira" to "first",
 "wait" to "waiting",
 "capacidade" to "capability",
 "modelo" to "model",
 "compatível" to "compatible",
 "emparelhado" to "paired",
 "settings" to "settings",
 "enable" to "enable",
 "ligue" to "connect",
 "execute" to "run",
 "search" to "search",
 "procurando" to "searching",
 "found" to "found",
 "found" to "found",
 "assumidos" to "assumed",
 "específica" to "specific",
 "pública" to "public",
 "documentação" to "documentation",
 "means" to "means",
 "update" to "update",
 "update" to "update",
 "funciona" to "works",
 "integração" to "integration",
 "própria" to "own",
 "persistente" to "persistent",
 "send" to "send",
 "entidades" to "entities",
 "desenvolvido" to "developed",
 "desenhada" to "designed",
 "compatibilidade" to "compatibility",
 "real" to "real",
 "depende" to "depends",
 "operação" to "operation",
 "enviados" to "sent",
 "commands" to "commands",
 "escrita" to "write",
 "programação" to "programming",
 "codificação" to "coding",
 "adaptação" to "adaptation",
 "value" to "value",
 "recebido" to "received",
 "possível" to "possible",
 "zero" to "zero",
 "identifica" to "identifies",
 "declara" to "declares",
 "depois" to "then",
 "permite" to "allows",
 "apresentar" to "display",
 "parâmetros" to "parameters",
 "disponíveis" to "available",
 "integrado" to "integrated",
 "persistente" to "persistent",
 "recusado" to "rejected",
 "perdida" to "lost",
 "disconnected" to "disconnected",
 "connected" to "connected",
 "connection" to "connection",
 "error" to "error",
 "Status" to "Status",
 "Perfil" to "Profile",
 "Modo" to "Mode",
 "Ready" to "Ready",
 "Nota" to "Note",
 "A search" to "Searching",
 "A consultar" to "Querying",
 "A wait" to "Waiting"
 ))
 var result = value
 replacements.forEach { (pt, en) -> result = result.replace(pt, en) }
 return result
 }

 private fun liveDataAppend(value: String) {
 safeUi {
 if (::liveDataLog.isInitialized) liveDataLog.append(englishRuntimeText(value))
 }
 }

 private fun append(value: String) {
 safeUi {
 if (::log.isInitialized) {
 val current = log.text?.toString().orEmpty()
 val displayValue = englishRuntimeText(value)
 log.append(if (current.isEmpty()) displayValue else "\n$displayValue")
 }
 }
 }

 override fun onRequestPermissionsResult(
 requestCode: Int,
 permissions: Array<out String>,
 grantResults: IntArray
 ) {
 super.onRequestPermissionsResult(requestCode, permissions, grantResults)
 if (requestCode == 10) refreshBluetoothList()
 }

 override fun onDestroy() {
 // Do not tear down an active OBD session merely because the Activity
 // leaves the foreground. The foreground service keeps the process alive.
 super.onDestroy()
 }
 private fun updateAdapterInfo(identification: String, transportName: String = "Bluetooth") {
 val clean = identification
 .replace("\r", " ")
 .replace("\n", " ")
 .trim()
 .ifBlank { "OBD-II compatível — modelo not identificado" }

 val lower = clean.lowercase()
 val maker = when {
 "obdlink" in lower -> "OBDLink"
 "elm327" in lower || "elm electronics" in lower -> "ELM327"
 "stn" in lower -> "STN"
 else -> "OBD-II compatível"
 }

 adapterInfo = "Adaptador: $maker • $clean • $transportName"
 if (::adapterInfoView.isInitialized) {
 runOnUiThread { adapterInfoView.text = adapterInfo }
 }
 }
}

// HOMEBD: notification permission must be granted before FGS on Android 13+.
