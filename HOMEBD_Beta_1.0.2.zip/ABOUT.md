# About HOMEBD

## Identity

**HOMEBD — Home Assistant Onboard Monitoring & Board Data**

**Version:** Beta 1.0.2  
**Developer:** lufime

## Purpose

HOMEBD is an independent Android project focused on read-only vehicle monitoring and diagnostics, with optional Home Assistant integration.

The project provides vehicle data through a dedicated Android interface and can make supported telemetry available to Home Assistant when the optional integration is enabled.

## Design principles

- Read-only monitoring and diagnostics
- Automatic application language detection
- Optional Home Assistant integration
- Clear separation between HOMEBD material and external components
- Original HOMEBD visual assets

## Project assets

The HOMEBD icons, logos and original graphics included with the project were created for HOMEBD and are owned by lufime.

The HOMEBD name and official visual identity are project branding.

## Copyright

Copyright © 2026 lufime — HOMEBD

Original HOMEBD source code and documentation are licensed under the MIT License unless otherwise stated.

## Android Auto

Beta 1.0.2 includes a dedicated Android Auto service based on the Android for Cars App Library. The car interface is separate from the phone Activity and is designed for the Android Auto host to render in a driver-optimized layout.

The current car screen is read-only and consumes the live OBD-II values already received by the HOMEBD process. It does not send diagnostic write, coding, programming, or SecurityAccess commands.
