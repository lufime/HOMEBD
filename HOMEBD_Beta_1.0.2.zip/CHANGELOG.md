# HOMEBD CHANGELOG

## Beta 1.0.2

### Android Auto
- Added a dedicated Android Auto `CarAppService` interface.
- Declared the Android Auto template capability through `automotive_app_desc.xml`.
- Declared the Android Auto IoT car-app category.
- Added a driver-oriented read-only LIVE screen for the fast OBD-II parameters.
- Added a process-local vehicle-state bridge so Android Auto can display values already received by HOMEBD.
- Android Auto refreshes the displayed live values approximately once per second while the car screen is active.

### LIVE DATA
- Fast lane aligned with the main dynamic dashboard parameters: RPM, vehicle speed, engine load, accelerator pedal position, throttle position and control-module voltage.
- No diagnostic write, coding, programming or SecurityAccess operation was added.

### Documentation
- Updated README, ABOUT, INSTALLATION_GUIDE and LICENSES for Android Auto support.
- Version and release documentation updated to Beta 1.0.2.

## Beta 1.0.1

### Application
- English-mode runtime strings cleaned up to prevent Portuguese UI/log text from appearing when Android is set to English.
- Read-only OBD-II vehicle monitoring and diagnostics.
- Bluetooth OBD-II adapter connection.
- Diagnostic parameter discovery.
- VIN discovery where supported.
- LIVE DATA monitoring.
- Automatic application language detection.
- English fallback when the Android system language is not supported.

### Home Assistant
- Optional Home Assistant integration.
- HOMEBD telemetry support.
- HOMEBD entity namespace: `sensor.homebd_*`.

### Licensing
- Original HOMEBD source code and documentation released under the MIT License.
- External component licences documented separately in `LICENSES.md`.
