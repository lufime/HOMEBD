package pt.homebd.car

import android.app.ApplicationInfo
import android.content.Intent
import androidx.car.app.CarAppService
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.validation.HostValidator
import androidx.car.app.model.ItemList
import androidx.car.app.model.ListTemplate
import androidx.car.app.model.Row
import androidx.car.app.CarContext
import androidx.car.app.model.Header
import pt.homebd.HomeBdCarState

/**
 * Android Auto entry point for HOMEBD.
 *
 * The interface deliberately uses Car App Library templates rather than an
 * Activity so Android Auto can render it in a driver-optimized layout.
 */
class HomeBdCarAppService : CarAppService() {
    override fun createHostValidator(): HostValidator {
        return if ((applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
        } else {
            HostValidator.Builder(this)
                .addAllowedHosts(androidx.car.app.R.array.hosts_allowlist_sample)
                .build()
        }
    }

    override fun onCreateSession(): Session = HomeBdCarSession()
}

private class HomeBdCarSession : Session() {
    override fun onCreateScreen(intent: Intent): Screen = HomeBdCarScreen(carContext)
}

private class HomeBdCarScreen(carContext: CarContext) : Screen(carContext) {
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    init {
        handler.post(object : Runnable {
            override fun run() {
                invalidate()
                handler.postDelayed(this, 1000L)
            }
        })
    }

    override fun onGetTemplate(): androidx.car.app.model.Template {
        val rows = listOf(
            metricRow("RPM", "010C", "rpm"),
            metricRow("SPEED", "010D", "km/h"),
            metricRow("ENGINE LOAD", "0104", "%"),
            metricRow("PEDAL", "0149", "%"),
            metricRow("THROTTLE", "0111", "%"),
            metricRow("VOLTAGE", "0142", "V")
        )

        val status = when {
            !HomeBdCarState.obdConnected -> "OBD-II DISCONNECTED"
            HomeBdCarState.liveDataActive -> "OBD-II CONNECTED • LIVE DATA"
            else -> "OBD-II CONNECTED"
        }

        val list = ItemList.Builder()
            .addItem(Row.Builder().setTitle(status).addText("HOMEBD • READ-ONLY").build())
            .apply { rows.forEach { addItem(it) } }
            .build()

        return ListTemplate.Builder()
            .setSingleList(list)
            .setHeader(Header.Builder().setTitle("HOMEBD • LIVE").build())
            .build()
    }

    private fun metricRow(title: String, pid: String, unit: String): Row {
        val value = HomeBdCarState.value(pid)
        val text = when {
            value.isNullOrBlank() -> "—"
            value.endsWith(unit) -> value
            else -> value
        }
        return Row.Builder()
            .setTitle(title)
            .addText(text)
            .build()
    }
}
