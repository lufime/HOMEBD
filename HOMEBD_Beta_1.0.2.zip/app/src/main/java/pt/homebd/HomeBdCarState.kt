package pt.homebd

import java.util.concurrent.ConcurrentHashMap

/**
 * Small process-local bridge between the OBD-II reader and the Android Auto
 * Car App service. The car UI is read-only and only exposes values that
 * HOMEBD has actually received from the vehicle.
 */
object HomeBdCarState {
    private val values = ConcurrentHashMap<String, String>()

    @Volatile var obdConnected: Boolean = false
    @Volatile var liveDataActive: Boolean = false

    fun update(pid: String, label: String, value: String) {
        values[pid.uppercase()] = "$label|$value"
    }

    fun value(pid: String): String? = values[pid.uppercase()]?.substringAfter('|')

    fun label(pid: String): String? = values[pid.uppercase()]?.substringBefore('|')

    fun clear() {
        values.clear()
        obdConnected = false
        liveDataActive = false
    }
}
