plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "pt.homebd"
    compileSdk = 35

    defaultConfig {
        applicationId = "pt.homebd"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.0.2.0"
    }
}

dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("androidx.car.app:app:1.7.0")
    implementation("androidx.car.app:app-projected:1.7.0")
}

kotlin {
    jvmToolchain(17)
}
