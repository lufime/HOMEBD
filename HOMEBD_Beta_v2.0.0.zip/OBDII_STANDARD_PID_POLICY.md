# HOMEBD — OBD-II Standard PID Policy

HOMEBD implements standard OBD-II Mode 01 PIDs independently. The catalogue is based on public descriptions of SAE J1979 / ISO 15031-5 data items. The app first reads the standard PID-support bitmaps and only requests PIDs reported as supported.

Manufacturer-specific CAN/UDS maps and PID tables from third-party applications are not included.

Some later PIDs have complex multi-byte structures. Until a decoder is implemented and validated, HOMEBD preserves the response as raw data rather than inventing a scale or formula.
