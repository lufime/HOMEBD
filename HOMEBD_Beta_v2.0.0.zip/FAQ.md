# HOMEBD FAQ

**HOMEBD — Home Onboard Monitoring & Electronic Board Diagnostics**  
**Version:** Beta v2.0.0  
**Developer:** lufime

## Settings
SETTINGS is opened from the main dashboard. The three-dot menu in the upper-right provides access to **FAQ** and **ABOUT**.

## PID Filter
SETTINGS > PID FILTER lets you search standard OBD-II PIDs and enable or disable individual parameters. The selection is stored locally.

## LIVE DATA selection
LIVE DATA uses the PIDs detected as supported by the vehicle that remain enabled in PID FILTER. GAUGES, VALUES and GRAPHS use the same active set.

## Gauges
**GAUGES** presents the active numeric PIDs as real gauge instruments with an adaptive range. The gauge view is intended for at-a-glance real-time monitoring.

## Graphs
**GRAPHS** presents a separate real-time line chart for each active PID with available history. The graph uses the latest samples received by HOMEBD.

## Active PID count
The active count represents detected supported PIDs that remain enabled by the PID Filter and are available to LIVE DATA.

## Consumption
- **L/100 km:** fuel rate × 100 ÷ vehicle speed.
- **kWh/100 km:** electrical power × 100 ÷ vehicle speed.
- When direct electrical power is unavailable, HOMEBD can estimate it from voltage × current where suitable data exists.

## READ-ONLY
HOMEBD does not write to, program, code or clear vehicle ECUs.

## Home Assistant
Home Assistant integration is optional.

## About / project
The About screen contains the official project identity, developer information and GitHub project address:
**https://github.com/lufime/HOMEBD**


## Background Monitoring
HOMEBD can keep OBD-II monitoring active in the background when enabled in Settings. Android displays a persistent foreground-service notification with the OBD connection state and active PID count. Disabling the option stops background monitoring and removes the notification.


### Does Background Monitoring depend on the main screen?
No. When enabled, the Bluetooth/OBD session is held by the process-wide HOMEBD session manager and the foreground service keeps the session visible to Android. The Activity is only the user interface.
