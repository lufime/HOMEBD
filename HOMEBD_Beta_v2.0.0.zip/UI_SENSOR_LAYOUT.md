# HOMEBD Beta v2.0.0 — Sensor Layout

## Live Data
LIVE DATA is a dedicated full-screen horizontal layout, separate from the main dashboard.

## Gauges / Bars
All detected compatible numeric sensors can be assigned to a gauge or bar.
Typical adaptive ranges:
- RPM: 0–7000 rpm
- Vehicle speed: 0–250 km/h
- Engine coolant temperature: 0–130 °C
- Engine oil temperature: 0–150 °C
- Intake air temperature: 0–100 °C
- Ambient temperature: -30–60 °C
- Accelerator/throttle/load: 0–100%
- Fuel level: 0–100%
- MAP/MAF, pressure and voltage: adaptive range based on detected sensor data

## Values
All compatible detected sensors are available in a dedicated Values view: Sensor | Value | Unit | Status.

## Graphs
Any compatible numeric sensor can be selected for a time-series graph. Multiple sensors may be selected for comparison.

## Sensor selection
Each detected compatible sensor can be assigned independently to Gauge, Bar, Value, or Graph.

## Safety
This changes presentation/layout only. OBD-II/Bluetooth communication, PID discovery, diagnostics and Home Assistant logic remain unchanged.

## LIVE DATA visual presentation
- GAUGES: circular gauge instruments for active numeric PIDs.
- VALUES: active PID list with current values.
- GRAPHS: individual line charts for active PIDs with rolling history.


## Background Monitoring
HOMEBD can keep OBD-II monitoring active in the background when enabled in Settings. Android displays a persistent foreground-service notification with the OBD connection state and active PID count. Disabling the option stops background monitoring and removes the notification.
