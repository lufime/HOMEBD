package pt.homebd

/**
 * HOMEBD V2.14 - validação de PIDs OBD-II.
 *
 * Um PID só é considerado suportdo quando a response contém:
 * 0x41 + PID solicitado + pelo menos um byte de data
 *
 * NO DATA / SEM RESPOSTA / responses negativas not são valuees.
 */
object ObdPidValidator {
 fun isValidResponse(pid: Int, response: String): Boolean {
 val clean = response
 .replace("\\s".toRegex(), "")
 .uppercase()

 if (clean.isEmpty()) return false
 if (clean.contains("NODATA") || clean.contains("SEMRESPOSTA")) return false
 if (clean.startsWith("7F")) return false

 val expected = "41" + "%02X".format(pid and 0xFF)
 return clean.contains(expected) && clean.length >= expected.length + 2
 }
}
