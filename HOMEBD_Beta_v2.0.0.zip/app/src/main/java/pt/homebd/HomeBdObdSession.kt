package pt.homebd

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Process-wide OBD transport/session owner.
 *
 * The transport is deliberately independent of MainActivity so the
 * foreground service and the UI can use the same live OBD session.
 * No diagnostic write/programming operations are introduced here.
 */
class HomeBdObdSession private constructor(private val context: Context) {
    companion object {
        @Volatile private var instance: HomeBdObdSession? = null
        fun get(context: Context): HomeBdObdSession =
            instance ?: synchronized(this) {
                instance ?: HomeBdObdSession(context.applicationContext).also { instance = it }
            }
    }

    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: android.bluetooth.BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private var bleGatt: BluetoothGatt? = null
    private var bleWriteCharacteristic: BluetoothGattCharacteristic? = null
    private var bleNotifyCharacteristic: BluetoothGattCharacteristic? = null
    private val bleRx = LinkedBlockingQueue<Byte>(8192)
    @Volatile private var usingBle = false
    private var bleConnectedLatch: CountDownLatch? = null
    private var bleServicesLatch: CountDownLatch? = null
    private var bleNotificationLatch: CountDownLatch? = null
    private var bleWriteLatch: CountDownLatch? = null

    private val bleUartServices = listOf(
        UUID.fromString("6E400001-B5A3-F393-E0A9-E50E24DCCA9E"),
        UUID.fromString("0000FFE0-0000-1000-8000-00805F9B34FB"),
        UUID.fromString("49535343-FE7D-4AE5-8FA9-9FAFD205E455")
    )
    private val bleWriteUuids = setOf(
        UUID.fromString("6E400002-B5A3-F393-E0A9-E50E24DCCA9E"),
        UUID.fromString("0000FFE1-0000-1000-8000-00805F9B34FB"),
        UUID.fromString("49535343-8841-43F4-A8D4-ECBE34729BB3")
    )
    private val bleNotifyUuids = setOf(
        UUID.fromString("6E400003-B5A3-F393-E0A9-E50E24DCCA9E"),
        UUID.fromString("0000FFE1-0000-1000-8000-00805F9B34FB"),
        UUID.fromString("49535343-1E4D-4BD9-BA61-23C647249616")
    )

    @Volatile var adapterIdentity: String = ""
        private set
    @Volatile var adapterKind: String = "OBD-II Bluetooth"
        private set
    @Volatile var detectedProtocol: String = ""
        private set
    @Volatile var canActive: Boolean = false
        private set

    val isBle: Boolean get() = usingBle
    val isConnected: Boolean get() = (usingBle && bleWriteCharacteristic != null) || output != null

    data class ConnectionInfo(
        val adapterKind: String,
        val adapterIdentity: String,
        val protocol: String,
        val protocolNumber: String,
        val canActive: Boolean,
        val usingBle: Boolean
    )

    @Synchronized
    fun connect(device: BluetoothDevice): ConnectionInfo {
        close()
        var classicError: Exception? = null
        try {
            if (Build.VERSION.SDK_INT >= 31 &&
                context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
            ) throw SecurityException("Bluetooth permission required")
            socket = device.createRfcommSocketToServiceRecord(spp)
            socket!!.connect()
            input = socket!!.inputStream
            output = socket!!.outputStream
            usingBle = false
            adapterKind = "OBD-II Bluetooth Classic"
        } catch (e: Exception) {
            classicError = e
            try { socket?.close() } catch (_: Exception) {}
            socket = null; input = null; output = null
            connectBle(device)
            usingBle = true
            adapterKind = "OBD-II Bluetooth BLE"
        }

        try {
            elm("ATZ", 5000)
            Thread.sleep(1200)
            elm("ATE0", 2500)
            adapterIdentity = elm("ATI", 2500)
            adapterKind = identifyAdapter(adapterIdentity) + if (usingBle) " • BLE" else " • Bluetooth Classic"
            elm("ATL0", 2500)
            elm("ATS0", 2500)
            elm("ATSP0", 2500)

            val protocol = elm("ATDP", 2500)
            var protocolNumber = elm("ATDPN", 2500).trim().uppercase().removePrefix("A")
            if (protocol.isBlank()) throw IOException("Adapter did not respond to ATDP")

            detectedProtocol = protocolNumber
            canActive = protocolNumber in setOf("6", "7", "8", "9", "A", "B", "C") || protocol.uppercase().contains("CAN") || protocol.uppercase().contains("J1939")
            if (!canActive || protocolNumber == "0") {
                val stable = stabilizeCanProtocol()
                if (stable != null) {
                    protocolNumber = stable
                    detectedProtocol = stable
                    canActive = true
                }
            }
            if (canActive) {
                elm("ATCFC1", 1500)
            }
            return ConnectionInfo(adapterKind, adapterIdentity, protocol, protocolNumber, canActive, usingBle)
        } catch (e: Exception) {
            close()
            if (classicError != null && !usingBle) throw classicError
            throw e
        }
    }

    private fun stabilizeCanProtocol(): String? {
        val candidates = listOf("6", "7", "8", "9")
        for (candidate in candidates) {
            try {
                elm("ATSP$candidate", 1800)
                elm("ATCAF1", 1000)
                elm("ATCFC1", 1000)
                val raw = elm("0100", 3000)
                if (isPositiveObdResponse(raw, 0x41, 0x00)) return candidate
            } catch (_: Exception) { }
        }
        elm("ATSP0", 1200)
        return null
    }

    private fun isPositiveObdResponse(raw: String, service: Int, pid: Int): Boolean {
        val hex = raw.uppercase().replace(Regex("[^0-9A-F]"), "")
        val marker = String.format("%02X%02X", service, pid)
        return hex.contains(marker)
    }

    private fun connectBle(device: BluetoothDevice) {
        if (Build.VERSION.SDK_INT >= 31 && context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
            throw SecurityException("Bluetooth permission required")
        bleConnectedLatch = CountDownLatch(1)
        bleServicesLatch = CountDownLatch(1)
        bleNotificationLatch = CountDownLatch(1)
        bleGatt = device.connectGatt(context, false, bleCallback, BluetoothDevice.TRANSPORT_LE)
        if (bleConnectedLatch?.await(8, TimeUnit.SECONDS) != true) { closeBle(); throw IOException("BLE: timeout while connecting to the adapter") }
        if (bleServicesLatch?.await(8, TimeUnit.SECONDS) != true || bleWriteCharacteristic == null) { closeBle(); throw IOException("BLE: OBD/UART service not found") }
        if (bleNotifyCharacteristic != null && bleNotificationLatch?.await(5, TimeUnit.SECONDS) != true) { closeBle(); throw IOException("BLE: notifications were not enabled") }
    }

    private val bleCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, statusCode: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                bleConnectedLatch?.countDown()
                if (Build.VERSION.SDK_INT >= 31 && context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return
                gatt.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                bleConnectedLatch?.countDown(); bleServicesLatch?.countDown(); bleNotificationLatch?.countDown(); bleWriteLatch?.countDown()
            }
        }
        override fun onServicesDiscovered(gatt: BluetoothGatt, statusCode: Int) {
            if (statusCode != BluetoothGatt.GATT_SUCCESS) { bleServicesLatch?.countDown(); return }
            var write: BluetoothGattCharacteristic? = null
            var notify: BluetoothGattCharacteristic? = null
            for (service in gatt.services) {
                val serviceMatches = bleUartServices.contains(service.uuid)
                for (characteristic in service.characteristics) {
                    val props = characteristic.properties
                    val canWrite = props and BluetoothGattCharacteristic.PROPERTY_WRITE != 0 || props and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0
                    val canNotify = props and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0 || props and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0
                    if (canWrite && (serviceMatches || bleWriteUuids.contains(characteristic.uuid))) write = characteristic
                    if (canNotify && (serviceMatches || bleNotifyUuids.contains(characteristic.uuid))) notify = characteristic
                }
            }
            bleWriteCharacteristic = write; bleNotifyCharacteristic = notify
            if (notify != null && (Build.VERSION.SDK_INT < 31 || context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)) {
                gatt.setCharacteristicNotification(notify, true)
                notify.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805F9B34FB"))?.let { descriptor ->
                    descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    gatt.writeDescriptor(descriptor)
                }
            }
            bleServicesLatch?.countDown()
        }
        override fun onDescriptorWrite(gatt: BluetoothGatt, descriptor: BluetoothGattDescriptor, statusCode: Int) {
            if (descriptor.uuid == UUID.fromString("00002902-0000-1000-8000-00805F9B34FB")) bleNotificationLatch?.countDown()
        }
        override fun onCharacteristicWrite(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) { bleWriteLatch?.countDown() }
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) { characteristic.value?.forEach { bleRx.offer(it) } }
        @Deprecated("Deprecated in API 33") override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) { value.forEach { bleRx.offer(it) } }
    }

    private fun writeBle(data: ByteArray) {
        val gatt = bleGatt ?: throw IOException("BLE not connected")
        val characteristic = bleWriteCharacteristic ?: throw IOException("BLE: write characteristic not found")
        if (Build.VERSION.SDK_INT >= 31 && context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) throw SecurityException("Bluetooth permission required")
        val latch = CountDownLatch(1)
        bleWriteLatch = latch
        characteristic.value = data
        characteristic.writeType = if (characteristic.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        if (!gatt.writeCharacteristic(characteristic)) { bleWriteLatch = null; throw IOException("BLE: failed to send command") }
        if (characteristic.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE == 0) {
            if (!latch.await(3, TimeUnit.SECONDS)) { bleWriteLatch = null; throw IOException("BLE write timeout") }
        } else Thread.sleep(25)
        bleWriteLatch = null
    }

    private fun closeBle() {
        try {
            if (Build.VERSION.SDK_INT < 31 || context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) {
                bleGatt?.disconnect(); bleGatt?.close()
            }
        } catch (_: Exception) { }
        bleGatt = null; bleWriteCharacteristic = null; bleNotifyCharacteristic = null; bleRx.clear(); usingBle = false
    }

    @Synchronized fun close() {
        try { socket?.close() } catch (_: Exception) { }
        socket = null; input = null; output = null
        closeBle()
        adapterIdentity = ""; adapterKind = "OBD-II Bluetooth"; detectedProtocol = ""; canActive = false
    }

    @Synchronized fun elm(cmd: String, timeout: Long = 2500): String {
        if (usingBle) return elmBle(cmd, timeout)
        val out = output ?: return ""
        val ins = input ?: return ""
        try { out.write((cmd + "\r").toByteArray(Charsets.US_ASCII)); out.flush() }
        catch (e: Exception) { throw IOException("Failed to send $cmd: ${e.message}", e) }
        val start = System.currentTimeMillis(); val buf = ByteArray(4096); val data = StringBuilder()
        while (System.currentTimeMillis() - start < timeout) {
            if (ins.available() > 0) {
                val n = ins.read(buf); if (n > 0) data.append(String(buf, 0, n, Charsets.US_ASCII))
                if (data.contains(">")) break
            } else Thread.sleep(30)
        }
        return data.toString().replace("\r", "\n").replace(">", "").trim()
    }

    private fun elmBle(cmd: String, timeout: Long): String {
        if (bleWriteCharacteristic == null) return ""
        bleRx.clear(); writeBle((cmd + "\r").toByteArray(Charsets.US_ASCII))
        val deadline = System.currentTimeMillis() + timeout; val data = StringBuilder()
        while (System.currentTimeMillis() < deadline) {
            val remaining = deadline - System.currentTimeMillis()
            val b = bleRx.poll(minOf(remaining, 100), TimeUnit.MILLISECONDS)
            if (b != null) { data.append(b.toInt().and(0xFF).toChar()); if (data.contains(">")) break }
        }
        return data.toString().replace("\r", "\n").replace(">", "").trim()
    }

    private fun identifyAdapter(identity: String): String {
        val id = identity.uppercase()
        return when {
            id.contains("STN") -> "STN / OBDLink"
            id.contains("OBDLINK") || id.contains("SCANTOOL") -> "OBDLink / compatible"
            id.contains("ELM327") -> "ELM327 compatible"
            id.isBlank() -> "OBD-II Bluetooth"
            else -> "OBD-II compatible"
        }
    }
}
