package pt.homebd

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * HOMEBD foreground service.
 *
 * The service is started only while an OBD session is active. It keeps the
 * application in the foreground-service execution class while the Activity
 * is in the background. The OBD/ELM327 transport is owned by the process-wide
 * HomeBdObdSession and is therefore independent from the Activity UI.
 */
class HomeBdForegroundService : Service() {

 companion object {
 const val ACTION_START = "pt.homebd.action.START_FOREGROUND"
 const val ACTION_STOP = "pt.homebd.action.STOP_FOREGROUND"
 private const val PREFS = "homebd_settings"
 private const val PREF_BACKGROUND = "background_monitoring"
 @Volatile private var activePidCount = 0
 @Volatile private var connectionState = "OBD-II · Live Data active"

 private const val CHANNEL_ID = "homebd_obd_session"
 private const val NOTIFICATION_ID = 41001
 private var monitorThread: Thread? = null
 @Volatile private var monitorRunning = false

 fun start(context: Context) {
 val intent = Intent(context, HomeBdForegroundService::class.java)
 .setAction(ACTION_START)

 if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
 context.startForegroundService(intent)
 } else {
 context.startService(intent)
 }
 }

 fun stop(context: Context) {
 context.stopService(
 Intent(context, HomeBdForegroundService::class.java)
 )
 }

 fun isEnabled(context: Context): Boolean =
 context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
  .getBoolean(PREF_BACKGROUND, false)

 fun setEnabled(context: Context, enabled: Boolean) {
  context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
   .edit().putBoolean(PREF_BACKGROUND, enabled).apply()
  if (!enabled) stop(context)
 }

 fun updateNotification(context: Context, activePids: Int, state: String = "OBD-II · Background Monitoring") {
  activePidCount = activePids.coerceAtLeast(0)
  connectionState = state
  val manager = context.getSystemService(NotificationManager::class.java)
  manager?.notify(NOTIFICATION_ID, buildNotificationFor(context))
 }

 private fun buildNotificationFor(context: Context): Notification {
  val openIntent = Intent(context, MainActivity::class.java).apply {
   flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
  }
  val flags = PendingIntent.FLAG_UPDATE_CURRENT or
   if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
  val openPending = PendingIntent.getActivity(context, 41002, openIntent, flags)
  return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
   Notification.Builder(context, CHANNEL_ID)
    .setSmallIcon(R.drawable.homebd_icon)
    .setContentTitle("HOMEBD")
    .setContentText("$connectionState · $activePidCount active PIDs")
    .setSubText("Background Monitoring")
    .setOngoing(true)
    .setCategory(Notification.CATEGORY_SERVICE)
    .setContentIntent(openPending)
    .setOnlyAlertOnce(true)
    .build()
  } else {
   Notification.Builder(context)
    .setSmallIcon(R.drawable.homebd_icon)
    .setContentTitle("HOMEBD")
    .setContentText("$connectionState · $activePidCount active PIDs")
    .setOngoing(true)
    .setContentIntent(openPending)
    .build()
  }
 }
 }

 override fun onCreate() {
 super.onCreate()
 createChannel()
 }

 override fun onStartCommand(
 intent: Intent?,
 flags: Int,
 startId: Int
 ): Int {
 when (intent?.action) {
 ACTION_STOP -> {
 stopForeground(STOP_FOREGROUND_REMOVE)
 stopSelf()
 return START_NOT_STICKY
 }
 }

 val notification = buildNotification()

 startSessionMonitor()

 if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
 startForeground(
 NOTIFICATION_ID,
 notification,
 ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
 )
 } else {
 startForeground(NOTIFICATION_ID, notification)
 }

 // Do not resurrect an old OBD session after the process is killed.
 return START_NOT_STICKY
 }

 private fun createChannel() {
 if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

 val manager = getSystemService(NotificationManager::class.java)
 manager.createNotificationChannel(
 NotificationChannel(
 CHANNEL_ID,
 "HOMEBD — session OBD",
 NotificationManager.IMPORTANCE_LOW
 ).apply {
 description =
 "Session OBD-II e Live Data do HOMEBD em second plano."
 setShowBadge(false)
 }
 )
 }

 private fun buildNotification(): Notification = buildNotificationFor(this)

 override fun onDestroy() {
  monitorRunning = false
  monitorThread?.interrupt()
  monitorThread = null
  super.onDestroy()
 }

 private fun startSessionMonitor() {
  if (monitorRunning) return
  monitorRunning = true
  monitorThread = Thread({
   val session = HomeBdObdSession.get(this)
   while (monitorRunning) {
    try {
     val state = if (session.isConnected) "OBD-II · Connected" else "OBD-II · Waiting"
     updateNotification(this, activePidCount, state)
     Thread.sleep(2000L)
    } catch (_: InterruptedException) {
     break
    } catch (_: Throwable) {
     // Notification refresh must never terminate the OBD service.
    }
   }
  }, "HOMEBD-SessionMonitor").also { it.isDaemon = true; it.start() }
 }

 override fun onBind(intent: Intent?): IBinder? = null
}

// HOMEBD: notification permission check is required by Android 13+ before starting the foreground service.
