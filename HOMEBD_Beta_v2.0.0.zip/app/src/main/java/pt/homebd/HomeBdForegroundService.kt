package pt.homebd

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * HOMEBD foreground service.
 *
 * The service is started only while an OBD session is active. It keeps the
 * application in the foreground-service execution class while the Activity
 * is in the background. The existing OBD/ELM327 transport remains owned by
 * MainActivity in this project.
 */
class HomeBdForegroundService : Service() {

 companion object {
 const val ACTION_START = "pt.homebd.action.START_FOREGROUND"
 const val ACTION_STOP = "pt.homebd.action.STOP_FOREGROUND"

 private const val CHANNEL_ID = "homebd_obd_session"
 private const val NOTIFICATION_ID = 41001

 fun start(context: Context) {
 val intent = Intent(context, HomeBdForegroundService::class.java)
 .setAction(ACTION_START)

 if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
 context.startForegroundService(intent)
 } else {
 context.startService(intent)
 }
 }

 fun stop(context: Context) {
 context.stopService(
 Intent(context, HomeBdForegroundService::class.java)
 )
 }
 }

 override fun onCreate() {
 super.onCreate()
 createChannel()
 }

 override fun onStartCommand(
 intent: Intent?,
 flags: Int,
 startId: Int
 ): Int {
 when (intent?.action) {
 ACTION_STOP -> {
 stopForeground(STOP_FOREGROUND_REMOVE)
 stopSelf()
 return START_NOT_STICKY
 }
 }

 val notification = buildNotification()

 if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
 startForeground(
 NOTIFICATION_ID,
 notification,
 ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
 )
 } else {
 startForeground(NOTIFICATION_ID, notification)
 }

 // Do not resurrect an old OBD session after the process is killed.
 return START_NOT_STICKY
 }

 private fun createChannel() {
 if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

 val manager = getSystemService(NotificationManager::class.java)
 manager.createNotificationChannel(
 NotificationChannel(
 CHANNEL_ID,
 "HOMEBD — session OBD",
 NotificationManager.IMPORTANCE_LOW
 ).apply {
 description =
 "Session OBD-II e Live Data do HOMEBD em second plano."
 setShowBadge(false)
 }
 )
 }

 private fun buildNotification(): Notification {
 val openIntent = Intent(this, MainActivity::class.java).apply {
 flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or
 Intent.FLAG_ACTIVITY_CLEAR_TOP
 }

 val pendingFlags =
 PendingIntent.FLAG_UPDATE_CURRENT or
 if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
 PendingIntent.FLAG_IMMUTABLE
 } else {
 0
 }

 val openPending = PendingIntent.getActivity(
 this,
 41002,
 openIntent,
 pendingFlags
 )

 return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
 Notification.Builder(this, CHANNEL_ID)
 .setSmallIcon(R.drawable.homebd_icon)
 .setContentTitle("HOMEBD")
 .setContentText("OBD-II · Live Data active")
 .setSubText("Bluetooth · READ-ONLY")
 .setOngoing(true)
 .setCategory(Notification.CATEGORY_SERVICE)
 .setContentIntent(openPending)
 .setOnlyAlertOnce(true)
 .build()
 } else {
 Notification.Builder(this)
 .setSmallIcon(R.drawable.homebd_icon)
 .setContentTitle("HOMEBD")
 .setContentText("OBD-II · Live Data active")
 .setOngoing(true)
 .setContentIntent(openPending)
 .build()
 }
 }

 override fun onBind(intent: Intent?): IBinder? = null
}

// HOMEBD: notification permission check is required by Android 13+ before starting the foreground service.
