package pt.homebd

/**
 * Universal READ-ONLY discovery plan.
 *
 * Order:
 * CAN stabilization -> standard OBD/PIDs -> VIN -> HV/BMS -> GPS/Telematics
 * -> live data publication.
 *
 * The actual ECU queries remain in MainActivity/ELM327 code; this class keeps
 * the policy explicit and prevents accidental write services.
 */
object HomeBdReadOnlyDiscovery {
 const val VIN_DID = "F190"
 const val SERVICE_READ_DATA = "22"
 const val GPS_TELEMATICS_LABEL = "GPS/Telemática"
 const val HV_BMS_LABEL = "HV/BMS"

 fun isReadOnlyService(service: String): Boolean =
 service.equals("22", true) || service.equals("01", true) ||
 service.equals("09", true)

 fun plan(): List<String> = listOf(
 "CAN stabilization ISO 15765-4 11-bit / 500 kbit/s",
 "OBD-II standard PIDs",
 "VIN 09 02 / UDS F190 fallback",
 "HV/BMS UDS discovery",
 "GPS/Telemática UDS discovery",
 "Live Data",
 "Home Assistant WebSocket"
 )
}
