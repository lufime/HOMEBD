package pt.homebd

/**
 * GPS/Telematics discovery result.
 * Coordinates are only populated when an ECU actually returns a confirmed
 * value. No guessed location is produced.
 */
data class HomeBdGpsDiscovery(
 val ecuRequestId: String = "",
 val ecuResponseId: String = "",
 val moduleDetected: Boolean = false,
 val satellites: Int? = null,
 val latitude: Double? = null,
 val longitude: Double? = null,
 val note: String = "READ-ONLY discovery"
)
