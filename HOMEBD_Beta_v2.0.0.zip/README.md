# HOMEBD

**HOMEBD — Home Onboard Monitoring & Electronic Board Diagnostics**

Independent Android application for read-only OBD-II vehicle monitoring and diagnostics, with optional Home Assistant integration.

**Current release: Beta v2.0.0**

LIVE DATA rendering is bounded to avoid unnecessary UI rebuilds during continuous PID polling, and graph history is kept to a fixed in-memory window.

## Features

- Bluetooth OBD-II adapter connection
- OBD-II / CAN diagnostic communication
- Read-only vehicle monitoring and diagnostics
- Automatic diagnostic parameter discovery
- VIN discovery where supported
- LIVE DATA
- Optional Home Assistant integration
- Real-time HOMEBD telemetry
- SETTINGS with PID FILTER, search, per-PID enable/disable and persistent selection
- LIVE DATA synchronized with the selected active PID set across GAUGES, VALUES and GRAPHS
- Active PID count on the main connection dashboard
- `sensor.homebd_*` entity namespace

## Language

HOMEBD detects the Android system language automatically. When a supported language is available, it is selected automatically. English is used as the fallback language.

## Installation

See [INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md).

## Home Assistant

Home Assistant integration is optional.

See [INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md) for setup information.

## Project documentation

- [ABOUT.md](ABOUT.md)
- [FAQ.md](FAQ.md)
- [INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md)
- [LICENSES.md](LICENSES.md)
- [LICENSE](LICENSE)

## License

Original HOMEBD source code and documentation are released under the MIT License unless otherwise stated.

The HOMEBD name, logo, icons and original graphics are original project assets created for HOMEBD and owned by lufime. The MIT software licence does not grant trademark rights to the official HOMEBD visual identity.

See [LICENSES.md](LICENSES.md) for external component licences and official licence links.

## Beta status

HOMEBD Beta v2.0.0 is a development release. Diagnostic coverage, supported parameters, interface elements and integration behaviour may change in future releases.


## Beta v2.0.0 features

- Full-width Live Data dashboard with GAUGES, VALUES and GRAPHS views.
- Real-time gauges for RPM, vehicle speed, coolant temperature, throttle, engine load and control-module voltage when supported.
- PID discovery remains explicit and read-only.
- Standard OBD-II DTC reading through Mode 03 when supported. HOMEBD does not clear DTCs or write to ECUs.
- HV / UDS read-only discovery remains available for supported hybrid/EV modules.
- Home Assistant WebSocket integration remains optional.
- Export/share options for Live Data and diagnostics.


## Current release
**Beta v2.0.0** — UI layout aligned with the reference design. Live Data uses a dedicated full-screen layout with Gauges, Values and Graphs. Core OBD-II/Bluetooth and Home Assistant logic is unchanged.


## Current release — Beta v2.0.0

This release documents the redesigned UI structure: a dedicated full-screen Live Data layout, adaptive Gauge/Bar/Value/Graph presentation for compatible detected sensors, and multi-sensor graph selection.

Developer: **lufime**


## Vehicle independence
HOMEBD Beta v2.0.0 is vehicle-independent. References specific to C5/Citroën vehicles have been removed from the documentation and project text. The application presents compatible OBD-II data based on detected sensors/PIDs rather than a fixed vehicle model.


## Beta v2.0.0 — portrait vehicle dashboard
- Main dashboard is portrait/vertical and centered.
- The interactive generic vehicle is the main visual element.
- The vehicle opens the dedicated LIVE DATA screen when tapped.
- LIVE DATA displays instantaneous fuel consumption as **L/100 km** using `fuel rate × 100 / speed`.
- LIVE DATA displays instantaneous electric consumption as **kWh/100 km** using `electrical power × 100 / speed`, when compatible power/voltage/current data is available.
- The application remains vehicle-independent.
- Developer: **lufime**


## Settings

HOMEBD Beta v2.0.0 includes a dedicated Settings screen with a **PID Filter**. Each standard OBD-II PID can be enabled or disabled, the list can be searched by PID code or name, and the selection is stored locally. After capability discovery, only vehicle-supported and enabled PIDs are used by LIVE DATA.

Official name: **HOMEBD — Home Onboard Monitoring & Electronic Board Diagnostics**.


## Project
GitHub: https://github.com/lufime/HOMEBD


## Background Monitoring
HOMEBD can keep OBD-II monitoring active in the background when enabled in Settings. Android displays a persistent foreground-service notification with the OBD connection state and active PID count. Disabling the option stops background monitoring and removes the notification.


### Background OBD session
When Background Monitoring is enabled, the OBD/Bluetooth session is owned by the process-wide HOMEBD session manager rather than by the Activity UI. The foreground service keeps the session visible to Android and refreshes the persistent notification while the UI is minimized. Closing the Activity therefore does not intentionally tear down an active OBD session.


### Stability and Background Monitoring
Background Monitoring uses a process-wide OBD session manager plus the Android foreground service. The Activity presents the session but does not own the Bluetooth transport, so minimizing the UI does not intentionally close an active OBD session. ELM/OBD commands are serialized by the session manager to prevent concurrent requests from corrupting the transport.


### Electric / Hybrid OBD coverage
HOMEBD supports the standard Hybrid/EV PIDs exposed by the vehicle, including PID 015B (hybrid/EV battery pack remaining life when supported) and PID 019A (Hybrid/EV vehicle system data). PID 019A is decoded read-only into battery voltage, battery current and operating mode when the ECU provides those fields. Availability depends on the vehicle ECU and protocol. Manufacturer-specific battery PIDs are not assumed automatically.


### Standard OBD-II PID coverage
HOMEBD exposes the standards-based Mode 01 PID catalogue through PID Filter. Support is determined by the vehicle-reported PID bitmaps; unsupported PIDs are not requested. No manufacturer-specific PID tables from third-party apps are used.


**PID Filter default:** on a fresh installation, HOMEBD pre-selects 30 core OBD-II PIDs covering engine load/temperature, RPM/speed, airflow/throttle, voltage, fuel, hybrid/EV data, torque, extended runtime, transmission gear and odometer. User changes are persisted on the device.
