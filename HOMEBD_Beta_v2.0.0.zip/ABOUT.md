# About HOMEBD

## Identity

**HOMEBD — Home Onboard Monitoring & Electronic Board Diagnostics**

**Version:** Beta v2.0.0 
**Developer:** lufime

## Purpose

HOMEBD is an independent Android project focused on read-only vehicle monitoring and diagnostics, with optional Home Assistant integration.

The project provides vehicle data through a dedicated Android interface and can make supported telemetry available to Home Assistant when the optional integration is enabled.

## Design principles

- Read-only monitoring and diagnostics
- Automatic application language detection
- Optional Home Assistant integration
- Clear separation between HOMEBD material and external components
- Original HOMEBD visual assets

## Project assets

The HOMEBD icons, logos and original graphics included with the project were created for HOMEBD and are owned by lufime.

The HOMEBD name and official visual identity are project branding.

## Copyright

Copyright © 2026 lufime — HOMEBD

Original HOMEBD source code and documentation are licensed under the MIT License unless otherwise stated.


### Official project name
**HOMEBD — Home Onboard Monitoring & Electronic Board Diagnostics**

### Settings
The application includes a PID Filter in Settings so standard OBD-II parameters can be individually enabled or disabled before LIVE DATA requests.
