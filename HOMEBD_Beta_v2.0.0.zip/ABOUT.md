# About HOMEBD

**HOMEBD — Home Onboard Monitoring & Electronic Board Diagnostics**

- Version: Beta v2.0.0
- Developer: lufime
- GitHub: https://github.com/lufime/HOMEBD

HOMEBD is an independent Android application for READ-ONLY OBD-II monitoring and diagnostics, with optional Home Assistant integration.


## Background Monitoring
HOMEBD can keep OBD-II monitoring active in the background when enabled in Settings. Android displays a persistent foreground-service notification with the OBD connection state and active PID count. Disabling the option stops background monitoring and removes the notification.
