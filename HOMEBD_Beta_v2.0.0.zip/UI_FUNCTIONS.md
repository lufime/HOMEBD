# HOMEBD — UI and Function Specification

## Beta v2.0.0

The HOMEBD dashboard follows the dynamic diagnostic flow used by the current visual concept.

### 1. Application start
- HOMEBD branding and vehicle-diagnostics purpose.
- Read-only operation is maintained.

### 2. Main connection screen
- Bluetooth OBD-II adapter selection.
- Automatic/manufacturer profile selection.
- CONNECT / DISCONNECT OBD-II.
- Connection status indicator.

### 3. PID scan
- Explicit SCAN PIDs / RESCAN PIDs action.
- Supported standard OBD-II PIDs are discovered from vehicle responses.
- Unsupported parameters are not invented.

### 4. LIVE DATA
Three views are available:

- **GAUGES** — displays the numeric PIDs currently enabled in PID FILTER and detected by the vehicle, with adaptive/common ranges.
- **VALUES** — lists the active detected PIDs and their latest values.
- **GRAPHS** — shows rolling history for the same active PID set.
- **Consumption** — L/100 km and kWh/100 km remain inside LIVE DATA.

Fast parameters are prioritised for approximately one-second telemetry cycles where the adapter and vehicle permit it.

### 5. Diagnostics
- Standard OBD-II Mode 03 DTC reading when supported.
- Diagnostic output remains read-only.
- HOMEBD does not clear codes, program ECUs, flash firmware or perform coding.

### 6. HV / UDS SCAN
- Existing read-only HV/BMS and UDS discovery remains available.
- Only confirmed positive responses are presented.

### 7. Home Assistant
- Optional persistent WebSocket integration.
- HOMEBD entities remain in the `sensor.homebd_*` namespace.
- Existing configuration and authentication flow are retained.

### 8. Export and sharing
- Live Data TXT/CSV export.
- Diagnostics TXT/CSV export.
- Direct Android sharing of the current data.

## Layout

All primary dashboard cards use the available width of the activity. The dashboard is designed to remain centred and full-width rather than leaving a fixed-width panel offset to either side.


## SETTINGS
- Full-screen Settings view.
- PID Filter with search by code/name.
- Per-PID enable/disable.
- Enable All / Disable All.
- Selection persisted locally.
- LIVE DATA requests only vehicle-supported PIDs that remain enabled.


## Active PID synchronization
- SETTINGS > PID FILTER controls which standard OBD-II PIDs may be requested after capability discovery.
- The selection is persisted locally on the device.
- LIVE DATA uses only PIDs that are both supported by the vehicle and enabled in PID FILTER.
- GAUGES, VALUES and GRAPHS use the same active PID selection.
- The main dashboard reports the number of active detected PIDs.

## Beta v2.0.0 UI refinements
- GAUGES use real circular gauge instruments for active numeric PIDs.
- GRAPHS use per-PID real-time line charts with rolling samples.
- SETTINGS has a three-dot menu in the upper-right for FAQ and ABOUT.
- FAQ and ABOUT are no longer placed on the main dashboard footer.
- ABOUT includes the project GitHub address: https://github.com/lufime/HOMEBD
- The top HOMEBD logo area uses a soft gradient/transparent logo treatment to blend with the dashboard panels.


## Background Monitoring
HOMEBD can keep OBD-II monitoring active in the background when enabled in Settings. Android displays a persistent foreground-service notification with the OBD connection state and active PID count. Disabling the option stops background monitoring and removes the notification.


### Background OBD session architecture
The foreground service and the UI share a process-wide `HomeBdObdSession`. Bluetooth Classic/BLE transport, ELM command serialization and connection state are no longer owned by `MainActivity`. This allows the active session to continue while the Activity is minimized, when Background Monitoring is enabled.


### Electric / Hybrid OBD coverage
HOMEBD supports the standard Hybrid/EV PIDs exposed by the vehicle, including PID 015B (hybrid/EV battery pack remaining life when supported) and PID 019A (Hybrid/EV vehicle system data). PID 019A is decoded read-only into battery voltage, battery current and operating mode when the ECU provides those fields. Availability depends on the vehicle ECU and protocol. Manufacturer-specific battery PIDs are not assumed automatically.


### Standard OBD-II PID coverage
HOMEBD exposes the standards-based Mode 01 PID catalogue through PID Filter. Support is determined by the vehicle-reported PID bitmaps; unsupported PIDs are not requested. No manufacturer-specific PID tables from third-party apps are used.


**PID Filter default:** on a fresh installation, HOMEBD pre-selects 30 core OBD-II PIDs covering engine load/temperature, RPM/speed, airflow/throttle, voltage, fuel, hybrid/EV data, torque, extended runtime, transmission gear and odometer. User changes are persisted on the device.
