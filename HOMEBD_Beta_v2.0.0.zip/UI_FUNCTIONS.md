# HOMEBD — UI and Function Specification

## Beta v2.0.0

The HOMEBD dashboard follows the dynamic diagnostic flow used by the current visual concept.

### 1. Application start
- HOMEBD branding and vehicle-diagnostics purpose.
- Read-only operation is maintained.

### 2. Main connection screen
- Bluetooth OBD-II adapter selection.
- Automatic/manufacturer profile selection.
- CONNECT / DISCONNECT OBD-II.
- Connection status indicator.

### 3. PID scan
- Explicit SCAN PIDs / RESCAN PIDs action.
- Supported standard OBD-II PIDs are discovered from vehicle responses.
- Unsupported parameters are not invented.

### 4. LIVE DATA
Three views are available:

- **GAUGES** — RPM, vehicle speed, coolant temperature, throttle, engine load and control-module voltage when supported.
- **VALUES** — grouped live PID values.
- **GRAPHS** — short rolling history of the live parameters.

Fast parameters are prioritised for approximately one-second telemetry cycles where the adapter and vehicle permit it.

### 5. Diagnostics
- Standard OBD-II Mode 03 DTC reading when supported.
- Diagnostic output remains read-only.
- HOMEBD does not clear codes, program ECUs, flash firmware or perform coding.

### 6. HV / UDS SCAN
- Existing read-only HV/BMS and UDS discovery remains available.
- Only confirmed positive responses are presented.

### 7. Home Assistant
- Optional persistent WebSocket integration.
- HOMEBD entities remain in the `sensor.homebd_*` namespace.
- Existing configuration and authentication flow are retained.

### 8. Export and sharing
- Live Data TXT/CSV export.
- Diagnostics TXT/CSV export.
- Direct Android sharing of the current data.

## Layout

All primary dashboard cards use the available width of the activity. The dashboard is designed to remain centred and full-width rather than leaving a fixed-width panel offset to either side.


## SETTINGS
- Full-screen Settings view.
- PID Filter with search by code/name.
- Per-PID enable/disable.
- Enable All / Disable All.
- Selection persisted locally.
- LIVE DATA requests only vehicle-supported PIDs that remain enabled.
