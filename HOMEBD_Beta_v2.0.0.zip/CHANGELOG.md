# HOMEBD Beta v2.0.0 — UI/bug fixes

- Moved L/100 km and kWh/100 km consumption cards into the dedicated LIVE DATA screen.
- Fixed LIVE DATA re-rendering so consumption cards are not detached from the visible UI.
- Corrected gauge ranges to 0–7000 rpm, 0–250 km/h and 0–130 °C where applicable.
- Made the manufacturer/profile label single-line to prevent layout wrapping.
- Fixed nested LIVE DATA scrolling so the parent can take over at the panel limits.
- Home Assistant main status now says `configured` until an actual connection is established.
- Cleaned minor diagnostic code/documentation typos.

# HOMEBD Beta v2.0.0 — Portrait vehicle dashboard

- Main layout set to portrait/vertical.
- Generic interactive vehicle added as the central navigation element.
- Added L/100 km and kWh/100 km instantaneous consumption formulas.
- Consumption values use detected compatible OBD-II data and remain unavailable when the required inputs are not detected.
- Developer: lufime

# HOMEBD Beta v2.0.0

## UI and sensor layout
- LIVE DATA is a dedicated full-screen horizontal layout.
- Added support in the UI specification for all compatible detected numeric sensors.
- Each detected sensor can be presented as Gauge, Bar, Value or Graph.
- Multiple sensors can be selected for graph comparison.
- Adaptive ranges are defined for common automotive parameters.
- Main dashboard and Live Data layouts remain centered and use the available horizontal width.

## Core behavior
- OBD-II/Bluetooth communication logic is unchanged by the UI update.
- Home Assistant integration remains unchanged.
- Diagnostics and PID discovery remain read-only.

Developer: lufime

# HOMEBD — Beta v2.0.0

Layout aligned with the reference UI: main dashboard plus a dedicated full-screen Live Data layout (Gauges / Values / Graphs), with centered full-width cards.

# HOMEBD CHANGELOG

## Beta v2.0.0 — Dynamic diagnostic dashboard

### Application
- Added a Live Data dashboard with GAUGES, VALUES and GRAPHS views.
- Added live visualisation for RPM, speed, coolant temperature, throttle, engine load and control-module voltage when the vehicle confirms those PIDs.
- Added standard OBD-II Mode 03 diagnostic trouble-code reading when supported.
- Kept diagnostic operations read-only: no DTC clearing, ECU coding, programming or flashing.
- Added export/share choices for Live Data and diagnostics.
- Kept HV / UDS read-only discovery and Home Assistant WebSocket integration.

### Documentation
- Updated project documentation to Beta v2.0.0.
- Documented the new dashboard and diagnostic functions.

## Previous baseline

Initial documented HOMEBD Beta release.

### Application
- English-mode runtime strings cleaned up to prevent Portuguese UI/log text from appearing when Android is set to English.
- Read-only OBD-II vehicle monitoring and diagnostics.
- Bluetooth OBD-II adapter connection.
- Diagnostic parameter discovery.
- VIN discovery where supported.
- LIVE DATA monitoring.
- Automatic application language detection.
- English fallback when the Android system language is not supported.

### Home Assistant
- Optional Home Assistant integration.
- HOMEBD telemetry support.
- HOMEBD entity namespace: `sensor.homebd_*`.

### Documentation
- Documentation reset at Beta v2.0.0.
- English installation guide.
- Project overview and About documentation.
- Licensing documentation.
- Original HOMEBD icons, logos and graphics documented as project assets.

### Licensing
- Original HOMEBD source code and documentation released under the MIT License.
- External component licences documented separately in `LICENSES.md`.

## Future releases

Changes made after Beta v2.0.0 will be recorded here.


## Build fix
- Fixed an invalid Kotlin string interpolation in `MainActivity.kt` that caused `Unresolved reference: label` during Kotlin compilation.

### Home Assistant telemetry performance
- Added batched `homebd/update_batch` telemetry transport over the persistent WebSocket.
- LIVE DATA now queues the current cycle and sends supported HOMEBD sensor updates in one WebSocket message when the updated integration is installed.
- Added capability detection so older HOMEBD integrations continue to receive individual updates.

## Main layout vehicle visual
- Added a generic blue front-view vehicle visual with HOMEBD branding to the main dashboard.
- The visual is presentation-only and does not identify or target a specific vehicle model.
- OBD-II/Bluetooth and Home Assistant logic remain unchanged.
