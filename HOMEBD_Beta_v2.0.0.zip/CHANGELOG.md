## Beta v2.0.0

### Major updates
- Introduced the portrait main dashboard and dedicated full-screen LIVE DATA experience.
- Added real GAUGES, VALUES and GRAPHS views for active detected PIDs.
- Added SETTINGS with persistent PID FILTER controls.
- Added L/100 km and kWh/100 km consumption indicators inside LIVE DATA.
- Added the official HOMEBD identity: Home Onboard Monitoring & Electronic Board Diagnostics.

### Medium updates
- LIVE DATA now follows the PID FILTER and displays the active detected PID set consistently across GAUGES, VALUES and GRAPHS.
- Main dashboard shows the number of active detected PIDs.
- Added circular gauge presentation and per-PID real-time line graphs.
- Moved FAQ and ABOUT access into SETTINGS via the three-dot menu.
- Added the project GitHub address to ABOUT.
- Updated the in-app FAQ and project documentation.
- Improved LIVE DATA rendering stability by throttling UI rebuilds and retaining a bounded history buffer.
- Aligned the Android application version name with Beta v2.0.0 (`2.0.0`).

### Bug fixes
- Fixed LIVE DATA re-rendering and consumption card persistence.
- Fixed PID filter text-field compilation issue.
- Fixed single-line manufacturer/profile presentation.
- Fixed nested LIVE DATA scrolling behaviour.
- Fixed minor diagnostic, UI and documentation text issues.

**Developer:** lufime


## Bug fixes
- Improved background monitoring control and foreground notification state.
- Added active PID count to the HOMEBD background notification.

### Medium updates
- OBD transport/session ownership moved out of `MainActivity` into a process-wide session manager so Background Monitoring can keep the active Bluetooth/OBD session independent from the UI.
- Foreground notification now refreshes the OBD connection state while the Activity is minimized.

### Bug fixes
- Prevented Activity destruction from being coupled to OBD transport ownership.


### Medium updates
- Expanded standard electric/hybrid OBD coverage: improved Hybrid/EV PID 0x9A decoding (battery voltage, battery current and operating mode) and expanded standard hybrid fuel-type codes.

## Major updates
- Expanded the standards-based OBD-II Mode 01 catalogue through the documented 0xA8 range, including additional diesel, aftertreatment, NOx, hybrid/EV and drivetrain parameters.
- PID Filter now exposes the expanded standard catalogue while the existing support-bitmask scan prevents unsupported PIDs from being requested.

## Bug fixes
- Corrected several PID descriptions and torque decoding mappings so standard identifiers are not presented under incorrect names.
### Medium updates
- Moved Background Monitoring ON/OFF control to the bottom of the main dashboard for direct access.
- Reorganized FAQ and ABOUT access inside SETTINGS into dedicated actions.
- Improved LIVE DATA screen lifecycle handling to prevent duplicate screens and view-parent crashes.

### Bug fixes
- Fixed a LIVE DATA navigation crash caused by reusing views that could still be attached to a previous screen.
- LIVE DATA now stops cleanly when leaving its full-screen view.
- FAQ line breaks now render correctly instead of showing literal `\n` text.

