# Vehicle Consumption Formulas — HOMEBD Beta v2.0.0

## Fuel
When engine fuel rate and vehicle speed are available:

`L/100 km = fuel_rate_L_per_hour × 100 / speed_km_per_hour`

If the vehicle is stationary or speed is unavailable, HOMEBD shows `— L/100 km`.

## Electric
When electrical power and vehicle speed are available:

`kWh/100 km = electrical_power_kW × 100 / speed_km_per_hour`

If direct electrical power is unavailable, HOMEBD may estimate power from compatible voltage/current data:

`power_kW = voltage_V × current_A / 1000`

Then:

`kWh/100 km = power_kW × 100 / speed_km_per_hour`

These are instantaneous consumption estimates. They are not cumulative trip energy consumption unless distance/energy accumulation is separately available.

## UI
The values are displayed on the main interactive vehicle panel and in Live Data. Tapping the vehicle opens the dedicated Live Data screen.
