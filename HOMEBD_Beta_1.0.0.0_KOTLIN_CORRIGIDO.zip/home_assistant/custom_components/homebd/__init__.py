"""HOMEBD Home Assistant integration."""
from __future__ import annotations

import logging

import voluptuous as vol
from homeassistant.components import websocket_api
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback

from .const import DOMAIN, PLATFORMS, WS_PING_TYPE, WS_TYPE
from .sensor import HomeBdManager

_LOGGER = logging.getLogger(__name__)


async def async_setup(hass: HomeAssistant, config: dict) -> bool:
    """Set up HOMEBD and register its native WebSocket commands."""
    hass.data.setdefault(DOMAIN, {})
    websocket_api.async_register_command(hass, _ws_update)
    websocket_api.async_register_command(hass, _ws_ping)
    return True


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up one HOMEBD hub."""
    manager = HomeBdManager(hass, entry)
    hass.data.setdefault(DOMAIN, {})[entry.entry_id] = manager
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    manager.mark_ready()
    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload a HOMEBD hub."""
    unload_ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unload_ok:
        hass.data.get(DOMAIN, {}).pop(entry.entry_id, None)
    return unload_ok


def _get_manager(hass: HomeAssistant) -> HomeBdManager | None:
    """Return the active HOMEBD manager, or create one for an existing entry."""
    managers = hass.data.setdefault(DOMAIN, {})
    for value in managers.values():
        if isinstance(value, HomeBdManager):
            return value

    # This also covers a native WebSocket client connecting immediately after
    # the integration was installed but before the config entry platform has
    # completed its setup.
    entries = hass.config_entries.async_entries(DOMAIN)
    if entries:
        entry = entries[0]
        manager = HomeBdManager(hass, entry)
        managers[entry.entry_id] = manager
        _LOGGER.debug("HOMEBD manager recovered for config entry %s", entry.entry_id)
        return manager
    return None


@websocket_api.websocket_command({
    vol.Required("type"): WS_TYPE,
    vol.Required("entity_id"): str,
    vol.Required("state"): vol.Any(str, int, float),
    vol.Optional("attributes", default={}): dict,
})
@websocket_api.async_response
async def _ws_update(hass: HomeAssistant, connection, msg: dict) -> None:
    """Receive a HOMEBD sensor update over the native HA WebSocket API."""
    manager = _get_manager(hass)
    if manager is None:
        connection.send_error(msg["id"], "not_configured", "Add the HOMEBD integration first")
        return

    entity_id = str(msg["entity_id"]).lower()
    if not entity_id.startswith("sensor.homebd_"):
        connection.send_error(
            msg["id"], "invalid_entity", "Only sensor.homebd_* entities are accepted"
        )
        return

    await manager.async_update(entity_id, str(msg["state"]), msg.get("attributes", {}))
    connection.send_result(msg["id"], {"ok": True, "entity_id": entity_id})


@websocket_api.websocket_command({vol.Required("type"): WS_PING_TYPE})
@callback
def _ws_ping(hass: HomeAssistant, connection, msg: dict) -> None:
    """Confirm that HOMEBD is installed and has a configured hub."""
    entries = hass.config_entries.async_entries(DOMAIN)
    if not entries:
        connection.send_error(msg["id"], "not_configured", "Add the HOMEBD integration first")
        return

    connection.send_result(
        msg["id"],
        {
            "ok": True,
            "configured": True,
            "domain": DOMAIN,
            "version": "1.4.0",
        },
    )
