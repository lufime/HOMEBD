package pt.homebd

/**
 * Universal vehicle profile.
 *
 * The profile is deliberately conservative: vehicle-specific capabilities are
 * enabled only after identification/response. No proprietary manufacturer-specific DID is assumed.
 */
data class HomeBdVehicleProfile(
    val vin: String = "",
    val manufacturer: String = "",
    val model: String = "",
    val year: String = "",
    val profile: String = "AUTO",
    val hybridOrEv: Boolean = false
) {
    companion object {
        fun fromVin(vin: String): HomeBdVehicleProfile {
            val clean = vin.uppercase().replace(Regex("[^A-Z0-9]"), "")
            val wmi = clean.take(3)
            val manufacturer = when (wmi) {
                "VR7", "VF7" -> "Citroën"
                "VF3", "VR3" -> "Peugeot"
                "VF1" -> "Renault"
                "VSS" -> "SEAT"
                "WVW" -> "Volkswagen"
                "WBA", "WBY" -> "BMW"
                "WDD", "W1K" -> "Mercedes-Benz"
                "KMH", "KNA" -> "Hyundai/Kia"
                "JTD", "JT2", "JTE" -> "Toyota"
                else -> ""
            }
            return HomeBdVehicleProfile(
                vin = clean,
                manufacturer = manufacturer,
                profile = if (manufacturer.isNotBlank()) manufacturer.uppercase() else "AUTO"
            )
        }
    }
}
