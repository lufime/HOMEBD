# GitHub Actions — HOMEBD

O workflow foi corrigido para compilar diretamente o projeto Android.

Não procura nem extrai `HOMEBD_*.zip`.

Requisitos esperados na raiz:
- `gradlew`
- `settings.gradle` ou `settings.gradle.kts`
- `build.gradle` ou `build.gradle.kts`

O APK debug é publicado como artifact `HOMEBD-debug`.
