DOMAIN = "homebd"
PLATFORMS = ["sensor"]
WS_TYPE = "homebd/update"
WS_PING_TYPE = "homebd/ping"
HTTP_URL = "/api/homebd/update"
HTTP_NAME = "api:homebd:update"

ATTR_SOURCE = "source"
ATTR_HOMEBD_PID = "homebd_pid"
