"""HOMEBD Home Assistant integration."""
from __future__ import annotations

import logging
from http import HTTPStatus

from aiohttp import web
import voluptuous as vol

from homeassistant.components import websocket_api
from homeassistant.components.http import HomeAssistantView, KEY_HASS
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback

from .const import DOMAIN, HTTP_NAME, HTTP_URL, PLATFORMS, WS_PING_TYPE, WS_TYPE
from .sensor import HomeBdManager

_LOGGER = logging.getLogger(__name__)


async def async_setup(hass: HomeAssistant, config: dict) -> bool:
    """Set up the HOMEBD integration."""
    hass.data.setdefault(DOMAIN, {})
    websocket_api.async_register_command(hass, _ws_update)
    hass.http.register_view(HomeBdUpdateView())
    return True


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up a HOMEBD config entry."""
    manager = HomeBdManager(hass, entry)
    hass.data.setdefault(DOMAIN, {})[entry.entry_id] = manager
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload a HOMEBD config entry."""
    unload_ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unload_ok:
        hass.data.get(DOMAIN, {}).pop(entry.entry_id, None)
    return unload_ok


def _get_manager(hass: HomeAssistant) -> HomeBdManager | None:
    managers = hass.data.get(DOMAIN, {})
    return next(iter(managers.values()), None)


@websocket_api.websocket_command({
    vol.Required("type"): WS_TYPE,
    vol.Required("entity_id"): str,
    vol.Required("state"): vol.Any(str, int, float),
    vol.Optional("attributes", default={}): dict,
})
@websocket_api.async_response
async def _ws_update(hass: HomeAssistant, connection, msg: dict) -> None:
    """Receive a HOMEBD sensor update over the HA native WebSocket API."""
    manager = _get_manager(hass)
    if manager is None:
        connection.send_error(msg["id"], "not_configured", "HOMEBD integration is not configured")
        return
    if not str(msg["entity_id"]).startswith("sensor.homebd_"):
        connection.send_error(msg["id"], "invalid_entity", "Only sensor.homebd_* entities are accepted")
        return
    await manager.async_update(
        str(msg["entity_id"]),
        str(msg["state"]),
        msg.get("attributes", {}),
    )
    connection.send_result(msg["id"], {"ok": True})


@websocket_api.websocket_command({vol.Required("type"): WS_PING_TYPE})
@callback
def _ws_ping(hass: HomeAssistant, connection, msg: dict) -> None:
    """Confirm that the HOMEBD integration is installed and configured."""
    if _get_manager(hass) is None:
        connection.send_error(msg["id"], "not_configured", "HOMEBD integration is not configured")
        return
    connection.send_result(msg["id"], {"ok": True})


class HomeBdUpdateView(HomeAssistantView):
    """Authenticated REST fallback for HOMEBD telemetry."""

    url = HTTP_URL
    name = HTTP_NAME
    requires_auth = True

    async def post(self, request: web.Request) -> web.Response:
        """Accept one HOMEBD entity update."""
        hass: HomeAssistant = request.app[KEY_HASS]
        manager = _get_manager(hass)
        if manager is None:
            return self.json_message("HOMEBD is not configured", HTTPStatus.NOT_FOUND)

        try:
            payload = await request.json()
        except Exception:
            return self.json_message("Invalid JSON", HTTPStatus.BAD_REQUEST)

        entity_id = str(payload.get("entity_id", ""))
        if not entity_id.startswith("sensor.homebd_"):
            return self.json_message("Only sensor.homebd_* entities are accepted", HTTPStatus.BAD_REQUEST)

        state = payload.get("state")
        if state is None:
            return self.json_message("Missing state", HTTPStatus.BAD_REQUEST)

        attributes = payload.get("attributes")
        if not isinstance(attributes, dict):
            attributes = {}

        await manager.async_update(entity_id, str(state), attributes)
        return self.json_message("ok", HTTPStatus.OK)
