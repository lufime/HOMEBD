# HOMEBD

**Home Onboard Monitoring Engine Board Data**

Aplicação Android universal para diagnóstico OBD-II, CAN/ISO-TP e leitura de dados do veículo.

## Versão atual

**BETA V2.54**

### Funcionalidades atuais

- Bluetooth para adaptadores OBD-II compatíveis com ELM327 e transportes suportados pela aplicação.
- Deteção automática do protocolo OBD-II.
- Scan dos PIDs OBD-II suportados pelo veículo.
- Live Data em tempo real.
- Leitura de DTCs quando suportada pelo veículo/interface.
- Leitura de VIN por OBD-II Mode 09 PID 02 e UDS F190 quando disponível.
- CAN / ISO-TP / UDS em modo **READ-ONLY**.
- Descoberta conservadora de ECUs e HV/BMS quando suportada.
- Descoberta READ-ONLY de GPS/Telemática quando suportada.
- Perfis universais por fabricante sem assumir mapas proprietários não verificados.
- Integração nativa HOMEBD para Home Assistant no mesmo repositório.
- Transporte Home Assistant por WebSocket persistente, com REST como fallback.
- Entidades dinâmicas `sensor.homebd_*` agrupadas num dispositivo HOMEBD.
- Aplicação em orientação vertical (portrait).

## Home Assistant

A integração está em:

`home_assistant/custom_components/homebd/`

### Instalação

1. Copiar a pasta `homebd` para:

   `/config/custom_components/homebd/`

2. Reiniciar o Home Assistant.
3. Abrir **Definições → Dispositivos e serviços → Adicionar integração**.
4. Procurar **HOMEBD**.
5. Adicionar a integração.

A HOMEBD Android usa o WebSocket nativo do Home Assistant para enviar as alterações das entidades. A aplicação confirma primeiro que a integração HOMEBD está disponível; caso contrário, usa o endpoint REST autenticado da própria integração.

As entidades aceites pela integração são exclusivamente:

`sensor.homebd_*`

A integração cria um dispositivo HOMEBD e adiciona dinamicamente os sensores que a aplicação enviar.

## Arquitetura atual

`OBD/CAN → HOMEBD Android → Home Assistant WebSocket → integração HOMEBD → sensor.homebd_*`

Fallback:

`OBD/CAN → HOMEBD Android → endpoint REST da integração HOMEBD → sensor.homebd_*`

## READ-ONLY

A HOMEBD foi concebida para diagnóstico e leitura. Não executa:

- `0x27 SecurityAccess`
- `0x2E WriteDataByIdentifier`
- `0x2F InputOutputControlByIdentifier`
- `0x31 RoutineControl`
- programação ou flashing de ECU
- coding, reset ou adaptação
- bypass de gateways de segurança

Quando um parâmetro ou ECU não responde, a aplicação deve indicar indisponibilidade em vez de inventar valores.

## VIN e identificação

A aplicação tenta obter um VIN completo através de métodos standard e UDS suportados pelo transporte. A identificação de fabricante/modelo é conservadora e não deve ser interpretada como garantia de acesso a todas as ECUs ou parâmetros proprietários.

## Compatibilidade

A compatibilidade depende do veículo, ano, ECU, gateway, adaptador, protocolo de transporte e parâmetros disponíveis. Algumas arquiteturas podem exigir interfaces diferentes de um ELM327 Bluetooth, incluindo DoIP/Ethernet.

## Estrutura do projeto

```text
HOMEBD/
├── app/                                  # Aplicação Android
├── home_assistant/
│   └── custom_components/homebd/         # Integração Home Assistant
├── README.md
├── CHANGELOG.md
├── HOMEASSISTANT_INTEGRATION.md
├── LICENSES.md
├── THIRD_PARTY_NOTICES.md
└── DEVELOPER.txt
```

## Créditos

- Desenvolvedor: **lufime**
- Plataforma: Android
- Diagnóstico: OBD-II / CAN / UDS READ-ONLY
- Versão: **BETA V2.54**
