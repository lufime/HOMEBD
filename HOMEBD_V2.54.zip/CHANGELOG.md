# CHANGELOG

## 2.54
- Corrigido o transporte HOMEBD ↔ Home Assistant.
- WebSocket nativo continua como transporte principal, com reconexão automática.
- Adicionado endpoint REST autenticado da integração como fallback.
- Entidades dinâmicas `sensor.homebd_*` passam a ficar associadas ao dispositivo HOMEBD.
- Evitada a criação de hubs HOMEBD duplicados pelo config flow.
- Mantidos OBD-II, CAN/UDS, HV/BMS, VIN, GPS/Telemática, Bluetooth e modo READ-ONLY.

# CHANGELOG

## BETA V2.54
- Confirmado que as entidades publicadas pela integração são exclusivamente `sensor.homebd_*`.
- Limpeza da documentação e referências que já não fazem parte do projeto.

# HOMEBD — Changelog

## V2.54

- Documentação revista e alinhada com a arquitetura atual.
- Removida documentação histórica que já não representa a aplicação atual.
- Atualizada a documentação da integração Home Assistant.
- Créditos/documentação atualizados para **lufime**.
- Mantido o transporte Home Assistant por WebSocket persistente com REST como fallback.

## V2.51

- Adicionada integração customizada HOMEBD para Home Assistant no mesmo repositório.
- Adicionado transporte Home Assistant WebSocket persistente na aplicação Android.
- WebSocket preferencial para telemetria; REST como fallback.
- Entidades dinâmicas `sensor.homebd_*` agrupadas num dispositivo HOMEBD.

## V2.50

- Otimizada a publicação REST para reduzir atrasos quando o WebSocket não está disponível.
- Mantidos timeouts e proteção contra falhas de rede.

## V2.49

- Consolidação do fluxo universal: CAN → OBD-II/PIDs → VIN → HV/BMS → GPS/Telemática → Live Data → Home Assistant.
- Correção de VIN completo através de OBD-II/UDS quando suportado.
- Mantida operação READ-ONLY.

## V2.48 e anteriores

As alterações históricas anteriores permanecem no histórico Git do projeto. A documentação de desenvolvimento antiga foi removida do pacote de distribuição para evitar instruções contraditórias com a arquitetura atual.
