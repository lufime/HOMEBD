# HOMEBD — Integração Home Assistant

A HOMEBD inclui uma integração customizada do Home Assistant no mesmo repositório:

`home_assistant/custom_components/homebd/`

## Arquitetura

```text
OBD/CAN
  ↓
HOMEBD Android
  ↓ WebSocket persistente
Home Assistant
  ↓
integracao HOMEBD
  ↓
sensor.homebd_*
```

O WebSocket nativo é o transporte preferencial para telemetria. A aplicação faz um `homebd/ping` para confirmar a integração. Se o WebSocket não estiver disponível, usa o endpoint REST autenticado `/api/homebd/update` da própria integração.

## Instalação

Copiar:

`home_assistant/custom_components/homebd/`

para:

`/config/custom_components/homebd/`

Reiniciar o Home Assistant e abrir:

**Definições → Dispositivos e serviços → Adicionar integração → HOMEBD**

A integração usa Config Flow e cria um único dispositivo HOMEBD com sensores dinâmicos.

## Entidades

A integração aceita apenas entidades cujo ID começa por:

`sensor.homebd_`

Os sensores são criados quando a aplicação envia o primeiro valor correspondente.

## Atualização

A HOMEBD envia cada alteração através do WebSocket persistente. O estado é atualizado no Home Assistant sem polling individual por sensor.

Se o WebSocket não estiver disponível, a aplicação usa `/api/homebd/update`, mantendo as entidades associadas ao dispositivo HOMEBD.

## Segurança

- Comunicação autenticada pelo Long-Lived Access Token do Home Assistant.
- A HOMEBD envia apenas dados de diagnóstico em modo READ-ONLY.
- A integração não envia comandos para ECUs.
