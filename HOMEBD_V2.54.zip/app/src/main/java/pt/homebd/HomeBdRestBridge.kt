package pt.homebd

import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentHashMap

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * Home Assistant REST bridge.
 *
 * Uses the official Home Assistant HTTP API directly.
 * Authentication is a Long-Lived Access Token sent as Bearer.
 */
class HomeBdRestBridge(private val context: Context) {
    private val haWebSocket = HomeBdHaWebSocket()
    // Small fixed pool prevents REST from blocking OBD/CAN while still keeping
    // enough parallelism for near-real-time updates of multiple HOMEBD sensors.
    private val telemetryExecutor: ExecutorService = Executors.newFixedThreadPool(4)

    // Last state/time sent per entity. This avoids flooding Home Assistant when
    // a PID is unchanged, while still sending a heartbeat at least every 5 s.
    private val lastPublishedState = ConcurrentHashMap<String, String>()
    private val lastPublishedAt = ConcurrentHashMap<String, Long>()
    private val heartbeatMs = 5_000L



    enum class Mode { AUTO, LOCAL, EXTERNAL }

    private val prefs = context.getSharedPreferences("homebd_rest", Context.MODE_PRIVATE)

    @Volatile var connected: Boolean = false
        private set

    var mode: Mode = runCatching {
        Mode.valueOf(prefs.getString("mode", Mode.AUTO.name) ?: Mode.AUTO.name)
    }.getOrDefault(Mode.AUTO)
        private set

    var localBaseUrl: String = prefs.getString("local", "") ?: ""
        private set

    var externalBaseUrl: String = prefs.getString("external", "") ?: ""
        private set

    /** Home Assistant Long-Lived Access Token. */
    var token: String = prefs.getString("token", "") ?: ""
        private set

    var basePath: String = prefs.getString("path", "/api") ?: "/api"
        private set

    /** Only entities matching this filter are published to Home Assistant. */
    var entityFilter: String = prefs.getString("entity_filter", "sensor.homebd_*") ?: "sensor.homebd_*"
        private set

    var activeMode: Mode? = null
        private set

    val baseUrl: String
        get() = when (activeMode ?: mode) {
            Mode.LOCAL -> localBaseUrl
            Mode.EXTERNAL -> externalBaseUrl
            Mode.AUTO -> localBaseUrl.ifBlank { externalBaseUrl }
        }

    fun save(
        local: String,
        external: String,
        accessToken: String,
        path: String,
        selectedMode: Mode,
        entityFilterPattern: String = "sensor.homebd_*"
    ) {
        localBaseUrl = normalize(local)
        externalBaseUrl = normalize(external)
        token = accessToken.trim()
        basePath = normalizePath(path)
        entityFilter = entityFilterPattern.trim().ifBlank { "sensor.homebd_*" }
        mode = selectedMode

        prefs.edit()
            .putString("local", localBaseUrl)
            .putString("external", externalBaseUrl)
            .putString("token", token)
            .remove("username")
            .remove("password")
            .putString("path", basePath)
            .putString("entity_filter", entityFilter)
            .putString("mode", mode.name)
            .apply()
    }

    fun connect(callback: (Boolean, String) -> Unit) {
        Thread {
            var success = false
            var message = "Home Assistant não respondeu."

            try {
                if (token.isBlank()) {
                    message = "Configure o token de acesso do Home Assistant."
                } else {
                    val candidates = when (mode) {
                        Mode.LOCAL -> listOf(Mode.LOCAL)
                        Mode.EXTERNAL -> listOf(Mode.EXTERNAL)
                        Mode.AUTO -> listOf(Mode.LOCAL, Mode.EXTERNAL)
                    }

                    for (candidate in candidates) {
                        val base = when (candidate) {
                            Mode.LOCAL -> localBaseUrl
                            Mode.EXTERNAL -> externalBaseUrl
                            Mode.AUTO -> ""
                        }
                        if (base.isBlank()) continue

                        val result = getApi(candidate)
                        if (result.isSuccess && (result.getOrNull() ?: 0) in 200..299) {
                            connected = true
                            activeMode = candidate
                            success = true
                            message = "Home Assistant ligado • ${candidate.name.lowercase()}"
                            // Prefer the persistent HOMEBD integration transport.
                            // REST remains available as a fallback.
                            haWebSocket.connect(base, token) { ok, wsMsg ->
                                if (ok) connected = true
                            }
                            break
                        }
                    }

                    if (!success) {
                        connected = false
                        activeMode = null
                        message = "Home Assistant não respondeu. Verifique URL, token e acesso à rede."
                    }
                }
            } catch (t: Throwable) {
                // REST must never be allowed to crash the application.
                connected = false
                activeMode = null
                message = "Erro REST: ${t.message ?: t.javaClass.simpleName}"
            }

            try {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    try { callback(success, message) } catch (_: Throwable) { /* UI callback must never crash HOMEBD */ }
                }
            } catch (_: Throwable) {
                // Never propagate REST callback failures.
            }
        }.start()
    }

    fun disconnect() {
        haWebSocket.disconnect()
        connected = false
        activeMode = null
    }

    /** Publish one OBD value as a Home Assistant sensor state.
     */
    fun publishPid(pid: String, label: String, value: String) {
        if (!connected || token.isBlank()) return

        val parsed = parseValue(value) ?: return
        val entityId = entityIdFor(pid, label)
        if (!matchesEntityFilter(entityId)) return
        val attrs = JSONObject()
            .put("friendly_name", "HOMEBD ${cleanLabel(label)}")
            .put("homebd_pid", pid.uppercase())
            .put("source", "HOMEBD")
            .put("raw_value", value)
            .put("state_class", "measurement")

        parsed.unit?.let { attrs.put("unit_of_measurement", it) }
        parsed.deviceClass?.let { attrs.put("device_class", it) }

        val body = JSONObject()
            .put("state", parsed.state)
            .put("attributes", attrs)

        val sentByWebSocket = haWebSocket.connected
        if (sentByWebSocket) {
            haWebSocket.publish(entityId, parsed.state, attrs)
        } else {
            // Send to the HOMEBD integration endpoint first so entities belong
            // to the HOMEBD device. If that integration is unavailable, retain
            // the standard HA state API as a compatibility fallback.
            val integrationBody = JSONObject()
                .put("entity_id", entityId)
                .put("state", parsed.state)
                .put("attributes", attrs)
            postAsync("/api/homebd/update", integrationBody, entityId, parsed.state, "/api/states/$entityId", body)
        }
    }

    /** Publish all currently read PIDs. Invalid / NO DATA values are skipped. */
    fun publishAggregate(values: List<Triple<String, String, String>>) {
        values.forEach { (pid, label, value) ->
            publishPid(pid, label, value)
        }
    }

    private fun matchesEntityFilter(entityId: String): Boolean {
        val filter = entityFilter.trim().lowercase(java.util.Locale.ROOT)
        val id = entityId.lowercase(java.util.Locale.ROOT)
        if (filter.isBlank() || filter == "*") return true
        // Simple glob: * means any sequence. This is sufficient for
        // sensor.homebd_* and avoids bringing in another dependency.
        val regex = "^" + Regex.escape(filter).replace("\\*", ".*") + "$"
        return Regex(regex).matches(id)
    }

    private data class ParsedValue(
        val state: String,
        val unit: String?,
        val deviceClass: String?
    )

    private fun parseValue(raw: String): ParsedValue? {
        val text = raw.trim()
        if (text.isBlank() || text.contains("NO DATA", ignoreCase = true) || text == "—") return null

        val number = Regex("[-+]?\\d+(?:[.,]\\d+)?").find(text)?.value
            ?.replace(',', '.') ?: return null
        val state = number.toDoubleOrNull()?.let {
            if (it % 1.0 == 0.0) it.toLong().toString() else it.toString()
        } ?: return null

        val lower = text.lowercase()
        val unit = when {
            "km/h" in lower -> "km/h"
            "rpm" in lower -> "rpm"
            "°c" in lower || " c" in lower -> "°C"
            "kpa" in lower -> "kPa"
            "v" in lower && "kv" !in lower -> "V"
            "a" in lower && (lower.contains(" a") || lower.endsWith("a")) -> "A"
            "%" in lower -> "%"
            "g/s" in lower -> "g/s"
            "l/100 km" in lower -> "L/100 km"
            "l/h" in lower -> "L/h"
            "ms" in lower -> "ms"
            else -> null
        }
        val deviceClass = when (unit) {
            "°C" -> "temperature"
            "km/h" -> "speed"
            "V" -> "voltage"
            "A" -> "current"
            "%" -> "percentage"
            "kPa" -> "pressure"
            else -> null
        }
        return ParsedValue(state, unit, deviceClass)
    }

    private fun entityIdFor(pid: String, label: String): String {
        val slug = cleanLabel(label)
            .lowercase(java.util.Locale.ROOT)
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
            .ifBlank { "pid_${pid.lowercase()}" }
        return "sensor.homebd_${slug}_${pid.lowercase()}"
    }

    private fun cleanLabel(label: String): String =
        label.trim().replace(Regex("\\s+"), " ")

    private fun getApi(which: Mode): Result<Int> = runCatching {
        val root = when (which) {
            Mode.LOCAL -> localBaseUrl
            Mode.EXTERNAL -> externalBaseUrl
            Mode.AUTO -> baseUrl
        }.trimEnd('/')
        require(root.isNotBlank())

        val url = URL(root + "/" + basePath.trimStart('/').trimEnd('/') + "/")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Authorization", "Bearer $token")
        }
        val code = conn.responseCode
        conn.disconnect()
        code
    }

    /**
     * Near-real-time REST publisher.
     *
     * The OBD/CAN loop never waits for Home Assistant. A small pool handles
     * several entity updates in parallel and unchanged values are suppressed,
     * with a 5 s heartbeat so the HA state remains visibly fresh.
     */
    private fun postAsync(
        path: String,
        body: JSONObject,
        entityId: String,
        state: String,
        fallbackPath: String? = null,
        fallbackBody: JSONObject? = null
    ) {
        val now = System.currentTimeMillis()
        val previous = lastPublishedState[entityId]
        val previousAt = lastPublishedAt[entityId] ?: 0L
        if (previous == state && now - previousAt < heartbeatMs) return

        // Reserve this update before enqueueing so a fast scan cannot create a
        // large backlog of duplicate REST requests.
        lastPublishedState[entityId] = state
        lastPublishedAt[entityId] = now

        try {
            telemetryExecutor.execute {
                try {
                    val result = post(activeMode ?: mode, path, body.toString())
                    if ((result.getOrNull() ?: 0) !in 200..299 && fallbackPath != null && fallbackBody != null) {
                        post(activeMode ?: mode, fallbackPath, fallbackBody.toString())
                    }
                } catch (_: Throwable) {
                    try {
                        if (fallbackPath != null && fallbackBody != null) {
                            post(activeMode ?: mode, fallbackPath, fallbackBody.toString())
                        }
                    } catch (_: Throwable) {
                        // HA telemetry failure must never terminate HOMEBD.
                    }
                }
            }
        } catch (_: Throwable) {
            // Executor shutdown/race must never terminate HOMEBD.
        }
    }

    private fun post(which: Mode, path: String, body: String): Result<Int> = runCatching {
        val root = when (which) {
            Mode.LOCAL -> localBaseUrl
            Mode.EXTERNAL -> externalBaseUrl
            Mode.AUTO -> baseUrl
        }.trimEnd('/')
        require(root.isNotBlank())

        val url = URL(root + "/" + path.trimStart('/'))
        val bodyBytes = body.toByteArray(StandardCharsets.UTF_8)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 2500
            readTimeout = 2500
            doOutput = true
            useCaches = false
            setFixedLengthStreamingMode(bodyBytes.size)
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Connection", "keep-alive")
        }

        conn.outputStream.use { it.write(bodyBytes) }
        val code = conn.responseCode
        // Consume the response stream so the HTTP connection can be reused.
        try {
            if (code in 200..299) conn.inputStream.use { it.copyTo(java.io.OutputStream.nullOutputStream()) }
            else conn.errorStream?.use { it.copyTo(java.io.OutputStream.nullOutputStream()) }
        } catch (_: Throwable) { }
        conn.disconnect()
        code
    }

    private fun normalize(value: String): String {
        val v = value.trim().removeSuffix("/")
        if (v.isBlank()) return ""
        return if (v.startsWith("http://", ignoreCase = true) ||
            v.startsWith("https://", ignoreCase = true)) {
            v
        } else {
            "http://$v"
        }
    }

    private fun normalizePath(value: String): String {
        val p = value.trim()
        if (p.isBlank()) return "/api"
        return "/" + p.trim('/').ifBlank { "api" }
    }
}
