# HOMEBD — LICENÇAS E CRÉDITOS

## Projeto HOMEBD

**Copyright © 2026 lufime. All rights reserved.**

O código original, documentação e materiais próprios do HOMEBD pertencem ao projeto HOMEBD, salvo os componentes de terceiros identificados abaixo.

---

## Componentes de terceiros

### Kotlin 2.0.21

Linguagem utilizada no desenvolvimento da aplicação.

**Licença:** Apache License 2.0

Licença oficial:
https://www.apache.org/licenses/LICENSE-2.0

Informação oficial:
https://kotlinlang.org/docs/faq.html

---

### Gradle

Sistema de compilação utilizado pelo projeto.

**Licença:** Apache License 2.0

Licença oficial:
https://www.apache.org/licenses/LICENSE-2.0

Informação oficial:
https://docs.gradle.org/current/userguide/licenses.html

---

### Android Gradle Plugin 8.7.3

Plugin utilizado para a compilação Android.

**Licenciamento e termos:** documentação oficial Android/Google.

Informação oficial:
https://developer.android.com/build/releases/gradle-plugin

Termos legais Android:
https://developer.android.com/legal

---

### Android SDK / Android APIs

APIs e ferramentas da plataforma Android utilizadas pela aplicação.

**Licenciamento:** termos e licenças aplicáveis da plataforma Android.

Informação oficial:
https://developer.android.com/legal

---

## Protocolos e standards automóveis

O HOMEBD utiliza referências técnicas relacionadas com:

- OBD-II
- CAN
- ISO-TP
- UDS

Estas referências são protocolos/standards técnicos e não representam, por si só, bibliotecas de software de terceiros incorporadas no projeto.

---

## Componentes não utilizados

O projeto não incorpora:

- bases de dados CAN de terceiros;
- mapas CAN proprietários de fabricantes;
- openDBC;
- código openDBC.

---

## Home Assistant

A integração `homebd` é código próprio do projeto HOMEBD.

A plataforma Home Assistant é um software externo e mantém os seus próprios direitos e licenças.

Informação oficial:
https://www.home-assistant.io/

---

## Recursos gráficos

Os recursos gráficos próprios do HOMEBD são identificados no projeto, incluindo:

- `homebd_header.png`
- `homebd_icon.png`

Não devem ser adicionados recursos gráficos de terceiros sem a respetiva licença ou autorização.

---

## Nota

Esta documentação identifica os componentes de terceiros atualmente documentados no projeto. As licenças e avisos devem ser revistos sempre que forem adicionadas novas dependências ou recursos de terceiros.

Esta documentação não constitui aconselhamento jurídico.


## Public OBD/CAN data policy
HOMEBD does not bundle OpenDBC/opendbc, CSS Electronics databases, proprietary OEM databases, or copies of SAE/ISO standards. Bundled OBD/CAN data is limited to sources with explicit redistribution permission, prioritizing CC0/public-domain material.
