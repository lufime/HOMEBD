package pt.homebd

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * OBDex CC0 data loader.
 *
 * The catalog is fetched from the OBDex static JSON endpoints and cached
 * locally. HOMEBD does not bundle a proprietary CAN database or OpenDBC data.
 * OBDex declares its data CC0-1.0 and its tooling MIT.
 */
class ObdExRepository(private val context: Context) {
    companion object {
        const val MODE01_URL = "https://foerbsnavi.github.io/obdex/pids/mode01.json"
        const val MODE09_URL = "https://foerbsnavi.github.io/obdex/pids/mode09.json"
        const val DTC_URL = "https://foerbsnavi.github.io/obdex/generic.min.json"
    }

    data class Pid(
        val mode: String,
        val pid: String,
        val name: String,
        val formula: String?,
        val unit: String?,
        val bytes: Int?
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(15, TimeUnit.SECONDS)
        .build()

    private val cacheDir = File(context.cacheDir, "obdex")

    private fun requestText(url: String, cacheName: String): String? {
        cacheDir.mkdirs()
        val cache = File(cacheDir, cacheName)
        return try {
            val request = Request.Builder().url(url).get().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code}")
                val body = response.body?.string() ?: throw IllegalStateException("empty response")
                cache.writeText(body, Charsets.UTF_8)
                body
            }
        } catch (_: Throwable) {
            if (cache.isFile) cache.readText(Charsets.UTF_8) else null
        }
    }

    fun loadMode01(): List<Pid> = parsePids(requestText(MODE01_URL, "mode01.json"), "01")
    fun loadMode09(): List<Pid> = parsePids(requestText(MODE09_URL, "mode09.json"), "09")

    /** Downloads and caches the complete generic DTC bundle for offline reuse after first download. */
    fun ensureGenericDtcBundle(): Boolean = requestText(DTC_URL, "generic.min.json") != null

    fun cachedDtcBundleFile(): File = File(cacheDir, "generic.min.json")

    private fun parsePids(text: String?, defaultMode: String): List<Pid> {
        if (text.isNullOrBlank()) return emptyList()
        return try {
            val array = JSONArray(text)
            buildList {
                for (i in 0 until array.length()) {
                    val o = array.optJSONObject(i) ?: continue
                    val pid = o.optString("pid").uppercase().padStart(2, '0')
                    if (pid.length != 2) continue
                    val mode = o.optString("mode", defaultMode).uppercase()
                    val nameObj = o.optJSONObject("name")
                    val name = nameObj?.optString("en")?.takeIf { it.isNotBlank() }
                        ?: o.optString("name").takeIf { it.isNotBlank() }
                        ?: "OBD-II PID $mode:$pid"
                    add(Pid(
                        mode = mode,
                        pid = pid,
                        name = name,
                        formula = o.optString("formula").takeIf { it.isNotBlank() },
                        unit = o.optString("unit").takeIf { it.isNotBlank() },
                        bytes = if (o.has("bytes")) o.optInt("bytes") else null
                    ))
                }
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }
}
