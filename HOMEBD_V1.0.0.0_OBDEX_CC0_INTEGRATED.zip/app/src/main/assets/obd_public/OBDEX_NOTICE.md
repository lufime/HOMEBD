# OBDex notice

HOMEBD integrates the OBDex public OBD-II catalogue by runtime loading and local caching. OBDex declares its data CC0-1.0 and tooling MIT.

HOMEBD does not include OpenDBC/opendbc, CSS Electronics databases, manufacturer CAN matrices, or proprietary diagnostic databases.

OBDex: https://github.com/foerbsnavi/OBDex
