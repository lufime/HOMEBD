# HOMEBD Public OBD/CAN data policy

HOMEBD only incorporates data that is explicitly public-domain/CC0, or code/data whose license permits redistribution under the project's terms. No OpenDBC/opendbc data, CSS Electronics database, proprietary OEM database, SAE standard document, or other restricted database is bundled.

Preferred sources: CC0/public-domain datasets and permissively licensed code/data where redistribution is explicitly allowed.

Excluded from bundled data when their license imposes attribution/share-alike or database obligations: CC-BY-SA, GPL-only data, ODbL/DbCL databases, and proprietary/commercial databases.

This policy does not claim that OBD-II, SAE J1979, CAN, ISO-TP or UDS standards themselves are public-domain. HOMEBD uses independent implementations and only redistributable source data.
