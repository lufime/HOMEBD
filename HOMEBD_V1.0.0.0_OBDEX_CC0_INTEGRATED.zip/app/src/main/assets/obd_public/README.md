# Public OBD catalogue

HOMEBD integrates the OBDex public data source at runtime. OBDex currently documents 132 OBD-II PIDs (Mode 01 + Mode 09) and 9,533 generic DTCs.

Mode 01 and Mode 09 catalogues are cached after download. The generic DTC bundle can be downloaded/cached on demand. Vehicle capability discovery still determines which PID requests are sent.

Source: https://github.com/foerbsnavi/OBDex
Data: CC0-1.0 as declared by OBDex. Tooling: MIT.
