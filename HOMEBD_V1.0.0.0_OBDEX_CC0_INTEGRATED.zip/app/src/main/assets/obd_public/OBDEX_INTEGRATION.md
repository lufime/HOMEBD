# OBDex integration

HOMEBD can load the OBDex public catalogue at runtime and cache it locally.

Source: https://github.com/foerbsnavi/OBDex
Data licence declared by OBDex: CC0-1.0. Tooling: MIT.

Endpoints:
- Mode 01: https://foerbsnavi.github.io/obdex/pids/mode01.json
- Mode 09: https://foerbsnavi.github.io/obdex/pids/mode09.json
- Generic DTCs: https://foerbsnavi.github.io/obdex/generic.min.json

The app only polls PIDs that the vehicle reports as supported. The complete DTC bundle is cached on demand; it is not fabricated or reconstructed from a secondary source. Manufacturer-specific proprietary P1/B1/C1/U1 databases remain excluded.
