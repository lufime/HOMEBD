plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "pt.homebd"
    compileSdk = 35

    defaultConfig {
        applicationId = "pt.homebd"
        minSdk = 26
        targetSdk = 34
        versionCode = 22
        versionName = "2.58"
    }
}

dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}

kotlin {
    jvmToolchain(17)
}
