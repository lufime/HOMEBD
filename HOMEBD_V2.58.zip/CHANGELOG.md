# HOMEBD V2.58

- Telemetria HOMEBD otimizada para tempo real: PIDs dinâmicos em ciclo rápido e restantes intercalados.
- Integração Home Assistant mantém apenas o último valor por entidade durante falhas/reconexões.
- Atualizações sem alteração de estado são suprimidas para reduzir tráfego WebSocket.
- Reconexão WebSocket com backoff até 60 s e proteção contra múltiplos sockets/reconexões concorrentes.
- Mantido WebSocket como único transporte; REST não é utilizado.

# HOMEBD V2.57

- Corrigido o handshake da integração HOMEBD por WebSocket.
- `homebd/ping` confirma a integração quando existe um hub configurado, mesmo antes de o gestor de sensores terminar o arranque.
- O gestor HOMEBD é recuperado automaticamente a partir de um Config Entry existente.
- Valores recebidos antes da plataforma de sensores estar pronta ficam em fila e são publicados quando a plataforma fica disponível.
- Mantido WebSocket como único transporte.
- Apenas entidades `sensor.homebd_*`.

# HOMEBD V2.57

- Removido completamente o transporte REST da aplicação Android.
- Home Assistant passa a usar exclusivamente WebSocket persistente + Long-Lived Access Token.
- A integração HOMEBD passa a aceitar telemetria exclusivamente pelo comando `homebd/update`.
- Configuração Home Assistant simplificada para um único endereço + token.
- Mantido o namespace exclusivo `sensor.homebd_*`.
- Mantida a integração dinâmica com um único dispositivo HOMEBD.
- Atualizada a documentação para refletir a arquitetura WebSocket-only.
- Versão Android: 2.56.
- Versão da integração Home Assistant: 1.3.0.
- Desenvolvedor: lufime.
