# HOMEBD

**HOMEBD** é uma aplicação de diagnóstico OBD-II universal para veículos, com
comunicação Bluetooth Classic/SPP através de adaptadores ELM327 compatíveis.

## Estado atual

- OBD-II/CAN em modo **READ-ONLY**.
- LIVE DATA em tempo real.
- Diagnóstico e registo de respostas RAW para análise.
- Comunicação MQTT para integração com Home Assistant.
- Parser e estabilização ELM327/CAN em evolução.
- Descoberta HV/UDS mantida em modo READ-ONLY, sem DIDs proprietários assumidos.
- Interface preparada para utilização horizontal, em full screen e centrada.

## V2.6

- Campo **Password MQTT** com botão de olho.
- O botão permite mostrar ou ocultar a password.
- A alteração não modifica o armazenamento nem o funcionamento da ligação MQTT.
- Todas as alterações do projeto são registadas por versão no CHANGELOG.

## Documentação

Consulte `CHANGELOG.md` para o histórico das alterações e
`DOCUMENTACAO_ALTERACOES.md` para a regra de documentação por versão.

## Licenciamento e terceiros

Consultar os ficheiros de licença/NOTICE existentes no projeto. Não assumir que
a menção a um protocolo, plataforma ou serviço concede direitos sobre marcas,
logótipos ou código de terceiros.

## Desenvolvimento

**Developer: Katios**

## V2.8
A aplicação inclui agora a secção **Sobre / FAQ** diretamente na interface.

## V2.9
Separação documentada entre LIVE DATA OBD-II e descoberta UDS/HV.

## V2.12
- Correção do Live Data: especificação de leitura contínua deve separar corretamente cabeçalhos CAN/ELM327 do payload OBD-II antes da descodificação.
- Não considerar `NO DATA` como valor válido.
- Manter o protocolo detetado ISO 15765-4 CAN 11-bit / 500 kbit/s em READ-ONLY.
- Identificação automática mantém VIN quando disponível.
- HV/UDS continua sem DIDs proprietários e sem comandos de escrita até existir resposta válida.
- Mantida a regra de interface: cards full screen horizontal, centrados e a ocupar toda a largura.

## V2.13
Correções reais no código: leitura Live Data com recuperação da sessão, perfis de fabricantes apresentados individualmente e correção do botão de mostrar/ocultar password MQTT.
