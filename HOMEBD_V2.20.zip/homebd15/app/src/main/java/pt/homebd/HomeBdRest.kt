package pt.homebd

import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * HOMEBD REST transport.
 *
 * Replaces the Eclipse Paho MQTT client with plain HTTP/REST.
 * No external MQTT client library is required.
 */
class HomeBdRest(
    private var baseUrl: String,
    private var token: String? = null,
    private val timeoutMs: Int = 8000
) {
    fun setBaseUrl(url: String) {
        baseUrl = url.trimEnd('/')
    }

    fun setToken(value: String?) {
        token = value
    }

    fun publishState(path: String, json: String): Result<Int> {
        return postJson(path, json)
    }

    fun postJson(path: String, json: String): Result<Int> {
        return runCatching {
            val url = URL(baseUrl.trimEnd('/') + "/" + path.trimStart('/'))
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = timeoutMs
                readTimeout = timeoutMs
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
                token?.takeIf { it.isNotBlank() }?.let {
                    setRequestProperty("Authorization", "Bearer $it")
                }
            }

            OutputStreamWriter(conn.outputStream, StandardCharsets.UTF_8).use {
                it.write(json)
            }

            val code = conn.responseCode
            conn.disconnect()
            code
        }
    }
}
