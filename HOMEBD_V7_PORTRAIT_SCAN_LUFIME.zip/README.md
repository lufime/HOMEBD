# HOMEBD V7 — PORTRAIT + SCAN

C5 AIRCROSS HYBRID — OBD diagnostic app.

- Portrait orientation.
- Full-screen interface.
- Vertical layout with vertical scroll.
- Large touch-friendly LIGAR OBDII button.
- Large touch-friendly SCAN PIDs button.
- SCAN is enabled only after successful ELM327 connection.
- Fixed Kotlin scope error: scan button is now a class property.
- `7F 01 22` is treated as a negative ECU response.
- Developer: lufime.
