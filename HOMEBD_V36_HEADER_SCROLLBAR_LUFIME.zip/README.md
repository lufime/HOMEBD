# HOMEBD

Universal Android OBD-II diagnostic application.

## V35
- Added the latest HOMEBD automotive header image to the app.
- Header includes Bluetooth and engine symbols beside the car.
- Existing Bluetooth device list, OBD connection and PID scan UI retained.
- No GitHub Actions workflow included in this ZIP.
