# HOMEBD V3

Correção da compilação Kotlin da interface vertical com scroll.

- Landscape/full-screen mantido
- Conteúdo vertical
- Scroll vertical
- Log com auto-scroll
- Correções de `setTextColor`
- Correções de `LayoutParams`
- Workflow GitHub corrigido para extrair e compilar o projeto
