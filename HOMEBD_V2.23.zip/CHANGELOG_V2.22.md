# HOMEBD V2.23 — CORREÇÃO REST / BUILD

Base: HOMEBD V2.21.

## Build
- Corrigidas as últimas referências antigas da camada MQTT no MainActivity.
- `brokerUri` → `baseUrl`.
- `localBrokerUri` → `localBaseUrl`.
- `externalBrokerUri` → `externalBaseUrl`.
- `baseTopic` → `basePath`.
- Removida qualquer dependência Paho que ainda existisse no Gradle.

## Comunicação
- A interface passou a usar terminologia REST.
- Mantida a comunicação HTTP/JSON.
- MQTT não é reintroduzido.

## Mantido
- Foco HV/BMS.
- UDS READ-ONLY.
- Deteção automática de idioma.
- Identificação VIN.
