# V2.38
- Adicionado botão rápido **USAR TAILSCALE** na configuração Home Assistant REST.
- Preenche automaticamente o endereço MagicDNS Tailscale configurado para este projeto: `https://homeassistant.tail719a66.ts.net`.
- Deteta se existe uma interface Tailscale ativa no Android e informa o utilizador.
- O endereço continua editável; a app não acede à conta/API Tailscale.
- Mantida a configuração REST simples: URL + token + `/api`.
- Mantida orientação portrait e proteção contra crashes.

