# HOMEBD V2.40

## Home Assistant REST sensors

- Added direct publication of OBD live values through the Home Assistant REST state API.
- No MQTT broker, Mosquitto or Paho client is used.
- Each valid numeric OBD PID is published as a `sensor.homebd_*` state.
- States include `friendly_name`, OBD PID, source and the raw value as attributes.
- Units and common Home Assistant device classes are included when safely detected.
- `NO DATA` values are ignored.
- Uses the configured Home Assistant `/api` path and Bearer Long-Lived Access Token.
- Publishing remains best-effort and is protected against REST/network failures so it cannot crash HOMEBD.

## Important

These are Home Assistant REST state entities. They are available to dashboards, automations and the States view, but this method does not create a MQTT/config-entry device in the Devices & services registry.

## Existing behaviour retained

- HTTPS Home Assistant connection.
- Manual URL/token configuration; no Tailscale auto-fill.
- Portrait orientation.
- OBD-II, HV/UDS read-only diagnostics unchanged.
- MQTT remains removed from the application runtime.
