# HOMEBD V2.36

## Correção REST / Home Assistant

- Corrigido crash ao abrir a configuração REST/Home Assistant.
- Corrigido `restText()` que continha chamadas recursivas para si próprio, provocando `StackOverflowError` ao construir o diálogo.
- Mantida a orientação da aplicação em portrait/vertical.
- Mantidas as proteções contra erros de REST/HTTPS sem fechar a aplicação.
- Atualizada a versão apresentada no rodapé para 2.36.
