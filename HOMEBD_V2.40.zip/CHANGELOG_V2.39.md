# HOMEBD V2.39

- Removido o autopreenchimento de Tailscale na configuração Home Assistant REST.
- Removido o botão que preenchia automaticamente o endereço MagicDNS.
- O utilizador introduz manualmente a URL HTTPS do Home Assistant, incluindo o endereço Tailscale se desejar.
- Mantida a ligação REST direta por HTTPS, com token e `/api`.
- Mantida a orientação vertical (portrait).
- Mantidas as proteções contra crashes REST/Home Assistant.
- OBD/Bluetooth/HV não foram alterados.
