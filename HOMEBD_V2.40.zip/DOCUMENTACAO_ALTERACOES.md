V2.33 — correção de sintaxe no bridge REST e proteção do postAsync contra crashes.\n\n# HOMEBD — Documentação de alterações


## V2.6 — Password MQTT
- Interface: campo Password MQTT com botão de olho.
- Comportamento: tocar no olho alterna entre ocultar e mostrar a password.
- Segurança: não altera o armazenamento nem a ligação MQTT.
