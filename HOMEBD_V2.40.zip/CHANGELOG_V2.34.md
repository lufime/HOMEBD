# HOMEBD V2.34

- Hardening of Home Assistant and REST button actions.
- REST callbacks are dispatched safely to the Android main thread.
- UI callbacks are guarded against Activity destruction and runtime exceptions.
- Safe REST dialog opening.
- Safe Home Assistant open/configure actions.
- Safe log append to prevent UI callback crashes.
- HTTPS support preserved.
- OBD/Bluetooth/HV functionality unchanged.
