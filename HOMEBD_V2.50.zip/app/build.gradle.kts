plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "pt.homebd"
    compileSdk = 35

    defaultConfig {
        applicationId = "pt.homebd"
        minSdk = 26
        targetSdk = 34
        versionCode = 17
        versionName = "2.50"
    }
}

dependencies {
}

kotlin {
    jvmToolchain(17)
}
