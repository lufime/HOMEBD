# HOMEBD V2.50

## Home Assistant — tempo real
- REST telemetry usa 4 workers para não deixar a fila de sensores atrasar.
- Publicação de `sensor.homebd_*` só quando o estado muda, com heartbeat máximo de 5 s.
- Timeouts REST reduzidos para evitar pedidos presos durante falhas de rede.
- O loop OBD/CAN continua independente da rede/Home Assistant.
- Mantido READ-ONLY e sem MQTT/Mosquitto.
