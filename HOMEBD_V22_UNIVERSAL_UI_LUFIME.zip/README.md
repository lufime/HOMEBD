# HOMEBD V21

- HOMEBD is the APK/application designation.
- No fullscreen: Android status/navigation bars remain visible.
- Portrait interface.
- Bluetooth paired-device list remains visible.
- LIGAR OBDII and SCAN PIDs are fixed, visible and clickable.
- ScrollView removed completely.
- Diagnostic panel is fixed in the remaining screen space.
- Developer: lufime.
