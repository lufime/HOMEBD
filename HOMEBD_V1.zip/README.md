# HOMEBD

Real-time onboard vehicle data for Home Assistant.

## V1
- Bluetooth Classic / SPP for ELM327
- OBD-II PID scanner
- Android landscape full-screen interface
- Prepared for PSA/Stellantis HEV/PHEV PIDs
- Prepared for Home Assistant real-time telemetry

## GitHub Actions
The repository includes `.github/workflows/build.yml` for building the debug APK.
