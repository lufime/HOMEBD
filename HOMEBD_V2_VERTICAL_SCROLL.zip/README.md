# HOMEBD V2

C5 AIRCROSS HYBRID — OBD diagnostic app.

## V2 changes
- Landscape full-screen preserved.
- Interface arranged vertically.
- Main content uses vertical scrolling.
- Diagnostic log auto-scrolls to the latest response.
- ELM327 initialization waits after ATZ reset.
- Reads the actual ELM327 protocol with ATDP.
- `7F 01 22` is correctly classified as a negative ECU response, not a sensor value.
- Prepared for the next PSA/Stellantis ECU scan.

## Build
GitHub Actions builds the debug APK with Gradle 8.9.
