# HOMEBD V6 — PORTRAIT + SCAN

C5 AIRCROSS HYBRID — OBD diagnostic app.

- Portrait orientation.
- Full-screen interface.
- Vertical layout with vertical scroll.
- Large, centered, touch-friendly LIGAR OBDII button.
- Large, centered, touch-friendly SCAN PIDs button.
- SCAN PIDs remains disabled until the ELM327 connection succeeds.
- Scan status is shown while scanning and when complete.
- `7F 01 22` is treated as a negative ECU response.
- Developer: lufime.
