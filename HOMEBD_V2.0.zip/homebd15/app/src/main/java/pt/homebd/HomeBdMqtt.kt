package pt.homebd

import android.content.Context
import android.os.Build
import android.util.Log
import org.eclipse.paho.client.mqttv3.*
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence
import org.json.JSONObject
import java.util.Locale

/**
 * HOMEBD MQTT bridge.
 *
 * Two broker profiles are supported:
 *  - LOCAL: plain MQTT on the home LAN (normally tcp://...:1883)
 *  - EXTERNAL: MQTT over TLS (normally ssl://...:8883)
 *  - AUTO: try LOCAL first, then EXTERNAL
 *
 * The OBD data remain local to HOMEBD; MQTT is only an optional transport to
 * Home Assistant. No cloud/API dependency is required.
 */
class HomeBdMqtt(private val context: Context) {
    enum class Mode { AUTO, LOCAL, EXTERNAL }

    private var client: MqttAsyncClient? = null
    private val lastPublished = HashMap<String, String>()
    @Volatile var connected: Boolean = false
        private set
    @Volatile var activeMode: Mode? = null
        private set

    var localBrokerUri: String = ""
        private set
    var externalBrokerUri: String = ""
        private set
    var username: String = ""
        private set
    var password: String = ""
        private set
    var baseTopic: String = "homebd/live"
        private set
    var mode: Mode = Mode.AUTO
        private set

    private val prefs = context.getSharedPreferences("homebd_mqtt", Context.MODE_PRIVATE)

    init { load() }

    // Backward-compatible getter for the previous single-broker UI.
    val brokerUri: String
        get() = when (mode) {
            Mode.LOCAL -> localBrokerUri
            Mode.EXTERNAL -> externalBrokerUri
            Mode.AUTO -> if (localBrokerUri.isNotBlank()) localBrokerUri else externalBrokerUri
        }

    private fun load() {
        localBrokerUri = prefs.getString("localBroker", "") ?: ""
        externalBrokerUri = prefs.getString("externalBroker", "") ?: ""
        username = prefs.getString("username", "") ?: ""
        password = prefs.getString("password", "") ?: ""
        baseTopic = prefs.getString("baseTopic", "homebd/live") ?: "homebd/live"
        mode = runCatching { Mode.valueOf(prefs.getString("mode", "AUTO") ?: "AUTO") }.getOrDefault(Mode.AUTO)

        // Migrate the V1.1 single broker setting without losing it.
        if (localBrokerUri.isBlank() && externalBrokerUri.isBlank()) {
            val old = prefs.getString("broker", "") ?: ""
            if (old.isNotBlank()) localBrokerUri = old
        }
    }

    fun save(local: String, external: String, user: String, pass: String, topic: String, selectedMode: Mode) {
        localBrokerUri = local.trim()
        externalBrokerUri = external.trim()
        username = user.trim()
        password = pass
        baseTopic = topic.trim().trim('/').ifBlank { "homebd/live" }
        mode = selectedMode
        prefs.edit()
            .putString("localBroker", localBrokerUri)
            .putString("externalBroker", externalBrokerUri)
            .putString("username", username)
            .putString("password", password)
            .putString("baseTopic", baseTopic)
            .putString("mode", mode.name)
            .apply()
    }

    fun connect(onResult: (Boolean, String) -> Unit) {
        if (connected) {
            onResult(true, "MQTT já ligado • ${activeModeLabel()}")
            return
        }

        val candidates = when (mode) {
            Mode.LOCAL -> listOf(Mode.LOCAL)
            Mode.EXTERNAL -> listOf(Mode.EXTERNAL)
            Mode.AUTO -> listOf(Mode.LOCAL, Mode.EXTERNAL)
        }

        Thread {
            var lastError = "Configure um broker MQTT"
            for (candidate in candidates) {
                val raw = if (candidate == Mode.LOCAL) localBrokerUri else externalBrokerUri
                if (raw.isBlank()) continue
                try {
                    connectTo(candidate, raw)
                    activeMode = candidate
                    connected = true
                    publishAvailability(true)
                    publishDiscovery()
                    onResult(true, "MQTT ligado • ${activeModeLabel()} • ${clientBrokerUri()}")
                    return@Thread
                } catch (e: Exception) {
                    lastError = "${candidateLabel(candidate)}: ${e.message ?: "erro de ligação"}"
                    disconnectInternal()
                }
            }
            connected = false
            activeMode = null
            onResult(false, "MQTT: $lastError")
        }.start()
    }

    private fun connectTo(candidate: Mode, rawUri: String) {
        val uri = normalizeUri(rawUri, candidate)
        val id = "HOMEBD-${Build.MODEL.replace(Regex("[^A-Za-z0-9_-]"), "")}-${System.currentTimeMillis() % 100000}"
        val c = MqttAsyncClient(uri, id, MemoryPersistence())
        client = c
        val opts = MqttConnectOptions().apply {
            isAutomaticReconnect = true
            isCleanSession = true
            connectionTimeout = 8
            keepAliveInterval = 20
            maxInflight = 100
            if (username.isNotBlank()) {
                userName = username
                password = this@HomeBdMqtt.password.toCharArray()
            }
        }
        c.connect(opts).waitForCompletion(8000)
    }

    private fun normalizeUri(raw: String, candidate: Mode): String {
        var s = raw.trim()
        if (s.isBlank()) throw IllegalArgumentException("broker vazio")
        s = s.removeSuffix("/")
        if (s.startsWith("https://", true)) s = "ssl://" + s.removePrefix("https://")
        if (s.startsWith("http://", true)) s = "tcp://" + s.removePrefix("http://")
        if (!s.contains("://")) {
            val defaultPort = if (candidate == Mode.EXTERNAL) 8883 else 1883
            s = "${if (candidate == Mode.EXTERNAL) "ssl" else "tcp"}://$s"
            if (!s.substringAfter("://").contains(":")) s += ":$defaultPort"
        } else if (candidate == Mode.EXTERNAL && s.startsWith("tcp://", true)) {
            s = "ssl://" + s.removePrefix("tcp://")
        }
        return s
    }

    fun disconnect() {
        try {
            if (connected) publishAvailability(false)
            client?.disconnect()?.waitForCompletion(3000)
        } catch (_: Exception) {}
        disconnectInternal()
    }

    private fun disconnectInternal() {
        connected = false
        activeMode = null
        client = null
    }

    fun publishPid(pid: String, label: String, result: String) {
        if (!connected) return
        val key = pid.lowercase(Locale.US)
        val obj = JSONObject()
        val numeric = parseNumeric(result)
        if (numeric == null) obj.put("value", JSONObject.NULL) else obj.put("value", numeric)
        obj.put("text", result)
        obj.put("pid", pid)
        obj.put("label", label)
        obj.put("available", !result.contains("NO DATA", true) && !result.contains("N/D", true))
        // Create/update the Home Assistant entity only when this PID is actually
        // returned by the vehicle. This keeps unsupported PIDs out of HA while
        // allowing every detected standard PID to become an entity automatically.
        if (obj.optBoolean("available", false)) {
            publishDiscoveryForPid(pid, label)
        }
        // Live values are deliberately NOT retained: frequent retained writes
        // add broker/storage work and can make HA appear slow. Discovery/status
        // remain retained. Publish only when the payload actually changes.
        publishIfChanged("$baseTopic/$key", obj.toString())
        publishIfChanged("$baseTopic/$key/text", result)
    }

    fun publishAggregate(values: List<Pair<String, String>>) {
        if (!connected) return
        val root = JSONObject()
        values.forEach { (pid, value) -> root.put(pid.lowercase(Locale.US), value) }
        publish("$baseTopic/all", root.toString(), false)
    }

    private fun publishAvailability(available: Boolean) {
        publish("$baseTopic/status", if (available) "online" else "offline", true)
    }

    private fun publishIfChanged(topic: String, payload: String) {
        synchronized(lastPublished) {
            if (lastPublished[topic] == payload) return
            lastPublished[topic] = payload
        }
        publish(topic, payload, false)
    }

    private fun publish(topic: String, payload: String, retained: Boolean) {
        try {
            val msg = MqttMessage(payload.toByteArray(Charsets.UTF_8)).apply {
                qos = 0
                isRetained = retained
            }
            client?.publish(topic, msg)
        } catch (e: Exception) {
            Log.w("HOMEBD_MQTT", "publish failed: ${e.message}")
        }
    }

    private fun parseNumeric(text: String): Double? {
        if (text.contains("NO DATA", true) || text.contains("N/D", true) ||
            text.contains("multi-byte", true) || text.contains("Dados insuficientes", true) ||
            text == "—") return null
        val m = Regex("""[-+]?\d+(?:[.,]\d+)?""").find(text) ?: return null
        return m.value.replace(",", ".").toDoubleOrNull()
    }

    private fun clientBrokerUri(): String = client?.serverURI ?: ""
    private fun candidateLabel(m: Mode): String = if (m == Mode.LOCAL) "Local" else "Externo"
    private fun activeModeLabel(): String = activeMode?.let { candidateLabel(it) } ?: mode.name

    private fun publishDiscovery() {
        // V1.5 created a fixed subset of entities. Clear those legacy discovery
        // topics so V1.6 can recreate only the PIDs actually detected by the ECU.
        val legacyKeys = listOf(
            "rpm", "speed", "coolant_temperature", "intake_air_temperature",
            "engine_load", "map", "maf", "stft", "ltft", "ignition_timing",
            "control_module_voltage", "fuel_rate", "barometric_pressure",
            "fuel_rail_pressure", "throttle_position", "absolute_throttle_position_b",
            "accelerator_pedal_position_d", "accelerator_pedal_position_e",
            "commanded_throttle_actuator", "lambda", "dtc"
        )
        legacyKeys.forEach { key ->
            publish("homeassistant/sensor/homebd/$key/config", "", true)
        }
    }

    private fun publishDiscoveryForPid(pid: String, label: String) {
        val key = pid.lowercase(Locale.US)
        val unit = unitForPid(pid)
        val payload = JSONObject()
            .put("name", "HOMEBD $label")
            .put("unique_id", "homebd_$key")
            .put("state_topic", "$baseTopic/$key")
            .put("value_template", "{{ value_json.value if value_json.value is not none else value_json.text }}")
            .put("availability_topic", "$baseTopic/status")
            .put("payload_available", "online")
            .put("payload_not_available", "offline")
            .put("device", JSONObject()
                .put("identifiers", org.json.JSONArray().put("homebd"))
                .put("name", "HOMEBD")
                .put("manufacturer", "lufime")
                .put("model", "HOMEBD OBD-II"))

        if (unit != null) {
            payload.put("unit_of_measurement", unit)
            payload.put("state_class", "measurement")
        }
        val dc = deviceClass(key)
        if (dc.isNotBlank()) payload.put("device_class", dc)

        publish("homeassistant/sensor/homebd/$key/config", payload.toString(), true)
    }

    private fun unitForPid(pid: String): String? = when (pid.uppercase(Locale.US)) {
        "0104", "0106", "0107", "0108", "0109", "0111", "0112", "012C", "012D",
        "012E", "012F", "0143", "0145", "0147", "0148", "0149", "014A", "014B",
        "014C", "0152", "0155", "0156", "0157", "0158", "015B" -> "%"
        "0105", "010F", "013C", "013D", "013E", "013F", "0146", "015C",
        "0166", "0167", "0168", "0169", "016D", "0175", "0176", "0177",
        "0178", "0179", "017C", "0184" -> "°C"
        "010A", "010B", "0133", "0123", "0159", "016B", "016F", "0173" -> "kPa"
        "010C", "0174" -> "rpm"
        "010D" -> "km/h"
        "010E", "015D" -> "°"
        "0110" -> "g/s"
        "0142" -> "V"
        "015E" -> "L/h"
        "0132", "0154" -> "Pa"
        "011F", "0130", "0131", "014D", "014E" -> "s"
        "0165" -> "mA"
        "0144", "0134" -> "ratio"
        else -> null
    }

    private fun deviceClass(key: String): String = when (key) {
        "coolant_temperature", "intake_air_temperature" -> "temperature"
        "control_module_voltage" -> "voltage"
        "speed" -> "speed"
        else -> ""
    }
}
