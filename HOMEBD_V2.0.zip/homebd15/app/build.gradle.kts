plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "pt.homebd"
    compileSdk = 35

    defaultConfig {
        applicationId = "pt.homebd"
        minSdk = 26
        targetSdk = 34
        versionCode = 9
        versionName = "2.0"
    }
}

dependencies {
    implementation("org.eclipse.paho:org.eclipse.paho.client.mqttv3:1.2.5")
}

kotlin {
    jvmToolchain(17)
}
