# HOMEBD — Changelog

## V2.0
- Adicionado **SCAN HV/UDS** experimental e READ-ONLY para procurar respostas UDS em ECUs CAN.
- A pesquisa usa apenas o serviço UDS `0x22 ReadDataByIdentifier`; não envia SecurityAccess, escrita, coding ou programação.
- Janela inicial conservadora de DIDs `F180–F19F` nos IDs físicos `7E0–7E7`.
- Respostas positivas são apresentadas como **RAW hexadecimal**, sem inventar escalas de bateria ou converter dados desconhecidos em kW/kWh.
- Preparado para identificar posteriormente dados HV reais quando houver uma definição verificável do DID/ECU.
- Mantida a publicação MQTT dinâmica e as ligações Home Assistant local/externa.
- Versão da aplicação atualizada para 2.0.


## V1.9
- Otimização da atualização MQTT para LIVE DATA com menor latência.
- Aumentado o limite de mensagens MQTT em trânsito (`maxInflight=100`).
- Valores LIVE deixam de usar `retain`, reduzindo escrita e processamento desnecessários no broker.
- HOMEBD publica um valor LIVE apenas quando o payload desse sensor muda.
- Discovery e estado online/offline continuam retidos.
- Mantida a leitura OBD contínua e a publicação dinâmica dos PIDs suportados.

# HOMEBD — Changelog

## V1.8
- Home Assistant sem endereço predefinido.
- Configuração independente para **acesso local** e **acesso externo**.
- Se ambos estiverem configurados, o botão permite escolher Local ou Externo.
- Se apenas um estiver configurado, o botão abre diretamente esse acesso.
- Se nenhum estiver configurado, o botão abre a configuração.
- Removido o endereço Tailscale previamente predefinido.
- Barra superior compacta com o **ícone da app à esquerda**, libertando espaço vertical.
- Atualizada a versão da aplicação para 1.8.

# HOMEBD — Changelog

## V1.7
- Added a dedicated **ABRIR HOME ASSISTANT** button.
- Opens the configured Home Assistant web interface using Android browser handling.
- Default Home Assistant URL is the configured Tailscale address `http://100.92.242.12:8123`; the user can change it.
- Long press on the Home Assistant button opens the URL configuration dialog.
- Clarifies that port 8123 is the Home Assistant web interface port, not MQTT.

## V1.6
- Home Assistant MQTT Discovery changed from a fixed sensor subset to dynamic discovery.
- Every standard OBD-II PID actually returned by the vehicle during LIVE DATA is automatically published as a Home Assistant entity.
- Unsupported/unavailable PIDs are not created as new Home Assistant entities.
- Legacy V1.5 fixed Discovery entities are cleared before dynamic discovery.
- Dynamic entities keep the HOMEBD device grouping and use units/device classes only where defined by the PID decoder.
- Updated third-party licence documentation to include the real MQTT Paho dependency.

## V1.5
- Added an in-app FAQ.
- FAQ documents the current OBD-II, MQTT, Tailscale and Android Auto development status.
- FAQ is intended to be updated with each relevant development release.
- Updated the in-app About/version text to 1.5.
- Kept MQTT CONNECT/DISCONNECT functionality from V1.4.

## V1.4
- MQTT LIGAR/DESLIGAR control.
- Long press on MQTT button opens MQTT configuration.
- Local/external MQTT configuration retained.
