# HOMEBD — Changelog

## V1.5
- Added an in-app FAQ.
- FAQ documents the current OBD-II, MQTT, Tailscale and Android Auto development status.
- FAQ is intended to be updated with each relevant development release.
- Updated the in-app About/version text to 1.5.
- Kept MQTT CONNECT/DISCONNECT functionality from V1.4.

## V1.4
- MQTT LIGAR/DESLIGAR control.
- Long press on MQTT button opens MQTT configuration.
- Local/external MQTT configuration retained.
