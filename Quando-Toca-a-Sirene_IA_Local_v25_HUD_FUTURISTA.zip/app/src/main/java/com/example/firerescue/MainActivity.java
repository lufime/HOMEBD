package com.example.firerescue;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.io.*;
import org.json.*;

public class MainActivity extends Activity {
    private LinearLayout root, content;
    private TextView status, money, rep, crew;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    // Frases já utilizadas nesta sessão: a IA nunca repete literalmente uma fala.
    private final java.util.HashSet<String> dialogoFrasesUsadas = new java.util.HashSet<>();
    private final ArrayList<Person> people = new ArrayList<>();

    private int cash = 1200;
    private int stars = 0;

    // Equipa inicial:
    // 1 bombeira centralista para urgências
    // 1 bombeira centralista para não urgentes
    // 4 funcionários de não urgência
    // 6 bombeiros/bombeiras operacionais
    private int urgentDispatchers = 1;
    private int nonUrgentDispatchers = 1;
    private int nonUrgentStaff = 4;
    private int firefighters = 6;
    private static final int TOTAL_FIREFIGHTERS = 100;
    private static final int TOTAL_NON_URGENT = 20;
    private static final int TOTAL_CENTRALISTS = 8;

    private int urgentVehicles = 2;
    private int nonUrgentVehicles = 1;
    private int supportVehicles = 0;

    // Identificação individual da frota: cada viatura recebe um número sequencial.
    private final ArrayList<String> fleet = new ArrayList<>();

    private int activeUrgent = 0;
    private int activeNonUrgent = 0;
    private boolean gameRunning = true;

    // Contexto da ocorrência atualmente ativa. O diálogo principal só a menciona quando existe uma ocorrência ativa.
    private IncidentType activeIncidentType = null;
    private String activeIncidentLocation = "";

    private static class Person {
        String id, nome, funcao, personalidade;
        int lideranca, obediencia, autonomia, impulsividade, resistencia, cooperacao, conflitos, confianca, pressao, empatia;
        Person(JSONObject o) throws JSONException {
            id=o.getString("id"); nome=o.getString("nome"); funcao=o.getString("funcao");
            personalidade=o.getString("personalidade");
            lideranca=o.getInt("lideranca"); obediencia=o.getInt("obediencia"); autonomia=o.getInt("autonomia");
            impulsividade=o.getInt("impulsividade"); resistencia=o.getInt("resistencia_autoridade");
            cooperacao=o.getInt("cooperacao"); conflitos=o.getInt("conflitualidade"); confianca=o.getInt("confianca");
            pressao=o.getInt("pressao"); empatia=o.getInt("empatia");
        }
    }

    private void loadPeople() {
        if (!people.isEmpty()) return;
        try {
            InputStream in = getAssets().open("pessoas_128.json");
            BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            StringBuilder b = new StringBuilder(); String line;
            while ((line=r.readLine()) != null) b.append(line);
            in.close();
            JSONArray a = new JSONArray(b.toString());
            for (int i=0;i<a.length();i++) people.add(new Person(a.getJSONObject(i)));
        } catch (Exception e) {
            Toast.makeText(this, "Erro a carregar fichas: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private static class IncidentType {
        String name, icon, vehicle;
        int firefighters, reward, priority, maxOccupants;
        double baseMinutes;
        boolean urgent;
        boolean cardiology;
        boolean clinicalEscort;

        IncidentType(String name, String icon, String vehicle,
                     int firefighters, int reward, double baseMinutes,
                     int priority, boolean urgent, int maxOccupants,
                     boolean cardiology, boolean clinicalEscort) {
            this.name = name;
            this.icon = icon;
            this.vehicle = vehicle;
            this.firefighters = firefighters;
            this.reward = reward;
            this.baseMinutes = baseMinutes;
            this.priority = priority;
            this.urgent = urgent;
            this.maxOccupants = maxOccupants;
            this.cardiology = cardiology;
            this.clinicalEscort = clinicalEscort;
        }
    }

    private final IncidentType[] incidentTypes = {
        new IncidentType("Transporte de doente", "🛏️", "Viatura de Transporte Não Urgente",
                2, 70, 2.8, 1, false, 1, false, false),
        new IncidentType("Transporte para Cardiologia", "❤️", "Viatura de Transporte Não Urgente",
                2, 95, 3.2, 1, false, 1, true, true),
        new IncidentType("Cadeira de rodas", "♿", "Viatura de Transporte Não Urgente",
                2, 60, 2.6, 1, false, 1, false, false),
        new IncidentType("Emergência médica", "🚑", "Ambulância de Urgência",
                2, 130, 3.2, 3, true, 1, false, false),
        new IncidentType("Acidente rodoviário", "🚗", "Veículo de Socorro",
                3, 170, 3.6, 3, true, 2, false, false),
        new IncidentType("Desencarceramento", "🚗💥", "Veículo de Resgate Técnico",
                5, 260, 5.0, 3, true, 6, false, false),
        new IncidentType("Pequeno incêndio", "🔥", "Veículo de Combate a Incêndios",
                3, 150, 3.6, 3, true, 4, false, false),
        new IncidentType("Incêndio urbano", "🔥🏠", "Veículo Urbano de Combate a Incêndios",
                6, 300, 5.6, 3, true, 6, false, false),
        new IncidentType("Incêndio florestal", "🌲🔥", "Veículo Florestal de Combate a Incêndios",
                5, 280, 5.2, 3, true, 6, false, false),
        new IncidentType("Incêndio industrial", "🏭🔥", "Veículo de Combate + Apoio",
                6, 350, 6.5, 3, true, 8, false, false),
        new IncidentType("Inundação", "🌊", "Veículo de Socorro e Assistência",
                3, 160, 3.8, 3, true, 4, false, false),
        new IncidentType("Resgate animal", "🐕", "Veículo de Socorro",
                2, 90, 3.0, 2, true, 2, false, false),
        new IncidentType("Queda de árvore", "🌳", "Veículo Técnico de Assistência",
                3, 140, 3.4, 2, true, 2, false, false),
        new IncidentType("Perigo elétrico", "⚡", "Veículo Técnico de Assistência",
                3, 180, 3.8, 3, true, 2, false, false),
        new IncidentType("Resgate em altura", "🧗", "Veículo de Resgate em Altura",
                4, 240, 4.8, 3, true, 2, false, false)
    };

    private final String[] locations = {
        "Rua Central", "Avenida da Liberdade", "Zona Industrial",
        "Bairro Novo", "Estrada Municipal", "Centro da Cidade"
    };

    private void initializeFleet() {
        if (!fleet.isEmpty()) return;
        addFleetVehicle("ABSC", "Urgência");
        addFleetVehicle("ABSC", "Urgência");
        addFleetVehicle("A1", "Não urgente");
    }

    private void addFleetVehicle(String type, String category) {
        int number = fleet.size() + 1;
        fleet.add(String.format(Locale.US, "%s%02d — %s", type, number, category));
    }

    private String fleetSummary() {
        StringBuilder b = new StringBuilder();
        for (String v : fleet) b.append("• ").append(v).append("\n");
        return b.length() == 0 ? "Sem viaturas" : b.toString();
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        initializeFleet();
        loadPeople();
        showHome();
        scheduleNextOccurrence();
    }

    private TextView text(String s, int size) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(Color.WHITE);
        v.setPadding(18, 12, 18, 12);
        return v;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        return b;
    }

    private void base() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(12, 0, 12, 0);
        root.setBackgroundColor(Color.rgb(16, 24, 32));
        root.setFitsSystemWindows(true);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(12, insets.getSystemWindowInsetTop() + 6, 12, insets.getSystemWindowInsetBottom() + 4);
            return insets;
        });

        ScrollView sc = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 0, 0, 18);
        sc.setFillViewport(false);
        sc.setClipToPadding(false);
        sc.addView(content);
        root.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(0, 4, 0, 2);
        nav.setBackgroundColor(Color.rgb(10, 17, 23));
        String[] navLabels = {"🏠\nQuartel", "🚨\nOcorrências", "👥\nPessoal", "🚒\nFrota"};
        for (int i=0;i<navLabels.length;i++) {
            final int n=i;
            TextView nb = new TextView(this);
            nb.setText(navLabels[i]);
            nb.setTextSize(10);
            nb.setTextColor(Color.WHITE);
            nb.setGravity(Gravity.CENTER);
            nb.setIncludeFontPadding(true);
            nb.setLineSpacing(0, 1.0f);
            nb.setPadding(0, 3, 0, 3);
            nb.setBackground(bg(Color.rgb(22, 34, 44), 18));
            nav.addView(nb, new LinearLayout.LayoutParams(0, 64, 1));
            if (n==0) nb.setOnClickListener(v -> showHome());
            else if (n==1) nb.setOnClickListener(v -> triggerOccurrence(true));
            else if (n==2) nb.setOnClickListener(v -> showPeopleList());
            else nb.setOnClickListener(v -> showManagement());
        }
        root.addView(nav, new LinearLayout.LayoutParams(-1, 58));
        setContentView(root);
    }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private TextView card(String title, String value, int accent) {
        TextView v = new TextView(this);
        v.setText(title + "\n" + value);
        v.setTextColor(Color.WHITE);
        v.setTextSize(16);
        v.setPadding(18, 16, 18, 16);
        v.setBackground(bg(Color.rgb(27, 38, 48), 24));
        v.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
        return v;
    }

    private Button menuCard(String icon, String title, String subtitle) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(icon + "  " + title + "\n" + subtitle);
        b.setTextSize(16);
        b.setTextColor(Color.WHITE);
        b.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        b.setPadding(20, 10, 20, 10);
        b.setMinHeight(78);
        b.setBackground(bg(Color.rgb(28, 41, 52), 22));
        return b;
    }

    private void addGap(int dp) {
        Space sp = new Space(this);
        content.addView(sp, new LinearLayout.LayoutParams(1, dp));
    }

    private void addSectionTitle(String title) {
        TextView t = text(title, 20);
        t.setTextColor(Color.rgb(235, 240, 245));
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(6, 8, 6, 8);
        content.addView(t);
    }

    private TextView statTile(String icon, String value, String label) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(8, 8, 8, 8);
        box.setBackground(bg(Color.rgb(27, 39, 51), 24));

        TextView top = text(icon + "  " + value, 17);
        top.setGravity(Gravity.CENTER);
        top.setTypeface(Typeface.DEFAULT, Typeface.BOLD);

        TextView bottom = text(label, 11);
        bottom.setGravity(Gravity.CENTER);
        bottom.setTextColor(Color.rgb(165, 181, 193));

        box.addView(top);
        box.addView(bottom);

        return wrapTile(box);
    }

    private TextView wrapTile(LinearLayout box) {
        TextView holder = new TextView(this);
        holder.setBackground(box.getBackground());
        holder.setPadding(0, 0, 0, 0);
        holder.setText("");
        return holder;
    }

    private LinearLayout gamePanel(String title, String subtitle, String icon, int accent) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(18, 14, 18, 14);
        panel.setBackground(bg(Color.rgb(27, 39, 51), 24));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);

        TextView ic = text(icon, 24);
        ic.setPadding(0, 0, 12, 0);

        TextView tt = text(title, 18);
        tt.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        tt.setTextColor(Color.WHITE);

        head.addView(ic);
        head.addView(tt);
        panel.addView(head);

        TextView sub = text(subtitle, 13);
        sub.setTextColor(Color.rgb(175, 190, 201));
        sub.setPadding(36, 3, 4, 0);
        panel.addView(sub);

        return panel;
    }

    private Button gameAction(String icon, String title, String subtitle) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(icon + "  " + title + "\n" + subtitle);
        b.setTextSize(15);
        b.setTextColor(Color.WHITE);
        b.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        b.setPadding(18, 8, 18, 8);
        b.setMinHeight(72);
        b.setBackground(bg(Color.rgb(33, 48, 62), 22));
        return b;
    }

    private void addGameGap(int h) {
        Space sp = new Space(this);
        content.addView(sp, new LinearLayout.LayoutParams(1, h));
    }

    private TextView sceneButton(String icon, String title, String subtitle) {
        TextView b = text(icon + "\n" + title + "\n" + subtitle, 14);
        b.setGravity(Gravity.CENTER);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(Color.WHITE);
        b.setPadding(8, 10, 8, 10);
        b.setBackground(bg(Color.rgb(29, 45, 58), 22));
        return b;
    }

    private LinearLayout sceneBuilding(String icon, String title, String subtitle) {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setGravity(Gravity.CENTER);
        b.setPadding(10, 12, 10, 12);
        b.setBackground(bg(Color.rgb(25, 38, 50), 24));

        TextView i = text(icon, 27);
        i.setGravity(Gravity.CENTER);
        i.setIncludeFontPadding(true);
        i.setPadding(0, 2, 0, 2);
        TextView t = text(title, 12);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(true);
        t.setPadding(0, 1, 0, 1);
        TextView st = text(subtitle, 9);
        st.setGravity(Gravity.CENTER);
        st.setIncludeFontPadding(true);
        st.setPadding(0, 1, 0, 1);
        st.setTextColor(Color.rgb(165, 185, 198));

        b.addView(i);
        b.addView(t);
        b.addView(st);
        return b;
    }

    private int hudCyan = Color.rgb(0, 205, 235);
    private int hudBlue = Color.rgb(8, 38, 52);
    private int hudPanel = Color.rgb(8, 20, 29);

    private GradientDrawable hudBg(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(radius);
        d.setStroke(2, stroke);
        return d;
    }

    private TextView hudLabel(String value, float size) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(hudCyan);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL));
        v.setIncludeFontPadding(true);
        return v;
    }

    private TextView hudMenuButton(String value) {
        TextView v = hudLabel(value, 11);
        v.setTextColor(Color.WHITE);
        v.setGravity(Gravity.CENTER);
        v.setPadding(8, 9, 8, 9);
        v.setBackground(hudBg(hudBlue, hudCyan, 12));
        return v;
    }

    private LinearLayout hudPanel(String title) {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(12, 10, 12, 10);
        p.setBackground(hudBg(hudPanel, Color.rgb(0, 125, 155), 16));
        TextView t = hudLabel(title, 12);
        t.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        t.setPadding(2, 0, 2, 7);
        p.addView(t, new LinearLayout.LayoutParams(-1, -2));
        return p;
    }

    private void showHome() {
        iniciarIA_Local();
        gameRunning = true;
        base();
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        // ===== HUD FUTURISTA — ECRÃ PRINCIPAL =====
        LinearLayout header = hudPanel("QUANDO TOCA A SIRENE // COMMAND HUD");
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView brand = hudLabel("◉  QUANDO TOCA A SIRENE", 15);
        brand.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        top.addView(brand, new LinearLayout.LayoutParams(0, 50, 1));

        TextView level = hudLabel("NÍVEL " + getLevel() + " / 50", 11);
        level.setGravity(Gravity.CENTER);
        level.setTextColor(Color.WHITE);
        level.setBackground(hudBg(Color.rgb(5,35,48), hudCyan, 12));
        top.addView(level, new LinearLayout.LayoutParams(105, 42));
        header.addView(top);

        LinearLayout stats = new LinearLayout(this);
        stats.setGravity(Gravity.CENTER);
        stats.setPadding(0, 8, 0, 2);
        TextView money = hudLabel("€" + cash, 11);
        TextView crew = hudLabel("👨‍🚒 " + firefighters, 11);
        TextView status = hudLabel("● ONLINE", 11);
        status.setTextColor(Color.rgb(70,240,150));
        stats.addView(money); addSpaceTo(stats, 18); stats.addView(crew); addSpaceTo(stats, 18); stats.addView(status);
        header.addView(stats);
        content.addView(header);
        addGameGap(7);

        // ===== MENU LATERAL EM FORMATO HUD =====
        LinearLayout menu = hudPanel("FUTURISTIC MENU // QUARTEL");
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        TextView central = hudMenuButton("◉\nCENTRAL\nMISSÕES");
        TextView team = hudMenuButton("◈\nEQUIPA\nOPERACIONAIS");
        TextView garage = hudMenuButton("▣\nGARAGEM\nVIATURAS");
        row1.addView(central, new LinearLayout.LayoutParams(0, 78, 1));
        addSpaceTo(row1, 6); row1.addView(team, new LinearLayout.LayoutParams(0, 78, 1));
        addSpaceTo(row1, 6); row1.addView(garage, new LinearLayout.LayoutParams(0, 78, 1));
        menu.addView(row1);
        content.addView(menu);
        central.setOnClickListener(v -> triggerOccurrence(true));
        team.setOnClickListener(v -> showPeopleList());
        garage.setOnClickListener(v -> showManagement());
        addGameGap(8);

        // ===== CORE CENTRAL DO QUARTEL =====
        LinearLayout core = hudPanel("STATUS CORE // QUARTEL");
        LinearLayout coreRow = new LinearLayout(this);
        coreRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView ring = hudLabel("◉\n◎\n◉", 27);
        ring.setGravity(Gravity.CENTER);
        ring.setTextColor(hudCyan);
        ring.setBackground(hudBg(Color.rgb(4,30,43), hudCyan, 80));
        coreRow.addView(ring, new LinearLayout.LayoutParams(100, 125));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        TextView q = hudLabel("QUARTEL", 16);
        q.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        q.setTextColor(Color.WHITE);
        TextView op = hudLabel("● OPERACIONAL", 12);
        op.setTextColor(Color.rgb(70,240,150));
        TextView sys = hudLabel("CENTRAL  ● ONLINE\nEQUIPA    ● DISPONÍVEL\nVIATURAS  ● PRONTAS", 9);
        sys.setTextColor(Color.rgb(150,195,205));
        info.addView(q); info.addView(op); info.addView(sys);
        coreRow.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        core.addView(coreRow);
        content.addView(core);
        addGameGap(8);

        // ===== CENTRAL DE MISSÕES =====
        LinearLayout mission = hudPanel("SYSTEM /// CENTRAL DE MISSÕES");
        TextView m1 = hudLabel(activeIncidentType == null ? "NENHUMA OCORRÊNCIA ATIVA" : "OCORRÊNCIA ATIVA", 13);
        m1.setGravity(Gravity.CENTER);
        m1.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        m1.setTextColor(Color.WHITE);
        mission.addView(m1);
        TextView m2 = hudLabel(activeIncidentType == null ? "A Central está pronta para receber uma chamada." : activeIncidentType.icon + "  " + activeIncidentType.name, 10);
        m2.setGravity(Gravity.CENTER);
        m2.setTextColor(Color.rgb(170,205,215));
        mission.addView(m2);
        TextView call = hudLabel(activeIncidentType == null ? "🚨  RECEBER CHAMADA" : "◉  OCORRÊNCIA EM CURSO", 13);
        call.setGravity(Gravity.CENTER);
        call.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        call.setTextColor(Color.WHITE);
        call.setPadding(8, 14, 8, 14);
        call.setBackground(hudBg(activeIncidentType == null ? Color.rgb(125,35,30) : Color.rgb(12,55,65), activeIncidentType == null ? Color.rgb(255,85,65) : hudCyan, 12));
        mission.addView(call);
        content.addView(mission);
        if (activeIncidentType == null) call.setOnClickListener(v -> triggerOccurrence(true));
        addGameGap(8);

        // ===== OPERACIONAIS DISPONÍVEIS =====
        LinearLayout teamPanel = hudPanel("OPERACIONAIS DISPONÍVEIS // " + Math.max(0, Math.min(firefighters, unlockedFirefighters())));
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout peopleRow = new LinearLayout(this);
        peopleRow.setOrientation(LinearLayout.HORIZONTAL);
        peopleRow.setPadding(4, 4, 4, 7);
        int availableCount = Math.max(0, Math.min(firefighters, unlockedFirefighters()));
        ArrayList<Person> operationalTeam = pessoasPorFuncao("Bombeiro", availableCount);
        for (Person person : operationalTeam) {
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.CENTER);
            box.setPadding(4, 4, 4, 4);
            box.setBackground(hudBg(Color.rgb(7,28,39), hudCyan, 10));
            ImageView portrait = new ImageView(this);
            portrait.setScaleType(ImageView.ScaleType.CENTER_CROP);
            loadDialoguePortrait(portrait, person);
            box.addView(portrait, new LinearLayout.LayoutParams(88, 96));
            TextView nm = hudLabel(person.nome, 8);
            nm.setTextColor(Color.WHITE);
            nm.setGravity(Gravity.CENTER);
            nm.setMaxLines(1);
            nm.setEllipsize(android.text.TextUtils.TruncateAt.END);
            box.addView(nm, new LinearLayout.LayoutParams(92, 25));
            TextView av = hudLabel("● DISPONÍVEL", 7);
            av.setTextColor(Color.rgb(70,240,150));
            av.setGravity(Gravity.CENTER);
            box.addView(av, new LinearLayout.LayoutParams(92, 22));
            box.setOnClickListener(v -> showPersonCard(person));
            peopleRow.addView(box, new LinearLayout.LayoutParams(100, 153));
            addSpaceTo(peopleRow, 7);
        }
        hsv.addView(peopleRow, new HorizontalScrollView.LayoutParams(-2, -2));
        teamPanel.addView(hsv);
        TextView hint = hudLabel("Toque na fotografia para consultar a ficha do operacional.", 8);
        hint.setGravity(Gravity.CENTER);
        hint.setTextColor(Color.rgb(150,195,205));
        teamPanel.addView(hint);
        content.addView(teamPanel);
        addGameGap(8);

        // ===== DIÁLOGO OPERACIONAL =====
        LinearLayout dialogue = hudPanel("COMMS // CENTRAL ↔ EQUIPA");
        TextView dt = hudLabel("💬  FALAR COM A EQUIPA", 14);
        dt.setGravity(Gravity.CENTER);
        dt.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        dt.setTextColor(Color.WHITE);
        dialogue.addView(dt);
        TextView ds = hudLabel("IA LOCAL  •  0,5 s  •  SEM REPETIÇÃO DE FRASES", 8);
        ds.setGravity(Gravity.CENTER);
        ds.setTextColor(Color.rgb(150,195,205));
        dialogue.addView(ds);
        content.addView(dialogue);
        dialogue.setOnClickListener(v -> mostrarDialogoEquipaPrincipal());
        addGameGap(8);

        // ===== PROGRESSÃO 1 / 50 =====
        LinearLayout progress = hudPanel("SYSTEM /// PROGRESSÃO");
        TextView p1 = hudLabel("NÍVEL " + getLevel() + " / 50", 14);
        p1.setGravity(Gravity.CENTER);
        p1.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        p1.setTextColor(Color.WHITE);
        progress.addView(p1);
        TextView bar = hudLabel("[██████░░░░░░░░░░░░]", 11);
        bar.setGravity(Gravity.CENTER);
        bar.setTextColor(hudCyan);
        progress.addView(bar);
        TextView p2 = hudLabel("NOVOS OPERACIONAIS • VIATURAS • OCORRÊNCIAS • COMPLEXIDADE", 8);
        p2.setGravity(Gravity.CENTER);
        p2.setTextColor(Color.rgb(150,195,205));
        progress.addView(p2);
        content.addView(progress);
        addGameGap(10);
    }

    private void addSpaceTo(LinearLayout parent, int width) {
        Space sp = new Space(this);
        parent.addView(sp, new LinearLayout.LayoutParams(width, 1));
    }

    private void addGameGapTo(LinearLayout parent, int height) {
        Space sp = new Space(this);
        parent.addView(sp, new LinearLayout.LayoutParams(1, height));
    }


    // ===== IA LOCAL DAS PERSONAGENS =====
    // Motor determinístico e offline: personalidade + estado + contexto -> decisão/diálogo.
    private static class PersonaAI {
        String nome;
        String personalidade;
        int lideranca, obediencia, autonomia, impulsividade, resistencia,
                cooperacao, conflito, confianca, pressao, empatia;
        int stress = 0;
        int fadiga = 0;
        int relacaoMedia = 50;

        PersonaAI(String nome, String personalidade, int lideranca, int obediencia,
                  int autonomia, int impulsividade, int resistencia, int cooperacao,
                  int conflito, int confianca, int pressao, int empatia) {
            this.nome=nome; this.personalidade=personalidade;
            this.lideranca=lideranca; this.obediencia=obediencia; this.autonomia=autonomia;
            this.impulsividade=impulsividade; this.resistencia=resistencia;
            this.cooperacao=cooperacao; this.conflito=conflito; this.confianca=confianca;
            this.pressao=pressao; this.empatia=empatia;
        }

        String reagir(String evento) {
            String e = evento.toLowerCase(java.util.Locale.ROOT);
            if (e.contains("ocorr")) {
                if (stress > 70 && pressao < 45) return "Preciso de alguns segundos para me concentrar.";
                if (impulsividade > 75) return "Vamos agir. Não podemos perder tempo!";
                if (pressao > 80) return "Mantenham a calma. Vamos por etapas.";
                if (cooperacao > 80) return "Digam-me o que é preciso e eu ajudo.";
                return "Recebido. Estou pronto.";
            }
            if (e.contains("ordem")) {
                if (resistencia > 80 && autonomia > 75) return "Compreendo, mas acho que há uma alternativa mais segura.";
                if (obediencia > 80) return "Recebido. A executar.";
                if (lideranca > 85) return "Recebido. Posso coordenar esta parte.";
                return "Entendido.";
            }
            if (e.contains("conflito")) {
                if (conflito > 75) return "Não concordo. Temos de falar sobre isto.";
                if (cooperacao > 80) return "Vamos resolver isto sem prejudicar a equipa.";
                return "Vamos manter a concentração e continuar.";
            }
            if (e.contains("cans")) {
                if (empatia > 80) return "Acho que precisamos de dar algum descanso à equipa.";
                return "Estou cansado, mas consigo continuar se for necessário.";
            }
            return "Estou disponível.";
        }

        void experiencia(boolean sucesso) {
            if (sucesso) {
                confianca = Math.min(100, confianca + 2);
                pressao = Math.min(100, pressao + 1);
                stress = Math.max(0, stress - 3);
            } else {
                stress = Math.min(100, stress + 8);
                confianca = Math.max(0, confianca - 1);
            }
        }

        void passarTempo(int horas) {
            fadiga = Math.max(0, Math.min(100, fadiga + horas * 3));
            stress = Math.max(0, stress - horas * 2);
        }
    }

    private final java.util.ArrayList<PersonaAI> iaPersonagens = new java.util.ArrayList<>();

    private void iniciarIA_Local() {
        iaPersonagens.clear();
        // Personagens iniciais. A base pode ser expandida para os 128 perfis.
        iaPersonagens.add(new PersonaAI("Flamma","Sereno, observador e metódico",78,82,58,34,22,86,18,88,80,72));
        iaPersonagens.add(new PersonaAI("Ignis","Enérgico e competitivo",72,61,74,65,42,78,51,76,72,54));
        iaPersonagens.add(new PersonaAI("Ardor","Comunicativo e motivador",67,90,20,28,12,92,8,81,88,94));
        iaPersonagens.add(new PersonaAI("Fervor","Intenso e impulsivo",64,55,82,71,61,70,66,73,48,58));
        iaPersonagens.add(new PersonaAI("Incendium","Silencioso e analítico",88,77,31,52,18,80,25,90,82,62));
        iaPersonagens.add(new PersonaAI("Pyra","Corajosa e independente",54,44,86,89,70,66,84,79,62,75));
        iaPersonagens.add(new PersonaAI("Vesta","Paciente e empática",83,86,24,41,16,94,12,88,91,97));
        iaPersonagens.add(new PersonaAI("Vulcanus","Prático e engenhoso",76,68,43,63,35,84,29,82,78,71));
    }

    private PersonaAI personagemIA(String nome) {
        for (PersonaAI p : iaPersonagens) if (p.nome.equalsIgnoreCase(nome)) return p;
        return null;
    }

    private String gerarDialogoIA(String nome, String evento) {
        PersonaAI p = personagemIA(nome);
        if (p == null) return "Recebido.";
        return p.reagir(evento);
    }

    private void mostrarDialogoEquipaPrincipal() {
        // O popup principal é o mesmo diálogo interno da equipa.
        // Sem ocorrência ativa: conversa/briefing geral, sem repetir uma ocorrência aleatória.
        // Com ocorrência ativa: usa exclusivamente o contexto dessa ocorrência.
        if (activeIncidentType != null) {
            mostrarDialogoOperacionalIA(activeIncidentType.name);
        } else {
            mostrarDialogoOperacionalIA(null);
        }
    }

    private String fraseUnica(String chave, String... opcoes) {
        ArrayList<String> disponiveis = new ArrayList<>();
        for (String f : opcoes) {
            if (!dialogoFrasesUsadas.contains(f)) disponiveis.add(f);
        }
        if (disponiveis.isEmpty()) {
            // Se todas as variantes desta ocorrência já foram usadas, cria uma variante
            // adicional numerada. Assim a frase literal nunca volta a aparecer.
            String base = opcoes.length > 0 ? opcoes[rnd.nextInt(opcoes.length)] : chave;
            String nova = base + " (confirmação " + (dialogoFrasesUsadas.size() + 1) + ")";
            dialogoFrasesUsadas.add(nova);
            return nova;
        }
        String escolhida = disponiveis.get(rnd.nextInt(disponiveis.size()));
        dialogoFrasesUsadas.add(escolhida);
        return escolhida;
    }

    private String gerarFalaCentralUnica(Person p, IncidentType type, String location,
                                         double distanceKm, double traffic) {
        String ocorrencia = type.name;
        return fraseUnica("CENTRAL:" + ocorrencia,
                "Recebemos " + (type.urgent ? "uma ocorrência urgente" : "um serviço não urgente") + " de " + ocorrencia + ". Local: " + location + ". Confirmem os meios.",
                "Central para equipa: ocorrência de " + ocorrencia + " em " + location + ", a " + String.format(Locale.US, "%.1f", distanceKm) + " km. Trânsito " + trafficLabel(traffic) + ". Prontos para saída?",
                "Temos " + ocorrencia + " para resposta. A localização é " + location + ". Necessitamos de " + type.firefighters + " operacionais. Confirmem disponibilidade.",
                "Atenção equipa: " + ocorrencia + ". Deslocação para " + location + ". Avaliem equipamento e confirmem prontidão antes do início.");
    }

    private String gerarFalaBombeiroUnica(Person p, IncidentType type, boolean lider) {
        String n = type.name;
        if (p.impulsividade >= 75 && p.autonomia >= 65) {
            return fraseUnica("BOMBEIRO:" + n,
                    "Recebido. Para " + n + ", estou pronto para sair e verifico o equipamento em marcha.",
                    "Confirmado. Assumo a minha função na equipa para " + n + ".",
                    "Recebido. Vou preparar o material específico para " + n + ".");
        }
        if (p.resistencia >= 65 && p.conflitos >= 55) {
            return fraseUnica("BOMBEIRO:" + n,
                    "Recebido. Antes de sair para " + n + ", confirmo a composição da equipa e o material.",
                    "Confirmo a missão. Quero apenas garantir que levamos o equipamento adequado para " + n + ".",
                    "Entendido. Verifico os meios antes da saída para " + n + ".");
        }
        if (p.obediencia >= 80 && p.cooperacao >= 75) {
            return fraseUnica("BOMBEIRO:" + n,
                    "Recebido. Meios confirmados para " + n + ". Pronto para a missão.",
                    "Confirmado. Equipa preparada para responder a " + n + ".",
                    "Tudo pronto. Podemos iniciar a resposta a " + n + ".");
        }
        return fraseUnica("BOMBEIRO:" + n,
                "Recebido. Vou manter a atenção durante a intervenção de " + n + ".",
                "Confirmado. Estou preparado para " + n + ".",
                "Entendido. Preparado para integrar a equipa nesta ocorrência de " + n + ".");
    }

    private void mostrarDialogoOperacionalIA(String evento) {
        loadPeople();

        final String[] nomes = {"Vox", "Flamma", "Ignis", "Ardor", "Fervor", "Incendium", "Pyra"};
        final String[] funcoes = {"Centralista", "Bombeiro", "Bombeiro", "Bombeiro", "Bombeiro", "Bombeiro", "Bombeiro"};

        ScrollView scroll = new ScrollView(this);
        LinearLayout conversation = new LinearLayout(this);
        conversation.setOrientation(LinearLayout.VERTICAL);
        conversation.setPadding(12, 8, 12, 8);
        scroll.addView(conversation);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("💬 DIÁLOGO OPERACIONAL — IA")
                .setView(scroll)
                .setNegativeButton("Fechar", null)
                .create();
        dialog.show();

        final int[] index = {0};
        final Runnable[] next = new Runnable[1];
        next[0] = () -> {
            if (index[0] >= nomes.length || !dialog.isShowing()) return;

            String nome = nomes[index[0]];
            String fala;
            if ("Vox".equals(nome)) {
                if (evento == null || evento.trim().isEmpty()) {
                    fala = fraseUnica("CENTRAL:BRIEFING",
                            "Bom dia, equipa. Confirmem disponibilidade e mantenham os meios preparados.",
                            "Central para equipa: estado operacional confirmado. Alguma necessidade antes do próximo serviço?",
                            "Equipa, façam a verificação habitual dos meios e comuniquem qualquer alteração.",
                            "Central ativa. Confirmem prontidão, comunicações e equipamento.");
                } else {
                    fala = fraseUnica("CENTRAL:" + evento,
                            "Recebida a ocorrência de " + evento + ". Confirmem meios e preparação da equipa.",
                            "Central para equipa: temos uma ocorrência de " + evento + ". Confirmem disponibilidade para a saída.",
                            "A ocorrência de " + evento + " foi recebida. Verifiquem equipamento e prontidão.");
                }
            } else {
                PersonaAI p = personagemIA(nome);
                String base = p != null ? p.reagir(evento == null ? "equipa" : evento) : "Recebido. Equipa pronta.";
                fala = fraseUnica("OPERACIONAL:" + nome + ":" + (evento == null ? "GERAL" : evento), base,
                        base + " Confirmo a minha disponibilidade.",
                        base + " Vou manter a comunicação com a equipa.");
            }

            LinearLayout line = new LinearLayout(MainActivity.this);
            line.setOrientation(LinearLayout.HORIZONTAL);
            line.setGravity(Gravity.CENTER_VERTICAL);
            line.setPadding(10, 8, 10, 8);
            line.setBackground(bg(Color.rgb(24, 37, 49), 18));

            ImageView portrait = new ImageView(MainActivity.this);
            portrait.setLayoutParams(new LinearLayout.LayoutParams(82, 82));
            portrait.setScaleType(ImageView.ScaleType.CENTER_CROP);
            Person person = null;
            for (Person pp : people) {
                if (pp.nome.equalsIgnoreCase(nome)) { person = pp; break; }
            }
            if (person != null) {
                try {
                    int photoIndex = people.indexOf(person) + 1;
                    InputStream img = getAssets().open(String.format(Locale.US,
                            "characters/people/person_%03d.jpg", photoIndex));
                    Bitmap bmp = BitmapFactory.decodeStream(img);
                    img.close();
                    portrait.setImageBitmap(bmp);
                } catch (Exception ignored) {
                    portrait.setImageResource(android.R.drawable.ic_menu_gallery);
                }
            } else {
                portrait.setImageResource(android.R.drawable.ic_menu_gallery);
            }
            line.addView(portrait);

            LinearLayout words = new LinearLayout(MainActivity.this);
            words.setOrientation(LinearLayout.VERTICAL);
            words.setPadding(12, 0, 4, 0);
            words.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));

            TextView speaker = text(("Vox".equals(nome) ? "📻  " : "👨‍🚒  ") + nome + " — " + funcoes[index[0]], 15);
            speaker.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            speaker.setTextColor(Color.WHITE);
            words.addView(speaker);

            TextView speech = text("“" + fala + "”", 15);
            speech.setTextColor(Color.rgb(225, 235, 240));
            speech.setPadding(0, 5, 0, 2);
            words.addView(speech);
            line.addView(words);

            conversation.addView(line, new LinearLayout.LayoutParams(-1, -2));
            scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));

            index[0]++;
            if (index[0] < nomes.length) {
                handler.postDelayed(next[0], 500L);
            }
        };

        // Primeira fala imediata; entre cada interveniente há exatamente 0,5 s.
        handler.post(next[0]);
    }

    private void mostrarDialogoIA(String nome, String evento) {
        // Compatibilidade com o botão antigo: encaminha para o diálogo operacional.
        mostrarDialogoOperacionalIA(evento);
    }

    private void scheduleNextOccurrence() {
        if (!gameRunning) return;
        int level = getLevel();
        // Ritmo progressivo: no início o jogador tem tempo para conhecer o quartel.
        long minDelay = Math.max(60000L, 180000L - (level - 1) * 2500L);
        long maxDelay = Math.max(minDelay + 30000L, 300000L - (level - 1) * 3500L);
        long delay = minDelay + (long)(rnd.nextDouble() * (maxDelay - minDelay));
        handler.postDelayed(() -> {
            if (gameRunning && !hasActiveOccurrence()) triggerOccurrence(false);
            scheduleNextOccurrence();
        }, delay);
    }

    private boolean hasActiveOccurrence() {
        return currentIncident != null && currentIncident.active;
    }

    private double randomDistanceKm() {
        return 1.0 + rnd.nextDouble() * 24.0;
    }

    private boolean isPeakHour(int hour) {
        return (hour >= 7 && hour < 9) ||
               (hour >= 11 && hour < 13) ||
               (hour >= 16 && hour < 20);
    }

    private double trafficFactor(boolean urgent) {
        Calendar now = Calendar.getInstance();
        int hour = now.get(Calendar.HOUR_OF_DAY);
        boolean night = hour < 7 || hour >= 22;

        double factor;
        if (night) factor = 0.85 + rnd.nextDouble() * 0.10;
        else if (isPeakHour(hour)) factor = 1.35 + rnd.nextDouble() * 0.45;
        else factor = 1.05 + rnd.nextDouble() * 0.35;

        // Urgências têm prioridade no trânsito.
        if (urgent) factor = 1.0 + (factor - 1.0) * 0.35;
        return factor;
    }

    private int calculateDurationMs(IncidentType type, double distanceKm, double traffic) {
        // A duração da ocorrência é composta por: deslocação até ao local +
        // complexidade real da operação + regresso ao quartel.
        // Assim, distância, trânsito e complexidade da ocorrência têm impacto
        // direto no tempo total do serviço.
        double idaMin = (distanceKm / 40.0) * 60.0 * traffic;

        // Complexidade dinâmica: equipa necessária, pessoas envolvidas,
        // prioridade e acompanhamento clínico tornam a operação mais longa.
        double complexidade = 1.0
                + (type.firefighters / 6.0) * 0.65
                + (type.maxOccupants / 8.0) * 0.30
                + (type.priority == 3 ? 0.35 : type.priority == 2 ? 0.18 : 0.0)
                + (type.clinicalEscort ? 0.25 : 0.0);

        double operacaoMin = type.baseMinutes * complexidade;

        // No regresso já não há prioridade de emergência: o trânsito pesa
        // novamente de forma normal.
        double retornoTraffic = Math.max(1.0, traffic * 0.92);
        double regressoMin = (distanceKm / 42.0) * 60.0 * retornoTraffic;

        double totalMinutes = Math.max(1.0, idaMin + operacaoMin + regressoMin);
        return (int)(totalMinutes * 60_000.0);
    }

    private String durationBreakdown(IncidentType type, double distanceKm, double traffic) {
        double idaMin = (distanceKm / 40.0) * 60.0 * traffic;
        double complexidade = 1.0
                + (type.firefighters / 6.0) * 0.65
                + (type.maxOccupants / 8.0) * 0.30
                + (type.priority == 3 ? 0.35 : type.priority == 2 ? 0.18 : 0.0)
                + (type.clinicalEscort ? 0.25 : 0.0);
        double operacaoMin = type.baseMinutes * complexidade;
        double retornoTraffic = Math.max(1.0, traffic * 0.92);
        double regressoMin = (distanceKm / 42.0) * 60.0 * retornoTraffic;
        return String.format(Locale.US,
                "🚒 Deslocação para o TO: %.0f min\n" +
                "🛠️ Intervenção no TO: %.0f min\n" +
                "🏠 Regresso ao quartel: %.0f min",
                idaMin, operacaoMin, regressoMin);
    }

    private String complexityLabel(IncidentType type) {
        double score = type.firefighters + type.maxOccupants * 0.5 + type.priority * 1.5
                + (type.clinicalEscort ? 2.0 : 0.0);
        if (score >= 13) return "MUITO ALTA";
        if (score >= 9) return "ALTA";
        if (score >= 6) return "MÉDIA";
        return "BAIXA";
    }

    private void triggerOccurrence(boolean forced) {
        if (!gameRunning) return;

        IncidentType type = incidentTypes[rnd.nextInt(incidentTypes.length)];
        String location = locations[rnd.nextInt(locations.length)];
        double distanceKm = randomDistanceKm();
        double traffic = trafficFactor(type.urgent);
        int durationMs = calculateDurationMs(type, distanceKm, traffic);

        // Uma ocorrência urgente só é gerada se existir capacidade de urgência.
        if (type.urgent && (urgentVehicles <= activeUrgent || firefighters < type.firefighters)) {
            status.setText("📻 Urgência pendente — aguarda equipa de urgência.");
            return;
        }

        showCommunicationDialog(type, location, distanceKm, traffic, durationMs);
    }

    private void showCommunicationDialog(IncidentType type, String location,
                                         double distanceKm, double traffic,
                                         int durationMs) {
        final Dialog dialog = new Dialog(this);
        dialog.setTitle("Receção da ocorrência");

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(20, 16, 20, 16);
        box.setBackgroundColor(Color.rgb(20, 29, 38));

        AnimatedCommunicationView cartoon = new AnimatedCommunicationView(this);
        box.addView(cartoon, new LinearLayout.LayoutParams(-1, 190));

        TextView message = text(
                "📻 RECEÇÃO DA OCORRÊNCIA\n\n" +
                type.icon + " " + type.name + "\n" +
                "📍 " + location + "\n" +
                "🚨 Tipo: " + (type.urgent ? "URGENTE" : "NÃO URGENTE") + "\n" +
                "🚒 Meio: " + type.vehicle + "\n" +
                "👨‍🚒 Meios necessários: " + type.firefighters + "\n" +
                "📏 Distância: " + String.format(Locale.US, "%.1f", distanceKm) + " km\n" +
                "🚦 Trânsito: " + trafficLabel(traffic) + "\n" +
                durationBreakdown(type, distanceKm, traffic) + "\n" +
                "🧩 Complexidade: " + complexityLabel(type) + "\n" +
                "⏱️ Tempo total previsto: " + formatDuration((long)durationMs) + "\n" +
                "💰 Recompensa: €" + type.reward,
                15);
        box.addView(message);

        if (type.urgent) {
            box.addView(text("🚨 Sinal luminoso: ATIVO\n🔊 Sinal sonoro: ATIVO", 14));
        } else if (type.clinicalEscort) {
            box.addView(text("🚨 Sinal luminoso: ATIVO\n🔊 Sinal sonoro: INATIVO", 14));
        } else {
            box.addView(text("🚫 Sinal luminoso: INATIVO\n🔇 Sinal sonoro: INATIVO", 14));
        }

        LinearLayout actions = new LinearLayout(this);
        Button accept = button("✅ ACEITAR OCORRÊNCIA");
        Button later = button("⏳ AGUARDAR");
        actions.addView(accept, new LinearLayout.LayoutParams(0, -2, 1));
        actions.addView(later, new LinearLayout.LayoutParams(0, -2, 1));
        box.addView(actions);

        later.setOnClickListener(v -> dialog.dismiss());

        accept.setOnClickListener(v -> {
            if (type.urgent) {
                if (urgentVehicles <= activeUrgent || firefighters < type.firefighters) {
                    message.setText("⚠️ Não existem meios de urgência suficientes disponíveis.");
                    accept.setEnabled(false);
                    cartoon.setFailure();
                    return;
                }
            } else {
                if (nonUrgentVehicles <= activeNonUrgent || nonUrgentStaff < type.firefighters) {
                    message.setText("⚠️ Não existem meios não urgentes suficientes disponíveis.");
                    accept.setEnabled(false);
                    cartoon.setFailure();
                    return;
                }
            }

            accept.setEnabled(false);
            later.setEnabled(false);
            cartoon.setDispatching();
            activeIncidentType = type;
            activeIncidentLocation = location;
            showInternalOperationalDialogue(dialog, type, location, distanceKm, traffic, durationMs);
        });

        dialog.setContentView(box);
        Window w = dialog.getWindow();
        if (w != null) w.setBackgroundDrawableResource(android.R.color.transparent);
        dialog.show();
    }

    /**
     * Segunda fase da ocorrência: diálogo operacional interno entre a Central
     * e a equipa. As falas são geradas localmente a partir da personalidade,
     * obediência, autonomia, liderança, pressão e cooperação de cada pessoa.
     */
    private void showInternalOperationalDialogue(Dialog parent, IncidentType type,
                                                 String location, double distanceKm,
                                                 double traffic, int durationMs) {
        final Dialog dialog = new Dialog(this);
        dialog.setTitle("Diálogo operacional interno");

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(22, 18, 22, 18);
        box.setBackgroundColor(Color.rgb(18, 28, 37));

        TextView title = text("📻 DIÁLOGO OPERACIONAL INTERNO", 19);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        box.addView(title);

        box.addView(text("A Central transmite a ocorrência e a equipa confirma os meios antes do início da deslocação.", 13));

        ArrayList<Person> centralistas = pessoasPorFuncao("Centralista", Math.max(1, urgentDispatchers + nonUrgentDispatchers));
        ArrayList<Person> equipa = type.urgent
                ? pessoasPorFuncao("Bombeiro", Math.min(type.firefighters, Math.max(1, firefighters)))
                : pessoasPorFuncao("Transporte não urgente", Math.min(type.firefighters, Math.max(1, nonUrgentStaff)));

        if (centralistas.isEmpty()) {
            Person fallback = pessoaFallback("Vox", "Centralista");
            centralistas.add(fallback);
        }
        if (equipa.isEmpty()) {
            equipa.add(pessoaFallback(type.urgent ? "Flamma" : "Velox", type.urgent ? "Bombeiro" : "Transporte não urgente"));
        }

        Person central = centralistas.get(0);
        box.addView(dialogueLine("📻 CENTRAL — " + central.nome,
                gerarFalaCentralUnica(central, type, location, distanceKm, traffic), true));

        int maxLines = Math.min(3, equipa.size());
        for (int i = 0; i < maxLines; i++) {
            Person membro = equipa.get(i);
            String fala = gerarFalaBombeiroUnica(membro, type, i == 0);
            box.addView(dialogueLine("👨‍🚒 " + membro.nome, fala, false));
        }

        Person lider = equipa.get(0);
        box.addView(dialogueLine("📻 CENTRAL — " + central.nome,
                "Confirmem prontidão. Assim que houver confirmação, inicia-se a deslocação para o TO.", true));
        box.addView(dialogueLine("👨‍🚒 " + lider.nome,
                fraseUnica("CONFIRMACAO:" + type.name,
                "Confirmado. Todos prontos para iniciar a deslocação para " + type.name + ".",
                "Prontidão confirmada. Podemos iniciar a deslocação para " + type.name + ".",
                "Equipa pronta. Confirmo a saída para " + type.name + "."), false));

        TextView status = text("🟢 Estado: ocorrência aceite — aguarda início da deslocação.", 14);
        status.setTextColor(Color.rgb(90, 220, 130));
        box.addView(status);

        LinearLayout actions = new LinearLayout(this);
        Button start = button("🚒 INICIAR DESLOCAÇÃO");
        Button cancel = button("Voltar");
        actions.addView(start, new LinearLayout.LayoutParams(0, -2, 1));
        actions.addView(cancel, new LinearLayout.LayoutParams(0, -2, 1));
        box.addView(actions);

        cancel.setOnClickListener(v -> dialog.dismiss());
        start.setOnClickListener(v -> {
            dialog.dismiss();
            iniciarDeslocacaoAposDialogo(parent, type, location, distanceKm, traffic, durationMs);
        });

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(box);
        dialog.setContentView(scroll);
        Window w = dialog.getWindow();
        if (w != null) w.setBackgroundDrawableResource(android.R.color.transparent);
        dialog.show();
    }

    private View dialogueLine(String speaker, String speech, boolean central) {
        // Cada interveniente aparece com o seu retrato individual.
        // A fotografia é associada ao Person pelo índice da ficha em pessoas_128.json.
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(10, 8, 10, 8);
        row.setBackground(bg(central ? Color.rgb(32, 53, 68) : Color.rgb(36, 45, 53), 16));

        ImageView portrait = new ImageView(this);
        portrait.setScaleType(ImageView.ScaleType.CENTER_CROP);
        portrait.setBackground(bg(Color.rgb(12, 19, 25), 14));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(72, 72);
        pp.setMargins(0, 0, 12, 0);
        row.addView(portrait, pp);

        TextView content = text((central ? "📻 " : "👨‍🚒 ") + speaker + "\n“" + speech + "”", 15);
        content.setTextColor(Color.WHITE);
        content.setGravity(Gravity.CENTER_VERTICAL);
        content.setIncludeFontPadding(true);
        content.setLineSpacing(0, 1.05f);
        content.setPadding(0, 2, 0, 2);
        row.addView(content, new LinearLayout.LayoutParams(0, -2, 1));

        Person person = findPersonByName(speaker);
        loadDialoguePortrait(portrait, person);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 6, 0, 6);
        row.setLayoutParams(lp);
        return row;
    }

    private Person findPersonByName(String name) {
        loadPeople();
        if (name == null) return null;
        String clean = name.replace("📻", "").replace("👨‍🚒", "").trim();
        for (Person p : people) {
            if (p.nome.equalsIgnoreCase(clean)) return p;
        }
        return null;
    }

    private void loadDialoguePortrait(ImageView image, Person person) {
        if (person == null) {
            image.setImageResource(android.R.drawable.ic_menu_gallery);
            return;
        }
        try {
            int photoIndex = people.indexOf(person) + 1;
            String asset = String.format(Locale.US, "characters/people/person_%03d.jpg", photoIndex);
            InputStream img = getAssets().open(asset);
            image.setImageBitmap(BitmapFactory.decodeStream(img));
            img.close();
        } catch (Exception e) {
            image.setImageResource(android.R.drawable.ic_menu_gallery);
        }
    }

    private ArrayList<Person> pessoasPorFuncao(String funcao, int limite) {
        ArrayList<Person> out = new ArrayList<>();
        for (Person p : people) {
            if (funcao.equals(p.funcao) && out.size() < limite) out.add(p);
        }
        return out;
    }

    private Person pessoaFallback(String nome, String funcao) {
        try {
            JSONObject o = new JSONObject();
            o.put("id", "TEMP");
            o.put("nome", nome);
            o.put("funcao", funcao);
            o.put("personalidade", "profissional e cooperante");
            o.put("lideranca", 60); o.put("obediencia", 70); o.put("autonomia", 50);
            o.put("impulsividade", 30); o.put("resistencia_autoridade", 20); o.put("cooperacao", 80);
            o.put("conflitualidade", 20); o.put("confianca", 70); o.put("pressao", 30); o.put("empatia", 70);
            return new Person(o);
        } catch (Exception e) { return null; }
    }

    private String gerarFalaCentral(Person p, IncidentType type, String location,
                                    double distanceKm, double traffic) {
        String prefixo = type.urgent ? "Recebemos uma ocorrência urgente" : "Recebemos um serviço não urgente";
        if (p.autonomia >= 70) {
            return prefixo + ": " + type.name + ", em " + location + ", a "
                    + String.format(Locale.US, "%.1f", distanceKm) + " km. Trânsito "
                    + trafficLabel(traffic) + ". Preciso da vossa confirmação dos meios.";
        }
        return prefixo + ": " + type.name + ". Local: " + location + ". "
                + "Meios necessários: " + type.firefighters + ". Confirmem prontidão.";
    }

    private String gerarFalaBombeiro(Person p, IncidentType type, boolean lider) {
        if (p.impulsividade >= 75 && p.autonomia >= 65) {
            return lider ? "Recebido. Temos os meios e estamos prontos para sair." : "Recebido. Estou pronto e verifico o meu equipamento.";
        }
        if (p.resistencia >= 65 && p.conflitos >= 55) {
            return "Recebido. Antes de sair, confirmo apenas a composição e o material necessário.";
        }
        if (p.obediencia >= 80 && p.cooperacao >= 75) {
            return "Recebido. Meios confirmados. Pronto para a missão.";
        }
        if (p.empatia >= 80) {
            return "Recebido. Vamos manter a comunicação durante toda a intervenção.";
        }
        return "Recebido. A equipa está pronta.";
    }

    private String gerarFalaConfirmacao(Person p, IncidentType type) {
        if (p.lideranca >= 80) return "Equipa pronta. Confirmo a missão e assumo a coordenação da equipa no TO.";
        if (p.obediencia >= 85) return "Confirmação recebida. Todos prontos. Podemos iniciar a deslocação.";
        if (p.autonomia >= 75) return "Confirmado. Equipamento verificado e equipa pronta para iniciar.";
        return "Confirmado. Estamos prontos para iniciar a deslocação.";
    }

    private void iniciarDeslocacaoAposDialogo(Dialog parent, IncidentType type, String location,
                                              double distanceKm, double traffic, int durationMs) {
        if (type.urgent) {
            if (urgentVehicles <= activeUrgent || firefighters < type.firefighters) {
                Toast.makeText(this, "Sem meios de urgência disponíveis.", Toast.LENGTH_SHORT).show();
                return;
            }
            activeUrgent++;
        } else {
            if (nonUrgentVehicles <= activeNonUrgent || nonUrgentStaff < type.firefighters) {
                Toast.makeText(this, "Sem meios não urgentes disponíveis.", Toast.LENGTH_SHORT).show();
                return;
            }
            activeNonUrgent++;
        }

        firefighters -= type.firefighters;
        refreshStats();

        TextView statusText = new TextView(this);
        statusText.setTextColor(Color.WHITE);
        statusText.setTextSize(17);
        statusText.setPadding(22, 18, 22, 18);
        statusText.setText(
                "🚒 DESLOCAÇÃO INICIADA\n\n" +
                type.icon + " " + type.name + "\n" +
                "📍 " + location + "\n" +
                "📏 " + String.format(Locale.US, "%.1f", distanceKm) + " km\n" +
                "🚦 Trânsito: " + trafficLabel(traffic) + "\n\n" +
                durationBreakdown(type, distanceKm, traffic) + "\n" +
                "⏱️ Tempo total: " + formatDuration((long)durationMs));

        new AlertDialog.Builder(this)
                .setTitle("🚒 Início da operação")
                .setView(statusText)
                .setPositiveButton("Acompanhar", null)
                .show();

        handler.postDelayed(() -> {
            firefighters += type.firefighters;
            if (type.urgent) activeUrgent = Math.max(0, activeUrgent - 1);
            else activeNonUrgent = Math.max(0, activeNonUrgent - 1);
            cash += type.reward;
            stars += type.priority == 3 ? 3 : 2;
            if (activeIncidentType == type) { activeIncidentType = null; activeIncidentLocation = ""; }
            refreshStats();
            status.setText("📻 Central ativa — equipa regressou ao quartel e está novamente disponível.");
        }, durationMs);
    }

    private int getLevel() {
        return Math.min(50, 1 + (stars / 10));
    }

    // A progressão desbloqueia vagas. As pessoas só aparecem depois de contratadas.
    private int unlockedFirefighters() {
        return Math.min(TOTAL_FIREFIGHTERS, 6 + Math.max(0, getLevel() - 1) * 2);
    }

    private int unlockedNonUrgentStaff() {
        return Math.min(TOTAL_NON_URGENT, 4 + Math.max(0, getLevel() - 1));
    }

    private int unlockedCentralists() {
        return Math.min(TOTAL_CENTRALISTS, 2 + Math.max(0, (getLevel() - 1) / 3));
    }

    private int activeCountFor(String funcao) {
        if ("Bombeiro".equals(funcao)) return Math.min(firefighters, unlockedFirefighters());
        if ("Transporte não urgente".equals(funcao)) return Math.min(nonUrgentStaff, unlockedNonUrgentStaff());
        return Math.min(urgentDispatchers + nonUrgentDispatchers, unlockedCentralists());
    }

    private void showPeopleList() {
        loadPeople();
        ArrayList<Person> visiblePeople = new ArrayList<>();
        for (int i=0;i<people.size();i++) {
            Person p = people.get(i);
            int active = activeCountFor(p.funcao);
            int same = 0;
            for (int j=0;j<=i;j++) if (people.get(j).funcao.equals(p.funcao)) same++;
            // Só os já contratados aparecem. Os restantes ficam ocultos até serem desbloqueados
            // pelo nível e posteriormente contratados.
            if (same <= active) visiblePeople.add(p);
        }

        final String[] labels = new String[visiblePeople.size()];
        for (int i=0;i<visiblePeople.size();i++) {
            Person p = visiblePeople.get(i);
            labels[i] = "🟢 " + p.nome + " — " + p.funcao;
        }
        new AlertDialog.Builder(this)
                .setTitle("👥 " + visiblePeople.size() + " pessoas — fichas individuais")
                .setItems(labels,(d,which)->showPersonCard(visiblePeople.get(which)))
                .show();
    }

    private void showPersonCard(Person p) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(24, 16, 24, 8);

        ImageView portrait = new ImageView(this);
        portrait.setAdjustViewBounds(true);
        portrait.setScaleType(ImageView.ScaleType.CENTER_CROP);
        try {
            int photoIndex = people.indexOf(p) + 1;
            InputStream img = getAssets().open(String.format(Locale.US, "characters/people/person_%03d.jpg", photoIndex));
            portrait.setImageBitmap(BitmapFactory.decodeStream(img));
            img.close();
        } catch (Exception e) {
            portrait.setImageResource(android.R.drawable.ic_menu_gallery);
        }
        box.addView(portrait, new LinearLayout.LayoutParams(-1, 520));

        TextView heading = text(p.nome + "\n" + p.id + " • " + p.funcao, 22);
        heading.setGravity(Gravity.CENTER);
        box.addView(heading);

        StringBuilder b=new StringBuilder();
        b.append("🧠 PERSONALIDADE\n").append(p.personalidade).append("\n\n");
        b.append("👑 Liderança: ").append(p.lideranca).append("/100\n");
        b.append("📋 Obediência: ").append(p.obediencia).append("/100\n");
        b.append("🧭 Autonomia: ").append(p.autonomia).append("/100\n");
        b.append("⚡ Impulsividade: ").append(p.impulsividade).append("/100\n");
        b.append("⚠️ Resistência à autoridade: ").append(p.resistencia).append("/100\n");
        b.append("🤝 Cooperação: ").append(p.cooperacao).append("/100\n");
        b.append("⚔️ Conflitualidade: ").append(p.conflitos).append("/100\n");
        b.append("💪 Confiança: ").append(p.confianca).append("/100\n");
        b.append("🔥 Reação sob pressão: ").append(p.pressao).append("/100\n");
        b.append("❤️ Empatia: ").append(p.empatia).append("/100\n\n");
        b.append("🔄 Evolução: personalidade base + estados temporários + mudanças graduais por experiência, formação e acontecimentos.");

        TextView details = text(b.toString(), 16);
        box.addView(details);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Ficha individual")
                .setView(box)
                .setPositiveButton("Fechar", null)
                .create();
        dialog.show();
    }

    private void showManagement() {
        final String[] items = {
                "👩‍🚒 Contratar bombeiro/bombeira — €400",
                "👥 Contratar funcionário não urgente — €250",
                "🚑 Comprar viatura de urgência — €900",
                "🚐 Comprar viatura não urgente — €700",
                "🛠️ Comprar viatura de apoio — €600"
        };

        new AlertDialog.Builder(this)
                .setTitle("🏢 Gestão — contratar e comprar")
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        if (firefighters >= unlockedFirefighters()) {
                            showInfo("🔒 Próximo bombeiro bloqueado", "É necessário subir de nível para desbloquear a próxima vaga.\n\nNível atual: " + getLevel() + "\nPróximo nível: " + (getLevel() + 1));
                        } else if (cash >= 400) {
                            cash -= 400;
                            firefighters++;
                            refreshStats();
                            showInfo("Contratação", "👩‍🚒 Novo bombeiro/bombeira contratado.\nEfetivo: " + firefighters + "/" + unlockedFirefighters());
                        } else showInfo("Sem saldo", "São necessários €400.");
                    } else if (which == 1) {
                        if (nonUrgentStaff >= unlockedNonUrgentStaff()) {
                            showInfo("🔒 Próximo funcionário bloqueado", "É necessário subir de nível para desbloquear a próxima vaga.\n\nNível atual: " + getLevel() + "\nPróximo nível: " + (getLevel() + 1));
                        } else if (cash >= 250) {
                            cash -= 250;
                            nonUrgentStaff++;
                            refreshStats();
                            showInfo("Contratação", "👥 Novo funcionário não urgente contratado.\nEfetivo: " + nonUrgentStaff + "/" + unlockedNonUrgentStaff());
                        } else showInfo("Sem saldo", "São necessários €250.");
                    } else if (which == 2) {
                        if (cash >= 900) {
                            cash -= 900;
                            urgentVehicles++;
                            addFleetVehicle("ABSC", "Urgência");
                            refreshStats();
                            showInfo("Frota", "🚑 Nova viatura de urgência adquirida.\n\n" + fleet.get(fleet.size()-1));
                        } else showInfo("Sem saldo", "São necessários €900.");
                    } else if (which == 3) {
                        if (cash >= 700) {
                            cash -= 700;
                            nonUrgentVehicles++;
                            addFleetVehicle("A1", "Não urgente");
                            refreshStats();
                            showInfo("Frota", "🚐 Nova viatura não urgente adquirida.\n\n" + fleet.get(fleet.size()-1));
                        } else showInfo("Sem saldo", "São necessários €700.");
                    } else {
                        if (cash >= 600) {
                            cash -= 600;
                            supportVehicles++;
                            addFleetVehicle("APOIO", "Apoio");
                            refreshStats();
                            showInfo("Frota", "🛠️ Nova viatura de apoio adquirida.\n\n" + fleet.get(fleet.size()-1));
                        } else showInfo("Sem saldo", "São necessários €600.");
                    }
                })
                .show();
    }

    private void showInfo(String title, String msg) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(msg + "\n\n💰 Saldo: €" + cash + "\n⭐ Reputação: " + stars)
                .setPositiveButton("OK", null)
                .show();
    }

    private String trafficLabel(double factor) {
        if (factor < 1.00) return "Muito reduzido";
        if (factor < 1.25) return "Livre";
        if (factor < 1.50) return "Moderado";
        if (factor < 1.70) return "Intenso";
        return "Muito intenso";
    }

    private String formatDuration(long ms) {
        long safeMs = Math.max(0L, ms);
        int minutes = (int) Math.max(1L, Math.round(safeMs / 60000.0));
        if (minutes < 60) return minutes + " min";
        int h = minutes / 60;
        int m = minutes % 60;
        return h + " h " + m + " min";
    }

    private void refreshStats() {
        if (money != null) money.setText("💰 €" + cash);
        if (rep != null) rep.setText("⭐ " + stars);
        if (crew != null) crew.setText("👨‍🚒 " + firefighters);
    }

    private void showCrewDialog() {
        new AlertDialog.Builder(this)
                .setTitle("👨‍🚒 Estrutura do quartel")
                .setMessage(
                        "👩‍🚒 Centralista Urgência: 1\n" +
                        "👩‍🚒 Centralista Não Urgente: 1\n" +
                        "👥 Funcionários Não Urgente: " + nonUrgentStaff + "\n" +
                        "👨‍🚒 Bombeiros/Bombeiras: " + firefighters + "\n\n" +
                        "🚑 Viaturas de Urgência: " + urgentVehicles + "\n" +
                        "🚐 Viaturas Não Urgentes: " + nonUrgentVehicles + "\n" +
                        "🛠️ Viaturas de Apoio: " + supportVehicles + "\n\n" +
                        "Em serviço urgente: " + activeUrgent + "\n" +
                        "Em serviço não urgente: " + activeNonUrgent
                )
                .setPositiveButton("OK", null)
                .show();
    }

    @Override protected void onDestroy() {
        gameRunning = false;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private static class AnimatedCommunicationView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        long start = System.currentTimeMillis();
        int mode = 0;

        AnimatedCommunicationView(android.content.Context c) {
            super(c);
            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
        }

        void setDispatching() { mode = 1; invalidate(); }
        void setSuccess() { mode = 2; invalidate(); }
        void setFailure() { mode = 3; invalidate(); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float t = (System.currentTimeMillis() - start) / 180.0f;
            float bob = (float)Math.sin(t) * 7f;

            p.setColor(Color.rgb(35, 47, 58));
            c.drawRoundRect(8, 8, getWidth()-8, getHeight()-8, 25, 25, p);

            drawPerson(c, getWidth()*0.28f, 125+bob, Color.rgb(230, 70, 50),
                    mode == 1 ? "🚒" : "👩‍🚒");
            drawPerson(c, getWidth()*0.72f, 125-bob, Color.rgb(55, 130, 210),
                    mode == 2 ? "😊" : "📻");

            p.setColor(Color.WHITE);
            p.setTextSize(25);
            p.setTextAlign(Paint.Align.CENTER);
            String bubble = mode == 0 ? "📻 Temos uma ocorrência!"
                    : mode == 1 ? "🚒 Equipa a caminho!"
                    : mode == 2 ? "✅ Serviço concluído!"
                    : "⚠️ Sem equipa disponível";
            c.drawText(bubble, getWidth()/2f, 45, p);
            postInvalidateDelayed(40);
        }

        private void drawPerson(Canvas c, float x, float y, int color, String icon) {
            p.setColor(Color.rgb(245, 205, 165));
            c.drawCircle(x, y-42, 27, p);
            p.setColor(color);
            c.drawRoundRect(x-34, y-15, x+34, y+65, 22, 22, p);
            p.setColor(Color.WHITE);
            p.setTextSize(34);
            p.setTextAlign(Paint.Align.CENTER);
            c.drawText(icon, x, y+38, p);
        }
    }
}
