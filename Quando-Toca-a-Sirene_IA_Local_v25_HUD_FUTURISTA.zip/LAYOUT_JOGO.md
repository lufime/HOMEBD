# Layout de jogo — Quando Toca a Sirene v2

Interface principal orientada para jogo:
- Cabeçalho compacto com nível e estado do quartel.
- Recursos em cartões: dinheiro, reputação e pessoal.
- Cartão principal de missão/central.
- Botão grande para nova ocorrência.
- Pessoal mostra apenas contratados do nível atual.
- Garagem mostra resumo e abre gestão de frota.
- Quartel, disponibilidade e diário em cartões.
- Barra inferior: Quartel | Ocorrências | Pessoal | Frota.
- Conteúdo ainda bloqueado permanece oculto.
- Progressão apresentada como objetivo do nível sem revelar conteúdo futuro.
