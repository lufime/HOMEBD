# Quando Toca a Sirene — V12

## Correção definitiva do layout
- Elementos da cena do quartel sem corte vertical.
- Botão RECEBER CHAMADA com altura automática.
- Botão FALAR COM A EQUIPA com altura automática e texto completo.
- Equipa em serviço com espaço suficiente para os emojis/personagens.
- Barra inferior com ícone + nome visível.
- Conteúdo principal com padding inferior para não ficar escondido pela navegação.
- Font padding ativado nos textos que contêm emojis para evitar corte da renderização.
- Mantido o fluxo operacional: receção → aceitação → diálogo interno IA → início da deslocação.
- Mantida a duração baseada em distância, trânsito e complexidade.
