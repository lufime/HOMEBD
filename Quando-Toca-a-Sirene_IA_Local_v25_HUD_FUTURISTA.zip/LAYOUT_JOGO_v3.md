# QUANDO TOCA A SIRENE — Quartel Vivo v3

O ecrã inicial foi convertido para uma lógica de jogo:
- o quartel é apresentado como um cenário;
- Central, Garagem e Equipa são objetos interativos;
- a ocorrência é uma missão principal;
- a equipa aparece visualmente;
- a progressão aparece como nível;
- os detalhes são abertos por toque;
- pessoas não contratadas e outros conteúdos bloqueados continuam ocultos.
