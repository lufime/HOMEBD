# Diálogos operacionais com retratos

A partir da v13, cada linha do diálogo operacional mostra o retrato individual do interveniente.
A fotografia é carregada de `app/src/main/assets/characters/people/person_XXX.jpg` através da posição da pessoa em `pessoas_128.json`.

O diálogo continua local/offline e é gerado a partir da personalidade da pessoa. A janela usa ScrollView para evitar cortes em ecrãs pequenos.
