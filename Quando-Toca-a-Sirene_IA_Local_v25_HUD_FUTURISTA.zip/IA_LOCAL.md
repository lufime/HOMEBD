# IA local — Quando Toca a Sirene

A IA funciona offline e usa os atributos individuais das personagens para escolher reações e diálogos.

Cada personagem pode ter:
- personalidade;
- obediência;
- autonomia;
- resistência à autoridade;
- liderança;
- impulsividade;
- cooperação;
- conflitualidade;
- confiança;
- reação à pressão;
- empatia;
- stress e fadiga.

A experiência e o tempo alteram o estado da personagem.
