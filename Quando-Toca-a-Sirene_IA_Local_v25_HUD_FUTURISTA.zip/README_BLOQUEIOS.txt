QUANDO TOCA A SIRENE — REGRA DE INTERFACE

Itens bloqueados ficam completamente ocultos.
Quando uma funcionalidade, pessoa, veículo, ocorrência, formação ou instalação é desbloqueada,
passa automaticamente a aparecer no menu.

Não mostrar cadeados, botões cinzentos ou opções indisponíveis.
