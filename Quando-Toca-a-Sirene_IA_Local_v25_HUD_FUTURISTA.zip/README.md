# FIRE RESCUE — V7

Versão de jogo com gestão inicial do quartel, centralistas, equipas, frota e progressão por recompensas.

## Estrutura inicial
- 1 bombeira centralista de urgência
- 1 bombeira centralista de não urgência
- 4 funcionários de não urgência
- 6 bombeiros/bombeiras operacionais
- 2 viaturas de urgência
- 1 viatura de transporte não urgente

## Progressão
As recompensas dos serviços podem ser usadas para:
- contratar bombeiros/bombeiras;
- contratar funcionários não urgentes;
- comprar viaturas de urgência;
- comprar viaturas não urgentes;
- comprar viaturas de apoio.

## Regras
- Equipas não urgentes não respondem a serviços urgentes.
- Serviços não urgentes podem ser agrupados na mesma saída.
- O regresso ao quartel é sempre sem pirilampo e sem sirene.
- Cardiologia pode ter acompanhamento clínico; nesse caso usa pirilampo sem sirene durante o transporte.
- Urgências usam pirilampo e sirene.
- Trânsito considera dia/noite e picos 07–09, 11–13 e 16–20.
- Urgências sofrem menos impacto do trânsito devido à prioridade simulada.

Todos os tempos, recursos e recompensas são parâmetros de jogo e não representam procedimentos operacionais reais.

## Identificação da frota
Cada viatura adquirida recebe automaticamente um número sequencial com dois dígitos (por exemplo: ABSC 01, ABSC 02, A1 03). O número é individual e não é reutilizado.

## Perfis individuais
A versão inclui os 128 perfis individuais no jogo. A partir do ecrã principal, usar **Ver as 128 pessoas / fichas individuais** para consultar cada pessoa e os respetivos atributos comportamentais.


V18 — DIÁLOGO PRINCIPAL IA
- Falar com a equipa abre o popup principal de comunicação.
- As falas são específicas da ocorrência.
- A mesma frase literal não é reutilizada durante a sessão.
- Fotografias individuais dos operacionais permanecem no diálogo.
- Intervalo de 0,5 s entre intervenientes.


V21: secção Quartel corrigida; diálogo principal usa apenas ocorrência ativa; sem ocorrência há briefing geral; frases literais não são repetidas na sessão.


## Ritmo de ocorrências por nível
As ocorrências automáticas não são constantes. O jogador dispõe de tempo para gerir o quartel. No nível 1 surgem, em média, a cada 3–5 minutos; a frequência aumenta gradualmente com os níveis. O jogador pode sempre iniciar manualmente uma chamada através de «RECEBER CHAMADA». Não é criada uma nova ocorrência automática enquanto existir uma ocorrência ativa.


## Progressão
O jogo tem 50 níveis (1–50). O nível é limitado a 50 e os conteúdos futuros permanecem bloqueados até ao desbloqueio. O ritmo das ocorrências aumenta gradualmente com o nível.
