# FireRescue — Design Atual

## Efetivo
- 100 bombeiros e bombeiras.
- 20 funcionários de transporte não urgente.
- Início: 6 bombeiros/bombeiras + 2 funcionários não urgentes.
- 1 centralista de urgência.
- 1 centralista não urgente.

## Bombeiros
Carreira:
Estagiário → Bombeiro 3.ª → Bombeiro 2.ª → Bombeiro 1.ª → Subchefe → Chefe.

Oficiais:
Oficial Bombeiro 2.ª → Oficial Bombeiro 1.ª → Oficial Bombeiro Principal → Oficial Bombeiro Superior.

Comando:
Comandante → 2.º Comandante → Adjuntos de Comando.

Cada bombeiro/bombeira terá ficha individual, nome latino ligado a fogo/água/proteção,
rosto, cabelo, expressão e postura próprios, experiência, categoria, estado,
competências, formação, histórico e progressão.

## Não urgentes
- Não são bombeiros.
- 20 funcionários, homens e mulheres.
- Início: 2 funcionários.
- Nomes latinos relacionados com velocidade, movimento e transporte.
- Podem agrupar vários serviços numa saída.
- Não podem realizar serviços de urgência.
- Regresso sempre sem sirene e sem pirilampo.
- Ambulâncias brancas com riscas vermelhas.
- Fichas individuais em estilo cartoon.

## Urgências
- Bombeiros/bombeiras.
- 6 elementos iniciais = 2 equipas de 3.
- Sirene e pirilampo durante resposta urgente.
- Regresso ao quartel sem sirene/pirilampo.
- Só voltam a usar sinais de emergência se surgir novo serviço urgente.

## Trânsito e horário
Considerar distância em km, dia/noite e períodos de maior trânsito:
07:00–09:00, 11:00–13:00 e 16:00–20:00.
A duração deve ser calculada dinamicamente.

## Viaturas
Identificação sempre SIGLA+número, sem espaço e sem #:
ABTD01, ABTM02, ABSC03, ABCI04, VDTD05, etc.
Cada nova viatura recebe o próximo número.

## Visual
- Estilo cartoon moderno.
- Cada personagem com cara, cabelo, expressão e postura diferentes.
- Bombeiros/bombeiras: uniforme/camisa vermelho, calças azul-escuro.
- Não urgentes: camisa vermelha, calças azul-escuro.
- Viaturas de bombeiros vermelhas.
- Ambulâncias não urgentes brancas com riscas vermelhas.
- Sem logótipos de entidades reais.
- Fichas individuais para todos.

## Sistema de personalidades — 128 pessoas
- 128 fichas individuais carregadas a partir de `app/src/main/assets/pessoas_128.json`.
- 100 bombeiros/bombeiras, 20 funcionários de transporte não urgente e 8 centralistas.
- Cada pessoa possui personalidade e valores próprios de liderança, obediência, autonomia, impulsividade, resistência à autoridade, cooperação, conflitualidade, confiança, reação sob pressão e empatia.
- O jogador pode abrir a lista completa e consultar a ficha individual de cada pessoa.
- A personalidade pode sofrer alterações temporárias por fadiga, stress, conflitos ou ocorrências e alterações graduais/permanentes por experiência, formação e acontecimentos.
- O sistema distingue personalidade de competência profissional.


## Ritmo de ocorrências por nível
As ocorrências automáticas não são constantes. O jogador dispõe de tempo para gerir o quartel. No nível 1 surgem, em média, a cada 3–5 minutos; a frequência aumenta gradualmente com os níveis. O jogador pode sempre iniciar manualmente uma chamada através de «RECEBER CHAMADA». Não é criada uma nova ocorrência automática enquanto existir uma ocorrência ativa.
