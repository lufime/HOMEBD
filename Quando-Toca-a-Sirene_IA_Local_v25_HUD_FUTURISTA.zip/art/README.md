# Arte do jogo

Estas imagens são referências visuais integradas ao projeto nesta versão. O roster mostra o estilo dos 100 bombeiros/bombeiras e 20 não urgentes; as fichas individuais serão geradas como assets separados na próxima fase.

Imagens incluídas:
- bombeiro_ficha_referencia.png
- bombeira_ficha_referencia.png
- bombeira_postura_diferente_referencia.png
- roster_50_bombeiros_referencia.png
- dashboard_jogo_referencia.png

## Retratos individuais
A ficha individual carrega automaticamente o retrato correspondente a partir de `app/src/main/assets/characters/people/person_001.jpg` até `person_128.jpg`.
