# V16 — Layout redesenhado

Layout principal reorganizado em Quartel Vivo, Central de Missões, Equipa em Serviço, Diálogo Operacional IA e Progressão. Removidas alturas fixas dos blocos principais para evitar cortes.
