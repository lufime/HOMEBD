# HOMEBD — Changelog

## V1.6
- Home Assistant MQTT Discovery changed from a fixed sensor subset to dynamic discovery.
- Every standard OBD-II PID actually returned by the vehicle during LIVE DATA is automatically published as a Home Assistant entity.
- Unsupported/unavailable PIDs are not created as new Home Assistant entities.
- Legacy V1.5 fixed Discovery entities are cleared before dynamic discovery.
- Dynamic entities keep the HOMEBD device grouping and use units/device classes only where defined by the PID decoder.
- Updated third-party licence documentation to include the real MQTT Paho dependency.

## V1.5
- Added an in-app FAQ.
- FAQ documents the current OBD-II, MQTT, Tailscale and Android Auto development status.
- FAQ is intended to be updated with each relevant development release.
- Updated the in-app About/version text to 1.5.
- Kept MQTT CONNECT/DISCONNECT functionality from V1.4.

## V1.4
- MQTT LIGAR/DESLIGAR control.
- Long press on MQTT button opens MQTT configuration.
- Local/external MQTT configuration retained.
