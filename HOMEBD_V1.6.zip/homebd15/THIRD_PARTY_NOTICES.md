# HOMEBD — THIRD PARTY NOTICES

HOMEBD inclui componentes de terceiros. Os direitos e licenças desses componentes permanecem com os respetivos titulares.

## Eclipse Paho MQTT Java 1.2.5
- Maven/Gradle: `org.eclipse.paho:org.eclipse.paho.client.mqttv3:1.2.5`
- Utilização: cliente MQTT JVM/Android usado pelo HOMEBD.
- Projeto: Eclipse Paho / Eclipse Foundation.
- Licença: consultar os avisos/licença distribuídos com a versão 1.2.5 e a documentação oficial do projeto.

## Kotlin 2.0.21
Linguagem de programação utilizada no projeto. Aplicam-se os termos de licença do Kotlin/JetBrains.

## Android SDK / Android APIs
APIs da plataforma Android utilizadas pela aplicação. Aplicam-se os respetivos termos e licenças da plataforma.

## Android Gradle Plugin 8.7.3
Ferramenta de compilação Android configurada no projeto. Aplicam-se os respetivos termos/licença.

## Gradle
Sistema de compilação utilizado pelo projeto. Aplicam-se os respetivos termos/licença.

## Protocolos automóveis
OBD-II, CAN, ISO-TP e UDS são utilizados como referências/protocolos técnicos. A lógica de aplicação é própria e não incorpora openDBC nem bases CAN de terceiros.

## HOMEBD
Código original e materiais próprios: Copyright © 2026 lufime, salvo componentes de terceiros identificados acima.
