# HOMEBD — CHANGELOG


## V2.5
- Correção da sequência entre descoberta UDS e LIVE DATA.
- Restauração da sessão OBD-II antes do LIVE DATA.
- Limpeza de `ATCRA` antes da leitura.
- Configuração de cabeçalhos/pedido OBD-II para a sessão LIVE.
- Validação das respostas OBD antes da descodificação.
- Operação mantida em READ-ONLY.
- **Regra de documentação:** todas as alterações futuras devem ser registadas neste CHANGELOG, com a versão correspondente.

## V2.6
- Adicionado botão com ícone de olho no campo **Password MQTT**.
- Permite alternar entre password oculta e visível.
- O botão inclui descrição de acessibilidade para mostrar/ocultar a password.
- A password continua a ser guardada e utilizada pelo fluxo MQTT existente.
- Mantida a documentação obrigatória de cada alteração por versão.


## V2.7
- Atualizado o `README.md` com o estado atual do projeto e a alteração V2.6.
- Adicionado/atualizado `ABOUT.md` com a descrição da aplicação e a alteração V2.6.
- Mantida a regra de documentar todas as alterações por versão.

## V2.8
- Adicionado **Sobre / FAQ dentro da app**.
- Incluídas informações sobre o HOMEBD, READ-ONLY, OBD-II/CAN, MQTT, Home Assistant e HV/UDS.
- Incluída explicação do botão de olho da password MQTT.
- Mantida a documentação de alterações por versão.

## V2.9
- Definida a separação entre os contextos OBD-II LIVE e UDS/HV.
- Respostas `7F...` deixam de ser tratadas como valores OBD.
- Validação obrigatória de `41 + PID` antes da descodificação.
- RAW continua disponível para diagnóstico.
- Mantido READ-ONLY.

## V2.10
- Corrigido erro de compilação Kotlin no botão de mostrar/ocultar a password MQTT.
- Removida a referência inválida `isContentDescriptionEnabled`.
- Mantida a descrição de acessibilidade (`contentDescription`) e a funcionalidade do botão de olho.
- Mantido o funcionamento READ-ONLY e as restantes funções do projeto.

## V2.11
- Adicionada a especificação do modo Automático para identificação por VIN/protocolo.
- Definida identificação de marca, modelo e ano quando os dados estiverem disponíveis.
- Definido fallback **Não identificado** para dados não disponíveis.
- Definida arquitetura de perfis individuais por marca, sem grupos.
- Mantida a regra de cards full screen horizontal e centrados.
