# Sobre o HOMEBD

**HOMEBD**  
Diagnóstico OBD-II universal para veículos.

### Funcionalidades
- Bluetooth Classic / ELM327 compatível
- OBD-II e CAN em modo READ-ONLY
- LIVE DATA
- Diagnóstico RAW
- MQTT / integração com Home Assistant
- Descoberta HV/UDS exclusivamente READ-ONLY

### V2.6
Foi adicionado um botão de **olho** ao campo de password MQTT para alternar
entre password visível e oculta.

### Desenvolvimento
**Developer: Katios**

As alterações do projeto são documentadas por versão no `CHANGELOG.md`.


### V2.11
Identificação automática do veículo por dados OBD-II/VIN, com perfis individuais por marca e indicação de dados não identificados quando não estiverem disponíveis.
