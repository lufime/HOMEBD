# HOMEBD — Identificação Automática do Veículo

## Objetivo
Permitir que o modo Automático tente identificar o veículo sem obrigar o utilizador a escolher a marca manualmente.

## Fluxo
1. Ligação Bluetooth ao adaptador OBD-II.
2. Deteção do protocolo.
3. Tentativa de leitura do VIN.
4. Determinação da marca, modelo e ano a partir dos dados disponíveis.
5. Seleção do perfil individual da marca/veículo quando existir.
6. Seleção dos dados OBD-II, UDS e HV/BMS suportados.

## Regras
- Não inventar marca, modelo ou ano.
- Se um dado não estiver disponível: `Não identificado`.
- Cada marca possui perfil próprio.
- Não usar grupos de marcas.
- HV/BMS só deve ser ativado quando houver suporte confirmado.
- A comunicação permanece READ-ONLY.

## Interface
Os cards do painel devem permanecer em full screen horizontal, centrados e ocupando toda a largura disponível.
