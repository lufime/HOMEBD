# HOMEBD

**HOMEBD** é uma aplicação de diagnóstico OBD-II universal para veículos, com
comunicação Bluetooth Classic/SPP através de adaptadores ELM327 compatíveis.

## Estado atual

- OBD-II/CAN em modo **READ-ONLY**.
- LIVE DATA em tempo real.
- Diagnóstico e registo de respostas RAW para análise.
- Comunicação MQTT para integração com Home Assistant.
- Parser e estabilização ELM327/CAN em evolução.
- Descoberta HV/UDS mantida em modo READ-ONLY, sem DIDs proprietários assumidos.
- Interface preparada para utilização horizontal, em full screen e centrada.

## V2.6

- Campo **Password MQTT** com botão de olho.
- O botão permite mostrar ou ocultar a password.
- A alteração não modifica o armazenamento nem o funcionamento da ligação MQTT.
- Todas as alterações do projeto são registadas por versão no CHANGELOG.

## Documentação

Consulte `CHANGELOG.md` para o histórico das alterações e
`DOCUMENTACAO_ALTERACOES.md` para a regra de documentação por versão.

## Licenciamento e terceiros

Consultar os ficheiros de licença/NOTICE existentes no projeto. Não assumir que
a menção a um protocolo, plataforma ou serviço concede direitos sobre marcas,
logótipos ou código de terceiros.

## Desenvolvimento

**Developer: Katios**

## V2.8
A aplicação inclui agora a secção **Sobre / FAQ** diretamente na interface.

## V2.9
Separação documentada entre LIVE DATA OBD-II e descoberta UDS/HV.


## V2.10

Correção de compilação do botão de password MQTT. A referência Kotlin inválida foi removida sem alterar a funcionalidade de mostrar/ocultar a password.

## V2.11 — Identificação automática do veículo

- O modo **Automático** é a opção inicial de identificação.
- Fluxo previsto: Bluetooth → OBD-II → protocolo → VIN → marca/modelo/ano → perfil específico.
- Quando a identificação for possível, o HOMEBD deverá apresentar marca, modelo e ano obtidos dos dados disponíveis.
- Quando algum dado não estiver disponível, deverá ser apresentado como **Não identificado**, sem inventar informação.
- Após a identificação, o perfil específico poderá selecionar os dados OBD/UDS/HV compatíveis com o veículo.
- A identificação HV/BMS permanece dependente de suporte confirmado para o veículo/ECU.
- Perfis de marcas são individuais; não são usados grupos de marcas.
- Mantida a regra de interface: cards em full screen horizontal, centrados e ocupando toda a largura disponível.
