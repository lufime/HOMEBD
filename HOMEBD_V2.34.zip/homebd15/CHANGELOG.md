# V2.33
- Corrigida falha de compilação em `HomeBdRestBridge.kt`.
- Corrigido `postAsync()` para usar sintaxe Kotlin válida.
- REST continua protegido contra exceções e não deve encerrar a app.

# HOMEBD V2.5

- Restaura sessão OBD-II funcional antes do LIVE DATA.
- Limpa ATCRA e usa ATSH7DF para pedidos standard.
- Reaplica o protocolo CAN detetado após verificações UDS/Mode 09.
- Identifica respostas negativas separadamente.
- Protocolo 6: ISO 15765-4 CAN 11-bit / 500 kbit/s.

# HOMEBD — Changelog

## V2.2
- Melhorada a estabilização automática do transporte CAN quando o ELM327 reporta protocolo `AUTO/0`.
- Testados os protocolos CAN standard 6, 7, 8 e 9 através de uma consulta OBD-II `0100` de leitura.
- Descoberta de ECUs físicas ampliada para `7E0–7EF` antes da pesquisa UDS.
- Pesquisa UDS READ-ONLY ampliada para `F180–F1FF`.
- Respostas positivas `0x62` continuam apresentadas apenas em RAW hexadecimal; não são convertidas em SOC, tensão, corrente, kW ou kWh sem definição verificável.
- Mantidos os limites: sem SecurityAccess, escrita, coding ou programação.
- MQTT, LIVE DATA e restantes funções existentes mantidos.
- Interface horizontal em ecrã completo, centrada e ocupando toda a largura disponível.

# HOMEBD — Changelog

## V2.1
- Atualizado o autor do projeto para **Katios**.
- Expandido o SCAN HV/UDS READ-ONLY para a janela de DIDs **F180–F1FF**.
- Respostas UDS positivas continuam apresentadas em RAW hexadecimal, sem assumir que um DID corresponde a SOC, tensão, corrente, kW ou kWh.
- Respostas negativas UDS `7F 22 xx` passam a ser identificadas separadamente no log.
- Mantidos os limites de segurança: sem SecurityAccess, escrita, coding ou programação.
- Preparado para testar se o veículo expõe algum identificador adicional que possa posteriormente ser mapeado com evidência.


## V2.0
- Adicionado **SCAN HV/UDS** experimental e READ-ONLY para procurar respostas UDS em ECUs CAN.
- A pesquisa usa apenas o serviço UDS `0x22 ReadDataByIdentifier`; não envia SecurityAccess, escrita, coding ou programação.
- Janela inicial conservadora de DIDs `F180–F19F` nos IDs físicos `7E0–7E7`.
- Respostas positivas são apresentadas como **RAW hexadecimal**, sem inventar escalas de bateria ou converter dados desconhecidos em kW/kWh.
- Preparado para identificar posteriormente dados HV reais quando houver uma definição verificável do DID/ECU.
- Mantida a publicação MQTT dinâmica e as ligações Home Assistant local/externa.
- Versão da aplicação atualizada para 2.0.


## V1.9
- Otimização da atualização MQTT para LIVE DATA com menor latência.
- Aumentado o limite de mensagens MQTT em trânsito (`maxInflight=100`).
- Valores LIVE deixam de usar `retain`, reduzindo escrita e processamento desnecessários no broker.
- HOMEBD publica um valor LIVE apenas quando o payload desse sensor muda.
- Discovery e estado online/offline continuam retidos.
- Mantida a leitura OBD contínua e a publicação dinâmica dos PIDs suportados.

# HOMEBD — Changelog

## V1.8
- Home Assistant sem endereço predefinido.
- Configuração independente para **acesso local** e **acesso externo**.
- Se ambos estiverem configurados, o botão permite escolher Local ou Externo.
- Se apenas um estiver configurado, o botão abre diretamente esse acesso.
- Se nenhum estiver configurado, o botão abre a configuração.
- Removido o endereço Tailscale previamente predefinido.
- Barra superior compacta com o **ícone da app à esquerda**, libertando espaço vertical.
- Atualizada a versão da aplicação para 1.8.

# HOMEBD — Changelog

## V1.7
- Added a dedicated **ABRIR HOME ASSISTANT** button.
- Opens the configured Home Assistant web interface using Android browser handling.
- Default Home Assistant URL is the configured Tailscale address `http://100.92.242.12:8123`; the user can change it.
- Long press on the Home Assistant button opens the URL configuration dialog.
- Clarifies that port 8123 is the Home Assistant web interface port, not MQTT.

## V1.6
- Home Assistant MQTT Discovery changed from a fixed sensor subset to dynamic discovery.
- Every standard OBD-II PID actually returned by the vehicle during LIVE DATA is automatically published as a Home Assistant entity.
- Unsupported/unavailable PIDs are not created as new Home Assistant entities.
- Legacy V1.5 fixed Discovery entities are cleared before dynamic discovery.
- Dynamic entities keep the HOMEBD device grouping and use units/device classes only where defined by the PID decoder.

## V1.5
- Added an in-app FAQ.
- FAQ documents the current OBD-II, MQTT, Tailscale and Android Auto development status.
- FAQ is intended to be updated with each relevant development release.
- Updated the in-app About/version text to 1.5.
- Kept MQTT CONNECT/DISCONNECT functionality from V1.4.

## V1.4
- MQTT LIGAR/DESLIGAR control.
- Long press on MQTT button opens MQTT configuration.
- Local/external MQTT configuration retained.
## V2.6
- Adicionado botão com ícone de olho no campo **Password MQTT**.
- Permite alternar entre password oculta e visível.
- O botão inclui descrição de acessibilidade para mostrar/ocultar a password.
- A password continua a ser guardada e utilizada pelo fluxo MQTT existente.
- Mantida a documentação obrigatória de cada alteração por versão.

