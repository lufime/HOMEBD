# HOMEBD — AUDITORIA DE LICENÇAS

## Resultado

Foi feita uma inspeção do conteúdo distribuído neste projeto.

### Código de terceiros incorporado

Não foram encontradas bibliotecas de OBD/CAN de terceiros incorporadas no projeto.

O ficheiro `app/build.gradle.kts` não declara dependências `implementation(...)` ou `api(...)` de bibliotecas externas.

Não foi encontrado:
- openDBC / opendbc
- base CAN de terceiros
- código GPL/LGPL/MIT/Apache/BSD/MPL copiado para o projeto
- ficheiros de licença de terceiros incorporados no código-fonte
- mapas CAN proprietários de fabricantes

### Ferramentas de desenvolvimento

O projeto utiliza Kotlin, Android Gradle Plugin e Gradle como ferramentas de compilação. Estas são ferramentas externas do ambiente de desenvolvimento e não representam código de uma biblioteca OBD/CAN incorporado na aplicação.

As respetivas licenças continuam a aplicar-se às próprias ferramentas.

### Recursos gráficos

Foram inspecionados os dois PNG distribuídos pela aplicação:
- `homebd_header.png`
- `homebd_icon.png`

Não contêm metadados de copyright/licença incorporados no ficheiro.

Esta inspeção não consegue provar a autoria original de uma imagem apenas através do PNG. A origem/autoria dos recursos gráficos deve ser mantida documentada pelo proprietário do projeto.

### Código HOMEBD

O código Kotlin e a lógica OBD-II presentes neste pacote são tratados como código próprio do projeto.

O projeto não utiliza openDBC nem copia bases CAN de terceiros.

### Limitação da auditoria

Esta é uma auditoria técnica do conteúdo do pacote. Não constitui uma auditoria jurídica da cadeia de autoria de cada linha de código, imagem ou recurso criado fora deste pacote.

## Política do projeto

HOMEBD deve continuar sem incorporar:
- código de terceiros sem licença compatível;
- bases CAN proprietárias;
- dados copiados de openDBC;
- mapas CAN obtidos de projetos de terceiros sem autorização.

Para dados específicos de fabricantes, usar apenas informação que possa ser utilizada legalmente e manter a origem/documentação registada.
