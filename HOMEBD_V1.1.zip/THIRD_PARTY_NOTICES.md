# HOMEBD — THIRD PARTY NOTICES

## Open-source and external components

HOMEBD uses standard development technologies and platform APIs. Any applicable licences remain with their respective authors/projects.

### Development technologies

- Kotlin — open-source programming language; applicable Kotlin/JetBrains licence terms.
- Android SDK / Android APIs — Android platform components; applicable Android and Google terms.
- Gradle — build system; applicable Gradle licence terms.
- Android Gradle Plugin — build tooling; applicable Android/Google open-source licence terms.

## Automotive standards and protocols

HOMEBD implements its own application logic for standard automotive diagnostic protocols and interfaces, including OBD-II, CAN, ISO-TP and UDS where applicable.

These references describe technical standards/protocols and are not incorporated as third-party software libraries.

## External CAN databases

**Not used.**

## Manufacturer proprietary databases

**Not incorporated.**

Manufacturer-specific information is only used where its use is permitted and technically documented.

## HOMEBD

HOMEBD application code and original project materials are Copyright © 2026 lufime, except for third-party components and platform technologies subject to their respective terms.

This notice is a technical project notice and is not legal advice.
