# HOMEBD

**Home Onboard Monitoring Engine Board Data**

Universal Android OBD-II diagnostic application.

## BETA VERSION 1.0

- Bluetooth Classic / BLE / ELM327 device discovery and OBD-II connection.
- Generic OBD-II live data and diagnostic scanning.
- Manufacturer profiles with a conservative read-only layer.
- CAN / ISO-TP support through the ELM327 transport where available.
- UDS `0x22 ReadDataByIdentifier` only where a profile has a documented standard identifier configured.
- VIN via standard OBD-II Mode 09 PID 02 and/or UDS `F190` where supported.
- No ECU writing, coding, adaptation, programming or security-access operations.
- No openDBC database or third-party CAN database is used.
- The GitHub Actions workflow is intentionally **not included** in this ZIP.

## Manufacturer profiles

### Stellantis
Includes the Stellantis family represented in the app, including:
- Citroën
- Peugeot
- DS Automobiles
- Opel
- Vauxhall
- Fiat
- Jeep
- Alfa Romeo
- Lancia
- Abarth
- Chrysler
- Dodge
- RAM
- Maserati

Opel and Vauxhall are part of the same Stellantis profile and are not separate profiles in the selector.

The profile uses standard OBD-II data plus the controlled UDS read-only identification layer configured in the application. It does not bypass Secure Gateway protections.

### Renault / Dacia
Standard OBD-II plus documented standard UDS identification reads configured in the application.

### Volkswagen / Audi / SEAT / Škoda
Standard OBD-II plus documented standard UDS identification reads configured in the application.

### BMW
Standard OBD-II plus conservative standard UDS VIN identification when supported by the connected transport. No proprietary BMW CAN map is included.

### Mercedes-Benz
Standard OBD-II plus conservative standard UDS VIN identification when supported. No proprietary Mercedes-Benz CAN map is included.

### Ford
Standard OBD-II plus controlled UDS read-only identification reads configured in the application.

### Toyota
Standard OBD-II profile. Manufacturer-specific data is not guessed.

### Lexus
Separate profile from Toyota. Standard OBD-II plus conservative standard UDS VIN identification when supported.

### Honda / Acura
Standard OBD-II plus conservative standard UDS VIN identification when supported. No proprietary request map is included.

### Hyundai / Kia
Standard OBD-II plus conservative standard UDS VIN identification when supported. No proprietary request map is included.

### Nissan / INFINITI
Standard OBD-II plus controlled UDS read-only identification reads configured in the application.

### Volvo
Standard OBD-II plus conservative standard UDS VIN identification when supported. No proprietary Volvo CAN map is included.

### Tesla
Conservative OBD-II/CAN profile. UDS `F190` may be attempted through the current ELM327/CAN transport. Some Tesla diagnostic architectures require DoIP/Ethernet, which is not provided by a classic Bluetooth ELM327 adapter.

### Mazda
Standard OBD-II read-only profile. No unverified proprietary Mazda DID/CAN map is included.

### Subaru
Standard OBD-II plus conservative UDS VIN identification when supported. No proprietary Subaru DID/request map is included.

### Mitsubishi
Standard OBD-II plus conservative UDS VIN identification when supported. No proprietary Mitsubishi DID/request map is included.

### Jaguar / Land Rover
Standard OBD-II plus conservative UDS VIN identification when supported. Some vehicle generations may require diagnostic interfaces such as DoIP; the app does not claim universal access through ELM327.

### Porsche
Standard OBD-II plus conservative UDS VIN identification when supported. No proprietary Porsche CAN map is included.

### Suzuki
Standard OBD-II plus conservative UDS VIN identification when supported. No proprietary Suzuki CAN map is included.

### Isuzu
Standard OBD-II plus conservative UDS VIN identification when supported. No proprietary Isuzu CAN map is included.

### Geely / Polestar
Standard OBD-II plus conservative UDS VIN identification when supported. No proprietary Geely/Polestar CAN map is included.

### Outros
Generic OBD-II fallback for vehicles that do not match a manufacturer profile.

## READ-ONLY safety model

HOMEBD is intentionally restricted to diagnostic reading. The application does not send ECU control or programming services such as:

- `0x27 SecurityAccess`
- `0x2E WriteDataByIdentifier`
- `0x2F InputOutputControlByIdentifier`
- `0x31 RoutineControl`
- ECU flashing/programming commands

No gateway bypass is implemented.

## Important compatibility note

A manufacturer profile does not guarantee access to every ECU or every proprietary parameter on every model/year. ECU addressing, gateway architecture, transport (CAN/ISO-TP/DoIP), diagnostic session and supported identifiers vary by vehicle. When a requested identifier is not supported, HOMEBD reports it as unavailable instead of guessing.

## Credits

- Developer: **lufime**
- Platform: Android
- Diagnostics: OBD-II
- Version: **BETA VERSION 1.0**


## OBD-II standard catalogue
All manufacturer profiles use the same standards-based Mode 01 PID catalogue and first query the vehicle's supported-PID bitmaps before requesting individual PIDs. The application does not copy manufacturer CAN databases, proprietary source code, or third-party licensed mappings. Manufacturer-specific UDS is kept separate and is only used where explicitly documented in the project.

The application is read-only: it does not perform ECU coding, programming, parameter writing, SecurityAccess, or gateway bypass.

## HOMEBD — Funcionalidades desenvolvidas

- Aplicação Android para diagnóstico OBD-II.
- Ligação a adaptadores OBD-II através de Bluetooth.
- Deteção e seleção de dispositivos Bluetooth emparelhados.
- Comunicação com interfaces compatíveis com ELM327.
- Deteção automática do protocolo OBD-II.
- Identificação dos PIDs suportados pelo veículo.
- Leitura dinâmica e conversão dos parâmetros.
- Live Data em tempo real.
- Leitura de DTCs quando suportada.
- Leitura de VIN quando disponível.
- CAN / ISO-TP / UDS quando suportado.
- Perfis específicos de fabricantes.
- Operação 100% READ-ONLY.

### Nota de desenvolvimento

O HOMEBD foi desenvolvido de raiz, com arquitetura, funcionalidades e soluções técnicas concebidas especificamente para este projeto e desenvolvidas para a própria aplicação.



## MQTT — Home Assistant

HOMEBD can publish its read-only OBD-II Live Data directly to a local MQTT broker.

- Broker URI is configured in the app, for example `tcp://192.168.1.10:1883`.
- Optional MQTT username/password.
- Default base topic: `homebd/live`.
- Live PID topics: `homebd/live/<pid>`.
- Human-readable text: `homebd/live/<pid>/text`.
- Aggregate payload: `homebd/live/all`.
- Availability: `homebd/live/status` (`online` / `offline`).
- Home Assistant MQTT Discovery is published automatically under `homeassistant/sensor/homebd/...`.
- No REST API or cloud service is required.
- PIDs reported by the ECU as unavailable are published with a null numeric value and their original text, rather than being converted to zero.
