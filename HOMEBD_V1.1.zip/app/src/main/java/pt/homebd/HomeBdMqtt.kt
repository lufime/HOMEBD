
package pt.homebd

import android.content.Context
import android.os.Build
import android.util.Log
import org.eclipse.paho.client.mqttv3.*
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale

/**
 * HOMEBD MQTT bridge.
 *
 * Publishes read-only OBD live data to Home Assistant through MQTT.
 * No cloud/API dependency is used.
 */
class HomeBdMqtt(private val context: Context) {
    private var client: MqttAsyncClient? = null
    var connected: Boolean = false
        private set

    var brokerUri: String = ""
    var username: String = ""
    var password: String = ""
    var baseTopic: String = "homebd/live"

    private val prefs = context.getSharedPreferences("homebd_mqtt", Context.MODE_PRIVATE)

    init { load() }

    private fun load() {
        brokerUri = prefs.getString("broker", "") ?: ""
        username = prefs.getString("username", "") ?: ""
        password = prefs.getString("password", "") ?: ""
        baseTopic = prefs.getString("baseTopic", "homebd/live") ?: "homebd/live"
    }

    fun save(broker: String, user: String, pass: String, topic: String) {
        brokerUri = broker.trim()
        username = user
        password = pass
        baseTopic = topic.trim().trim('/').ifBlank { "homebd/live" }
        prefs.edit()
            .putString("broker", brokerUri)
            .putString("username", username)
            .putString("password", password)
            .putString("baseTopic", baseTopic)
            .apply()
    }

    fun connect(onResult: (Boolean, String) -> Unit) {
        if (connected) {
            onResult(true, "MQTT já ligado")
            return
        }
        if (brokerUri.isBlank()) {
            onResult(false, "Configure o broker MQTT")
            return
        }
        Thread {
            try {
                val id = "HOMEBD-${Build.MODEL.replace(Regex("[^A-Za-z0-9_-]"), "")}-${System.currentTimeMillis() % 100000}"
                val c = MqttAsyncClient(brokerUri, id, MemoryPersistence())
                client = c
                val opts = MqttConnectOptions().apply {
                    isAutomaticReconnect = true
                    isCleanSession = true
                    connectionTimeout = 8
                    keepAliveInterval = 20
                    if (username.isNotBlank()) {
                        userName = username
                        password = this@HomeBdMqtt.password.toCharArray()
                    }
                }
                c.connect(opts).waitForCompletion(8000)
                connected = true
                publishAvailability(true)
                publishDiscovery()
                onResult(true, "MQTT ligado: $brokerUri")
            } catch (e: Exception) {
                connected = false
                onResult(false, "MQTT: ${e.message ?: "erro de ligação"}")
            }
        }.start()
    }

    fun disconnect() {
        try {
            if (connected) publishAvailability(false)
            client?.disconnect()?.waitForCompletion(3000)
        } catch (_: Exception) {}
        connected = false
        client = null
    }

    fun publishPid(pid: String, label: String, result: String) {
        if (!connected) return
        val key = pid.lowercase(Locale.US)
        val obj = JSONObject()
        val numeric = parseNumeric(result)
        if (numeric == null) obj.put("value", JSONObject.NULL) else obj.put("value", numeric)
        obj.put("text", result)
        obj.put("pid", pid)
        obj.put("label", label)
        obj.put("available", !result.contains("NO DATA", true) && !result.contains("N/D", true))
        publish("$baseTopic/$key", obj.toString(), false)
        publish("$baseTopic/$key/text", result, false)
    }

    fun publishAggregate(values: List<Pair<String, String>>) {
        if (!connected) return
        val root = JSONObject()
        values.forEach { (pid, value) -> root.put(pid.lowercase(Locale.US), value) }
        publish("$baseTopic/all", root.toString(), false)
    }

    private fun publishAvailability(available: Boolean) {
        publish("$baseTopic/status", if (available) "online" else "offline", true)
    }

    private fun publish(topic: String, payload: String, retained: Boolean) {
        try {
            val msg = MqttMessage(payload.toByteArray(Charsets.UTF_8)).apply {
                qos = 0
                isRetained = retained
            }
            client?.publish(topic, msg)
        } catch (e: Exception) {
            Log.w("HOMEBD_MQTT", "publish failed: ${e.message}")
        }
    }

    private fun parseNumeric(text: String): Double? {
        if (text.contains("NO DATA", true) || text.contains("N/D", true) ||
            text.contains("multi-byte", true) || text.contains("Dados insuficientes", true) ||
            text == "—") return null
        val m = Regex("""[-+]?\d+(?:[.,]\d+)?""").find(text) ?: return null
        return m.value.replace(",", ".").toDoubleOrNull()
    }

    private fun publishDiscovery() {
        val defs = listOf(
            Triple("010C","rpm","rpm"),
            Triple("010D","speed","km/h"),
            Triple("0105","coolant_temperature","°C"),
            Triple("010F","intake_air_temperature","°C"),
            Triple("0104","engine_load","%"),
            Triple("010B","map","kPa"),
            Triple("0110","maf","g/s"),
            Triple("0106","stft","%"),
            Triple("0107","ltft","%"),
            Triple("010E","ignition_timing","°"),
            Triple("0142","control_module_voltage","V"),
            Triple("015E","fuel_rate","L/h"),
            Triple("0133","barometric_pressure","kPa"),
            Triple("0123","fuel_rail_pressure","kPa"),
            Triple("0111","throttle_position","%"),
            Triple("0145","absolute_throttle_position_b","%"),
            Triple("014A","accelerator_pedal_position_d","%"),
            Triple("014B","accelerator_pedal_position_e","%"),
            Triple("014C","commanded_throttle_actuator","%"),
            Triple("0134","lambda","ratio")
        )
        defs.forEach { (pid, key, unit) ->
            val payload = JSONObject()
                .put("name", "HOMEBD ${key.replace('_',' ').replaceFirstChar { it.uppercase() }}")
                .put("unique_id", "homebd_$key")
                .put("state_topic", "$baseTopic/${pid.lowercase(Locale.US)}")
                .put("value_template", "{{ value_json.value if value_json.value is not none else 'unknown' }}")
                .put("availability_topic", "$baseTopic/status")
                .put("payload_available", "online")
                .put("payload_not_available", "offline")
                .put("device_class", deviceClass(key))
                .put("unit_of_measurement", unit)
                .put("state_class", "measurement")
                .put("device", JSONObject()
                    .put("identifiers", org.json.JSONArray().put("homebd"))
                    .put("name", "HOMEBD")
                    .put("manufacturer", "lufime")
                    .put("model", "HOMEBD OBD-II"))
            publish("homeassistant/sensor/homebd/$key/config", payload.toString(), true)
        }

        val dtc = JSONObject()
            .put("name", "HOMEBD DTC")
            .put("unique_id", "homebd_dtc")
            .put("state_topic", "$baseTopic/0101")
            .put("value_template", "{{ value_json.text }}")
            .put("availability_topic", "$baseTopic/status")
            .put("payload_available", "online")
            .put("payload_not_available", "offline")
            .put("device", JSONObject().put("identifiers", org.json.JSONArray().put("homebd")).put("name","HOMEBD").put("manufacturer","lufime").put("model","HOMEBD OBD-II"))
        publish("homeassistant/sensor/homebd/dtc/config", dtc.toString(), true)
    }

    private fun deviceClass(key: String): String {
        return when (key) {
            "coolant_temperature","intake_air_temperature" -> "temperature"
            "control_module_voltage" -> "voltage"
            "speed" -> "speed"
            else -> ""
        }
    }
}
