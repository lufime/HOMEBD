# HOMEBD MQTT integration

Version 1.1 adds local MQTT publishing for read-only OBD-II Live Data.

## App
Open **MQTT**, enter the broker URI (for example `tcp://192.168.1.10:1883`) and optional credentials, then connect.

Default topic: `homebd/live`

## Home Assistant
MQTT Discovery is published automatically. Sensors appear under device **HOMEBD** after MQTT connection.

No REST API, cloud service, or OpenDBC data is used.
