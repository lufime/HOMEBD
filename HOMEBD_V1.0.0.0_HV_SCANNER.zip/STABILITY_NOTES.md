# HOMEBD — Stability notes

The current stability target is:

1. Bluetooth Classic/SPP is the active OBD transport.
2. If the Bluetooth socket reports Broken pipe / closed socket / reset:
   - stop LIVE DATA immediately;
   - do not write another OBD command to that socket;
   - reconnect and reinitialize before resuming.
3. Home Assistant uses WebSocket only.
4. WebSocket reconnection uses backoff (2, 5, 10, 30, 60 seconds) and must have one active reconnect loop.
5. DNS failures are treated as network failures, not as reasons to spin in a tight loop.
6. OBD scan/discovery runs once per connection session unless the user explicitly presses RESCAN.
7. VIN candidates are validated before being exposed as the vehicle VIN.
