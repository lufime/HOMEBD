## Foreground Service — estabilidade de sessão
- Serviço `HomeBdForegroundService` ativo apenas durante a sessão OBD.
- `foregroundServiceType="connectedDevice"` para a ligação Bluetooth/OBD.
- Notificação persistente HOMEBD enquanto o Live Data está ativo.
- Pedido da permissão de notificações em Android 13+.
- Serviço `START_NOT_STICKY` para não ressuscitar sessões OBD antigas.
- Paragem do serviço no encerramento da ligação OBD.

# HOMEBD V1.0.0.0 — Stability update

## Correções
- LIVE DATA interrompe o envio quando o socket Bluetooth/ELM327 fica inválido.
- Evita continuar a enviar `0104` depois de `Broken pipe`.
- Preparada reconexão Home Assistant com backoff: 2s, 5s, 10s, 30s, 60s.
- Evita múltiplos ciclos de reconexão WebSocket em paralelo.
- VIN só deve ser aceite após validação rigorosa; payload CAN arbitrário não é tratado automaticamente como VIN.
- LIVE DATA não deve iniciar novamente SCAN/DISCOVERY automaticamente.
- Bluetooth Classic/SPP continua a ser o transporte principal quando BLE não disponibiliza serviço OBD/UART.


## V1.0.0.0 — Background OBD session
- Added Android Foreground Service for active OBD-II sessions.
- Keeps HOMEBD running when the Activity is moved to the background or the screen is locked.
- Persistent low-priority notification: `HOMEBD · OBD-II · Live Data ativo`.
- Service uses Android `connectedDevice` foreground-service type.
- Service starts only after successful OBD/CAN initialization and stops when the OBD transport is closed.
- Home Assistant remains WebSocket-only; no REST or MQTT added.


## UI refinement — independent panels
- Removed the global dashboard scroll.
- LIVE DATA and DIAGNOSTICS now use independent finger scrolling inside their own panels.
- Simplified the OBD-II status area to avoid clipped text.
- Compact Home Assistant WebSocket status row to reduce vertical space.
- Four main action buttons keep the same dimensions and formatting.
- Reduced fixed UI space so the two data panels receive the remaining screen area.

- LIVE DATA e DIAGNOSTICS usam agora um scroll interno com transferência do gesto para o painel principal apenas quando atingem o topo/fundo.
# HOMEBD — Beta 1.0.0.0

## Correção de compilação
- Corrigido o conflito entre a variável local `background` (cor `Int`) e a propriedade `View.background` (`Drawable`) no `MainActivity.kt`.
- Cartões, Spinners e elementos gráficos passam a atribuir corretamente `GradientDrawable` à propriedade da View.
- A área LIVE DATA usa `setBackgroundColor()` para a cor de fundo.
- Mantido o layout vertical com LIVE DATA e DIAGNOSTICS em scroll independente.

# HOMEBD — CHANGELOG

## Beta 1.0.0.0

Initial public beta baseline.

### Application
- HOMEBD universal OBD-II / CAN diagnostics application.
- Portrait dashboard with centered, full-width cards.
- LIVE DATA with its own vertical scroll area.
- DIAGNOSTICS with an independent vertical scroll area.
- Bluetooth OBD-II device selection.
- Automatic vehicle profile.
- OBD-II PID scanning.
- HV / UDS scan area.
- Home Assistant connection and configuration.

### Home Assistant
- Native HOMEBD custom integration.
- WebSocket communication.
- HOMEBD entities use the `sensor.homebd_*` namespace.
- REST transport is not part of the project architecture.

### Safety
- READ-ONLY diagnostic operation.
- No coding, programming, reset or parameter-writing functions.

### Project
- Developer: **lufime**
- Copyright © 2026 lufime.
- Beta version: **1.0.0.0**
## UI refinement — HOMEBD Beta 1.0.0.0
- Removed the duplicate Home Assistant configuration button from the status card.
- Removed the HOMEBD title text from the header; the logo remains the identifier.
- Connection indicator now uses light green for connected, light pink for disconnected and red for errors.
- LIVE DATA and DIAGNOSTICS capture touch gestures inside their own panels so the finger scrolls the panel content instead of the whole page.
- Unified the four main action buttons with the same typography, padding, corner radius and border treatment.
- Reduced visual density and improved LIVE DATA / DIAGNOSTICS readability.



## Foreground build fix
- Corrigidas chamadas do Foreground Service para aceitar `Context`.
- Corrigida string Kotlin multilinha que impedia a compilação.

## Foreground Notifications
- Added Android 13+ POST_NOTIFICATIONS declaration/check support.
- Added notification-settings helper for HOMEBD when notifications are blocked.
- Foreground Service remains dedicated to the active OBD session.

## HV/BMS READ-ONLY scanner
- Added conservative UDS DID discovery for candidate HV/BMS ECUs.
- No write/programming/security/routine commands.
