# HOMEBD — HV/BMS READ-ONLY

Scanner de descoberta UDS exclusivamente de leitura.

Candidatos CAN: 7E0–7E7.
Serviço: `22` ReadDataByIdentifier.
DIDs candidatos iniciais: `DA02`, `FD73`.

Não envia SecurityAccess (27), WriteData (2E), RoutineControl (31),
reset, coding, programming ou comandos de atuação.

As respostas devem ser validadas antes de criar sensores de SOC,
tensão, corrente ou temperatura. Os DIDs são candidatos de descoberta,
não uma afirmação de que são oficiais do C5 Aircross Hybrid.
