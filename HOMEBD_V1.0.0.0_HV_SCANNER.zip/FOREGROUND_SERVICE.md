# HOMEBD — Foreground Service

A sessão OBD inicia `HomeBdForegroundService` depois de Bluetooth Classic/ELM327 e CAN/OBD estarem inicializados.

Enquanto a sessão está ativa:
- Android trata o HOMEBD como foreground service.
- A notificação mostra `HOMEBD · OBD-II · Live Data ativo`.
- O serviço usa o tipo `connectedDevice`.
- Ao desligar o OBD, `MainActivity` chama `HomeBdForegroundService.stop(...)`.
- O serviço usa `START_NOT_STICKY`, evitando reabrir automaticamente uma sessão OBD antiga após uma morte do processo.

O serviço protege a execução em segundo plano; a lógica de transporte Bluetooth/ELM327 e Live Data continua no código existente da aplicação.
