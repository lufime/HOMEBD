# GitHub Actions — HOMEBD

Corrigido para o estado real do projeto.

- O projeto não inclui `gradlew`.
- O workflow instala Gradle 8.13 através de `gradle/actions/setup-gradle@v4`.
- Compila diretamente com `gradle assembleDebug`.
- Corrige o erro de sintaxe no `HomeBdForegroundService.kt`: o `package` passa a ser a primeira declaração.
- O APK debug é publicado como artifact `HOMEBD-debug`.

O erro anterior de Kotlin estava em `HomeBdForegroundService.kt` linha 4:
`imports are only allowed in the beginning of file`.
