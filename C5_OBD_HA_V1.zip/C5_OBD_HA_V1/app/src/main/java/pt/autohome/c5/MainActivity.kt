package pt.autohome.c5

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.*
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private lateinit var status: TextView
    private lateinit var log: TextView

    private val pids = linkedMapOf(
        "0100" to "Supported PIDs 01-20",
        "0104" to "Engine load",
        "0105" to "Coolant temperature",
        "010B" to "MAP pressure",
        "010C" to "RPM",
        "010D" to "Vehicle speed",
        "010F" to "Intake air temperature",
        "0110" to "MAF",
        "0111" to "Throttle position",
        "012F" to "Fuel level",
        "0142" to "Control module voltage",
        "0146" to "Ambient temperature",
        "015E" to "Engine fuel rate"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 18, 28, 18)
        }

        val title = TextView(this).apply {
            text = "C5 AIRCROSS HYBRID  •  OBD DIAGNÓSTICO V1"
            textSize = 22f
        }
        status = TextView(this).apply { text = "Estado: desligado"; textSize = 17f }
        log = TextView(this).apply { textSize = 14f; isVerticalScrollBarEnabled = true }

        val devices = Spinner(this)
        val connect = Button(this).apply { text = "LIGAR OBDII" }
        val scan = Button(this).apply { text = "SCAN PIDs" }

        root.addView(title)
        root.addView(status)
        root.addView(devices, LinearLayout.LayoutParams(-1, 0, 1f))
        val buttons = LinearLayout(this).apply {
            addView(connect, LinearLayout.LayoutParams(0, -2, 1f))
            addView(scan, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(buttons)
        root.addView(log, LinearLayout.LayoutParams(-1, 0, 3f))
        setContentView(root)

        requestBtPermissions()
        val adapter = BluetoothAdapter.getDefaultAdapter()
        val paired = try { adapter.bondedDevices.toList() } catch (_: SecurityException) { emptyList() }
        val names = paired.map { "${it.name ?: "Sem nome"}  (${it.address})" }
        devices.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)

        connect.setOnClickListener {
            val d = paired.getOrNull(devices.selectedItemPosition)
            if (d != null) connect(d) else append("Nenhum dispositivo emparelhado.")
        }
        scan.setOnClickListener { runScanner() }
    }

    private fun requestBtPermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT), 10)
        }
    }

    private fun connect(device: BluetoothDevice) {
        thread {
            try {
                runOnUiThread { status.text = "Estado: a ligar a ${device.name ?: device.address}…" }
                socket?.close()
                socket = device.createRfcommSocketToServiceRecord(spp)
                socket!!.connect()
                input = socket!!.inputStream
                output = socket!!.outputStream
                elm("ATZ")
                elm("ATE0")
                elm("ATL0")
                elm("ATS0")
                elm("ATSP0")
                runOnUiThread { status.text = "Estado: LIGADO • ELM327 pronto" }
                append("ELM327 inicializado. Protocolo automático.")
            } catch (e: Exception) {
                runOnUiThread { status.text = "Estado: erro de ligação" }
                append("ERRO: ${e.message}")
            }
        }
    }

    private fun elm(cmd: String, timeout: Long = 2500): String {
        val out = output ?: return ""
        val ins = input ?: return ""
        out.write((cmd + "\r").toByteArray())
        out.flush()
        val start = System.currentTimeMillis()
        val buf = ByteArray(4096)
        val data = StringBuilder()
        while (System.currentTimeMillis() - start < timeout) {
            if (ins.available() > 0) {
                val n = ins.read(buf)
                if (n > 0) data.append(String(buf, 0, n))
                if (data.contains(">")) break
            } else Thread.sleep(30)
        }
        return data.toString().replace("\r", "\n").trim()
    }

    private fun runScanner() {
        thread {
            if (output == null) {
                append("Liga primeiro ao OBDII.")
                return@thread
            }
            append("=== SCAN OBD-II ===")
            pids.forEach { (pid, label) ->
                val r = elm(pid, 1800)
                val ok = r.isNotBlank() && !r.contains("NO DATA", true) && !r.contains("ERROR", true)
                append("${if (ok) "✓" else "·"} $pid  $label  → ${r.replace("\n", " ")}")
            }
            append("=== FIM OBD-II ===")
            append("Próxima fase: PIDs PSA/Stellantis HEV/PHEV e envio HA.")
        }
    }

    private fun append(s: String) {
        runOnUiThread { log.append("\n$s") }
    }

    override fun onDestroy() {
        try { socket?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
