# C5 OBD Home Assistant V1

Primeira base Android para o projeto:
- Bluetooth Classic / SPP para ELM327
- seleção de dispositivos emparelhados
- inicialização ELM327
- scanner de PIDs OBD-II
- orientação horizontal e ecrã imersivo
- preparada para a próxima fase: PIDs PSA/Stellantis HEV/PHEV + Home Assistant em tempo real

Nota: esta V1 é código-fonte de teste; ainda não inclui os PIDs proprietários do C5 nem a publicação automática de entidades no Home Assistant.
