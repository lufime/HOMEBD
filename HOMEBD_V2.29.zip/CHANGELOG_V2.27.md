# HOMEBD V2.27 — LOCALIZAÇÃO COMPLETA DO DIAGNÓSTICO

Base: HOMEBD V2.26.

## Correção
- O bloco DIAGNÓSTICO passa a usar o idioma detetado pelo Android.
- Corrigidos textos de arranque, perfil, Bluetooth e estados REST.
- Corrigidos títulos e botões visíveis da interface que ainda estavam fixos em português.
- Android em inglês → diagnóstico/interface em inglês.
- Android em português → diagnóstico/interface em português.

## Mantido
- Ícone e banner HOMEBD da V2.26.
- REST para Home Assistant.
- Sem MQTT.
- HV/BMS e UDS READ-ONLY.
