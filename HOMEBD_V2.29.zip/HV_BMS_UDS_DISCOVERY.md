# HOMEBD V2.18 — HV/BMS UDS discovery

Base real: HOMEBD_V2.17 enviado pelo utilizador.

Preparação para descoberta do sistema HV/BMS por UDS em READ-ONLY.
Usa pedidos `22 DID` e aceita apenas respostas positivas `62 DID DATA`.
Não atribui automaticamente SOC, tensão, corrente, temperatura ou kWh;
os DIDs têm de ser confirmados no veículo.

Não são gerados comandos de escrita, coding, adaptation, routine, reset ou programação.
