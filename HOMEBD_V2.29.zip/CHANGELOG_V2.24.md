# HOMEBD V2.24 — CORREÇÃO DO CRASH NO ARRANQUE

Base: HOMEBD V2.24.

## Correção crítica
- Corrigido crash imediato ao abrir a app.
- `append()` estava a ser chamado antes da inicialização do `TextView log`.
- A mensagem de idioma automático passou para depois de `setContentView(root)`.

## Mantido
- Foco HV/BMS.
- Candidatos PSA Hybrid `7E4 → 7EC`.
- DID `22 24 12`.
- DID `22 20 02`.
- UDS READ-ONLY.
- REST sem MQTT.
- Deteção automática de idioma.
