# HOMEBD V2.25

Base: HOMEBD V2.24.

## Home Assistant REST
- REST passa a comunicar diretamente com a API HTTP do Home Assistant.
- Autenticação por Long-Lived Access Token (`Authorization: Bearer`).
- O teste de ligação usa `GET /api`.
- Removida a lógica de procurar um endpoint `/health` de um servidor REST separado.
- Não é necessário MQTT, broker, Paho ou porta 1883.
- URLs locais/externas usam normalmente a porta 8123 do Home Assistant.

## Idioma
- A interface principal passa a respeitar o idioma Android.
- Português quando o sistema está em português.
- Inglês quando o sistema está em inglês.
- Mantida deteção de espanhol, francês, alemão e italiano.

## HV/BMS
- Mantidos `7E4 → 7EC`, DID `22 24 12` e DID `22 20 02`.
- UDS continua READ-ONLY.

## Identidade
- Versão visual atualizada para HOMEBD 2.25.
- Desenvolvedor: lufime.
