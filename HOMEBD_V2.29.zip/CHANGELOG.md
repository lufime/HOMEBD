# HOMEBD — CHANGELOG


## V2.5
- Correção da sequência entre descoberta UDS e LIVE DATA.
- Restauração da sessão OBD-II antes do LIVE DATA.
- Limpeza de `ATCRA` antes da leitura.
- Configuração de cabeçalhos/pedido OBD-II para a sessão LIVE.
- Validação das respostas OBD antes da descodificação.
- Operação mantida em READ-ONLY.
- **Regra de documentação:** todas as alterações futuras devem ser registadas neste CHANGELOG, com a versão correspondente.

## V2.6
- Adicionado botão com ícone de olho no campo **Password MQTT**.
- Permite alternar entre password oculta e visível.
- O botão inclui descrição de acessibilidade para mostrar/ocultar a password.
- A password continua a ser guardada e utilizada pelo fluxo MQTT existente.
- Mantida a documentação obrigatória de cada alteração por versão.


## V2.7
- Atualizado o `README.md` com o estado atual do projeto e a alteração V2.6.
- Adicionado/atualizado `ABOUT.md` com a descrição da aplicação e a alteração V2.6.
- Mantida a regra de documentar todas as alterações por versão.

## V2.8
- Adicionado **Sobre / FAQ dentro da app**.
- Incluídas informações sobre o HOMEBD, READ-ONLY, OBD-II/CAN, MQTT, Home Assistant e HV/UDS.
- Incluída explicação do botão de olho da password MQTT.
- Mantida a documentação de alterações por versão.

## V2.9
- Definida a separação entre os contextos OBD-II LIVE e UDS/HV.
- Respostas `7F...` deixam de ser tratadas como valores OBD.
- Validação obrigatória de `41 + PID` antes da descodificação.
- RAW continua disponível para diagnóstico.
- Mantido READ-ONLY.

## V2.12
- Correção do Live Data: especificação de leitura contínua deve separar corretamente cabeçalhos CAN/ELM327 do payload OBD-II antes da descodificação.
- Não considerar `NO DATA` como valor válido.
- Manter o protocolo detetado ISO 15765-4 CAN 11-bit / 500 kbit/s em READ-ONLY.
- Identificação automática mantém VIN quando disponível.
- HV/UDS continua sem DIDs proprietários e sem comandos de escrita até existir resposta válida.
- Mantida a regra de interface: cards full screen horizontal, centrados e a ocupar toda a largura.

## V2.13
- Corrigida a leitura Live Data com segunda tentativa e recuperação da sessão OBD quando não existe resposta positiva `41 <PID>`.
- O parser continua a validar o par serviço/PID antes de descodificar.
- Lista de fabricantes alterada para marcas individuais, sem grupos.
- Corrigido o botão de olho da password MQTT usando transformação de texto explícita.
- Mantido READ-ONLY.

## V2.14
- Filtragem de PIDs baseada em respostas OBD-II positivas `41 <PID>`.
- `NO DATA`, `SEM RESPOSTA` e respostas negativas deixam de ser tratados como valores suportados.
- Comunicação mantida em READ-ONLY.

## V2.15
- Preparada análise de respostas UDS positivas `62 DID DATA` para descoberta HV/BMS.
- Mantido READ-ONLY, sem DIDs proprietários e sem comandos de escrita.

## V2.16
- Tratamento controlado do encerramento do socket na sessão HV/UDS.
- A sessão HV/UDS passa a ter estado explícito aberto/fechado.
- Um socket fechado não deve ser reutilizado para novas leituras.
- Mantido READ-ONLY, sem DIDs proprietários e sem comandos de escrita.
- O diagnóstico `socket closed` é registado como encerramento de sessão, não como resposta HV válida.

## V2.17
- Consolidado o fluxo de sessão HV/UDS para reutilizar a mesma ligação durante a descoberta.
- `socket closed` não é tratado como resposta UDS.
- Mantido READ-ONLY e sem DIDs proprietários.
