# HOMEBD V2.19 — REST

Base: HOMEBD V2.18.

## Comunicação
- Removida a dependência Eclipse Paho MQTT Java 1.2.5.
- Removido o cliente MQTT dedicado HomeBdMqtt.
- Adicionado `HomeBdRest.kt` para comunicação HTTP/REST.
- A comunicação usa JSON via HTTP POST.
- Autenticação Bearer opcional.
- Timeout configurável e tratamento por `Result`.

## Mantido
- OBD-II/CAN.
- Descoberta UDS/HV READ-ONLY.
- Restante do projeto existente.

## Nota
A integração REST com o Home Assistant requer um endpoint HTTP/REST que receba
os estados enviados pela aplicação; substituir o transporte não cria esse
endpoint automaticamente.
