# HOMEBD V2.20 — HV FOCUS

Base: HOMEBD V2.19.

## Prioridade HV/BMS
- Adicionado `HvBmsDiscovery.kt`.
- Descoberta orientada ao gateway, com pares request/response CAN candidatos.
- UDS 0x22 / resposta positiva 0x62 em READ-ONLY.
- Identificação das ECUs antes de interpretar DIDs HV.
- Sem write, coding, adaptation, routine, programação ou reset.

## VIN
- Adicionado `VinDecoder.kt`.
- Validação de VIN completo com 17 caracteres.
- Identificação conservadora de WMI Citroën (`VF7`/`VR7`).
- Região apenas quando suportada pelo primeiro carácter.
- País permanece desconhecido quando não existe uma correspondência
  verificada no código; não são inventados dados.

## Nota
A V2.20 prepara a descoberta HV e o tratamento do VIN. Os valores SOC,
tensão, corrente, temperaturas e energia só devem ser apresentados depois
de uma resposta real do BMS e da validação do DID correspondente.
