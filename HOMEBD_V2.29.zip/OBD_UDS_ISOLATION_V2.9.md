# HOMEBD V2.9 — Isolamento OBD-II / UDS

## Objetivo
Separar completamente o contexto de LIVE DATA OBD-II do contexto de
descoberta UDS/HV.

## Contexto OBD-II LIVE
- Limpar filtros/respostas pendentes antes de iniciar um pedido.
- Enviar o pedido OBD-II.
- Aceitar apenas uma resposta correspondente ao PID solicitado.
- Validar `41 + PID` antes da descodificação.
- Não interpretar `7F xx yy` como valor do PID.
- Frames que pertençam a outro pedido/serviço devem ser ignorados para o
  resultado LIVE, mas podem permanecer no RAW de diagnóstico.

## Contexto UDS/HV
- Executar numa sessão/contexto separado.
- Analisar respostas `62` apenas durante a descoberta UDS.
- Não deixar respostas UDS contaminar o parser OBD-II.

## Estados
VALID / NO_DATA / TIMEOUT / ERROR / UNSUPPORTED / NEGATIVE_RESPONSE

## Segurança
- READ-ONLY.
- Sem SecurityAccess.
- Sem coding/programming.
- Sem DIDs proprietários assumidos.

## Evidência
O diagnóstico V2.8 apresenta respostas `7F2211` e `7F0112` em vários PIDs,
enquanto o scan de capacidade varia entre diferentes quantidades de PIDs.
A alteração deve, portanto, ser validada com RAW antes de considerar qualquer
resposta como pertencente ao PID solicitado.
