# HOMEBD V2.3 — Parser ELM327/CAN

Base de diagnóstico: HOMEBD_LIVE_DATA (5).

## Objetivo
Interpretar respostas recebidas do adaptador ELM327 antes de apresentar valores.

## Pipeline
1. Receber a resposta RAW.
2. Normalizar espaços, CR/LF e eco do comando.
3. Separar cabeçalho CAN/ISO-TP dos dados úteis.
4. Reagrupar frames quando uma resposta vier fragmentada.
5. Validar a resposta de serviço/PID.
6. Confirmar que o PID recebido corresponde ao PID solicitado.
7. Extrair os bytes de dados.
8. Aplicar a fórmula do PID.
9. Publicar o valor e manter RAW para diagnóstico.

## Estados
- VALID: resposta válida e decodificada.
- NO_DATA: adapter/ECU indicou ausência de dados.
- TIMEOUT: não chegou resposta completa dentro do limite.
- ERROR: resposta do adapter inválida ou erro explícito.
- UNSUPPORTED: PID não confirmado como suportado.

## Regra essencial
`PID suportado` não significa `PID respondido`. A resposta LIVE DATA tem de
ser validada individualmente.

## Respostas RAW
Sequências como `7E9037F0111` e `7E9037F2211` do diagnóstico devem ser tratadas
como tráfego RAW para análise do enquadramento/protocolo. Não devem ser exibidas
como se fossem o valor do PID.

## Segurança
- OBD/UDS apenas READ-ONLY.
- Sem SecurityAccess.
- Sem coding/programming.
- Sem DIDs proprietários assumidos.
- Não substituir ausência de dados por zero.

## Primeiros PIDs de validação
RPM, velocidade, temperatura do líquido de arrefecimento, MAP e tensão do módulo.
