# HOMEBD — Documentação de alterações

A partir da V2.5, cada alteração efetuada ao projeto deve ser registada na
documentação da respetiva versão.

## Regra
Nenhuma alteração funcional, de interface, comunicação, diagnóstico, MQTT,
OBD/CAN/UDS ou configuração deve ser considerada concluída sem uma entrada
correspondente no `CHANGELOG.md`.

## Formato mínimo por versão
- Versão
- Alterações efetuadas
- Componentes afetados
- Alterações de comportamento observáveis
- Restrições/safety relevantes, quando aplicável

## Histórico
Consultar `CHANGELOG.md` para o histórico por versão.

## V2.7 — README e About
- README atualizado.
- About atualizado.
- Incluída referência à funcionalidade do olho da password MQTT.
- Mantida a identificação do developer como Katios.

## V2.8 — Sobre e FAQ na aplicação
- O utilizador pode consultar Sobre e FAQ diretamente dentro da app.
- Conteúdo alinhado com a documentação do projeto.

## V2.9 — Isolamento OBD/UDS
- Especificada a separação dos parsers/sessões OBD-II e UDS/HV.
- Definido tratamento explícito para respostas negativas.
