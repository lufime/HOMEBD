# HOMEBD V2.5 — OBD/ISO-TP stabilizer

Restores functional OBD-II addressing after UDS/Mode 09 operations:
`ATSP<protocol>` → `ATCAF1` → `ATCFC1` → `ATH0` → `ATCRA` → `ATSH7DF` → `ATAT1`.

Standard Mode 01 LIVE DATA validates `41 + PID` in the payload. CAN IDs and
ISO-TP framing are not treated as PID data. Negative responses are classified
separately. All diagnostic traffic remains READ-ONLY.
