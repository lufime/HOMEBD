# HOMEBD — AUDITORIA DE LICENÇAS E CRÉDITOS

## HOMEBD
- Projeto e código original: **Katios**
- Copyright © 2026 Katios, exceto componentes de terceiros sujeitos às respetivas licenças.

## Bibliotecas de terceiros incorporadas

#
## Tecnologias de desenvolvimento e plataforma

### Kotlin
- Versão configurada no projeto: 2.0.21.
- Linguagem utilizada no código da aplicação.
- Aplicam-se os termos de licença do projeto Kotlin/JetBrains.

### Android SDK / Android APIs
- Plataforma e APIs utilizadas pela aplicação.
- Aplicam-se as respetivas licenças e termos da plataforma Android.

### Android Gradle Plugin
- Plugin de compilação Android configurado no projeto.
- Aplicam-se os respetivos termos/licença do projeto Android/Google.

### Gradle
- Sistema de compilação utilizado pelo projeto.
- Aplicam-se os respetivos termos/licença do projeto Gradle.

## Protocolos e standards automóveis

HOMEBD implementa lógica própria para protocolos/interfaces de diagnóstico, incluindo OBD-II, CAN, ISO-TP e UDS quando aplicável.

Estas referências técnicas não representam bibliotecas de software de terceiros incorporadas na aplicação.

## Componentes que NÃO são utilizados

- **openDBC / opendbc:** não utilizado.
- **Bases CAN de terceiros:** não utilizadas.
- **Mapas CAN proprietários de fabricantes:** não incorporados.

## Integrações externas

### Home Assistant
HOMEBD pode comunicar com instalações Home Assistant através de MQTT. O Home Assistant, o nome e as respetivas marcas pertencem aos seus titulares. HOMEBD não deve ser apresentado como aplicação oficial ou afiliada ao Home Assistant, salvo autorização expressa.

### Tailscale
Tailscale pode ser utilizado como infraestrutura externa para alcançar o broker, quando configurado pelo utilizador. Não é incorporada uma biblioteca Tailscale na aplicação neste projeto.

### Android Auto
A documentação pode referir Android Auto como plataforma de integração futura. A utilização de APIs, SDKs, marcas ou recursos Android Auto deverá respeitar os respetivos termos quando forem incorporados ao projeto.

## Recursos gráficos

- `homebd_header.png`
- `homebd_icon.png`

A origem/autoria dos recursos gráficos deve permanecer documentada pelo proprietário do projeto. Não devem ser adicionados recursos de terceiros sem a respetiva licença/autorização.

## Nota
Esta documentação é uma auditoria técnica do conteúdo do projeto e não constitui aconselhamento jurídico. A lista deve ser atualizada sempre que uma nova dependência, recurso ou código de terceiros seja incorporado.
