# V2.13 — Correção Live Data

A rotina de Live Data tenta novamente cada PID quando não recebe uma resposta positiva `41 <PID>`.
Antes da segunda tentativa, a sessão OBD standard é preparada novamente para restaurar protocolo,
filtros e cabeçalho CAN.

Uma resposta só é considerada válida quando contém o serviço `41` e o PID solicitado. `NO DATA`,
`ERROR` e respostas UDS negativas não são convertidas em valores.

Os perfis de fabricantes são apresentados individualmente. Os perfis ainda usam o catálogo OBD-II
standard comum até existirem identificadores específicos verificados para cada veículo.
