package pt.homebd

/**
 * HOMEBD V2.16 — proteção de sessão HV/UDS.
 *
 * READ-ONLY: esta classe não envia comandos.
 * A camada de transporte deve verificar isOpen() antes de cada leitura
 * e encerrar graciosamente quando o socket for fechado.
 */
class HvSessionGuard {
    @Volatile private var open = false

    fun markOpened() { open = true }
    fun markClosed() { open = false }
    fun isOpen(): Boolean = open

    fun canRead(): Boolean = open

    fun onSocketClosed(): String {
        open = false
        return "HV/UDS: socket closed — sessão terminada de forma controlada"
    }
}
