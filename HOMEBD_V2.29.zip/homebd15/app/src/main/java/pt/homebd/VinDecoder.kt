package pt.homebd

/**
 * HOMEBD VIN decoder.
 *
 * Conservative: fields are returned only when the VIN is 17 characters and
 * the local mapping knows the value. Unknown values remain null.
 */
object VinDecoder {

    data class Result(
        val vin: String,
        val wmi: String,
        val manufacturer: String?,
        val region: String?,
        val country: String?,
        val yearCode: Char?,
        val serial: String
    )

    private val manufacturerByWmi = mapOf(
        "VF7" to "Citroën",
        "VR7" to "Citroën"
    )

    // ISO/SAE WMI first-character region, intentionally broad.
    private val regionByFirst = mapOf(
        'S' to "Europa",
        'T' to "Europa",
        'V' to "Europa",
        'W' to "Europa",
        'X' to "Europa",
        'Y' to "Europa",
        'Z' to "Europa"
    )

    fun decode(raw: String): Result? {
        val vin = raw.uppercase().replace("\\s".toRegex(), "")
        if (vin.length != 17) return null

        val wmi = vin.substring(0, 3)
        val first = vin.first()

        return Result(
            vin = vin,
            wmi = wmi,
            manufacturer = manufacturerByWmi[wmi],
            region = regionByFirst[first],
            country = null, // country requires a verified WMI mapping
            yearCode = vin[9],
            serial = vin.substring(11, 17)
        )
    }
}
