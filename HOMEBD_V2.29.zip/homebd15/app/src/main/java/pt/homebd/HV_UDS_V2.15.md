# HOMEBD V2.15 — HV / UDS READ-ONLY

## Objetivo
Preparar a camada de análise de respostas UDS positivas das ECUs descobertas.

## Regra de segurança
- Apenas leitura.
- Nenhum DID proprietário é assumido.
- Nenhum comando de escrita é enviado.
- Respostas negativas `7F...` são descartadas.
- Uma resposta só é aceite como `ReadDataByIdentifier` quando começa por `62` e contém DID + dados.

## ECUs observadas no diagnóstico
O diagnóstico recente detetou respostas nas ECUs:
- 7E5 → 7ED
- 7E6 → 7EE
- 7E7 → 7EF
- 7EA → 7F2
- 7EE → 7F6

Estas ECUs são apenas pontos de descoberta. O projeto não deve atribuir SOC, tensão, corrente ou temperatura a nenhuma delas sem uma resposta UDS válida e identificada.

## Próximo teste
Capturar respostas UDS `62 xx xx ...` e guardar o DID e payload bruto para posterior identificação. Só depois poderão ser criados descodificadores específicos.
