package pt.homebd

/**
 * HOMEBD V2.15 — contrato de descoberta HV/UDS READ-ONLY.
 *
 * Esta camada apenas classifica respostas UDS positivas.
 * Não contém DIDs proprietários nem comandos de escrita.
 */
object HvUdsReadOnly {
    data class PositiveResponse(
        val ecuResponseId: String,
        val did: Int,
        val payloadHex: String
    )

    fun parsePositiveResponse(responseId: String, response: String): PositiveResponse? {
        val clean = response.replace("\\s".toRegex(), "").uppercase()
        if (clean.isEmpty() || clean.startsWith("7F")) return null

        // UDS ReadDataByIdentifier positive response: 62 DID_H DID_L DATA...
        if (!clean.startsWith("62") || clean.length < 6) return null

        val did = clean.substring(2, 6).toIntOrNull(16) ?: return null
        val payload = clean.substring(6)
        if (payload.isEmpty()) return null

        return PositiveResponse(responseId, did, payload)
    }
}
