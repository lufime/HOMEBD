# HOMEBD V2.16 — HV/UDS Socket

O diagnóstico mostrou repetidamente `HV/UDS: socket closed`.

Esta versão adiciona um estado explícito para a sessão HV/UDS:
- aberto antes da leitura;
- fechado quando o socket termina;
- nenhuma leitura é considerada válida depois do fecho;
- o fecho não é tratado como resposta UDS;
- não são introduzidos comandos de escrita nem DIDs proprietários.

A integração com o transporte existente deve manter o socket aberto durante a sessão de descoberta e só terminar a sessão no encerramento normal ou após uma falha real de transporte.
