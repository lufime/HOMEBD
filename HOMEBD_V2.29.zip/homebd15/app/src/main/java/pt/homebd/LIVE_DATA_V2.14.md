# HOMEBD V2.14 — PIDs realmente suportados

## Objetivo
Evitar que o Live Data apresente como suportados PIDs que foram apenas detetados no catálogo/capability scan.

## Regra
Um PID só deve entrar na lista de dados válidos quando existir uma resposta OBD positiva:
`41 <PID> <dados>`

São descartados:
- `NO DATA`
- `SEM RESPOSTA`
- respostas negativas `7F...`
- respostas sem o PID solicitado
- respostas sem bytes de dados

## Resultado esperado
O Live Data deve mostrar apenas PIDs com resposta válida na sessão atual. PIDs sem resposta podem continuar a ser conhecidos pelo catálogo, mas não devem ser apresentados como valores suportados.

## Segurança
A comunicação permanece READ-ONLY. Não são introduzidos comandos de escrita nem DIDs proprietários.
