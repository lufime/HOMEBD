# HOMEBD V2.17 — HV/UDS sessão persistente

## Objetivo
Consolidar o fluxo de descoberta HV/UDS sem fechar a ligação OBD antes de terminar a sessão.

### Fluxo
1. Confirmar socket Bluetooth Classic aberto.
2. Estabilizar CAN.
3. Guardar a referência da sessão de transporte.
4. Executar descoberta de ECUs em READ-ONLY.
5. Reutilizar a mesma sessão para consultas UDS.
6. Só fechar o socket no fim da descoberta ou numa falha real de transporte.

### Regras
- `socket closed` não é uma resposta UDS.
- Depois de um socket fechado, não enviar novas consultas nessa sessão.
- Não criar uma nova ligação dentro de cada tentativa de DID.
- Não assumir DIDs HV.
- Aceitar apenas respostas UDS positivas `62 DID DATA`.
- Nenhum comando de escrita.
