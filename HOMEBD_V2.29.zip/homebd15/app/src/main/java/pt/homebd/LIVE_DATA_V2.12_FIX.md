# HOMEBD V2.12 — Live Data

## Diagnóstico de referência
O diagnóstico indica:
- protocolo CAN 6;
- ISO 15765-4 CAN 11-bit / 500 kbit/s;
- ELM327 v2.1 Bluetooth Classic / SPP;
- 36 PIDs standard detetados;
- VIN disponível em determinada leitura;
- Live Data com PIDs detetados mas sem valores válidos.

## Regra de correção
A resposta ELM327/CAN deve ser normalizada antes do parser:
1. remover espaços e linhas vazias;
2. separar cabeçalhos CAN quando presentes;
3. extrair o payload OBD-II;
4. validar o modo e PID;
5. só então descodificar o valor;
6. se não houver resposta válida, marcar `NO DATA`.

Não assumir valores e não enviar comandos de escrita.
