# HOMEBD V2.2 — ELM327/ECU LIVE DATA diagnostic handling

## Objective
Diagnose the communication path before changing PID mappings.

## Required response states
- VALID: a decodable ECU response was received.
- NO_DATA: the adapter explicitly reports no data, or the ECU response is empty.
- TIMEOUT: no complete response arrived within the read timeout.
- ERROR: the adapter returned an error/invalid response.
- UNSUPPORTED: the PID was not confirmed as supported.

## Important rule
A PID being listed as supported does not by itself prove that a subsequent
LIVE DATA request returned a value. The raw adapter response must be retained
for diagnosis.

## First validation PIDs
Validate communication with:
- Engine RPM
- Vehicle speed
- Engine coolant temperature
- Control module voltage

Do not substitute zero for missing data.

## Safety
Diagnostic traffic remains read-only. No write commands, coding, SecurityAccess,
or assumed proprietary DIDs are introduced by this diagnostic layer.

## Current evidence
The supplied LIVE DATA report shows 19 standard PIDs detected, while all listed
LIVE DATA entries currently report NO DATA. Therefore the next debugging step
is the ELM327/ECU response path, not inventing or changing PID values.
