# HOMEBD V2.29 — PACOTE COMPLETO

Base estrutural preservada da HOMEBD V2.25 (pacote completo de 3,33 MB).

Aplicadas as alterações posteriores:
- Correções REST/Home Assistant.
- Correção do crash de arranque.
- Ícone e banner HOMEBD.
- Localização de interface/diagnóstico conforme idioma Android.
- HV/BMS PSA Hybrid e UDS READ-ONLY.
- Sem MQTT.

Esta versão preserva os ficheiros existentes da base V2.25 e adiciona apenas
as alterações necessárias das versões V2.26/V2.27.
