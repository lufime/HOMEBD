# Sobre o HOMEBD

**HOMEBD**  
Diagnóstico OBD-II universal para veículos.

### Funcionalidades
- Bluetooth Classic / ELM327 compatível
- OBD-II e CAN em modo READ-ONLY
- LIVE DATA
- Diagnóstico RAW
- MQTT / integração com Home Assistant
- Descoberta HV/UDS exclusivamente READ-ONLY

### V2.6
Foi adicionado um botão de **olho** ao campo de password MQTT para alternar
entre password visível e oculta.

### Desenvolvimento
**Developer: Katios**

As alterações do projeto são documentadas por versão no `CHANGELOG.md`.


### V2.12
Correção documentada da camada de Live Data e manutenção da identificação automática/VIN em modo READ-ONLY.

### V2.13
Correção do Live Data, lista individual de marcas e botão de password MQTT.

### V2.15 — HV/UDS
Preparada a análise de respostas UDS positivas em modo READ-ONLY. Nenhum DID proprietário ou comando de escrita é assumido.

### V2.16
Tratamento controlado do encerramento do socket na sessão HV/UDS, mantendo comunicação READ-ONLY.

### V2.17
Consolidação da sessão HV/UDS durante a descoberta, mantendo comunicação READ-ONLY.
