# HOMEBD V2.24

Base: HOMEBD V2.24.

## HV/BMS
- Adicionados os DIDs PSA Hybrid candidatos `24 12` e `20 02`.
- Alvo prioritário `7E4 → 7EC`.
- Mantida a abordagem READ-ONLY através de UDS `0x22`.
- Respostas devem ser preservadas em hexadecimal antes de qualquer conversão.
- Não foi assumida nenhuma fórmula de SOC/degradação/capacidade.

## Mantido
- Comunicação REST; MQTT não foi reintroduzido.
- Foco no diagnóstico HV/BMS.
- Deteção automática de idioma.
- Identificação VIN.
