# HOMEBD V2.27 — NOVO ÍCONE E BANNER

Base: HOMEBD V2.25.

## Identidade visual
- Novo logótipo HOMEBD aplicado ao ícone da aplicação.
- O mesmo logótipo substitui o banner/imagem de topo dentro da app.
- Letras `H`, `M`, `E` em azul.
- Letras `O`, `B`, `D` em branco.
- Mantida a imagem em fundo preto.

## Mantido
- REST para Home Assistant.
- Sem MQTT.
- Diagnóstico HV/BMS.
- UDS READ-ONLY.
- Candidatos PSA Hybrid `7E4 → 7EC`, `22 24 12` e `22 20 02`.
