# HOMEBD V2.4 — OBD Live Stabilizer

Base: HOMEBD_LIVE_DATA (5), com CAN estabilizado no protocolo 6 e respostas
OBD-II `0100`.

## Objetivo
Evitar que a capacidade OBD seja redescoberta a cada ciclo LIVE e estabilizar
a leitura contínua.

## Fluxo
1. Inicializar ELM327.
2. Confirmar protocolo/CAN.
3. Executar o scan de capacidade uma única vez após a ligação.
4. Guardar a lista de PIDs confirmados.
5. Iniciar LIVE DATA usando apenas essa lista.
6. Para cada pedido, validar a resposta `41 + PID`.
7. Ignorar frames que não pertençam ao pedido atual.
8. Em timeout/erro, repetir o PID sem refazer todo o scan.
9. Manter o último valor válido identificado como `stale` quando apropriado.
10. Só mostrar `NO DATA` quando não existir valor válido disponível.
11. Repetir o scan completo apenas após reconexão ou falha estrutural do protocolo.

## Estados
VALID / STALE / NO_DATA / TIMEOUT / ERROR / UNSUPPORTED

## RAW
Guardar a resposta RAW associada a cada pedido para diagnóstico, sem a
apresentar como valor decodificado.

## Segurança
READ-ONLY. Sem escrita, coding, SecurityAccess ou DIDs proprietários assumidos.

## Interface
Manter o painel em horizontal full-screen, centrado e ocupando toda a largura.
