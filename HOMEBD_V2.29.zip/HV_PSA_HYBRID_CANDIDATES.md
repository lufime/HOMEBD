# HOMEBD V2.24 — Candidatos PSA Hybrid HV/BMS

Fonte de referência fornecida pelo utilizador:

- ECU candidata: `7E4` com resposta `7EC`
- Candidato alternativo referido: `7ED`
- UDS ReadDataByIdentifier:
  - `22 24 12`
  - `22 20 02`

## Regra de segurança

Estes são **DIDs candidatos**, não valores confirmados para este veículo.
O HOMEBD apenas envia pedidos UDS `0x22` (ReadDataByIdentifier), sem escrita,
codificação, reset, rotina ou programação.

## Interpretação

A resposta deve ser guardada em hexadecimal antes de qualquer conversão.
Não é assumida uma fórmula de SOC, degradação, capacidade Ah ou kWh sem
confirmação da resposta e da estrutura de bytes.

## Objetivo

Confirmar primeiro se `7E4 → 7EC` responde no C5 AIRCROSS Hybrid e, depois,
usar os bytes devolvidos para determinar o significado do DID.
