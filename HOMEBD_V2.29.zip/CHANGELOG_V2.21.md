# HOMEBD V2.21 — REST + IDIOMA AUTOMÁTICO

Base: HOMEBD V2.20.

## Correção do build
- Corrigidas referências residuais a HomeBdMqtt no MainActivity.
- Removida a dependência lógica da antiga camada MQTT.
- O transporte da aplicação passa a usar HomeBdRestBridge.

## Comunicação
- REST/JSON via HTTP POST.
- Endpoint local/externo com modo automático.
- Autenticação HTTP Basic opcional.
- Health check antes de considerar a ligação ativa.

## Idioma
- Deteção automática do idioma definido no Android.
- Português, inglês, espanhol, francês, alemão e italiano.
- Idiomas não suportados fazem fallback para inglês.

## Diagnóstico
O log fornecido mostrava falhas de compilação Kotlin por referências a
HomeBdMqtt, disconnect, connect, activeMode e parâmetros associados.
A V2.21 elimina essas referências da camada REST.
