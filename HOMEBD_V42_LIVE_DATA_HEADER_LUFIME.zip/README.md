# HOMEBD

Universal Android OBD-II diagnostic application.

### V42
- Converted generic OBD-II PID responses into readable vehicle data values.
- Automatically discovers supported OBD-II PID ranges (01-20, 21-40, 41-60, 61-80) and queries only supported PIDs.
- Added/retained the scrollable diagnostic log.

## Previous UI
- Header includes Bluetooth and engine symbols beside the car.
- Existing Bluetooth device list, OBD connection and PID scan UI retained.
- Header includes Bluetooth and engine symbols beside the car.
- Existing Bluetooth device list, OBD connection and PID scan UI retained.
- No GitHub Actions workflow included in this ZIP.

## Credits
- HOMEBD — Home Onboard Monitoring Engine Board Data
- Version: V42 — TEST
- Developed by: lufime
- Platform: Android
- Diagnostic standard: OBD-II

## Legal / third-party components
The project does not declare external runtime libraries in `app/build.gradle.kts`. Android SDK/Kotlin/Gradle tooling are platform/build dependencies.

## Manufacturer profiles
- Automatic manufacturer detection when the ECU exposes a VIN through OBD-II Mode 09 PID 02.
- Manual manufacturer selection is available when automatic detection is unavailable.
- Standard OBD-II PID decoding remains the universal fallback.
