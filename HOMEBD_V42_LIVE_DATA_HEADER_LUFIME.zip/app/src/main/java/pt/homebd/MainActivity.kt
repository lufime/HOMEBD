package pt.homebd

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.*
import java.io.InputStream
import java.io.IOException
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    @Volatile private var liveRunning = false
    private var liveThread: Thread? = null
    @Volatile private var supportedLivePids: List<Int> = emptyList()

    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var scanButton: TextView
    private lateinit var liveData: TextView
    private lateinit var devicesSpinner: Spinner
    private lateinit var manufacturerSpinner: Spinner

    private val manufacturers = listOf(
        "Automático", "Audi", "BMW", "Citroën", "Dacia", "Fiat", "Ford",
        "Honda", "Hyundai", "Kia", "Mercedes-Benz", "Nissan", "Opel",
        "Peugeot", "Renault", "SEAT", "Škoda", "Toyota", "Volkswagen", "Volvo"
    )

    private val wmiManufacturers = mapOf(
        "WAU" to "Audi", "WBA" to "BMW", "WDB" to "Mercedes-Benz", "WDD" to "Mercedes-Benz",
        "VF7" to "Citroën", "VR7" to "Citroën", "VF3" to "Peugeot", "VF1" to "Renault",
        "VF6" to "Renault", "ZFA" to "Fiat", "WF0" to "Ford", "JHM" to "Honda",
        "KMH" to "Hyundai", "KNA" to "Kia", "JN1" to "Nissan", "W0L" to "Opel",
        "VSS" to "SEAT", "TMB" to "Škoda", "JTD" to "Toyota", "JTN" to "Toyota",
        "WVW" to "Volkswagen", "WV1" to "Volkswagen", "YV1" to "Volvo", "UU1" to "Dacia"
    )

    private val pidLabels = mapOf(
        0x01 to "Monitor status since DTC clear",
        0x03 to "Fuel system status",
        0x04 to "Engine load",
        0x05 to "Coolant temperature",
        0x06 to "Short-term fuel trim Bank 1",
        0x07 to "Long-term fuel trim Bank 1",
        0x08 to "Short-term fuel trim Bank 2",
        0x09 to "Long-term fuel trim Bank 2",
        0x0A to "Fuel pressure",
        0x0B to "MAP pressure",
        0x0C to "RPM",
        0x0D to "Vehicle speed",
        0x0E to "Timing advance",
        0x0F to "Intake air temperature",
        0x10 to "MAF",
        0x11 to "Throttle position",
        0x1C to "OBD standard",
        0x1F to "Run time since engine start",
        0x21 to "Distance with MIL on",
        0x2C to "Commanded EGR",
        0x2D to "EGR error",
        0x2E to "Evaporative purge",
        0x2F to "Fuel level",
        0x30 to "Warm-ups since DTC clear",
        0x31 to "Distance since DTC clear",
        0x33 to "Barometric pressure",
        0x42 to "Control module voltage",
        0x46 to "Ambient temperature",
        0x47 to "Throttle position absolute",
        0x49 to "Accelerator pedal position D",
        0x4A to "Accelerator pedal position E",
        0x4C to "Commanded throttle actuator",
        0x51 to "Fuel type",
        0x5C to "Engine oil temperature",
        0x5E to "Engine fuel rate",
        0x63 to "Engine reference torque"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(23, 23, 23)
        window.navigationBarColor = Color.rgb(23, 23, 23)

        // Ecrã normal: o conteúdo nunca fica por baixo das barras do sistema.
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(true)
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = 0
        }

        val background = Color.rgb(28, 28, 28)
        val panel = Color.rgb(55, 55, 55)
        val primary = Color.rgb(235, 235, 235)
        val secondary = Color.rgb(190, 190, 190)
        val blue = Color.rgb(20, 145, 245)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(background)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            clipChildren = true
            clipToPadding = true
        }

        val header = ImageView(this).apply {
            setImageResource(pt.homebd.R.drawable.homebd_header)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
            contentDescription = "HOMEBD"
            adjustViewBounds = true
            clipToOutline = true
        }

        status = TextView(this).apply {
            text = "Estado: desligado"
            textSize = 14f
            setTextColor(secondary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        val manufacturerLabel = TextView(this).apply {
            text = "FABRICANTE"
            textSize = 14f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        manufacturerSpinner = Spinner(this).apply {
            this.background = GradientDrawable().apply {
                setColor(panel)
                cornerRadius = 2f
            }
            minimumHeight = dp(48)
        }
        manufacturerSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_item, manufacturers
        ).apply { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }

        val deviceLabel = TextView(this).apply {
            text = "DISPOSITIVO OBD-II"
            textSize = 14f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        devicesSpinner = Spinner(this).apply {
            this.background = GradientDrawable().apply {
                setColor(panel)
                cornerRadius = 2f
            }
            minimumHeight = dp(48)
        }

        val connect = actionButton("LIGAR OBDII", blue, primary)
        scanButton = actionButton("SCAN PIDs", Color.rgb(70, 70, 70), primary).apply {
            isEnabled = false
            alpha = 0.55f
        }

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        buttons.addView(connect, LinearLayout.LayoutParams(0, dp(50), 1f).apply {
            setMargins(dp(0), dp(4), dp(4), dp(4))
        })
        buttons.addView(scanButton, LinearLayout.LayoutParams(0, dp(50), 1f).apply {
            setMargins(dp(4), dp(4), dp(0), dp(4))
        })

        log = TextView(this).apply {
            textSize = 14f
            setTextColor(primary)
            setBackgroundColor(panel)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            includeFontPadding = true
            gravity = Gravity.TOP or Gravity.START
            setLineSpacing(0f, 1.0f)
        }

        logScroll = ScrollView(this).apply {
            setBackgroundColor(panel)
            isFillViewport = true
            isVerticalScrollBarEnabled = true
            scrollBarStyle = View.SCROLLBARS_INSIDE_INSET
            isScrollbarFadingEnabled = false
            addView(log, ViewGroup.LayoutParams(-1, -2))
        }

        val liveLabel = TextView(this).apply {
            text = "LIVE DATA"
            textSize = 14f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        liveData = TextView(this).apply {
            text = "A aguardar dados OBD-II…"
            textSize = 13f
            setTextColor(primary)
            setBackgroundColor(panel)
            setPadding(dp(8), dp(6), dp(8), dp(6))
            gravity = Gravity.TOP or Gravity.START
            includeFontPadding = false
            setLineSpacing(0f, 1.05f)
        }

        val diagnosticLabel = TextView(this).apply {
            text = "DIAGNÓSTICO"
            textSize = 14f
            setTextColor(primary)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

        root.addView(header, LinearLayout.LayoutParams(-1, dp(150)))
        root.addView(status, LinearLayout.LayoutParams(-1, dp(36)))
        root.addView(deviceLabel, LinearLayout.LayoutParams(-1, dp(34)))
        root.addView(devicesSpinner, LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(manufacturerLabel, LinearLayout.LayoutParams(-1, dp(30)))
        root.addView(manufacturerSpinner, LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(buttons, LinearLayout.LayoutParams(-1, dp(62)))
        root.addView(liveLabel, LinearLayout.LayoutParams(-1, dp(30)))
        root.addView(liveData, LinearLayout.LayoutParams(-1, dp(156)))
        root.addView(diagnosticLabel, LinearLayout.LayoutParams(-1, dp(36)))
        root.addView(logScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val credits = TextView(this).apply {
            text = "HOMEBD  •  V42 — TEST  •  lufime"
            textSize = 11f
            setTextColor(secondary)
            gravity = Gravity.CENTER
            includeFontPadding = false
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        root.addView(credits, LinearLayout.LayoutParams(-1, dp(28)))

        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener { v, insets ->
                val bars = insets.getInsets(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                v.setPadding(
                    dp(10),
                    bars.top + dp(4),
                    dp(10),
                    bars.bottom + dp(4)
                )
                insets
            }
        }

        setContentView(root)
        root.requestApplyInsets()

        connect.setOnClickListener {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            val paired = try {
                adapter?.bondedDevices?.toList() ?: emptyList()
            } catch (_: SecurityException) {
                emptyList()
            }

            val position = devicesSpinner.selectedItemPosition
            val device = paired.getOrNull(position)

            if (device != null) {
                connect(device)
            } else {
                append("⚠ Nenhum dispositivo Bluetooth selecionável.")
                append("Emparelhe o seu ELM327 nas definições Bluetooth do Android.")
            }
        }

        scanButton.setOnClickListener { runScanner() }

        append("HOMEBD pronto.")
        append("Diagnóstico OBD-II universal para veículos.")
        append("Selecione o seu ELM327 na lista e toque em LIGAR OBDII.")

        requestBtPermissions()
        refreshBluetoothList()
    }

    private fun actionButton(label: String, color: Int, textColor: Int): TextView =
        TextView(this).apply {
            text = label
            textSize = 14f
            setTextColor(textColor)
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            this.background = GradientDrawable().apply {
                setColor(color)
                cornerRadius = 8f
            }
        }

    private fun refreshBluetoothList() {
        val adapter = BluetoothAdapter.getDefaultAdapter()

        if (adapter == null) {
            setDevices(listOf("Bluetooth não disponível neste dispositivo"))
            return
        }

        try {
            if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
            ) {
                setDevices(listOf("Permitir Bluetooth para mostrar dispositivos"))
                return
            }

            if (!adapter.isEnabled) {
                setDevices(listOf("Bluetooth desligado — ative o Bluetooth"))
                return
            }

            val paired = adapter.bondedDevices.toList()
            val names = if (paired.isEmpty()) {
                listOf("Nenhum dispositivo emparelhado")
            } else {
                paired.map { device ->
                    val name = try { device.name ?: "Sem nome" } catch (_: SecurityException) { "Sem nome" }
                    "$name  (${device.address})"
                }
            }

            setDevices(names)
            append("✓ Bluetooth: ${paired.size} dispositivo(s) emparelhado(s).")
        } catch (_: SecurityException) {
            setDevices(listOf("Permissão Bluetooth necessária"))
        }
    }

    private fun setDevices(names: List<String>) {
        devicesSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            names
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                ),
                10
            )
        }
    }

    private fun connect(device: BluetoothDevice) {
        thread {
            try {
                runOnUiThread {
                    status.text = "Estado: a ligar…"
                }

                socket?.close()
                socket = device.createRfcommSocketToServiceRecord(spp)
                socket!!.connect()

                input = socket!!.inputStream
                output = socket!!.outputStream

                elm("ATZ", 5000)
                Thread.sleep(1200)
                elm("ATE0", 2500)
                elm("ATL0", 2500)
                elm("ATS0", 2500)
                elm("ATSP0", 2500)

                val protocol = elm("ATDP", 2500)
                val vin = readVin()

                if (protocol.isBlank()) {
                    throw IOException("ELM327 não respondeu ao ATDP")
                }

                runOnUiThread {
                    status.text = "Estado: LIGADO • ELM327 pronto"
                    scanButton.isEnabled = true
                    scanButton.alpha = 1f
                }

                append("✓ ELM327 inicializado.")
                append("Protocolo: ${clean(protocol)}")
                if (vin.isNotBlank()) {
                    val detected = wmiManufacturers[vin.take(3).uppercase()]
                    if (detected != null && manufacturerSpinner.selectedItemPosition == 0) {
                        val idx = manufacturers.indexOf(detected)
                        if (idx >= 0) runOnUiThread { manufacturerSpinner.setSelection(idx) }
                        append("Fabricante detetado pelo VIN: $detected")
                    } else {
                        append("VIN: $vin")
                    }
                } else {
                    append("VIN: não disponível via OBD-II")
                }
                append("Perfil: ${manufacturerSpinner.selectedItem}")
                append("Pronto. A iniciar LIVE DATA…")
                detectAndStartLiveData()
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Estado: erro de ligação"
                }
                append("✕ ERRO: ${e.message ?: "erro desconhecido"}")
            }
        }
    }

    private fun elm(cmd: String, timeout: Long = 2500): String {
        val out = output ?: return ""
        val ins = input ?: return ""

        try {
            out.write((cmd + "\r").toByteArray(Charsets.US_ASCII))
            out.flush()
        } catch (e: Exception) {
            throw IOException("Falha ao enviar $cmd: ${e.message}", e)
        }

        val start = System.currentTimeMillis()
        val buf = ByteArray(4096)
        val data = StringBuilder()

        while (System.currentTimeMillis() - start < timeout) {
            if (ins.available() > 0) {
                val n = ins.read(buf)
                if (n > 0) data.append(String(buf, 0, n, Charsets.US_ASCII))
                if (data.contains(">")) break
            } else {
                Thread.sleep(30)
            }
        }

        return data.toString()
            .replace("\r", "\n")
            .replace(">", "")
            .trim()
    }

    private fun readVin(): String {
        return try {
            val raw = elm("0902", 5000)
            val compact = raw.uppercase().replace(Regex("[^0-9A-F]"), "")
            val matches = Regex("49 02(?:[0-9A-F]{2})?([0-9A-F]{2,})").find(raw.uppercase())
            val ascii = matches?.groupValues?.getOrNull(1)?.chunked(2)?.mapNotNull { it.toIntOrNull(16)?.toChar() }?.joinToString("")
            val fallback = compact.chunked(2).mapNotNull { it.toIntOrNull(16)?.toChar() }
                .joinToString("").filter { it.isLetterOrDigit() }
            val vin = (ascii ?: fallback).filter { it.isLetterOrDigit() }.uppercase()
            if (vin.length >= 17) vin.takeLast(17) else ""
        } catch (_: Exception) { "" }
    }

    private fun runScanner() {
        stopLiveData()
        thread {
            if (output == null) {
                append("⚠ OBDII não está ligado.")
                return@thread
            }

            runOnUiThread {
                status.text = "Estado: SCAN OBD-II em execução…"
                scanButton.isEnabled = false
                scanButton.alpha = 0.55f
            }

            append("=== SCAN OBD-II ===")
            append("Perfil: ${manufacturerSpinner.selectedItem}")
            append("A detetar automaticamente os PIDs suportados pela ECU...")
            append("")

            val supported = detectSupportedPids()
            supportedLivePids = supported

            append("")
            if (supported.isEmpty()) {
                append("Sem PIDs suportados identificados.")
            } else {
                append("PIDs suportados: ${supported.sorted().joinToString(", ") { String.format("01%02X", it) }}")
                append("")
                append("A iniciar LIVE DATA com os PIDs suportados…")
            }

            runOnUiThread {
                status.text = if (supported.isEmpty()) "Estado: LIGADO • sem PIDs" else "Estado: LIGADO • LIVE DATA"
                scanButton.isEnabled = true
                scanButton.alpha = 1f
            }

            if (supported.isNotEmpty()) startLiveData(supported)
        }
    }

    private fun detectAndStartLiveData() {
        thread {
            val supported = detectSupportedPids()
            supportedLivePids = supported
            if (supported.isEmpty()) {
                append("⚠ Não foi possível determinar os PIDs suportados.")
                return@thread
            }
            append("✓ ${supported.size} PID(s) suportado(s). LIVE DATA ativo.")
            startLiveData(supported)
        }
    }

    private fun detectSupportedPids(): List<Int> {
        val supported = linkedSetOf<Int>()
        var requestPid = 0x00
        while (requestPid <= 0x60) {
            val raw = elm(String.format("01%02X", requestPid), 1800)
            val found = supportedPidsFromBitmap(requestPid, raw)
            if (found.isEmpty()) break
            supported.addAll(found)
            val next = when (requestPid) {
                0x00 -> 0x20
                0x20 -> 0x40
                0x40 -> 0x60
                else -> 0x80
            }
            if (next > 0x60) break
            requestPid = next
        }
        return supported.filter { it in pidLabels.keys }.sorted()
    }

    private fun startLiveData(pids: List<Int>) {
        stopLiveData()
        liveRunning = true
        liveThread = thread(start = true, name = "HOMEBD-LiveData") {
            while (liveRunning && socket?.isConnected == true) {
                val lines = mutableListOf<String>()
                for (code in pids) {
                    if (!liveRunning) break
                    val pid = String.format("01%02X", code)
                    try {
                        val raw = elm(pid, 1200)
                        val decoded = decodePid(pid, raw)
                        if (!decoded.startsWith("·")) lines += decoded.removePrefix("✓ ")
                    } catch (_: Exception) {
                        // Mantém os últimos valores visíveis se um ciclo falhar.
                    }
                }
                if (lines.isNotEmpty()) {
                    val snapshot = lines.distinct().joinToString("\n")
                    runOnUiThread {
                        if (!isFinishing) liveData.text = snapshot
                    }
                }
                Thread.sleep(250)
            }
        }
    }

    private fun stopLiveData() {
        liveRunning = false
        liveThread?.interrupt()
        liveThread = null
    }

    private fun supportedPidsFromBitmap(basePid: Int, raw: String): List<Int> {
        val compact = raw.uppercase().replace(Regex("[^0-9A-F]"), "")
        val responsePid = String.format("41%02X", basePid)
        val match = Regex("${responsePid}([0-9A-F]{8})").find(compact) ?: return emptyList()
        val data = match.groupValues[1]
        val result = mutableListOf<Int>()
        for (i in 0 until 32) {
            val b = data.substring(i / 8 * 2, i / 8 * 2 + 2).toInt(16)
            if ((b and (1 shl (7 - (i % 8)))) != 0) {
                result += basePid + i + 1
            }
        }
        return result
    }

    private fun decodePid(pid: String, raw: String): String {
        val readable = raw.replace("\r", " ").replace("\n", " ")
            .replace(Regex("\\s+"), " ").trim()
        val upper = readable.uppercase()
        if (upper.contains("NO DATA")) return "· NO DATA — sem resposta desse PID"
        if (upper.contains("UNABLE TO CONNECT")) return "· SEM LIGAÇÃO ECU"
        if (upper.contains("ERROR")) return "· ERROR — ELM327 recusou o comando"

        val pidCode = pid.substring(2).uppercase()
        val compact = upper.replace(Regex("[^0-9A-F]"), "")
        val match = Regex("41$pidCode([0-9A-F]+)").find(compact)
            ?: return if (readable.isBlank()) "· SEM RESPOSTA" else "· Resposta: $readable"

        val data = match.groupValues[1]
        if (data.length < 2) return "· Resposta: $readable"

        fun byteAt(index: Int): Int? {
            val from = index * 2
            if (data.length < from + 2) return null
            return data.substring(from, from + 2).toIntOrNull(16)
        }

        fun wordAt(): Int? {
            val a = byteAt(0) ?: return null
            val b = byteAt(1) ?: return null
            return (a shl 8) or b
        }

        fun fmt(value: Double, decimals: Int = 1): String =
            String.format(java.util.Locale.getDefault(), "%.${decimals}f", value)

        return when (pid.uppercase()) {
            "0100", "0120", "0140", "0160" -> "✓ Mapa de PIDs suportados recebido"
            "0101" -> if (data.length >= 8) "✓ Monitor/estado: $data" else "· Resposta: $readable"
            "0103" -> "✓ Sistema de combustível: $data"
            "0106", "0107", "0108", "0109" -> byteAt(0)?.let { "✓ Fuel trim: ${fmt(it * 100.0 / 128.0 - 100.0)} %" } ?: "· Resposta: $readable"
            "010A" -> byteAt(0)?.let { "✓ Pressão de combustível: ${it * 3} kPa" } ?: "· Resposta: $readable"
            "010E" -> byteAt(0)?.let { "✓ Avanço de ignição: ${fmt(it / 2.0 - 64.0)} °" } ?: "· Resposta: $readable"
            "011C" -> "✓ Norma OBD: $data"
            "011F", "0121", "0130", "0131" -> wordAt()?.let { value ->
                when (pid.uppercase()) {
                    "011F" -> "✓ Tempo desde arranque: $value s"
                    "0121" -> "✓ Distância com MIL ligada: $value km"
                    "0130" -> "✓ Aquecimentos desde limpar DTC: $value"
                    else -> "✓ Distância desde limpar DTC: $value km"
                }
            } ?: "· Resposta: $readable"
            "012C" -> byteAt(0)?.let { "✓ EGR comandada: ${fmt(it * 100.0 / 255.0)} %" } ?: "· Resposta: $readable"
            "012D" -> byteAt(0)?.let { "✓ Erro EGR: ${fmt(it * 100.0 / 128.0 - 100.0)} %" } ?: "· Resposta: $readable"
            "012E" -> byteAt(0)?.let { "✓ Purga evaporativa: ${fmt(it * 100.0 / 255.0)} %" } ?: "· Resposta: $readable"
            "0133" -> byteAt(0)?.let { "✓ Pressão barométrica: $it kPa" } ?: "· Resposta: $readable"
            "0147", "0149", "014A", "014C" -> byteAt(0)?.let { "✓ Posição/comando acelerador: ${fmt(it * 100.0 / 255.0)} %" } ?: "· Resposta: $readable"
            "0151" -> "✓ Tipo de combustível: $data"
            "015C" -> byteAt(0)?.let { "✓ Temperatura do óleo: ${it - 40} °C" } ?: "· Resposta: $readable"
            "0163" -> wordAt()?.let { "✓ Binário de referência do motor: $it Nm" } ?: "· Resposta: $readable"
            "0104" -> byteAt(0)?.let { "✓ Carga do motor: ${fmt(it * 100.0 / 255.0)} %" }
                ?: "· Resposta: $readable"
            "0105" -> byteAt(0)?.let { "✓ Temperatura do líquido: ${it - 40} °C" }
                ?: "· Resposta: $readable"
            "010B" -> byteAt(0)?.let { "✓ Pressão MAP: $it kPa" }
                ?: "· Resposta: $readable"
            "010C" -> wordAt()?.let { "✓ RPM: ${fmt(it / 4.0)} rpm" }
                ?: "· Resposta: $readable"
            "010D" -> byteAt(0)?.let { "✓ Velocidade: $it km/h" }
                ?: "· Resposta: $readable"
            "010F" -> byteAt(0)?.let { "✓ Temperatura do ar: ${it - 40} °C" }
                ?: "· Resposta: $readable"
            "0110" -> wordAt()?.let { "✓ MAF: ${fmt(it / 100.0)} g/s" }
                ?: "· Resposta: $readable"
            "0111" -> byteAt(0)?.let { "✓ Posição do acelerador: ${fmt(it * 100.0 / 255.0)} %" }
                ?: "· Resposta: $readable"
            "012F" -> byteAt(0)?.let { "✓ Nível de combustível: ${fmt(it * 100.0 / 255.0)} %" }
                ?: "· Resposta: $readable"
            "0142" -> wordAt()?.let { "✓ Tensão módulo de controlo: ${fmt(it / 1000.0, 2)} V" }
                ?: "· Resposta: $readable"
            "0146" -> byteAt(0)?.let { "✓ Temperatura ambiente: ${it - 40} °C" }
                ?: "· Resposta: $readable"
            "015E" -> wordAt()?.let { "✓ Taxa de combustível: ${fmt(it / 20.0)} L/h" }
                ?: "· Resposta: $readable"
            else -> "✓ Resposta OBD-II: $readable"
        }
    }

    private fun clean(value: String): String =
        value.replace("\n", " ").replace(Regex("\\s+"), " ").trim()

    private fun append(value: String) {
        runOnUiThread {
            log.append(if (log.text.isEmpty()) value else "\n$value")
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) refreshBluetoothList()
    }

    override fun onDestroy() {
        stopLiveData()
        try { socket?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
