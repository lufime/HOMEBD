# HOMEBD V4
Correção final dos erros Kotlin do V3.
- `Button.text` usa `this.text` para evitar conflito com a variável `text`.
- Interface vertical com scroll.
- Landscape/full-screen mantido.
- Workflow preparado para o ZIP V4.
