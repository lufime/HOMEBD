# HOMEBD V2.31 — CORREÇÃO REST LOCAL

## Correção principal
- Ativado `usesCleartextTraffic=true` para permitir REST local do Home Assistant
  por HTTP (`http://IP:8123`).
- Um endereço sem `http://` ou `https://` passa a ser normalizado automaticamente
  para `http://`.
- Mantido suporte HTTPS para acesso externo.
- Mensagem de erro REST melhorada.

## Exemplo local
`http://192.168.1.100:8123`

## Mantido
- Token Bearer do Home Assistant.
- `/api`.
- Sem MQTT.
- HV/BMS e UDS READ-ONLY.
- Ícone e banner HOMEBD.
- Localização PT/EN.
