package pt.homebd

import android.content.Context
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * Home Assistant REST bridge.
 *
 * Uses the official Home Assistant HTTP API directly.
 * Authentication is a Long-Lived Access Token sent as Bearer.
 * No MQTT broker or Paho client is used.
 */
class HomeBdRestBridge(private val context: Context) {

    enum class Mode { AUTO, LOCAL, EXTERNAL }

    private val prefs = context.getSharedPreferences("homebd_rest", Context.MODE_PRIVATE)

    @Volatile var connected: Boolean = false
        private set

    var mode: Mode = runCatching {
        Mode.valueOf(prefs.getString("mode", Mode.AUTO.name) ?: Mode.AUTO.name)
    }.getOrDefault(Mode.AUTO)
        private set

    var localBaseUrl: String = prefs.getString("local", "") ?: ""
        private set

    var externalBaseUrl: String = prefs.getString("external", "") ?: ""
        private set

    /** Home Assistant Long-Lived Access Token. */
    var token: String = prefs.getString("token", "") ?: ""
        private set

    var basePath: String = prefs.getString("path", "/api") ?: "/api"
        private set

    var activeMode: Mode? = null
        private set

    val baseUrl: String
        get() = when (activeMode ?: mode) {
            Mode.LOCAL -> localBaseUrl
            Mode.EXTERNAL -> externalBaseUrl
            Mode.AUTO -> localBaseUrl.ifBlank { externalBaseUrl }
        }

    fun save(
        local: String,
        external: String,
        accessToken: String,
        path: String,
        selectedMode: Mode
    ) {
        localBaseUrl = normalize(local)
        externalBaseUrl = normalize(external)
        token = accessToken.trim()
        basePath = normalizePath(path)
        mode = selectedMode

        prefs.edit()
            .putString("local", localBaseUrl)
            .putString("external", externalBaseUrl)
            .putString("token", token)
            .remove("username")
            .remove("password")
            .putString("path", basePath)
            .putString("mode", mode.name)
            .apply()
    }

    fun connect(callback: (Boolean, String) -> Unit) {
        Thread {
            val candidates = when (mode) {
                Mode.LOCAL -> listOf(Mode.LOCAL)
                Mode.EXTERNAL -> listOf(Mode.EXTERNAL)
                Mode.AUTO -> listOf(Mode.LOCAL, Mode.EXTERNAL)
            }

            var success = false
            var message = "Home Assistant não respondeu."

            if (token.isBlank()) {
                callback(false, "Configure o token de acesso do Home Assistant.")
                return@Thread
            }

            for (candidate in candidates) {
                val base = when (candidate) {
                    Mode.LOCAL -> localBaseUrl
                    Mode.EXTERNAL -> externalBaseUrl
                    Mode.AUTO -> ""
                }
                if (base.isBlank()) continue

                val result = getApi(candidate)
                if (result.isSuccess && (result.getOrNull() ?: 0) in 200..299) {
                    connected = true
                    activeMode = candidate
                    success = true
                    message = "Home Assistant ligado • ${candidate.name.lowercase()}"
                    break
                }
            }

            if (!success) {
                connected = false
                activeMode = null
                message = "Home Assistant não respondeu. Verifique URL, token e acesso à rede."
            }

            callback(success, message)
        }.start()
    }

    fun disconnect() {
        connected = false
        activeMode = null
    }

    fun publishPid(pid: String, label: String, value: String) {
        val body = JSONObject()
            .put("type", "pid")
            .put("pid", pid)
            .put("label", label)
            .put("value", value)
        postAsync("/api/homebd/pid", body)
    }

    fun publishAggregate(values: List<Pair<String, String>>) {
        val data = JSONObject()
        values.forEach { (key, value) -> data.put(key, value) }
        val body = JSONObject()
            .put("type", "live_data")
            .put("values", data)
        postAsync("/api/homebd/state", body)
    }

    private fun postAsync(path: String, body: JSONObject) {
        if (!connected || baseUrl.isBlank()) return
        Thread { post(activeMode ?: mode, path, body.toString()) }.start()
    }

    private fun getApi(which: Mode): Result<Int> = runCatching {
        val root = when (which) {
            Mode.LOCAL -> localBaseUrl
            Mode.EXTERNAL -> externalBaseUrl
            Mode.AUTO -> baseUrl
        }.trimEnd('/')
        require(root.isNotBlank())

        val url = URL(root + basePath)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Authorization", "Bearer $token")
        }
        val code = conn.responseCode
        conn.disconnect()
        code
    }

    private fun post(which: Mode, path: String, body: String): Result<Int> = runCatching {
        val root = when (which) {
            Mode.LOCAL -> localBaseUrl
            Mode.EXTERNAL -> externalBaseUrl
            Mode.AUTO -> baseUrl
        }.trimEnd('/')
        require(root.isNotBlank())

        val url = URL(root + "/" + path.trimStart('/'))
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 8000
            readTimeout = 8000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Authorization", "Bearer $token")
        }

        OutputStreamWriter(conn.outputStream, StandardCharsets.UTF_8).use { it.write(body) }
        val code = conn.responseCode
        conn.disconnect()
        code
    }

    private fun normalize(value: String): String {
        val v = value.trim().removeSuffix("/")
        if (v.isBlank()) return ""
        return if (v.startsWith("http://", ignoreCase = true) ||
            v.startsWith("https://", ignoreCase = true)) {
            v
        } else {
            "http://$v"
        }
    }

    private fun normalizePath(value: String): String {
        val p = value.trim()
        if (p.isBlank()) return "/api"
        return "/" + p.trim('/').ifBlank { "api" }
    }
}
