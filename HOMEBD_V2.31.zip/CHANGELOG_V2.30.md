# HOMEBD V2.31 — REST LOCALIZADO

## Correção
- O diálogo de configuração REST passa a respeitar o idioma do Android.
- Android em inglês: título, descrição, campos e botões em inglês.
- Android em português: título, descrição, campos e botões em português.
- Mantida a lógica REST/Home Assistant.
- Mantido o caminho `/api`.
- Mantidos HV/BMS, UDS READ-ONLY, ícone e banner.

## Base
- HOMEBD V2.29.
