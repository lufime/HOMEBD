# HOMEBD V2.31 — CORREÇÃO DE COMPILAÇÃO

Base: HOMEBD V2.28.

- Corrigida a comparação inválida entre `HomeBdLanguage.Language` e `String`.
- A seleção PT/EN passa a usar o nome público devolvido por `HomeBdLanguage.name()`.
- Mantida a localização automática da interface.
- Mantida a estrutura completa da V2.28.
- REST/Home Assistant, HV/BMS, UDS READ-ONLY, ícone e banner mantidos.
