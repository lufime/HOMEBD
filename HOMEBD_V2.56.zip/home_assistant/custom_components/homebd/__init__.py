"""HOMEBD Home Assistant integration."""
from __future__ import annotations

import logging

import voluptuous as vol
from homeassistant.components import websocket_api
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback

from .const import DOMAIN, PLATFORMS, WS_PING_TYPE, WS_TYPE
from .sensor import HomeBdManager

_LOGGER = logging.getLogger(__name__)


async def async_setup(hass: HomeAssistant, config: dict) -> bool:
    """Set up the HOMEBD integration."""
    hass.data.setdefault(DOMAIN, {})
    websocket_api.async_register_command(hass, _ws_update)
    websocket_api.async_register_command(hass, _ws_ping)
    return True


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up a HOMEBD config entry."""
    manager = HomeBdManager(hass, entry)
    hass.data.setdefault(DOMAIN, {})[entry.entry_id] = manager
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload a HOMEBD config entry."""
    unload_ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unload_ok:
        hass.data.get(DOMAIN, {}).pop(entry.entry_id, None)
    return unload_ok


def _get_manager(hass: HomeAssistant) -> HomeBdManager | None:
    managers = hass.data.get(DOMAIN, {})
    return next(iter(managers.values()), None)


@websocket_api.websocket_command({
    vol.Required("type"): WS_TYPE,
    vol.Required("entity_id"): str,
    vol.Required("state"): vol.Any(str, int, float),
    vol.Optional("attributes", default={}): dict,
})
@websocket_api.async_response
async def _ws_update(hass: HomeAssistant, connection, msg: dict) -> None:
    """Receive a HOMEBD sensor update over the native HA WebSocket API."""
    manager = _get_manager(hass)
    if manager is None:
        connection.send_error(msg["id"], "not_configured", "HOMEBD integration is not configured")
        return
    entity_id = str(msg["entity_id"])
    if not entity_id.startswith("sensor.homebd_"):
        connection.send_error(msg["id"], "invalid_entity", "Only sensor.homebd_* entities are accepted")
        return
    await manager.async_update(entity_id, str(msg["state"]), msg.get("attributes", {}))
    connection.send_result(msg["id"], {"ok": True})


@websocket_api.websocket_command({vol.Required("type"): WS_PING_TYPE})
@callback
def _ws_ping(hass: HomeAssistant, connection, msg: dict) -> None:
    """Confirm that the HOMEBD integration is installed and configured."""
    if _get_manager(hass) is None:
        connection.send_error(msg["id"], "not_configured", "HOMEBD integration is not configured")
        return
    connection.send_result(msg["id"], {"ok": True})
