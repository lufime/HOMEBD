# HOMEBD V2.56

- Removido completamente o transporte REST da aplicação Android.
- Removida a classe `HomeBdRestBridge.kt` e toda a lógica de fallback HTTP para telemetria.
- Home Assistant passa a usar exclusivamente WebSocket persistente + Long-Lived Access Token.
- A integração HOMEBD passa a aceitar telemetria exclusivamente pelo comando `homebd/update`.
- Removido o endpoint HTTP `/api/homebd/update` da integração.
- Configuração Home Assistant simplificada para um único endereço + token.
- Mantido o namespace exclusivo `sensor.homebd_*`.
- Mantida a integração dinâmica com um único dispositivo HOMEBD.
- Atualizada a documentação para refletir a arquitetura WebSocket-only.
- Versão Android: 2.56.
- Versão da integração Home Assistant: 1.3.0.
- Desenvolvedor: lufime.
