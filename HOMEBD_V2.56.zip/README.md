# HOMEBD

Universal OBD-II / CAN diagnostics with a dedicated Home Assistant integration.

Current beta: V2.56.

Home Assistant communication uses a persistent native WebSocket connection authenticated with a Long-Lived Access Token.

Home Assistant entities are restricted to the HOMEBD namespace: `sensor.homebd_*`. The custom integration includes local branding under `home_assistant/custom_components/homebd/brand/`.

Developer: lufime
